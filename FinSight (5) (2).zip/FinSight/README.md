# FinSight — Financial Intelligence & Control Platform

FinSight is a production-grade financial intelligence, executive control, and evidence-grounded investigation platform engineered specifically for corporate finance leaders (Chief Financial Officers, VPs of Finance, Group Controllers, and Treasury Directors).

FinSight establishes an audited, deterministic financial truth from underlying general ledgers and subledgers, surfaces explainable performance variances and counterparty credit risks, and transforms critical financial anomalies into accountable, traceable remediation action plans.

---

## 1. Executive Overview & Problem FinSight Solves

Modern corporate finance teams operate across complex Enterprise Resource Planning (ERP) landscapes (e.g. SAP S/4HANA, ECC). In typical enterprises, executives face three acute challenges:
1. **The Trust Deficit**: Multiple disconnected spreadsheets, BI tools, and ad-hoc queries frequently report conflicting numbers for core KPIs such as Net Working Capital, Cash, and Days Sales Outstanding (DSO).
2. **The Explanation Gap**: When cash dips or gross margins deteriorate, traditional dashboards display red arrows but fail to isolate *why* the change happened, *which counterparties* drove the variance, or *what portion* is explainable by operations versus timing.
3. **The AI Hallucination Hazard**: Unconstrained generative AI models prompted directly with raw tabular text hallucinate numbers, invent non-existent customer invoices, and confuse correlation with causation.

### Core Architectural Promise: Strict Deterministic Grounding
**The financial engine calculates. The LLM explains.**
- All numerical metrics, ratio computations, aging schedules, and reconciliation ties are executed deterministically in code from canonical ERP journal records.
- Generative AI models are strictly constrained to synthesizing explanations from verified, deterministic tool outputs and evidence artifacts.
- Every claim cited by FinSight AI links directly to underlying subledger records (`EvidenceItem` tracking document IDs, invoices, customer numbers, and amounts in INR `₹`).

---

## 2. Architecture & Data Flow

FinSight follows a clean modular monolith architecture with unidirectional data flow:

```
Source Data (SAP BKPF/BSEG Journal & BSID/BSIK Open Items)
         ↓
Validation Gate (Double-entry balance, referential integrity)
         ↓
Normalization & Canonical Financial Model (Universal Journal)
         ↓
Deterministic Financial Engine (Dual-ledger integrity, trial balance)
         ↓
Reconciliation & Trust Foundation (24/24 invariants, Δ = ₹0.00)
         ↓
CFO Metrics & Governed Ratios (Cash, NWC, Current Ratio, DSO, CCC, DuPont)
         ↓
Performance & Attention Intelligence (Variance decomposition, counterparty risks)
         ↓
Evidence-Ready AI Investigation (Deterministic tools → Evidence collection)
         ↓
Case Governance & SQLite Remediation Lifecycle (Accountable action tracking)
```

---

## 3. Technology Stack

FinSight is deliberately architected as a lean, resilient, self-contained modular monolith:

| Layer | Technologies | Rationale / Exclusions |
| :--- | :--- | :--- |
| **Backend Framework** | Python 3.11+, FastAPI, Pydantic v2, Starlette | High-performance asynchronous API, strict type safety, auto-generated OpenAPI contracts |
| **Financial Engine** | Pure Python, Pandas, NumPy, SQLite | 100% deterministic, audit-grade reproducibility without floating-point drift |
| **Database & Persistence**| SQLite (`data/finsight_cases.db`, `data/finsight_auth.db`) | Zero-ops local transactional persistence for cases, actions, users, and audit logs. No external PostgreSQL, Redis, or Kafka required |
| **AI & Investigation** | Pluggable Providers (Deterministic Mock, Google Gemini, OpenAI) | Strict tool-first invocation; offline reproducible testing with zero hallucination risk |
| **Frontend Architecture**| Vanilla ES6+ Modules, Native HTML5 `<dialog>`, Pure CSS | Zero npm build step, zero bundling complexity, fast executive rendering, tabular figures |
| **Containerization** | Docker (Multi-stage Python 3.11-slim, unprivileged `appuser`) | Secure, minimal surface, healthcheck-monitored deployment |

---

## 4. Key Financial Metrics & Ratios

All metrics are dynamically calculated across monthly fiscal periods (authoritative active period: `2026-09`) in Indian Rupees (`₹` / INR):

### Executive KPI Row (Overview Dashboard)
1. **Cash & Equivalents**: Balance across operational, treasury, and money market bank accounts. Authoritative baseline: **₹813,750.00**.
2. **Net Working Capital (NWC)**: $\text{Current Assets} - \text{Current Liabilities}$. Authoritative baseline: **₹4,848,840.00** ($\text{CA: ₹7,284,590} - \text{CL: ₹2,435,750}$).
3. **Current Ratio**: $\frac{\text{Total Current Assets}}{\text{Total Current Liabilities}}$. Authoritative baseline: **2.99x**. Safe zero-denominator indicator when liabilities are zero.
4. **Days Sales Outstanding (DSO)**: $\frac{\text{Accounts Receivable}}{\text{Monthly Revenue}} \times 30\text{ days}$. Authoritative baseline: **60.1 days** ($\text{AR: ₹2,984,000} / \text{Revenue: ₹1,490,000} \times 30$).
5. **Cash Conversion Cycle (CCC)**: $\text{DSO} + \text{DIO} - \text{DPO}$. Authoritative baseline: **89.5 days** ($60.1 + 89.6 - 60.2$).
6. **Gross Margin %**: $\frac{\text{Gross Profit}}{\text{Revenue}} \times 100\%$. Authoritative baseline: **40.28%** ($\text{Gross Profit: ₹600,140} / \text{Revenue: ₹1,490,000}$).

### Extended Governance Metrics
- **Days Inventory Outstanding (DIO)**: $\frac{\text{Inventory}}{\text{COGS}} \times 30 = 89.6\text{ days}$.
- **Days Payables Outstanding (DPO)**: $\frac{\text{Accounts Payable}}{\text{COGS}} \times 30 = 60.2\text{ days}$.
- **DuPont 3-Way ROE Decomposition**: $\text{Net Profit Margin} \times \text{Asset Turnover} \times \text{Equity Multiplier}$.
- **Customer Concentration & Aging**: Granular aging buckets (Current, 1-30, 31-60, 61-90, 90+ days), identifying material delinquent exposures (e.g. Apex Retail Group past-due receivables).

---

## 5. SAP-Ready Integration Boundary

FinSight features a native integration boundary structured around SAP S/4HANA and ECC financial schemas:
- **Universal Journal (ACDOCA / BKPF / BSEG)**: Ingests header document records (`BKPF`) and line items (`BSEG`) preserving company codes, fiscal periods, posting keys, debit/credit flags, and GL accounts.
- **Customer Subledger Open Items (BSID / BSAD)**: Ingests open customer receivables (`BSID`) and cleared items (`BSAD`) for dynamic aging schedules and payment performance tracking.
- **Vendor Subledger Open Items (BSIK / BSAK)**: Ingests open vendor obligations (`BSIK`) for 7-day, 14-day, and 30-day payment projection models.
- **Configuration Boundary**: Controlled via environment variables (`SAP_BASE_URL`, `SAP_CLIENT`, `SAP_USERNAME`, `SAP_PASSWORD`, `SAP_MOCK_MODE`). When `SAP_MOCK_MODE=true`, FinSight runs off a deterministic synthetic generator reflecting realistic enterprise transaction distributions.

---

## 6. Canonical Financial Model & Invariants

All imported records are validated through strict data quality gates before reaching calculation layers:
1. **Double-Entry Invariant**: Every journal entry must satisfy $\sum \text{Debits} - \sum \text{Credits} = 0.00$.
2. **Referential Integrity**: Every subledger invoice line must reference a verified counterparty (`Customer` or `Vendor`) and an active General Ledger chart of accounts mapping.
3. **Period Continuity**: 12 consecutive historical fiscal periods (`2025-10` to `2026-09`) with monotonically advancing document sequence numbers.

---

## 7. Reconciliation & Trust Architecture

Trust is the foundation of FinSight. The Data Trust Engine executes **24 comprehensive invariant checks** on every data refresh:
- **Dual-Ledger Reconciliation**: Compares the General Ledger Accounts Receivable control account (`GL-120000`) against the sum of all individual open items in the customer subledger (`BSID`).
- **Payables Dual-Ledger Tie**: Compares Trade AP control (`GL-200000`) against the vendor open items ledger (`BSIK`).
- **Inventory Reconciliation**: Compares inventory asset account (`GL-130000`) against SKU-level valuation logs.
- **Authoritative Balance**: Invariant check confirms **₹0.00 unreconciled variance** ($\Delta = 0.00$) with a 100% passed tie rate.
- **Trust Drawer & Audit Matrix**: Accessible across all UI pages to inspect exact account ties, tie tolerance, and subledger reconciliation timestamps.

---

## 8. AI Grounding & Investigation Engine

The FinSight AI Investigator enables natural language executive inquiry while maintaining strict financial safety:
- **Workflow**:
  $$\text{Executive Inquiry} \longrightarrow \text{Intent Classification} \longrightarrow \text{Observable Plan} \longrightarrow \text{Deterministic Tool Execution} \longrightarrow \text{Evidence Collection} \longrightarrow \text{Grounded Brief}$$
- **Evidence States**: Every response returns an explicit evidence classification:
  - `SUPPORTED`: Fully substantiated by deterministic ledger data and subledger invoices.
  - `PARTIALLY_SUPPORTED`: Primary directional claim verified; secondary operational factors unmeasured in ledger.
  - `INSUFFICIENT_DATA`: Required evidence is not maintained in corporate accounting records (e.g. forward revenue forecast).
  - `OUT_OF_SCOPE`: Non-financial, speculative, or irrelevant inquiry.
- **Causality Safeguards**: Avoids converting correlation into causation. Cautious language is strictly enforced (e.g. *"Apex Retail Group contributed 78% of the observed overdue variance"* rather than *"Revenue dropped because Apex delayed payment"*).

---

## 9. Case Management & Action Tracking

FinSight turns financial insights into concrete operational remediation:
- **SQLite Persistence**: Cases and remediation actions are persisted in `data/finsight_cases.db`, ensuring all notes, action assignments, and status updates survive server restarts.
- **Governed State Machine**: Strict lifecycle state transitions:
  $$\text{OPEN} \longrightarrow \text{IN\_REVIEW} \longrightarrow \text{ACTION\_REQUIRED} \longrightarrow \text{RESOLVED} \longrightarrow \text{CLOSED}$$
- **Closed Case Immutability**: Closed cases are terminal and cannot be modified. Any attempt to alter metadata or append actions to a closed case is rejected with a validation error.
- **Non-Silent Closure Enforcement**: A case cannot be resolved or closed without documented `resolution_summary` and verified `resolution_evidence`.

---

## 10. Authentication & Role-Based Access Control (RBAC)

Enterprise access security is enforced at both the HTTP routing and business service layers:

| Role | Permissions |
| :--- | :--- |
| **`ADMIN`** | Full platform access, user management, configuration editing, case creation, updates, and closure signoff. |
| **`FINANCE_MANAGER`** | Financial analysis, AI investigations, case creation, remediation assignment, and case closure signoff. |
| **`FINANCE_ANALYST`** | Financial analysis, ledger exploration, AI investigations, case creation, and note appending. Attempting to close a case returns **403 Forbidden** (requires Manager/Admin signoff). |
| **Unauthenticated** | Any attempt to access protected mutation endpoints returns **401 Unauthorized**. |

---

## 11. Getting Started & Installation

### Local Python Setup
```bash
# 1. Clone repository and navigate to root
cd FinSight

# 2. Create and activate virtual environment
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 3. Install dependencies in editable mode
pip install -e .

# 4. Run the application
python main.py
# Application serves at http://localhost:8000
```

### Docker Deployment
```bash
# 1. Build production container image
docker build -t finsight:latest .

# 2. Run container with port mapping and volume persistence
docker run -d \
  --name finsight-app \
  -p 8000:8000 \
  -v $(pwd)/data:/app/data \
  finsight:latest

# 3. Check container health status
docker ps
curl http://localhost:8000/health
```

---

## 12. Configuration & Environment Variables

FinSight reads configuration from environment variables or a local `.env` file (see `.env.example`):

| Variable | Default | Description |
| :--- | :--- | :--- |
| `FINSIGHT_ENV` | `development` | Deployment environment (`production` or `development`) |
| `FINSIGHT_HOST` | `0.0.0.0` | Bind host address |
| `FINSIGHT_PORT` | `8000` | Bind port number |
| `FINSIGHT_CURRENCY` | `INR` | Standard corporate presentation currency |
| `FINSIGHT_CURRENCY_SYMBOL` | `₹` | Currency symbol prefix |
| `FINSIGHT_CORS_ORIGINS` | `http://localhost:8000,...` | Comma-separated list of allowed origins |
| `FINSIGHT_CASES_DB` | `data/finsight_cases.db`| SQLite database path for cases & actions |
| `SAP_MOCK_MODE` | `true` | Enable internal deterministic synthetic data generator |
| `SAP_BASE_URL` | `None` | Live SAP S/4HANA OData service endpoint |
| `GEMINI_API_KEY` | `None` | Optional Google Gemini API key for external LLM provider |
| `OPENAI_API_KEY` | `None` | Optional OpenAI API key for external LLM provider |

---

## 13. API Reference & Key Endpoints

| Method | Endpoint | Description | Auth Required |
| :--- | :--- | :--- | :--- |
| `GET` | `/health` | Container & system liveness check | Public |
| `POST`| `/api/auth/login` | Authenticate user credentials and issue Bearer token | Public |
| `GET` | `/api/auth/me` | Return active user profile and assigned role | Yes (All Roles) |
| `GET` | `/api/financial-summary` | 6 Core executive KPIs (Cash, NWC, CR, DSO, CCC, GM%) | Yes (All Roles) |
| `GET` | `/api/financials/dupont` | 3-way DuPont Return on Equity decomposition | Yes (All Roles) |
| `GET` | `/api/forecast/cash` | 30/60/90-day scenario-based cash projections | Yes (All Roles) |
| `POST`| `/api/investigate` | Full AI investigation plan, tool executions, and findings | Yes (All Roles) |
| `POST`| `/api/ai/ask` | User-facing natural language Q&A with evidence state | Yes (All Roles) |
| `GET` | `/api/cases` | List financial remediation cases with filters | Yes (All Roles) |
| `POST`| `/api/cases` | Create a new remediation case | Yes (Analyst+) |
| `PATCH`| `/api/cases/{id}` | Update case metadata, status, or append note | Yes (Analyst+) |
| `POST`| `/api/cases/{id}/close` | Formally close case with verified evidence | Yes (Manager+) |
| `POST`| `/api/refresh` | Reconcile dual-ledgers and recompute all metrics | Yes (Manager+) |

---

## 14. Testing & Verification Suite

FinSight includes comprehensive unit, integration, invariant, and failure test suites:

```bash
# Run complete test suite with coverage
python -m pytest

# Run Master Phase 1 regression verification
python -m pytest tests/test_master_phase1.py

# Run Master Phase 2 contract, persistence, and security verification
python -m pytest tests/test_master_phase2.py

# Run standalone financial reconciliation audit
python scripts/audit_reconciliation.py

# Run Phase 4 invariant checks
python scripts/validate_phase4.py
```

---

## 15. Deployment & Production Readiness

- **Security Posture**: Unprivileged container user (`appuser` UID 1001), no root execution, sensitive secrets (`API keys`, `SAP passwords`) masked in `/api/config`, explicit production CORS rules preventing unauthorized cross-origin requests.
- **Resource Footprint**: Minimal CPU and RAM utilization (~120MB RSS) with fast cold-start (< 1.5 seconds).
- **Audit Compliance**: All financial mutations and state transitions produce immutable, append-only `CaseAuditEvent` log entries recording actor, timestamp, and details.
