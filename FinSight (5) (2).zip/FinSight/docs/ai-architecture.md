# FinSight — AI Investigation Architecture & Tool Calling Interface

## 1. Core AI Architecture & Grounding Philosophy

FinSight is designed as an agentic financial intelligence platform. However, the system fundamentally enforces strict **financial grounding and separation of concerns**:
- **The Financial Engine Calculates.**
- **The Financial Intelligence Engine Decomposes & Detects.**
- **The Financial Attention Engine Prioritizes.**
- **The LLM Explains & Synthesizes.**

```mermaid
flowchart TD
    UserQuery["CFO Question: 'Why did cash decrease?'"]
    Investigator["InvestigationService"]
    IntentClassifier["Intent Classifier"]
    PlanBuilder["Investigation Plan Builder"]

    subgraph Deterministic Tool Calling
        T1["compare_periods('cash_position')"]
        T2["get_receivables(overdue_only=True)"]
        T3["get_upcoming_payments(horizon_days=7)"]
        T4["find_metric_drivers('cash_position')"]
    end

    subgraph Grounded Tool Execution
        Engine["Canonical Financial Engine"]
        Intel["Financial Intelligence Service"]
    end

    subgraph Evidence & Findings
        Findings["Structured Verified Findings"]
        Evidence["Evidence Items (Invoices, GL Lines)"]
    end

    subgraph LLM Synthesis & Safety Guardrails
        SafetyPrompt["Financial Safety Guardrails"]
        LLMProvider["LLMProvider (Mock / Gemini / OpenAI)"]
        OutputBrief["Grounded Executive Response"]
    end

    UserQuery --> Investigator
    Investigator --> IntentClassifier
    IntentClassifier --> PlanBuilder
    PlanBuilder --> T1 & T2 & T3 & T4
    T1 & T2 & T3 & T4 --> Engine & Intel
    Engine & Intel --> Findings & Evidence
    Findings & Evidence --> LLMProvider
    SafetyPrompt --> LLMProvider
    LLMProvider --> OutputBrief
```

---

## 2. Strict Financial Safety & Grounding Guardrails

The LLM is governed by mandatory system instructions (`FINANCIAL_SAFETY_SYSTEM_PROMPT`):
1. **Never Calculate**: The LLM is strictly prohibited from calculating or computing financial figures.
2. **Never Fabricate**: No numbers, customer names, invoices, or dates may be invented.
3. **Traceability**: Every numerical claim in the generated answer must be traceable directly to tool outputs.
4. **Insufficient Data Handling**: If evidence is missing or inconclusive, the LLM must explicitly state that data is insufficient.
5. **Cautious Causal Phrasing**: Prohibits unsupported causal assertions; requires phrases like *"associated with"*, *"contributed to"*, and *"largest observed driver"*.
6. **No Fake Policies or Records**: Prohibits fabricating internal policies, SAP records, or accounting standard interpretations.

---

## 3. Investigation Workflow

### Step 1: Question & Intent Interpretation
Natural language questions are mapped to explicit analytical intents:
- *"Why did cash decrease?"* $\rightarrow$ `CASH_DECREASE_INVESTIGATION`
- *"Why is DSO increasing?"* $\rightarrow$ `DSO_INCREASE_INVESTIGATION`
- *"Which customers are driving overdue AR?"* $\rightarrow$ `OVERDUE_AR_DRIVERS`
- *"Where did gross margin decline?"* $\rightarrow$ `MARGIN_DECLINE_INVESTIGATION`
- *"What payments are due in the next 7 days?"* $\rightarrow$ `UPCOMING_PAYMENTS_INQUIRY`
- *"Which products are hurting profitability?"* $\rightarrow$ `PRODUCT_PROFITABILITY_ISSUE`
- *"Why is inventory increasing?"* $\rightarrow$ `INVENTORY_BUILDUP_INVESTIGATION`
- *"Where is our biggest financial exposure?"* $\rightarrow$ `BIGGEST_EXPOSURE_INVESTIGATION`
- *"What changed this month?"* $\rightarrow$ `PERIOD_CHANGE_OVERVIEW`

### Step 2: Structured Plan Creation
The investigator generates a plan containing discrete, inspectable steps before calling tools.
Example Plan for *"Why did cash decrease?"*:
1. `compare_periods(metric_name="cash_position", period_a="2026-09", period_b="2026-08")`
2. `get_receivables(overdue_only=True)`
3. `get_upcoming_payments(horizon_days=7)`
4. `compare_periods(metric_name="inventory_value", period_a="2026-09", period_b="2026-08")`
5. `find_metric_drivers(metric_name="cash_position", current_period="2026-09", previous_period="2026-08")`

### Step 3: Tool Execution & Evidence Collection
Each step is dispatched to the corresponding `AIToolsService` contract or `FinancialIntelligenceService`. Verified numbers, findings, and `EvidenceItem` audit objects are assembled.

### Step 4: Grounded Explanation Generation
The provider abstraction formats a structured response:
```json
{
  "answer": "Cash decreased by $433,000 (-34.7%) versus the previous period, closing at $813,750 compared to $1,246,750. The largest observed contributor was imminent accounts payable obligations, followed by receivables buildup & overdue aging...",
  "key_findings": [
    "cash_position moved from $1,246,750 to $813,750 (-433,000.0, -34.7%)",
    "Payment of $816,000.00 due to Titan Semiconductor Ltd in 5 days",
    "Payment of $408,000.00 due to Precision Metalworks in 0 days"
  ],
  "drivers": [
    "Imminent Accounts Payable Obligations",
    "Receivables Buildup & Overdue Aging",
    "Inventory Cash Absorption"
  ],
  "evidence": [
    {
      "source_type": "AP_OPEN_ITEM",
      "source_id": "INV-AP-70067",
      "entity": "Titan Semiconductor Ltd",
      "metric": "upcoming_payables_7d",
      "value": 816000.0,
      "period": "2026-09",
      "description": "Upcoming AP obligation INV-AP-70067 due to Titan Semiconductor Ltd in 5 days"
    }
  ],
  "suggested_next_steps": [
    "Review upcoming 7-day vendor disbursements and prioritize critical vendor commitments.",
    "Accelerate collections outreach for delinquent customer accounts with overdue balances > 60 days.",
    "Review inventory reorder policies to curb further working capital absorption."
  ]
}
```

---

## 4. LLM Provider Abstraction

The `llm_provider.py` module defines a provider interface:
- **`MockLLMProvider`**: Deterministic, offline synthesizer used in automated testing and development. Generates grounded explanations directly from verified tool outputs without external network calls or API keys.
- **`RealLLMProvider`**: Connects to Google Gemini or OpenAI when `GEMINI_API_KEY` or `OPENAI_API_KEY` is present. Automatically falls back to deterministic mock if API calls fail or timeout.
- **`get_llm_provider()`**: Factory function selecting provider from environment configuration.

---

## 5. RAG Policy & Roadmap

FinSight strictly separates structured transactional data from unstructured textual documentation:
- **Transactional queries $\rightarrow$ Deterministic Tools**: Questions about amounts, balances, due dates, margins, and customers are handled exclusively by financial tools.
- **Policy queries (Future Phase) $\rightarrow$ Vector RAG**: Retrieval-Augmented Generation will be introduced in a future phase specifically for corporate finance documents, including:
  - Credit & Collection Policies and bad debt write-off guidelines.
  - Revenue Recognition policies (ASC 606 / IFRS 15).
  - Delegation of Authority (DoA) matrices.
  - Standard Operating Procedures (SOPs).

---

## 6. Investigation-to-Action / Case Creation Workflow

FinSight bridges the gap between passive AI analysis and active financial governance. When an executive or controller completes an investigation, they can immediately convert findings into an accountable remediation workflow:

```mermaid
sequenceDiagram
    autonumber
    actor CFO as Finance Executive
    participant UI as FinSight Investigate UI
    participant Inv as InvestigationService
    participant Tools as AIToolsService
    participant Cases as CasesService

    CFO->>UI: Ask: "Which customers are driving overdue AR?"
    UI->>Inv: POST /api/investigate
    Inv->>Tools: get_receivables(overdue_only=True)
    Tools-->>Inv: Verified AR data & EvidenceItems
    Inv-->>UI: Grounded Brief, Top Drivers, Evidence Items
    UI->>CFO: Display Answer + "Escalate to Case" Action
    CFO->>UI: Click "Escalate to Case"
    UI->>Cases: POST /api/cases (pre-filled with findings & evidence_refs)
    Cases-->>UI: Case created (e.g. CASE-2026-004)
    UI->>CFO: Transition to Cases view with linked audit trail
```

### Safety Rules for Case Creation:
1. **Evidence Binding**: Every case created from an investigation preserves the exact `source_id` references (e.g. `INV-AR-50065`, `INV-AR-50073`, `INV-AR-50081`).
2. **Deterministic Exposure**: The case's `financial_exposure` is automatically drawn from the verified tool output (e.g. `$1,044,000.00`), never estimated by the LLM.
3. **Audit Immutability**: Appended notes record the author, timestamp, and audit trail of changes.

---

## 7. Audit Consistency Resolution & Grounding Guardrails

During Phase 2 validation, an inconsistency was identified where one AI response reported customer Apex Retail Group as driving only $189,000 of overdue AR, while the underlying financial engine reported total overdue AR of $1,044,000 across 3 open delinquent invoices.

### Root Cause Analysis:
- `INV-AR-50065`: $189,000 (68 days overdue)
- `INV-AR-50073`: $425,000 (39 days overdue)
- `INV-AR-50081`: $430,000 (15 days overdue)
- The subledger query returned all 3 delinquent invoices. However, when summarizing the top customer overdue driver, earlier logic grabbed the single oldest invoice (`$189,000`) rather than aggregating all delinquent open items for that customer (`$1,044,000`).

### Resolution & Prevention:
1. **Aggregated Customer Exposure**:
   In `src/finsight/services/llm_provider.py` and `src/finsight/services/investigation_service.py`, overdue amounts are aggregated across all open delinquent subledger items grouped by counterparty. Apex Retail Group now consistently reports:
   - Total Open AR: **$1,479,000.00**
   - Overdue AR: **$1,044,000.00** across 3 overdue invoices (100.0% of company-wide overdue AR).
2. **Strict Cross-Layer Regression Verification**:
   The test suite `tests/test_evidence_consistency.py` asserts that the exact identical value of `$1,044,000.00` is returned by:
   - `FinancialEngine`
   - `AIToolsService.get_customer_exposure()`
   - `AIToolsService.get_receivables(overdue_only=True)`
   - `FinancialIntelligenceService.detect_changes()`
   - `FinancialAttentionService.generate_attention_items()`
   - `InvestigationService.investigate("Which customers are driving overdue AR?")`
   - Generated `EvidenceItem` records and LLM briefing text.

---

## 8. Phase 5 — Governed Finance Knowledge & Policy Intelligence

Phase 5 elevates FinSight AI to answer enterprise questions requiring **both**:
1. **Deterministic Financial Facts** (from ledger tools)
2. **Governing Policies, Controls & SOPs** (from the internal knowledge base)

### Key Architectural Enhancements
- **Governed Knowledge Model**: Enterprise policies, SOPs, control thresholds, and escalation rules modeled in [`finsight.models.knowledge`](file:///C:/Users/samarth/OneDrive%20-%20Abhiyanta%20India%20Solutions%20Pvt%20Ltd/Pictures/FinSight/src/finsight/models/knowledge.py).
- **Deterministic Local Retriever**: Inverted index BM25 search with markdown section chunking, section boosting, substantive token matching, and strict effective-date boundary filtering (`LocalKnowledgeRetriever`). Zero external database dependencies.
- **Evidence Separation**: Strict demarcation between `financial_evidence` (invoices, GL lines, cash accounts) and `policy_evidence` (policy sections, document excerpts, control thresholds).
- **6-Part Brief Contract**: Executive Finding, Financial Evidence, Policy/Control Context, Assessment, Suggested Next Steps, Evidence Sources.
- **Strict Guardrails**: Prevents policy hallucination for unindexed policies (e.g. T&E), blocks operational actions on expired documents, detects missing financial data, and rejects unauthorized actions contradicting policy (e.g. shipments to overdue accounts).

See [`docs/knowledge-architecture.md`](file:///C:/Users/samarth/OneDrive%20-%20Abhiyanta%20India%20Solutions%20Pvt%20Ltd/Pictures/FinSight/docs/knowledge-architecture.md) for full architectural documentation.

