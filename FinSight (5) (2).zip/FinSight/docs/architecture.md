# FinSight — System Architecture Specification

## 1. Architectural Philosophy

FinSight is built on the tenet that **financial truth is deterministic, verifiable, and auditable**. In enterprise finance, numbers must never be hallucinated, approximated by statistical models, or estimated via language model text completion.

### The Separation of Concerns
1. **Financial Processing Layer (Deterministic Python)**:
   - Ingests double-entry journal entries and subledger transactions.
   - Enforces referential integrity and accounting identities (Assets = Liabilities + Equity, Debits = Credits).
   - Calculates key metrics (DSO, DPO, DIO, Cash, Net Working Capital, Gross Margin) with explicit mathematical definitions.
   - Produces structured evidence packages.
2. **Financial Intelligence & Attention Layer**:
   - Detects material changes, multi-period trajectories, and statistical anomalies.
   - Decomposes variances into quantified, attributed drivers.
   - Ranks business attention items using explainable multi-factor scoring.
3. **AI Investigation Layer**:
   - Classifies query intents and formulates step-by-step investigation plans.
   - Dispatches plan steps strictly to deterministic tool contracts.
   - Collects evidence items ("Follow the Money").
   - Synthesizes grounded, executive-level financial briefings without calculating numbers.

---

## 2. End-to-End System Architecture

```mermaid
flowchart TD
    subgraph Data Sources
        MockAdapter["Mock Financial Adapter (seed=42)"]
        SAPAdapter["Future SAP OData / CDS Adapter"]
    end

    subgraph Abstraction & Canonical Models
        BaseAdapter["BaseFinancialAdapter Interface"]
        Entities["Company, Customer, Vendor, Product, AccountMapping, JournalEntry, AR/AP Open Items"]
    end

    subgraph Governance & Foundation
        DQService["DataQualityService (Integrity, Balance, Blockers)"]
        Engine["FinancialEngine (GL & Subledger Aggregator)"]
        Metrics["MetricService (Foundational Metrics, Comparisons, CCC)"]
    end

    subgraph Layer 1: Financial Intelligence
        Intel["FinancialIntelligenceService"]
        Changes["Period Change & Materiality Engine"]
        Trends["Historical Trend Trajectory"]
        Anomalies["Deterministic Anomaly Detector"]
        Drivers["Metric Driver Decomposition"]
        Entity360["Customer & Product Intelligence"]
    end

    subgraph Layer 2: Financial Attention
        Attn["FinancialAttentionService"]
        Ranker["Explainable Attention Ranking Engine (0-100)"]
    end

    subgraph Layer 3: AI Investigator
        Inv["InvestigationService"]
        Planner["Intent & Investigation Planner"]
        AITools["AIToolsService (11 Deterministic Tool Contracts)"]
        LLMProvider["LLMProvider Abstraction (Mock / Gemini / OpenAI)"]
    end

    subgraph Layer 4: Financial Cases & Governance
        Cases["CasesService (Remediation Tracking & Audited Notes)"]
    end

    subgraph API & Static Serving
        FastAPI["FastAPI App (REST Endpoints & Static Files)"]
    end

    subgraph Executive Presentation Layer
        UI["FinSight Executive Workspace (Vanilla ES6 / CSS3)"]
        CC["Command Center (KPIs, Cash Trend, Attention)"]
        Money["Money (Cash, AR Aging, AP Obligations)"]
        Perf["Performance (P&L, Margins, Customer Matrix)"]
        InvestView["Investigate (AI Tool Trace & Follow-the-Money)"]
        CasesView["Cases (Audit Threads & Remediation)"]
        Drawer["Slide-Over Evidence Drawer (<dialog>)"]
    end

    MockAdapter --> BaseAdapter
    SAPAdapter -.-> BaseAdapter
    BaseAdapter --> Entities
    Entities --> DQService
    DQService --> Engine
    Engine --> Metrics
    Engine & Metrics --> Intel
    Intel --> Changes & Trends & Anomalies & Drivers & Entity360
    Intel --> Attn
    Attn --> Ranker
    Inv --> Planner
    Planner --> AITools
    AITools --> Metrics & Engine & Intel
    AITools --> Inv
    Inv --> LLMProvider
    Attn & Inv -.->|Escalate Issue| Cases
    Metrics & Intel & Attn & Inv & Cases --> FastAPI
    FastAPI --> UI
    UI --> CC & Money & Perf & InvestView & CasesView & Drawer
```

---

## 3. Layer Breakdown

### Layer 1: Financial Intelligence (`FinancialIntelligenceService`)
- **Period Change & Materiality**: Compares current period vs prior period across 14 standard metrics. Materiality is determined by absolute and relative thresholds tailored to each financial concept (e.g. DSO $\ge 5$ days or $\ge 12\%$; Gross Margin $\ge 1.5$ percentage points; monetary metrics $\ge \$150,000$ or $\ge 15\%$).
- **Trend Detection**: Tracks trailing directional persistence over multiple periods, identifying patterns: `PERSISTENT_INCREASE`, `PERSISTENT_DECREASE`, `ACCELERATION`, `DETERIORATION`, `RECOVERY`, and `STABLE`.
- **Deterministic Anomaly Detection**: Calculates moving historical baseline averages and standard deviations over historical periods. Flags statistical outliers exceeding configurable monetary thresholds.
- **Metric Driver Decomposition**: Explains variances for Cash, Gross Margin %, AR/DSO, and Inventory/DIO using cautious association phrasing.
- **Customer & Product Intelligence**: Builds 360-degree profiles for customers and products, calculating revenue, margin, overdue exposure, and tagging behavioral anomalies.

### Layer 2: Financial Attention (`FinancialAttentionService`)
- Converts intelligence findings into prioritized attention items with standardized types: `CASH_PRESSURE`, `AR_DETERIORATION`, `CUSTOMER_PAYMENT_DETERIORATION`, `INVENTORY_BUILDUP`, `MARGIN_COMPRESSION`, `HIGH_REVENUE_LOW_MARGIN`, `AP_PRESSURE`, `CUSTOMER_CONCENTRATION`, `MATERIAL_FINANCIAL_CHANGE`, `DATA_QUALITY_ISSUE`.
- **Ranking Formula**:
  $$\text{Priority Score} = \text{Base Severity Weight (0-40)} + \text{Financial Impact Score (0-30)} + \text{Concentration/Aging Multipliers (0-20)} + \text{Persistence Bonus (0-10)}$$
- Generates transparent, human-readable rationale for executive visibility.

### Layer 3: FinSight AI Investigator (`InvestigationService`)
- Interprets user intent from natural language questions.
- Formulates an observable multi-step investigation plan targeting specific deterministic tools.
- Executes tools sequentially, populating step outcomes and evidence links.
- Employs an LLM provider abstraction where the LLM is restricted to formatting, summarizing, and recommending next steps based on verified facts.

---

## 4. Evidence Model & "Follow the Money"

FinSight implements structured audit trails through the `EvidenceItem` model:
- `source_type`: `AR_OPEN_ITEM`, `AP_OPEN_ITEM`, `JOURNAL_ENTRY`, `CUSTOMER_RECORD`, `VENDOR_RECORD`, `PRODUCT_RECORD`
- `source_id`: Unique identifier (e.g. `INV-AR-50065`, `JE-2026-09-001`)
- `entity`: Associated counterparty (e.g. `Apex Retail Group`)
- `metric`: Specific metric supported
- `value`: Verified dollar or quantitative value
- `period`: Fiscal period
- `description`: Factual audit statement
- `metadata`: Subledger dates, days overdue, and terms

This allows UI clients to drill down from:
$$\text{Executive Brief} \rightarrow \text{Attention Item} \rightarrow \text{Driver} \rightarrow \text{Counterparty} \rightarrow \text{Subledger Document / Invoice}$$

---

## 5. Layer 4: Financial Cases & Action Layer (`CasesService`)

While FinSight AI operates in a strictly read-only capacity, finance teams need an actionable remediation workflow to assign, track, and resolve surfaced anomalies and investigation findings.

- **Data Model (`FinancialCase`)**:
  - `case_id`: Unique identifier (e.g. `CASE-2026-001`)
  - `title`, `description`, `category` (`COLLECTIONS`, `DISBURSEMENTS`, `INVENTORY`, `PROFITABILITY`, `AUDIT`)
  - `severity`: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW`
  - `status`: `OPEN`, `IN_PROGRESS`, `PENDING_REVIEW`, `RESOLVED`, `CLOSED`
  - `financial_exposure`: Quantified monetary balance tied to the issue
  - `assigned_to`: Responsible finance team member
  - `due_date`, `created_at`, `updated_at`
  - `notes`: Chronological audit thread (`CaseNote`) recording comments, updates, and mitigation steps
  - `evidence_refs`: Array of linked `source_id` keys connecting the case back to deterministic ERP subledger items
  - `source_investigation`: Originating question or attention item trigger

- **Workflow Endpoints**:
  - `GET /api/cases`: Filter cases by status, severity, category, or search term
  - `POST /api/cases`: Create case directly from UI modal or auto-escalate from Attention items / Investigate findings
  - `GET /api/cases/{case_id}`: Fetch complete case details including audit history and linked evidence
  - `PATCH /api/cases/{case_id}`: Update status, severity, assignee, due date, or append new audit notes

---

## 6. Executive Presentation Layer Architecture

FinSight adopts a modern, lightweight, buildless architecture for its web frontend:

- **Technology Stack**:
  - **Vanilla ECMAScript Modules (ES6+)**: Pure browser-native `import`/`export` with zero bundlers (Vite, Webpack) or complex node tooling.
  - **Enterprise CSS Design System (`css/main.css`)**:
    - Dark Navy primary UI (`#0f172a`, `#1e3a8a`, `#2563eb`), neutral slate borders (`#e2e8f0`), restrained semantic badges (green, amber, red).
    - Tabular figures (`font-variant-numeric: tabular-nums;`) for reliable monetary alignment across all financial grids.
    - Minimalist, high information density layout inspired by enterprise terminals.
  - **Native HTML5 `<dialog>` Slide-Over Evidence Drawer**:
    - Accessible, light-dismiss modal drawer (`#evidence-drawer`) supporting subledger document inspection without breaking executive workflow context.
  - **Zero Heavy Graphing Libraries**:
    - Clean inline SVG path rendering for multi-period cash trajectories (`CashTrendChart`), minimizing bundle bloat and ensuring sub-millisecond initial paint.

- **Primary Navigation Structure**:
  1. **COMMAND CENTER**: Executive landing page summarizing 6 foundational KPIs (Cash, NWC, DSO, CCC, AR, Gross Margin %), prioritized attention items, 12-month cash trendline, and month-over-month change matrix.
  2. **MONEY**: Liquidity, working capital, and cash conversion tracking across 3 detailed sub-views:
     - *Cash*: Bank ledger account distribution and period movements.
     - *Receivables*: Aging brackets (Current, 1-30, 31-60, 61-90, 90+ days), delinquent exposures, and customer risk profiles.
     - *Payables*: 7-day upcoming disbursement schedule and vendor concentration.
  3. **PERFORMANCE**: Operational profitability analytics:
     - P&L variance breakdown (Revenue, COGS, Gross Margin).
     - Customer revenue vs. margin quadrant matrix.
     - Product group profitability analysis and margin compression alerts.
  4. **INVESTIGATE**: Autonomous AI Investigation Console:
     - Natural language query box with 10 standard CFO quick-inquiry chips.
     - Real-time observable multi-step execution plan tracker.
     - Raw deterministic tool call inspector (JSON inputs and outputs).
     - Structured findings, quantified drivers, and prescriptive next steps.
     - "Follow the Money" verified subledger evidence table with instant "Escalate to Case" action.
  5. **CASES**: Centralized financial issue management table with status filters, quick-search, detailed case viewer, and audit note appending.
  6. **DATA STATUS**: Data quality telemetry, ERP sync status, referential integrity check (100%), and calculation blocker count (0).
  7. **SETTINGS**: Configurable deterministic materiality thresholds, anomaly sigma tolerances, and AI safety governance protocol display.

