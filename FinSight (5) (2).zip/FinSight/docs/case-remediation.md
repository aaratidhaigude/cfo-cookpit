# FinSight Phase 7: Financial Case Remediation Workflow

## 1. Overview & Policy Foundation

FinSight's **Case Remediation Workflow** enforces strict corporate governance under **`CASE-SOP-001` (Standard Operating Procedure: Financial Incident Remediation)**. It ensures that every material financial anomaly or policy control breach is managed through an accountable, auditable, non-silent lifecycle.

---

## 2. Extended Lifecycle States

Cases transition through seven explicit lifecycle states:

```
[DETECTED] ──► [INVESTIGATING] ──► [OPEN] ──► [IN_PROGRESS] ──► [PENDING_REVIEW] ──► [RESOLVED] ──► [CLOSED]
```

| Lifecycle State | Description | Permitted Next States |
|---|---|---|
| `DETECTED` | Automated trigger created by Attention or Control Engine | `INVESTIGATING`, `OPEN` |
| `INVESTIGATING` | AI investigator or analyst examining root cause | `OPEN`, `IN_PROGRESS` |
| `OPEN` | Formally registered remediation case with assigned owner | `IN_PROGRESS`, `PENDING_REVIEW` |
| `IN_PROGRESS` | Remediation action items being executed by operations | `PENDING_REVIEW`, `RESOLVED` |
| `PENDING_REVIEW` | Actions completed, awaiting executive sign-off | `RESOLVED`, `IN_PROGRESS` |
| `RESOLVED` | Remediation targets verified and confirmed | `CLOSED`, `IN_PROGRESS` |
| `CLOSED` | Formally archived with documented evidence and reviewer approval | *Terminal State* |

---

## 3. Remediation Action Plan Model

Each case maintains a structured, trackable remediation action plan:

```python
class RemediationAction(BaseModel):
    action_id: str          # ACT-202610-001
    action: str             # Specific operational action
    owner: str              # Responsible functional lead
    due_date: str           # Target completion date (YYYY-MM-DD)
    status: str             # OPEN, IN_PROGRESS, COMPLETED, BLOCKED
    evidence: Optional[str] # Audit verification (wire ref, contract #)
    created_at: str         # ISO timestamp
    completed_at: Optional[str]
```

Actions can be added dynamically via `POST /api/cases/{case_id}/remediation-action`.

---

## 4. Immutable Audit Trail

FinSight enforces strict append-only audit logging:
- Every state transition, action creation, note, or resolution creates an immutable `CaseAuditEvent`.
- Each event records `event_id`, `timestamp`, `event_type`, `actor`, `description`, and `details`.
- No historical entry can be updated or deleted.
- Accessible via `GET /api/cases/{case_id}/audit-trail`.

---

## 5. Enforced Non-Silent Closure

Under `CASE-SOP-001`, **silent closure of financial cases is strictly prohibited**:
- Moving a case to `CLOSED` via generic PATCH or status change without justification is blocked and raises a `ValueError` (HTTP 400).
- Formal closure requires `POST /api/cases/{case_id}/close` with:
  1. `resolution_summary`: Detailed narrative of how financial risk was mitigated.
  2. `resolution_evidence`: Objective verification (e.g. `Wire confirmation #BK-88402 & Legal Agreement #LGL-2026-094`).
  3. `reviewer`: Authorized executive sign-off (e.g. `VP Commercial Finance` or `CFO`).
- On successful validation, a `CLOSED` audit event is permanently logged with the reviewer's identity.

---

## 6. Executive UI: 7-Section Presentation

The Case Details view in the FinSight web interface renders seven structured sections:
1. **Exposure Header:** Case ID, Title, Status badge, Severity badge, Financial Exposure ($), Assignee, Due Date.
2. **Why This Case Exists:** Plain-language executive narrative explaining the financial anomaly or trigger.
3. **Governing Control Assessment:** Linked control ID, policy reference, observed value vs threshold, breach severity.
4. **Financial Truth Evidence:** Grounded metrics, GL accounts, invoices, and counterparties from deterministic engines.
5. **Governing Policy Evidence:** Document references, section numbers, and exact policy clause text.
6. **Remediation Action Items Table:** Action descriptions, owners, due dates, statuses, and evidence, with inline creation form.
7. **Activity Timeline & Audit Trail:** Chronological immutable history of all case events, with quick-pick template justification chips and note posting.
