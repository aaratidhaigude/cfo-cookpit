# FinSight Phase 8: Cash Outlook & Scenario Intelligence

## 1. Architectural Philosophy

FinSight's **Cash Outlook & Scenario Intelligence Engine** rejects black-box ML or speculative curve-fitting in favor of **deterministic, subledger-grounded cash forecasting**. Projections are derived directly from:
- Actual open Accounts Receivable invoices and customer payment velocities.
- Verified Accounts Payable aging schedules and contractual due dates.
- Fixed baseline operating expense disbursements ($4,000/day = $120,000/month).
- Governing liquidity policy thresholds under **`LIQ-CTRL-001`**.

---

## 2. Multi-Scenario Modeling

FinSight models three auditable operational scenarios across 30, 60, and 90-day horizons:

| Scenario | AR Collection Assumptions | AP Disbursement Assumptions | 30-Day Projected Cash |
|---|---|---|---|
| **`BASE`** | 55% current AR in days 1-30; 30% overdue AR (Apex restructuring tranche $313.2k) | All 7d obligations settled; remainder in days 8-45 | **$447,612.51** |
| **`CONSERVATIVE`** | 45% current AR in days 1-30; **0% from Apex Retail Group** (total default) | Full contractual AP settled as scheduled | **-$52,187.49** (Deficit) |
| **`IMPROVED_COLLECTIONS`** | 70% current AR in days 1-30; 60% overdue AR ($626.4k accelerated collection) | AP negotiated to standard vendor terms | **$1,156,212.51** (Surplus) |

---

## 3. Weekly Trajectory & Week-1 Liquidity Dip

The model generates discrete weekly points tracking running liquid cash:

### September 2026 30-Day Base Forecast:
- **Starting Cash (Day 0):** **$813,750.00**
- **Week 1 (Days 1–7):**
  - Expected Collections: +$207,030.00
  - Maturing 7-Day AP: **-$1,377,000.00**
  - Weekly OPEX Outflow: -$30,000.00
  - Net Flow: **-$1,199,970.00**
  - **Ending Cash (Dip):** **-$386,220.00**
  - **7-Day LCR Ratio:** **0.59x**
- **Week 2 (Days 8–14):** Ending Cash -$108,275.83
- **Week 3 (Days 15–21):** Ending Cash +$169,668.34
- **Week 4 (Days 22–30):** Ending Cash **+$447,612.51**

---

## 4. Policy-Governed Liquidity Indicator

The engine continuously evaluates rolling liquidity against **`LIQ-CTRL-001` (Corporate Liquidity & Cash Runway Policy)**:
- **Emergency Floor:** `0.75x` 7-day LCR.
- **Minimum Safe Target:** `1.00x` 7-day LCR.
- **Target Policy Buffer:** `1.25x` 7-day LCR.

### Detected Invariant Breach:
Because starting cash ($813,750) covers only 59% of maturing 7-day vendor disbursements ($1,377,000), **`CONTROL-LIQ-001` triggers a CRITICAL BREACH**, highlighting the need for immediate treasury intervention (e.g. drawing credit facilities or executing Case `CASE-2026-002`).

---

## 5. AI Tool #13: `get_cash_forecast`

Exposed via `AIToolsService.get_cash_forecast` and `/api/forecast/cash`:
- **Parameters:**
  - `horizon_days`: `30`, `60`, or `90`
  - `scenario`: `BASE`, `CONSERVATIVE`, `IMPROVED_COLLECTIONS`
  - `period`: fiscal period (default latest)
- **Output:** Complete `CashForecast` model with bounds, weekly projections, and liquidity indicators.

---

## 6. AI Cash Outlook Investigation Dispatch

When users ask questions regarding future liquidity, runway, or scenario projections (e.g., *"What is our cash outlook and 30-day liquidity forecast under the base scenario?"*):
1. **Intent Interpretation:** Classifies as `CASH_OUTLOOK_INVESTIGATION`.
2. **Multi-Step Plan Execution:** Dispatches `get_cash_position`, `get_cash_forecast`, `get_upcoming_payments`, `get_receivables`, and `search_finance_knowledge`.
3. **Synthesis:** Returns an executive briefing explaining:
   - Current liquidity baseline ($813,750).
   - Acute Week-1 maturing AP squeeze ($1,377,000 due vs $813,750 cash, 0.59x LCR).
   - End-of-horizon scenario projections ($447.6k Base vs -$52.2k Conservative vs $1.156M Improved).
   - Operational recommendations to remediate the Week-1 deficit.
