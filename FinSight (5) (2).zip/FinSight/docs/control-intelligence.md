# FinSight Phase 6: Financial Control Intelligence Engine

## 1. Architectural Overview

The **Control Intelligence Engine** transforms FinSight from an observation system (identifying metrics and variances) into an active **internal controls and policy enforcement engine**. It systematically evaluates deterministic financial facts against governed policy thresholds, raising auditable exceptions, tracking monetary exposures, and spawning remediation workflows.

```
Financial Truth (GL / Subledger)
          │
          ▼
   Financial Engine
          │
          ▼
Control Assessment Service ◄──── Governed Knowledge Base (Corpus)
          │                      (COLL-POL-001, LIQ-CTRL-001, etc.)
          ├──────────────────────────────────┐
          ▼                                  ▼
Control Assessment (Deterministic)     Portfolio Summary
  • Status: PASS / REVIEW / BREACH       • 8 Controls Evaluated
  • Monetary Exposure                    • 5 Breaches, 1 Review, 2 Pass
  • Governing Document & Clause Citation • $4,893,780 Total Exposure
          │
          ▼
Spawns Remediation Case (CASE-SOP-001)
```

---

## 2. Canonical Control Model

Defined in [`src/finsight/models/control.py`](file:///C:/Users/samarth/OneDrive%20-%20Abhiyanta%20India%20Solutions%20Pvt%20Ltd/Pictures/FinSight/src/finsight/models/control.py):

| Field | Type | Description |
|---|---|---|
| `control_id` | `str` | Unique canonical control code (e.g. `CONTROL-COLL-001`) |
| `name` | `str` | Descriptive control title |
| `domain` | `str` | Operating domain: `CREDIT_COLLECTIONS`, `TREASURY`, `WORKING_CAPITAL`, `REVENUE`, `PROCUREMENT`, `DATA_GOVERNANCE`, `CASE_MANAGEMENT` |
| `description` | `str` | Business control objective and scope |
| `policy_document_id` | `str` | Governing policy document ID (e.g. `COLL-POL-001`) |
| `policy_version` | `str` | Exact effective policy version (e.g. `2.1`) |
| `effective_from` / `effective_to` | `str` | Active date interval for policy validity |
| `severity` | `ControlSeverity` | `CRITICAL`, `HIGH`, `MEDIUM`, `LOW`, `INFO` |
| `evaluation_type` | `ControlEvaluationType` | `THRESHOLD`, `AGING`, `COVERAGE`, `MATERIALITY`, `POLICY_COMPLIANCE` |
| `status` | `ControlStatus` | `ACTIVE`, `INACTIVE`, `DEPRECATED` |
| `threshold_config` | `Dict[str, Any]` | Extracted dynamic policy parameters |

---

## 3. Registered Canonical Controls & September 2026 Evaluation

FinSight deploys 8 canonical controls dynamically bound to governed policy documents:

| Control ID | Name | Governing Policy | Observed vs Threshold | Status | Exposure |
|---|---|---|---|---|---|
| **`CONTROL-COLL-001`** | High-Value Overdue AR Escalation | `COLL-POL-001` v2.1 | $1,044,000 overdue vs $500,000 limit | **BREACH** | $1,044,000.00 |
| **`CONTROL-LIQ-001`** | Rolling 7-Day Liquidity Coverage Ratio | `LIQ-CTRL-001` v2.0 | 0.59x vs 1.00x target (0.75x floor) | **BREACH** | $1,377,000.00 |
| **`CONTROL-INV-001`** | Inventory Holding & DIO Surge Control | `INV-POL-001` v2.0 | 89.6d DIO vs 75.0d target floor | **BREACH** | $2,656,840.00 |
| **`CONTROL-GM-001`** | Gross Margin Floor & Compression | `GM-POL-001` v1.0 | 40.28% vs 42.00% floor (-1.77 pp delta) | **BREACH** | $600,140.00 |
| **`CONTROL-AP-001`** | Immediate Cash-to-Disbursements Coverage | `AP-POL-001` v1.2 | Shortfall -$563,250 ($813k vs $1.377M) | **REVIEW** | $1,377,000.00 |
| **`CONTROL-CREDIT-001`** | Mandatory Credit & Shipping Hold | `CREDIT-POL-001` v1.0 | Apex has $1.044M past due > 45 days | **BREACH** | $1,044,000.00 |
| **`CONTROL-DATA-001`** | Authoritative Subledger Reconciliation | `DATA-POL-001` v1.0 | 24/24 invariant tie checks passed | **PASS** | $0.00 |
| **`CONTROL-CASE-001`** | Remediation Case SOP Compliance | `CASE-SOP-001` v2.0 | Cases active with immutable logs | **PASS** | $0.00 |

### Portfolio Summary:
- **Controls Reviewed:** 8
- **Breaches:** 5
- **Under Review:** 1
- **Passed:** 2
- **Net Deduplicated Financial Exposure:** $4,893,780.00

---

## 4. Control Assessment Pipeline

Each control evaluation is executed deterministically without hardcoding:
1. **Dynamic Metadata Extraction:** The evaluator pulls current threshold configuration directly from the knowledge retriever document metadata.
2. **Deterministic Fact Extraction:** Subledger aging, trial balance, and metric engines provide exact numerical balances.
3. **Threshold Comparison:** Evaluates mathematical criteria (greater-than, less-than, compression delta, coverage ratios).
4. **Evidence Linkage:** Populates `financial_evidence_refs` (e.g. invoice IDs `INV-AR-50065`, GL account `110000`) and `policy_evidence_refs` (policy chunk IDs).
5. **Remediation Trigger:** If an exception is detected and `case_required` is `True`, the system exposes the assessment for automatic instantiation into a `FinancialCase`.

---

## 5. API Endpoints

- `GET /api/controls`: Lists all active internal controls with optional domain/status filters.
- `GET /api/controls/{control_id}`: Fetches specific control definition and threshold metadata.
- `GET /api/control-assessments`: Evaluates and returns all control assessments for a fiscal period.
- `GET /api/control-assessments/summary`: Returns the executive portfolio summary (breaches, exposure).
- `GET /api/control-assessments/{control_id}`: Evaluates a single control for a given period and entity.
- `POST /api/control-assessments/{assessment_id}/create-case`: Direct control-to-case remediation spawning.
