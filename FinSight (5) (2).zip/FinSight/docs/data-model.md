# FinSight — Canonical Financial Data Model

## 1. Overview

The Canonical Financial Data Model isolates FinSight's analytics and intelligence layers from source-specific schemas. Whether data originates from SAP S/4HANA, NetSuite, Microsoft Dynamics, or flat files, it is mapped into this standardized schema.

---

## 2. Entity Specifications

### A. Company
Defines the reporting legal entity.

| Field | Type | Required | Description | SAP Mapping |
| :--- | :--- | :--- | :--- | :--- |
| `company_code` | `string` | Yes | Unique company code (e.g., `'1000'`) | `T001-BUKRS` |
| `company_name` | `string` | Yes | Legal entity business name | `T001-BUTXT` |
| `currency` | `string` | Yes | Local functional currency (e.g., `'USD'`) | `T001-WAERS` |

---

### B. Customer Master
Represents buyers and accounts in the customer subledger.

| Field | Type | Required | Description | SAP Mapping |
| :--- | :--- | :--- | :--- | :--- |
| `customer_id` | `string` | Yes | Unique customer number | `KNA1-KUNNR` |
| `customer_name` | `string` | Yes | Trading or legal business name | `KNA1-NAME1` |
| `segment` | `string` | Yes | Market classification (`Enterprise`, `Mid-Market`, etc.) | `KNA1-BRSCH` |
| `region` | `string` | Yes | Geographical theater (`North America`, `EMEA`, etc.) | `KNA1-LAND1` |
| `payment_terms` | `string` | Yes | Contractual terms (`NET30`, `NET45`, `NET60`) | `KNB1-ZTERM` |

---

### C. Vendor Master
Represents suppliers and contractors in the accounts payable subledger.

| Field | Type | Required | Description | SAP Mapping |
| :--- | :--- | :--- | :--- | :--- |
| `vendor_id` | `string` | Yes | Unique vendor identifier | `LFA1-LIFNR` |
| `vendor_name` | `string` | Yes | Supplier legal business name | `LFA1-NAME1` |
| `category` | `string` | Yes | Spend category (`Raw Materials`, `Logistics`, etc.) | `LFA1-KTOKK` |
| `payment_terms` | `string` | Yes | Contractual payment terms (`NET15`, `NET30`) | `LFB1-ZTERM` |

---

### D. Product Master
Defines goods, subscriptions, and services sold.

| Field | Type | Required | Description | SAP Mapping |
| :--- | :--- | :--- | :--- | :--- |
| `product_id` | `string` | Yes | SKU or Material number | `MARA-MATNR` |
| `product_name` | `string` | Yes | Commercial product title | `MAKT-MAKTX` |
| `product_group` | `string` | Yes | Product category (`Software`, `Hardware`, `Services`) | `MARA-MATKL` |
| `profit_center` | `string` | Yes | Associated Profit Center code | `MARC-PRCTR` |

---

### E. Account Mapping (Chart of Accounts)
Standardizes General Ledger accounts into canonical financial concepts.

| Field | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `gl_account` | `string` | Yes | General ledger account number (e.g., `'101000'`) |
| `financial_concept` | `FinancialConcept` | Yes | Canonical concept: `CASH`, `AR`, `INVENTORY`, `REVENUE`, `COGS`, `OPEX`, etc. |
| `category` | `AccountCategory` | Yes | Financial statement category: `ASSET`, `LIABILITY`, `EQUITY`, `REVENUE`, `EXPENSE` |
| `valid_from` | `date` | Yes | Mapping validity start date |
| `valid_to` | `date` | No | Optional expiry date (`None` = indefinite) |

---

### F. Journal Entry (General Ledger)
Individual posting lines representing double-entry financial activity.

| Field | Type | Required | Description | SAP S/4HANA Mapping |
| :--- | :--- | :--- | :--- | :--- |
| `company_code` | `string` | Yes | Reporting company code | `ACDOCA-RBUKRS` |
| `fiscal_year` | `integer` | Yes | Fiscal year (e.g., `2026`) | `ACDOCA-GJAHR` |
| `fiscal_period` | `integer` | Yes | Fiscal period (`1` to `12`) | `ACDOCA-POPER` |
| `posting_date` | `date` | Yes | Accounting posting date | `ACDOCA-BUDAT` |
| `document_id` | `string` | Yes | Accounting document number | `ACDOCA-BELNR` |
| `gl_account` | `string` | Yes | General ledger account posted to | `ACDOCA-RACCT` |
| `profit_center` | `string` | No | Profit Center allocation | `ACDOCA-PRCTR` |
| `cost_center` | `string` | No | Cost Center allocation | `ACDOCA-RCNTR` |
| `segment` | `string` | No | Operating segment | `ACDOCA-SEGMENT` |
| `customer_id` | `string` | No | Customer subledger reference | `ACDOCA-KUNNR` |
| `vendor_id` | `string` | No | Vendor subledger reference | `ACDOCA-LIFNR` |
| `product_id` | `string` | No | Product / SKU reference | `ACDOCA-MATNR` |
| `debit_credit` | `string` | Yes | `'S'`/`'D'` (Debit) or `'H'`/`'C'` (Credit) | `ACDOCA-DRCRK` |
| `amount` | `float` | Yes | Absolute transaction amount ($\ge 0.0$) | `ACDOCA-HSL` (abs) |
| `currency` | `string` | Yes | Document currency code | `ACDOCA-RHCUR` |

---

### G. Accounts Receivable Open Item (Customer Subledger)
Line-item invoices and credit memos issued to customers.

| Field | Type | Required | Description | SAP Mapping |
| :--- | :--- | :--- | :--- | :--- |
| `company_code` | `string` | Yes | Company code | `BSID-BUKRS` |
| `customer_id` | `string` | Yes | Customer identifier | `BSID-KUNNR` |
| `invoice_id` | `string` | Yes | Billing document reference | `BSID-BELNR` / `VBRK-VBELN` |
| `invoice_date` | `date` | Yes | Invoice billing date | `BSID-BLDAT` |
| `due_date` | `date` | Yes | Net payment due date | `BSID-ZFBDT` + terms |
| `clearing_date` | `date` | No | Date payment was settled (`None` if open) | `BSAD-AUGDT` |
| `invoice_amount` | `float` | Yes | Total gross invoiced amount ($> 0.0$) | `BSID-WRBTR` |
| `open_amount` | `float` | Yes | Remaining unpaid balance ($0.0 \le \text{open} \le \text{invoice}$) | Open balance |
| `currency` | `string` | Yes | Currency code | `BSID-WAERS` |

---

### H. Accounts Payable Open Item (Vendor Subledger)
Invoices received from suppliers and service providers.

| Field | Type | Required | Description | SAP Mapping |
| :--- | :--- | :--- | :--- | :--- |
| `company_code` | `string` | Yes | Company code | `BSIK-BUKRS` |
| `vendor_id` | `string` | Yes | Supplier identifier | `BSIK-LIFNR` |
| `invoice_id` | `string` | Yes | Vendor invoice reference | `BSIK-BELNR` |
| `invoice_date` | `date` | Yes | Supplier invoice issue date | `BSIK-BLDAT` |
| `due_date` | `date` | Yes | Net payment due date | `BSIK-ZFBDT` + terms |
| `clearing_date` | `date` | No | Date invoice was cleared/paid | `BSAK-AUGDT` |
| `invoice_amount` | `float` | Yes | Total gross billed amount ($> 0.0$) | `BSIK-WRBTR` |
| `open_amount` | `float` | Yes | Remaining unpaid balance ($0.0 \le \text{open} \le \text{invoice}$) | Open balance |
| `currency` | `string` | Yes | Currency code | `BSIK-WAERS` |
