# FinSight — Financial Metrics Directory

## 1. Overview

FinSight implements deterministic metric calculations strictly grounded in standard accounting standards (US GAAP / IFRS). Every metric produces a typed `MetricResult` containing the calculated value, formatted string, raw formula inputs, accounting definition, and comparative analysis against the preceding period.

---

## 2. Metric Specifications

### Cash & Working Capital

#### 1. Cash Position
- **Metric Slug**: `cash_position`
- **Definition**: Cumulative balance of all bank, checking, and cash-equivalent general ledger accounts as of the reference date.
- **Formula**:
  $$\text{Cash Position} = \sum_{\text{GL} \in \text{CASH}} \left(\sum \text{Debits} - \sum \text{Credits}\right)$$
- **Unit**: Currency (`USD`)
- **Status When Empty**: `CALCULATED` (value = 0.0)

#### 2. Current Assets
- **Metric Slug**: `current_assets`
- **Definition**: Total economic resources convertible to cash within one operating cycle or twelve months.
- **Formula**:
  $$\text{Current Assets} = \text{Cash} + \text{Accounts Receivable} + \text{Inventory} + \text{Other Current Assets}$$
- **Unit**: Currency (`USD`)

#### 3. Current Liabilities
- **Metric Slug**: `current_liabilities`
- **Definition**: Financial obligations and debts due within twelve months.
- **Formula**:
  $$\text{Current Liabilities} = \text{Accounts Payable} + \text{Short-Term Debt} + \text{Other Current Liabilities}$$
- **Unit**: Currency (`USD`)

#### 4. Net Working Capital (NWC)
- **Metric Slug**: `net_working_capital`
- **Definition**: Operational liquidity available to fund day-to-day business operations.
- **Formula**:
  $$\text{Net Working Capital} = \text{Current Assets} - \text{Current Liabilities}$$
- **Unit**: Currency (`USD`)
- **Favorability**: An increasing NWC is favorable assuming it is not driven by bad debt or non-moving inventory.

---

### Receivables & Collections

#### 5. Accounts Receivable (AR)
- **Metric Slug**: `accounts_receivable`
- **Definition**: Total open invoice balances owed by customers in the AR subledger.
- **Formula**:
  $$\text{AR} = \sum_{i \in \text{Open AR Items}} \text{open\_amount}_i$$
- **Unit**: Currency (`USD`)

#### 6. Overdue Accounts Receivable
- **Metric Slug**: `overdue_ar`
- **Definition**: Total open AR balances where the invoice payment due date is prior to the reference date.
- **Formula**:
  $$\text{Overdue AR} = \sum_{i \in \text{Open AR Items, } \text{due\_date}_i < \text{as\_of\_date}} \text{open\_amount}_i$$
- **Unit**: Currency (`USD`)
- **Favorability**: Decreasing is favorable.

#### 7. Overdue AR Percentage
- **Metric Slug**: `overdue_ar_percent`
- **Formula**:
  $$\text{Overdue AR \%} = \frac{\text{Overdue AR}}{\text{Total AR}} \times 100$$
- **Edge Case**: If Total AR is $0$, returns `NOT_APPLICABLE` with formatted value `"N/A"`.
- **Unit**: Percentage (`%`)
- **Favorability**: Decreasing is favorable.

#### 8. Days Sales Outstanding (DSO)
- **Metric Slug**: `dso`
- **Definition**: Average number of days required to collect payment after a credit sale has been completed.
- **Formula**:
  $$\text{DSO} = \frac{\text{Ending AR}}{\text{Period Credit Sales}} \times \text{Days in Period}$$
- **Edge Cases**:
  - If Credit Sales $\le 0$, status is set to `ZERO_DENOMINATOR` or `INSUFFICIENT_DATA`, and value is `None`. The engine **never** silently defaults to zero.
- **Unit**: Days
- **Favorability**: Decreasing is favorable (faster cash conversion).

---

### Payables & Disbursements

#### 9. Accounts Payable (AP)
- **Metric Slug**: `accounts_payable`
- **Definition**: Total outstanding short-term liabilities owed to vendors and suppliers in the AP subledger.
- **Formula**:
  $$\text{AP} = \sum_{j \in \text{Open AP Items}} \text{open\_amount}_j$$
- **Unit**: Currency (`USD`)

#### 10. Upcoming Payables (7 Days)
- **Metric Slug**: `upcoming_payables_7d`
- **Definition**: Open vendor obligations due today or within the next 7 calendar days.
- **Formula**:
  $$\text{Upcoming 7d AP} = \sum_{j \in \text{Open AP, } \text{as\_of\_date} \le \text{due\_date}_j \le (\text{as\_of\_date} + 7)} \text{open\_amount}_j$$
- **Unit**: Currency (`USD`)

#### 11. Days Payable Outstanding (DPO)
- **Metric Slug**: `dpo`
- **Definition**: Average time in days the company takes to pay its suppliers and invoices.
- **Formula**:
  $$\text{DPO} = \frac{\text{Ending AP}}{\text{Period COGS}} \times \text{Days in Period}$$
- **Edge Cases**:
  - If COGS $\le 0$, status is set to `ZERO_DENOMINATOR`, value is `None`.
- **Unit**: Days

---

### Inventory

#### 12. Inventory Value
- **Metric Slug**: `inventory_value`
- **Definition**: Book value of raw materials and finished goods inventory held on the balance sheet.
- **Formula**:
  $$\text{Inventory} = \sum_{\text{GL} \in \text{INVENTORY}} \left(\sum \text{Debits} - \sum \text{Credits}\right)$$
- **Unit**: Currency (`USD`)

#### 13. Days Inventory Outstanding (DIO)
- **Metric Slug**: `dio`
- **Definition**: Number of days on average that inventory remains in stock before being sold.
- **Formula**:
  $$\text{DIO} = \frac{\text{Ending Inventory}}{\text{Period COGS}} \times \text{Days in Period}$$
- **Edge Cases**:
  - If COGS $\le 0$, returns `ZERO_DENOMINATOR`.
- **Unit**: Days
- **Favorability**: Decreasing is favorable (lower holding cost and risk of obsolescence).

---

### Profitability

#### 14. Revenue
- **Metric Slug**: `revenue`
- **Definition**: Gross recognized sales from credit postings to revenue GL accounts during the period.
- **Formula**:
  $$\text{Revenue} = \sum_{\text{GL} \in \text{REVENUE}} \left(\sum \text{Credits} - \sum \text{Debits}\right)$$
- **Unit**: Currency (`USD`)
- **Favorability**: Increasing is favorable.

#### 15. Cost of Goods Sold (COGS)
- **Metric Slug**: `cogs`
- **Definition**: Direct costs attributable to the production and delivery of goods and services sold during the period.
- **Formula**:
  $$\text{COGS} = \sum_{\text{GL} \in \text{COGS}} \left(\sum \text{Debits} - \sum \text{Credits}\right)$$
- **Unit**: Currency (`USD`)
- **Favorability**: Decreasing is favorable relative to sales.

#### 16. Gross Profit
- **Metric Slug**: `gross_profit`
- **Formula**:
  $$\text{Gross Profit} = \text{Revenue} - \text{COGS}$$
- **Unit**: Currency (`USD`)

#### 17. Gross Margin Percentage
- **Metric Slug**: `gross_margin_percent`
- **Formula**:
  $$\text{Gross Margin \%} = \frac{\text{Gross Profit}}{\text{Revenue}} \times 100$$
- **Edge Cases**:
  - If Revenue $\le 0$, returns `ZERO_DENOMINATOR`.
- **Unit**: Percentage (`%`)
- **Favorability**: Increasing is favorable.

#### 18. Cash Conversion Cycle (CCC)
- **Metric Slug**: `ccc` / `cash_conversion_cycle`
- **Definition**: The net number of days it takes for a business to convert its investments in inventory and other resources into cash inflows from sales.
- **Formula**:
  $$\text{CCC} = \text{DSO} + \text{DIO} - \text{DPO}$$
- **Edge Cases**:
  - Requires all three constituent working capital efficiency metrics (`DSO`, `DIO`, `DPO`) to be available and valid (`CALCULATED`).
  - If any component is unavailable or non-numeric, returns `INSUFFICIENT_DATA` or `NOT_APPLICABLE`.
- **Unit**: Days
- **Favorability**: Decreasing is favorable (shorter working capital cycle).

---

## 3. Period-over-Period Comparative Structure

Every metric includes an optional `MetricComparison` payload:
```json
{
  "previous_period": "2026-08",
  "previous_value": 42.05,
  "absolute_change": -1.77,
  "percentage_change": -4.21,
  "trend": "DECREASING",
  "is_favorable": false
}
```
- **Absolute Change**: $\text{Current Value} - \text{Previous Value}$
- **Percentage Change**: $\frac{\text{Current Value} - \text{Previous Value}}{|\text{Previous Value}|} \times 100$
- **Trend**: `INCREASING`, `DECREASING`, or `FLAT` ($|\Delta| < 10^{-4}$)
- **Favorability**: Evaluated dynamically based on metric nature (e.g., higher revenue is favorable; higher DSO or overdue AR is unfavorable).
