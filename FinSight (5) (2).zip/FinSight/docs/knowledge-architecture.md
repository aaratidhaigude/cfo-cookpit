# FinSight Phase 5 — Governed Finance Knowledge & Policy Intelligence Architecture

## 1. Executive Summary & Foundational Architectural Principle

FinSight Phase 5 introduces **Finance Knowledge & Policy Intelligence**, equipping FinSight AI with the capability to synthesize investigations that unite:
1. **Financial Facts (What Happened):** Grounded exclusively in deterministic double-entry general ledger, subledger, and cash transactions.
2. **Finance Policies & Controls (What Policy Applies & What Finance Should Do):** Retrieved from a governed, versioned internal enterprise finance knowledge repository.

### The Non-Negotiable Separation of Truth
```
                    Financial Data (GL / Subledger / ERP)
                                     ↓
                         Canonical Financial Model
                                     ↓
                       Deterministic Financial Engine
                                     ↓
                       Financial Intelligence Layer
                                     ↓
                           Financial Attention
                                     ↓
                           Investigation Engine
                                     ↓
             ┌───────────────────────────────────────────────┐
             │                                               │
    Financial Tools                                Knowledge Retrieval
 (Ledger, Aging, Cash, AP)                     (Policies, SOPs, Controls)
             │                                               │
             └───────────────────────┬───────────────────────┘
                                     ↓
                                FinSight AI
                                     ↓
                         Evidence + Policy Context
                                     ↓
                         Grounded Executive Brief
                                     ↓
                             Remediation Case
```

> **CORE PRINCIPLE:** RAG is an authoritative **KNOWLEDGE** layer for corporate policies, control thresholds, standard operating procedures, and business rules. RAG is **NEVER** the source of financial numbers, balances, aging schedules, or calculations. All metrics (Cash, AR, AP, NWC, DSO, DIO, DPO, CCC, GM) are computed deterministically with zero LLM arithmetic.

---

## 2. Canonical Knowledge Document Model

All enterprise finance documents conform to the canonical schema defined in [`finsight.models.knowledge`](file:///C:/Users/samarth/OneDrive%20-%20Abhiyanta%20India%20Solutions%20Pvt%20Ltd/Pictures/FinSight/src/finsight/models/knowledge.py):

| Field | Type | Description |
| :--- | :--- | :--- |
| `document_id` | `str` | Unique enterprise document identifier (e.g., `COLL-POL-001`) |
| `title` | `str` | Formal policy or procedure title |
| `document_type` | `DocumentType` | `POLICY`, `SOP`, `CONTROL`, `ACCOUNTING_GUIDANCE`, `PAYMENT_TERMS`, `ESCALATION_RULE`, `GOVERNANCE` |
| `domain` | `str` | Functional finance domain: `AR`, `AP`, `TREASURY`, `WORKING_CAPITAL`, `PROFITABILITY`, `GOVERNANCE` |
| `version` | `str` | Semantic policy release version (e.g., `2.1`) |
| `effective_from` | `str` | ISO date when policy takes legal effect (`YYYY-MM-DD`) |
| `effective_to` | `Optional[str]` | Expiration date or `None` if currently open-ended |
| `status` | `str` | `ACTIVE`, `SUPERSEDED`, `EXPIRED`, `DRAFT` |
| `owner` | `str` | Corporate governance owner (e.g., `Head of Credit & Collections`) |
| `source` | `str` | Repository origin (e.g., `Internal Enterprise Finance Knowledge Base`) |
| `confidentiality` | `str` | Classification (`INTERNAL_CONFIDENTIAL`, `INTERNAL_OPERATIONAL`, etc.) |
| `text` | `str` | Complete markdown policy body organized with `## Section` headings |
| `metadata` | `Dict[str, Any]` | Machine-readable control parameters (thresholds, days, ratios) |

---

## 3. Authoritative Enterprise Finance Knowledge Corpus

FinSight ships with 8 authoritative operational policies and controls governing fiscal year 2026, alongside versioned and expired test controls:

1. **`COLL-POL-001` (v2.1, Active): Collections Escalation Policy**
   - **Domain:** `AR` | **Owner:** Head of Credit & Collections
   - **Threshold 3.1 (1–15d):** Automated statement reminder.
   - **Threshold 3.2 (16–30d or > $250k):** Formal collection dunning letter.
   - **Threshold 3.3 (> 45d AND > $500,000.00):** Mandatory executive escalation, **immediate administrative shipment/credit hold**, C-level notification within 24h, formal case creation in FinSight.
   - **Threshold 3.4 (> 90d):** Legal referral and bad debt provisioning.
2. **`AR-SOP-001` (v1.5, Active): Accounts Receivable SOP**
   - **Domain:** `AR` | **Owner:** Credit & Collections Manager
   - Subledger aging brackets (`0-30`, `31-60`, `61-90`, `90+`), weekly aging review cadences, dispute resolution protocols within 2 business days.
3. **`AP-POL-001` (v3.0, Active): Vendor Payment Approval & Disbursement Policy**
   - **Domain:** `AP` | **Owner:** Corporate Controller
   - Mandatory 7-calendar-day forward disbursement horizon.
   - Delegation of Authority: Level 1 (< $50k), Level 2 ($50k–$250k), **Level 3 (> $250k: CFO / VP Finance dual approval)**.
   - Structured split-payment negotiation protocol for liabilities exceeding $250k during liquidity compression.
4. **`LIQ-CTRL-001` (v2.0, Active): Liquidity Risk & Cash Runway Control Policy**
   - **Domain:** `TREASURY` | **Owner:** VP Treasury
   - **Mandatory 7-Day Liquidity Coverage Ratio (LCR):** $\text{Cash} / \text{Upcoming 7-Day AP}$.
   - Target benchmark: $\ge 1.25\text{x}$. Safe operational floor: $\ge 1.00\text{x}$.
   - **Escalation Triggers:** Level 1 Warning ($\text{LCR} < 1.00\text{x}$), **Level 2 Emergency ($\text{LCR} < 0.75\text{x}$)** mandating discretionary payment pause and collections acceleration.
5. **`INV-POL-001` (v1.8, Active): Inventory Risk & Working Capital Policy**
   - **Domain:** `WORKING_CAPITAL` | **Owner:** Director of Supply Chain Finance
   - DIO target: $\le 75.0\text{ days}$. Material expansion trigger: $\Delta \text{DIO} > 10.0\text{ days}$.
   - Slow-moving reserve requirements and mandatory quarterly cycle counting.
6. **`GM-POL-001` (v2.2, Active): Gross Margin Control & Profitability Policy**
   - **Domain:** `PROFITABILITY` | **Owner:** VP Commercial Finance
   - Corporate gross margin floor: $42.0\%$. Customer segment floor: $30.0\%$.
   - Material margin compression trigger: $> 1.5\text{ pp}$ decrease.
7. **`CRED-POL-001` (v1.4, Active): Customer Credit & Payment Terms Governance Policy**
   - **Domain:** `AR` | **Owner:** Credit Risk Committee
   - Standard terms: Tier 1 Strategic (NET30), Tier 2 Commercial (NET30), Tier 3 Small (NET15).
   - Automated commercial credit suspension at 30 days overdue.
8. **`CASE-SOP-001` (v2.0, Active): Financial Remediation Case Governance SOP**
   - **Domain:** `GOVERNANCE` | **Owner:** Director of Financial Governance
   - Mandatory case creation criteria for AR delinquency (> $500k and > 45d), liquidity squeeze ($\text{LCR} < 1.00\text{x}$), and margin dilution (< 30%).
   - **Immutable incident snapshot integrity:** Initial exposure amount is permanently preserved.
9. **`COLL-POL-001-v1.0` (v1.0, Superseded): Legacy Collections Policy**
   - Effective 2024-01-01 to 2025-12-31. Filtered out for 2026 reference periods.
10. **`TAX-SOP-EXPIRED` (v1.0, Expired): Special Temporary Tax Assessment SOP**
   - Expired on 2025-12-31. Validates strict handling of expired policy inquiries.

---

## 4. Deterministic Local Knowledge Retriever

The knowledge retrieval subsystem (`LocalKnowledgeRetriever`) is designed with **zero external database dependencies**:
- **Semantic Chunking:** Documents are parsed into discrete markdown section chunks (`DocumentChunk`), preserving section hierarchies, metadata, and versioning.
- **Deterministic BM25 / TF-IDF Indexing:** Computes exact document frequency (DF), term frequency (TF), and inverse document frequency (IDF) with smoothed BM25 parameters ($k_1=1.5, b=0.75$).
- **Section & Title Boosting:** Term matches occurring in section headers receive a $3\times$ boost; title matches receive a $4\times$ boost. Exact phrase matches in headers receive a $+5.0$ relevance boost.
- **Stop Word & Substantive Filtering:** Standard English stop words and generic governance terminology are eliminated from substantive match scoring. Queries with domain terms (e.g. `travel`, `entertainment`) require candidate chunks to match substantive keywords, completely preventing false positive policy hallucination.
- **Effective Date Resolution:** Given an inquiry date (e.g. `2026-09-30`), only documents where $\text{effective\_from} \le \text{date} \le \text{effective\_to}$ are candidate targets. If multiple versions overlap, the latest semantic version is selected.
- **Domain Aliasing:** Maps aliases (`AR` $\leftrightarrow$ `RECEIVABLES`, `AP` $\leftrightarrow$ `PAYABLES`, `TREASURY` $\leftrightarrow$ `CASH` / `LIQUIDITY`, `INVENTORY` $\leftrightarrow$ `WORKING_CAPITAL`) seamlessly across API and tool boundaries.

---

## 5. Multi-Step Hybrid Investigation & 6-Part Brief Contract

Investigations explicitly categorize and execute multi-step plans:
- **`FINANCIAL_TOOL` Steps:** Dispatched to `AIToolsService` contracts (`get_receivables`, `get_upcoming_payments`, `get_cash_position`, `compare_periods`).
- **`KNOWLEDGE_RETRIEVAL` Steps:** Dispatched to `search_finance_knowledge` with targeted domain and query arguments.

### Evidence Separation
The investigation result maintains separate, non-colliding evidence structures:
- `financial_evidence`: Invoices, journal entries, aging brackets, cash positions.
- `policy_evidence`: Governing policy excerpts, section titles, document IDs, and versions.
- `knowledge_sources`: Structured citations with relevance scores, effective date windows, and document links.

### The 6-Part Response Contract
Every hybrid investigation generates an executive brief conforming to:
1. **Executive Finding:** High-level factual conclusion combining verified status and policy outcome.
2. **Financial Evidence:** Bulleted itemization of verified ledger amounts, invoices, aging, and concentrations.
3. **Policy / Control Context:** Exact policy citation (`COLL-POL-001 v2.1`), threshold requirements, and mandated actions.
4. **Assessment:** Objective comparison of financial evidence against governing policy thresholds.
5. **Suggested Next Steps:** Concrete operational actions aligned with policy mandates.
6. **Evidence Sources:** Clear lineage split between ledger accounts/subledgers and governing policy versions.

---

## 6. Safety Guardrails & Failure Modes

FinSight AI strictly prevents policy invention and false compliance approvals:

| Failure Mode | Trigger Condition | AI Response Behavior |
| :--- | :--- | :--- |
| **1. Missing Policy** | User asks for unindexed policy (e.g. *Travel & Entertainment*) | AI states *"No applicable policy was found in the internal knowledge base"* and confirms FinSight strictly avoids inventing internal policies. |
| **2. Expired Policy** | User inquires about expired policy (e.g. *Tax SOP*) | AI detects document was expired before reference date (`2026-09-30`) and refuses to evaluate operational compliance against expired guidelines. |
| **3. Insufficient Financial Data** | Financial entity or invoice not found in ledger | AI reports *"Insufficient financial evidence to assess policy compliance"* rather than hallucinating an approval. |
| **4. Policy vs Fact Contradiction** | User asks *"Can we release shipments to Apex?"* | AI rejects shipment release: *"Shipments cannot be released under current policy"*, citing $1,044,000 past-due exposure (> $500k) and 68-day aging (> 45d). |

---

## 7. REST API Endpoints & UI Integration

### REST Endpoints
- `GET /api/knowledge/documents`: Lists all registered enterprise knowledge documents (supports `?status=` filter).
- `GET /api/knowledge/documents/{id}`: Retrieves complete policy document text and metadata.
- `GET /api/knowledge/search`: Performs BM25 policy search (`?query=...&domain=...&top_k=...`).
- `GET /api/knowledge/summary`: Returns governance inventory, active/expired/superseded counts, and indexing health.

### Frontend Integration
- **Investigate View (`/investigate`):** Renders hybrid investigation plans with visual step badges (`[FINANCIAL TOOL]` vs `[POLICY RETRIEVAL]`), a dedicated **Governing Policy Sources** card, and policy context callouts.
- **Evidence Drawer:** Formats `POLICY_DOCUMENT` items cleanly with document badges, section tags, and text excerpts without polluting financial dollar summaries.
- **Data Status Page (`/data-status`):** Displays a live **Governed Finance Knowledge Base** governance panel reporting total documents, active count, indexed chunks, and retriever readiness status.
