# FinSight — Mock Data Architecture & Intentional Business Scenarios

## 1. Generation Philosophy & Reproducibility

FinSight relies on a deterministic synthetic dataset generated via `MockFinancialAdapter(seed=42)`.
- **Historical Horizon**: 12 consecutive monthly fiscal periods (`2025-10` through `2026-09`).
- **Reference Date**: `2026-09-30`.
- **Accounting Coherence**: Complete double-entry balancing ($\text{Debits} = \text{Credits}$) for all journal transactions, full referential integrity across master data, and exact reconciliation between subledgers and general ledger control accounts.

Rather than injecting random noise, the dataset intentionally encodes **9 real-world corporate financial distress and operational scenarios** that the FinSight intelligence layer will detect.

---

## 2. Intentional Business Scenarios

### Scenario 1 — Customer Payment Deterioration
- **Target Entity**: `CUST-101` ("Apex Retail Group", Enterprise, North America).
- **Behavior**: Apex is the company's largest account (~$380k - $440k monthly revenue). Historically, Apex settled invoices promptly within 30-35 days. Starting in June 2026 (Period 8), payment frequency slowed drastically; in July, August, and September (Periods 9-11), invoices went completely unpaid.
- **Evidence**: Open AR exceeds $1,044,000, with invoices aging across the 31-60, 61-90, and >90 day overdue buckets.

### Scenario 2 — AR Concentration
- **Evidence**: The top customer (`CUST-101`) accounts for over **60% of total overdue AR** across the entire enterprise. A default or prolonged dispute with Apex poses an existential cash collection hazard.

### Scenario 3 — Upcoming AP Pressure
- **Target Entities**: `VEND-202` (Precision Metalworks), `VEND-203` (Global Freight), `VEND-201` (Titan Semiconductor).
- **Behavior**: Concentrated vendor invoices maturing in rapid succession around the reference date (`2026-09-30`):
  - **Due Today**: $408,000
  - **Due in 1-3 Days**: $153,000
  - **Due in 4-7 Days**: $816,000
  - **Total 7-Day Outflow**: **$1,377,000**

### Scenario 4 — Inventory Buildup
- **Behavior**: In Periods 9, 10, and 11, material procurement multipliers increased to 1.35x, 1.55x, and 1.70x, while customer shipments expanded at only 0.68% - 3.0%.
- **Evidence**: Inventory increased from $1,100,000 to over $2,656,000 (+141% increase), driving Days Inventory Outstanding (DIO) upwards from 42 days to >65 days.

### Scenario 5 — Margin Compression
- **Behavior**: Titan Semiconductor (`VEND-201`) raised component costs on chipsets for the Industrial Edge Controller (`PRD-002`), while customer selling prices remained contractually fixed.
- **Evidence**: Gross margin compressed from 42.05% in August to 40.28% in September (and down from 48%+ earlier in the year), despite top-line revenue growing from $1.48M to $1.49M.

### Scenario 6 — Healthy Benchmark Customer
- **Target Entity**: `CUST-102` ("Nordic Solutions AG", Enterprise, EMEA).
- **Behavior**: Generates over $350,000 in monthly revenue with healthy 58%+ gross margins on software platforms (`PRD-001`). All historical invoices have been settled on or before due date, maintaining **0.0% overdue exposure**.

### Scenario 7 — High Revenue / Low Profitability Trap
- **Target Entity**: `CUST-104` ("OmniChannel Logistics", Wholesale).
- **Behavior**: Generates large sales volumes ($260k+/month) on Commodity Micro-Servers (`PRD-004`). However, high hardware bills of materials yield a razor-thin gross margin of **<11%** (gross profit < $28k on $260k volume).

### Scenario 8 — Acute Cash Pressure (The Working Capital Crunch)
- **Manifestation**:
  1. Cash collections collapsed due to Apex Retail's non-payment ($1.04M trapped in AR).
  2. Cash committed to excess inventory ($2.65M tied up on the balance sheet).
  3. Strategic prior-period CapEx ($1.0M) and debt paydown ($600k) reduced cash buffers.
  4. Available cash at end of September: **$813,750**.
  5. Imminent 7-day vendor obligations: **$1,377,000**.
- **Financial Finding**: Upcoming 7-day obligations exceed available cash by 1.7x, creating an urgent operational cash deficit.

### Scenario 9 — Exposure Concentration
- **Customer Exposure**: Top 2 customers (`CUST-101` and `CUST-102`) account for >50% of corporate revenue.
- **Vendor Exposure**: `VEND-201` (Titan Semiconductor) accounts for >40% of total raw materials procurement, creating supply chain vulnerability.

---

## 3. Data Integrity & Invariants

The dataset satisfies strict mathematical invariants verified by `DataQualityService`:
1. **Zero Double-Entry Discrepancy**: Every single journal document has $\sum \text{Signed Amounts} = 0.00$.
2. **Subledger Bounds**: $\text{Open Amount} \le \text{Invoice Amount}$ and $\text{Invoice Amount} > 0$.
3. **Master Referential Integrity**: Every subledger record maps to a valid customer or vendor.
4. **Non-Negative Real Assets**: Cash, Inventory, and Accounts Receivable are strictly positive.
