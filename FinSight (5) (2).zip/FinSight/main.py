"""FinSight Server Entry Point."""

import sys
from pathlib import Path

src_dir = str(Path(__file__).parent / "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

import uvicorn
from finsight.config import settings


def main():
    """Runs the FinSight API server using uvicorn."""
    uvicorn.run(
        "finsight.api.app:app",
        host=settings.host,
        port=settings.port,
        reload=False,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    main()
