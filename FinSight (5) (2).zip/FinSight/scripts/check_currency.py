import os

bad_terms = ['formatUSD', 'formatCompactUSD', '$']
exceptions = ['${', '$1', '$2', '$3', '$4', '$5', '$$']

found = []
for root, _, files in os.walk('src'):
    for f in files:
        if f.endswith(('.py', '.html', '.js')):
            p = os.path.join(root, f)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fh:
                for i, l in enumerate(fh, 1):
                    # Check if formatUSD or formatCompactUSD is in line
                    if 'formatUSD' in l or 'formatCompactUSD' in l:
                        found.append((p, i, l.strip()))
                    elif '$' in l:
                        # strip out ${...} and $1..$5
                        temp = l
                        for exc in exceptions:
                            temp = temp.replace(exc, '')
                        if '$' in temp:
                            found.append((p, i, l.strip()))

print(f"Total findings: {len(found)}")
for p, i, l in found:
    print(f"{p}:{i}: {l[:100]}".encode('ascii', errors='replace').decode('ascii'))
