import sys, os
sys.path.insert(0, os.path.join(os.getcwd(), 'src'))
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')
from starlette.testclient import TestClient
from finsight.api.app import app

client = TestClient(app)
login_resp = client.post('/api/auth/login', json={'username': 'admin', 'password': 'demo123'})
token = login_resp.json()['token']
headers = {'Authorization': 'Bearer ' + token}

for h in [30, 60, 90]:
    fc = client.get(f'/api/forecast/scenarios?horizon_days={h}&period=2026-09', headers=headers).json()
    base = fc.get('scenarios', {}).get('BASE', {})
    c_cash = base.get('closing_cash') or base.get('projected_cash')
    col = base.get('total_collections') or base.get('expected_collections')
    pay = base.get('total_disbursements') or base.get('expected_payables')
    print(f"Horizon {h}d: closing_cash={c_cash}, collections={col}, payables={pay}")

print("\n--- Attention Items ---")
attn = client.get('/api/attention', headers=headers).json()
for it in attn.get('items', [])[:5]:
    print(it.get('title'), "sev:", it.get('severity'), "exposure:", it.get('financial_impact') or it.get('financial_exposure'), "reason:", it.get('priority_reason') or it.get('summary'))

print("\n--- What Changed Items ---")
wc = client.get('/api/performance/what-changed', headers=headers).json()
for m in wc[:6]:
    print(m.get('metric_name'), "cur:", m.get('current_value'), "pri:", m.get('prior_value'), "pct:", m.get('percentage_change'), "abs:", m.get('absolute_change'), "reason:", m.get('materiality_reason'))
