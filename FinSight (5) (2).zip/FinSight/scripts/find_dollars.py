import glob
import re

dollar_pat = re.compile(r"\$[0-9]|\$\$\{")
found = []
for p in glob.glob("src/finsight/static/js/**/*.js", recursive=True):
    with open(p, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            if dollar_pat.search(line):
                found.append(f"{p}:{i}: {line.strip()}")

print(f"Total occurrences: {len(found)}")
for line in found:
    print(line)
