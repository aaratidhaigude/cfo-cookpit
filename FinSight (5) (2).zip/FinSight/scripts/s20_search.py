
import os, sys, re
sys.stdout.reconfigure(encoding='utf-8')

targets = ['813750', '1044000', '2984000', '60.1', '89.5', '89.6', '60.2']

for root, dirs, files in os.walk('src'):
    for f in files:
        if f.endswith(('.py', '.js')):
            path = os.path.join(root, f)
            if 'mock_adapter.py' in path:
                continue
            with open(path, 'r', encoding='utf-8', errors='ignore') as fp:
                for idx, line in enumerate(fp, 1):
                    for t in targets:
                        if t in line:
                            print(f'{path}:{idx}: [{t}] {line.strip()[:110]}')
