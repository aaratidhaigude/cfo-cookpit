import os
import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

get_num = re.compile(r'\.get\(\s*[\'\"][^\'\"]+[\'\"]\s*,\s*([1-9]\d*(\.\d+)?)\s*\)')
or_num = re.compile(r'\b(or|\|\||\?\?)\s*([1-9]\d{2,}(\.\d+)?)\b')

for root, dirs, files in os.walk('src'):
    for f in files:
        if f.endswith(('.py', '.js')):
            path = os.path.join(root, f)
            if 'mock_adapter.py' in path:
                continue
            with open(path, 'r', encoding='utf-8', errors='ignore') as fp:
                for idx, line in enumerate(fp, 1):
                    m1 = get_num.search(line)
                    m2 = or_num.search(line)
                    if m1 or m2:
                        print(f"{path}:{idx}: {line.strip()[:120]}")
