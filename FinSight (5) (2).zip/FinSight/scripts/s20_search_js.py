import os
import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

pattern = re.compile(r'(\|\||\?\?)\s*([\'\"\$0-9]|true|false)')

for root, dirs, files in os.walk('src/finsight/static/js'):
    for f in files:
        if f.endswith('.js'):
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8', errors='ignore') as fp:
                for idx, line in enumerate(fp, 1):
                    if pattern.search(line):
                        print(f"{path}:{idx}: {line.strip()[:120]}")
