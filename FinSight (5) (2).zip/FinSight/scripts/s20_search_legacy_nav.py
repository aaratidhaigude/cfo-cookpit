import os
import sys

sys.stdout.reconfigure(encoding='utf-8')
for root, dirs, files in os.walk('src/finsight/static/js'):
    for f in files:
        if f.endswith('.js') and f not in ['commandCenter.js', 'money.js', 'cases.js', 'status.js']:
            p = os.path.join(root, f)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                for idx, line in enumerate(fp, 1):
                    line_lower = line.lower()
                    for term in ['command center', 'commandcenter', "'money'", '"money"', "'cases'", '"cases"']:
                        if term in line_lower:
                            print(f"{p}:{idx}: {line.strip()[:100]}")
