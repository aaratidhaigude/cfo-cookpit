import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from starlette.testclient import TestClient
from finsight.api.app import app


client = TestClient(app)
login_res = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"}).json()
token = login_res.get("token")
if token:
    client.headers["Authorization"] = f"Bearer {token}"


print("=" * 70)
print("FINSIGHT PHASE 2 VALIDATION RUN")
print("=" * 70)

# 1. Attention API
print("\n[1] GET /api/attention?period=2026-09")
r1 = client.get("/api/attention?period=2026-09")
assert r1.status_code == 200
d1 = r1.json()
print(f"Total Attention Items: {d1['total_items']}")
print(f"Total Exposure: ${d1['total_financial_exposure']:,.2f}")
print(f"Counts by Severity: {d1['counts_by_severity']}")
for item in d1["items"][:3]:
    print(f"  * [{item['severity']}] {item['title']} (Score: {item['priority_score']})")
    print(f"    Reason: {item['priority_reason']}")

# 2. Intelligence API
print("\n[2] GET /api/intelligence?period=2026-09")
r2 = client.get("/api/intelligence?period=2026-09")
assert r2.status_code == 200
d2 = r2.json()
print(f"Period Changes: {len(d2['period_changes'])}")
print(f"Material Changes: {len(d2['material_changes'])}")
print(f"Trends Detected: {len(d2['trends'])}")
print(f"Anomalies Detected: {len(d2['anomalies'])}")
print(f"Driver Analyses: {len(d2['driver_analyses'])}")
print(f"Customer Profiles: {len(d2['customer_intelligence'])}")
print(f"Product Intelligence: {len(d2['product_intelligence'])}")

# 3. 5 Required Investigation Examples
print("\n[3] POST /api/investigate (5 Required Questions)")
questions = [
    "Why did cash decrease?",
    "Why is DSO increasing?",
    "Which customers are driving overdue AR?",
    "Where did gross margin decline?",
    "What payments are due in the next 7 days?",
]

for q in questions:
    r = client.post("/api/investigate", json={"question": q, "period": "2026-09"})
    assert r.status_code == 200
    res = r.json()
    print("-" * 70)
    print(f"Q: {q}")
    print(f"Intent: {res['intent']}")
    print(f"Steps: {len(res['steps'])} | Findings: {len(res['findings'])} | Evidence: {len(res['evidence'])}")
    print(f"Answer: {res['answer']}")
    print(f"Drivers: {res['drivers']}")
    print(f"Next Steps: {res['suggested_next_steps'][:2]}")

# 4. POST /api/ai/ask
print("\n[4] POST /api/ai/ask")
r_ask = client.post("/api/ai/ask", json={"question": "Which customers have high revenue but poor payment behaviour?", "period": "2026-09"})
assert r_ask.status_code == 200
d_ask = r_ask.json()
print(f"Q: Which customers have high revenue but poor payment behaviour?")
print(f"Answer: {d_ask['answer']}")
print(f"Key Findings: {d_ask['key_findings'][:2]}")

print("\n" + "=" * 70)
print("PHASE 2 VALIDATION SUCCESSFUL: ALL ENDPOINTS VERIFIED")
print("=" * 70)
