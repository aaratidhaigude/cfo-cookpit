"""End-to-End Validation Script for FinSight Phase 3.

Validates:
1. Data consistency: Overdue AR is $1,044,000.00 across all services without contradiction.
2. Cash Conversion Cycle: CCC = 89.5 days.
3. Cases management endpoints: List, create, retrieve, update.
4. Static UI web app serving & asset availability.
5. AI Investigation Engine with observable plan execution and transaction audit trail.
"""

import sys
from pathlib import Path
from starlette.testclient import TestClient

# Ensure src is on path
src_dir = str(Path(__file__).resolve().parent.parent / "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from finsight.api.app import app


def run_validation():
    print("==================================================")
    print("FINSIGHT PHASE 3: END-TO-END VALIDATION AUDIT")
    print("==================================================")

    client = TestClient(app)
    login_res = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"}).json()
    token = login_res.get("token")
    if token:
        client.headers["Authorization"] = f"Bearer {token}"

    # 1. Root & Static UI Serving
    print("\n[1] Verifying Executive Frontend Serving...")
    ui_resp = client.get("/")
    assert ui_resp.status_code == 200, f"UI failed: {ui_resp.status_code}"
    assert "FinSight" in ui_resp.text and "Financial Intelligence" in ui_resp.text
    print("  [OK] index.html successfully served at /")


    css_resp = client.get("/css/main.css")
    assert css_resp.status_code == 200
    print("  [OK] /css/main.css successfully served")

    js_resp = client.get("/js/app.js")
    assert js_resp.status_code == 200
    print("  [OK] /js/app.js ES module successfully served")

    # 2. Financial Summary & CCC
    print("\n[2] Verifying Financial Summary & Cash Conversion Cycle (CCC)...")
    sum_resp = client.get("/api/financial-summary?period=2026-09")
    assert sum_resp.status_code == 200
    summary = sum_resp.json()
    assert summary["cash_position"]["value"] == 813750.0
    assert summary["cash_position"]["comparison"]["absolute_change"] == -433000.0
    assert summary["dso"]["value"] == 60.1
    assert summary["dio"]["value"] == 89.6
    assert summary["dpo"]["value"] == 60.2
    assert summary["ccc"]["value"] == 89.5
    print(f"  [OK] Cash: {summary['cash_position']['formatted_value']} (Decreased by ${abs(summary['cash_position']['comparison']['absolute_change']):,.0f})")
    print(f"  [OK] DSO: {summary['dso']['formatted_value']}")
    print(f"  [OK] DIO: {summary['dio']['formatted_value']}")
    print(f"  [OK] DPO: {summary['dpo']['formatted_value']}")
    print(f"  [OK] CCC: {summary['ccc']['formatted_value']} (60.1 + 89.6 - 60.2 = 89.5 days)")

    # 3. Data Consistency: Overdue AR across all surfaces
    print("\n[3] Verifying Single Source of Truth Overdue AR Consistency...")
    ar_resp = client.get("/api/receivables?period=2026-09")
    assert ar_resp.status_code == 200
    ar_data = ar_resp.json()
    tot_od = ar_data["overdue_ar"]["value"]
    assert tot_od == 1044000.0, f"Expected 1,044,000, got {tot_od}"
    print(f"  [OK] /api/receivables total overdue AR: ${tot_od:,.2f}")

    attn_resp = client.get("/api/attention?period=2026-09")
    assert attn_resp.status_code == 200
    attn_items = attn_resp.json()["items"]
    ar_attn = next(it for it in attn_items if "AR" in it["type"] or "Apex" in it["title"])
    assert ar_attn["financial_impact"] == 1044000.0
    print(f"  [OK] Attention Item '{ar_attn['title']}' impact: ${ar_attn['financial_impact']:,.2f}")

    ask_resp = client.post("/api/ai/ask", json={"question": "Which customers are driving overdue AR?", "period": "2026-09"})
    assert ask_resp.status_code == 200
    ask_data = ask_resp.json()
    assert "1,044,000" in ask_data["answer"] or "1044000" in ask_data["answer"]
    assert "Apex Retail Group" in ask_data["answer"]
    assert "189,000" not in ask_data["answer"]
    print(f"  [OK] AI Answer: {ask_data['answer']}")

    # 4. Multi-Step AI Investigation Execution
    print("\n[4] Verifying Observable Multi-Step Investigation Plan...")
    inv_resp = client.post("/api/investigate", json={"question": "Why did cash decrease?", "period": "2026-09"})
    assert inv_resp.status_code == 200
    inv_data = inv_resp.json()
    print(f"  [OK] Intent Classified: {inv_data['intent']}")
    print(f"  [OK] Executed Steps ({len(inv_data['steps'])} steps):")
    for s in inv_data["steps"]:
        print(f"      [{s['step_number']}] {s['action']} -> {s['tool_name']} ({s['status']})")
    print(f"  [OK] Primary Driver: {inv_data['drivers'][0] if inv_data['drivers'] else 'N/A'}")
    print(f"  [OK] Evidence Items Collected: {len(inv_data['evidence'])} records")

    # 5. Cases Remediation Governance
    print("\n[5] Verifying Financial Remediation Cases System...")
    cases_resp = client.get("/api/cases")
    assert cases_resp.status_code == 200
    cases = cases_resp.json()
    assert len(cases) >= 3
    print(f"  [OK] Retrieved {len(cases)} initial cases (Seeded: CASE-2026-001, CASE-2026-002, CASE-2026-003)")

    # Create new case
    new_case_payload = {
        "title": "Validation Automated Audit Case",
        "severity": "HIGH",
        "category": "LIQUIDITY",
        "financial_impact": 510000.0,
        "summary": "7-day payable commitments exceed liquid reserves.",
        "assignee": "Treasurer",
        "recommended_actions": ["Review revolving credit line draw."]
    }
    c_create_resp = client.post("/api/cases", json=new_case_payload)
    assert c_create_resp.status_code == 200
    created_case = c_create_resp.json()
    case_id = created_case["id"]
    print(f"  [OK] Created new case {case_id} ('{created_case['title']}')")

    # Update case status
    c_update_resp = client.patch(f"/api/cases/{case_id}", json={"status": "IN_REVIEW", "new_note": "Audit review started."})
    assert c_update_resp.status_code == 200
    updated_case = c_update_resp.json()
    assert updated_case["status"] == "IN_REVIEW"
    print(f"  [OK] Updated case {case_id} status to IN_REVIEW with audit note")

    print("\n==================================================")
    print("ALL PHASE 3 VALIDATION CHECKS PASSED PERFECTLY!")
    print("==================================================")


if __name__ == "__main__":
    run_validation()
