"""FinSight Phase 4 Validation Script: Financial Truth, Reconciliation & Product Integrity Audit.

Validates:
1. Authoritative Financial Snapshot: Metadata, dataset version, readiness, provenance.
2. Complete 22-Check Deterministic Invariant Reconciliation Engine:
   - Balance Sheet (CA, CL, NWC)
   - P&L (Gross Margin, Gross Profit, Revenue Completeness)
   - Working Capital Cycle (DSO, DIO, DPO, CCC)
   - Subledger Aging & Schedules (AR Past-Due Buckets, AP 7-Day Maturing Schedule)
   - Concentration & Cross-Layer Ties (Control Accounts to BSID/BSIK, Trial Balance Tie)
3. Single-Source-of-Truth Invariants:
   - Apex Retail Group overdue AR = $1,044,000.00 across subledger, metrics, and cases (INV-AR-50065, 50073, 50081).
   - Liquid cash = $813,750.00.
   - 7-day payables squeeze = $1,377,000.00 (shortfall -$563,250 vs liquid cash).
   - Gross Margin = 40.28% (GP $600,140.00 / Revenue $1,490,000.00).
   - CCC = 89.5 days (60.1 + 89.6 - 60.2).
4. Executive UI & API endpoint verification.
"""

import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

from starlette.testclient import TestClient

src_dir = str(Path(__file__).resolve().parent.parent / "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from finsight.api.app import app


def run_phase4_validation():
    print("=" * 76)
    print("FINSIGHT PHASE 4: FINANCIAL TRUTH, RECONCILIATION & INTEGRITY VALIDATION")
    print("=" * 76)

    client = TestClient(app)
    login_resp = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    assert login_resp.status_code == 200, f"Login failed: {login_resp.status_code}"
    token = login_resp.json()["token"]
    client.headers["Authorization"] = f"Bearer {token}"

    # 1. Authoritative Financial Snapshot Verification
    print("\n[1] Verifying Authoritative Financial Snapshot (/api/snapshot)...")
    snap_resp = client.get("/api/snapshot")
    assert snap_resp.status_code == 200, f"Snapshot endpoint failed: {snap_resp.status_code}"
    snap = snap_resp.json()
    assert snap["period"] == "2026-09"
    assert snap["calculation_status"] in ("READY", "COMPLETED")
    assert snap["data_quality_status"] == "HEALTHY"
    assert snap["is_active"] is True
    print(f"  [OK] Snapshot ID:       {snap['snapshot_id']}")
    print(f"  [OK] Period:            {snap['period']} ({snap['period_start']} to {snap['period_end']})")
    print(f"  [OK] Reference Date:    {snap['reference_date']}")
    print(f"  [OK] Dataset Version:   {snap['dataset_version']}")
    print(f"  [OK] Status / Health:   {snap['calculation_status']} / {snap['data_quality_status']}")

    # 2. 24-Check Deterministic Financial Invariant Matrix
    print("\n[2] Verifying Deterministic Reconciliation Engine (/api/reconciliation)...")
    recon_resp = client.get("/api/reconciliation?period=2026-09")
    assert recon_resp.status_code == 200, f"Reconciliation endpoint failed: {recon_resp.status_code}"
    report = recon_resp.json()

    assert report["status"] == "RECONCILED", f"Expected RECONCILED, got {report['status']}"
    assert report["total_checks"] == 24, f"Expected 24 checks, got {report['total_checks']}"
    assert report["passed_checks"] == 24, f"Expected 24 passed, got {report['passed_checks']}"
    assert report["failed_checks"] == 0, f"Expected 0 failed, got {report['failed_checks']}"

    print(f"  [OK] Audit Status:      {report['status']}")
    print(f"  [OK] Invariants Tested: {report['total_checks']}/24 Passed (100% Deterministic Match)")
    print(f"  [OK] Discrepancies:     {report['failed_checks']} Failures (Tolerance: Delta = \u20b90.00)")

    print("\n      Invariant Verification Breakdown:")
    print("      " + "-" * 70)
    print(f"      {'Check ID':<18} | {'Category':<15} | {'Expected':<12} | {'Computed':<12} | {'Status'}")
    print("      " + "-" * 70)
    for c in report["checks"]:
        exp = f"{c['expected_value']:,.2f}" if isinstance(c['expected_value'], (int, float)) else str(c['expected_value'])
        comp = f"{c['computed_value']:,.2f}" if isinstance(c['computed_value'], (int, float)) else str(c['computed_value'])
        print(f"      {c['check_id']:<18} | {c['category']:<15} | {exp:<12} | {comp:<12} | {c['status']}")
    print("      " + "-" * 70)

    # 3. Single Source of Truth Invariance
    print("\n[3] Verifying Single Source of Truth Financial Invariants...")
    metrics = report["summary_metrics"]

    # Cash Invariance
    assert metrics["cash"] == 813750.0
    print(f"  [OK] Liquid Cash:             \u20b9{metrics['cash']:,.2f}")

    # Net Working Capital
    assert metrics["net_working_capital"] == 4848840.0
    assert round(metrics["current_assets"] - metrics["current_liabilities"], 2) == 4848840.0
    print(f"  [OK] Net Working Capital:     \u20b9{metrics['net_working_capital']:,.2f} (CA: \u20b9{metrics['current_assets']:,.2f} - CL: \u20b9{metrics['current_liabilities']:,.2f})")

    # GL \u2194 Subledger Reconciliation (AR & AP)
    assert metrics["gl_ar"] == 3814000.0
    assert metrics["trade_ar"] == 2984000.0
    assert metrics["other_receivables"] == 830000.0
    assert round(metrics["trade_ar"] + metrics["other_receivables"], 2) == metrics["gl_ar"]
    print(f"  [OK] GL AR <-> Subledger AR:    GL: \u20b9{metrics['gl_ar']:,.2f} = Trade: \u20b9{metrics['trade_ar']:,.2f} + Other Receivables: \u20b9{metrics['other_receivables']:,.2f}")

    assert metrics["gl_ap"] == 2435750.0
    assert metrics["trade_ap"] == 1785750.0
    assert metrics["other_payables"] == 650000.0
    assert round(metrics["trade_ap"] + metrics["other_payables"], 2) == metrics["gl_ap"]
    print(f"  [OK] GL AP <-> Subledger AP:    GL: \u20b9{metrics['gl_ap']:,.2f} = Trade: \u20b9{metrics['trade_ap']:,.2f} + Other Payables: \u20b9{metrics['other_payables']:,.2f}")

    # Working Capital Cycle (DSO, DIO, DPO, CCC)
    assert metrics["dso"] == 60.1
    assert metrics["dio"] == 89.6
    assert metrics["dpo"] == 60.2
    assert metrics["ccc"] == 89.5
    assert round(metrics["dso"] + metrics["dio"] - metrics["dpo"], 1) == 89.5
    print(f"  [OK] Working Capital Cycle:   DSO: {metrics['dso']}d + DIO: {metrics['dio']}d - DPO: {metrics['dpo']}d = CCC: {metrics['ccc']}d")

    # P&L Identities
    assert metrics["revenue"] == 1490000.0
    assert metrics["cogs"] == 889860.0
    assert metrics["gross_profit"] == 600140.0
    assert metrics["gross_margin_percent"] == 40.28
    assert round(metrics["revenue"] - metrics["cogs"], 2) == 600140.0
    print(f"  [OK] P&L Arithmetic:          Rev: \u20b9{metrics['revenue']:,.2f} - COGS: \u20b9{metrics['cogs']:,.2f} = GP: \u20b9{metrics['gross_profit']:,.2f} (GM: {metrics['gross_margin_percent']}%)")

    # Overdue Receivables Concentration
    assert metrics["open_ar"] == 2984000.0
    assert metrics["overdue_ar"] == 1044000.0
    print(f"  [OK] Receivables & Overdue:   Total AR: \u20b9{metrics['open_ar']:,.2f} | Overdue AR: \u20b9{metrics['overdue_ar']:,.2f} (35.0%)")

    # Apex Retail Group Single Source Verification
    rec_resp = client.get("/api/receivables?period=2026-09")
    assert rec_resp.status_code == 200
    rec = rec_resp.json()
    assert rec["overdue_ar"]["value"] == 1044000.0
    apex_cust = next(c for c in rec["top_overdue_customers"] if c["entity_id"] == "CUST-101")
    assert apex_cust["amount"] == 1044000.0
    assert apex_cust["percentage_of_total"] == 100.0
    overdue_invoices = rec["overdue_invoices"]
    assert len(overdue_invoices) == 3
    assert {inv["invoice_id"] for inv in overdue_invoices} == {"INV-AR-50065", "INV-AR-50073", "INV-AR-50081"}
    assert sum(inv["amount"] for inv in overdue_invoices) == 1044000.0
    print(f"  [OK] Apex Retail Group AR:    \u20b91,044,000.00 across 3 invoices (INV-AR-50065: \u20b9189k, 50073: \u20b9425k, 50081: \u20b9430k)")

    # Upcoming Payables Squeeze Verification
    assert metrics["upcoming_payables_7d"] == 1377000.0
    pay_resp = client.get("/api/payables?period=2026-09")
    assert pay_resp.status_code == 200
    pay = pay_resp.json()
    assert len(pay["upcoming_invoices"]) == 3
    assert sum(inv["amount"] for inv in pay["upcoming_invoices"]) == 1377000.0
    shortfall = metrics["cash"] - metrics["upcoming_payables_7d"]
    assert shortfall == -563250.0
    print(f"  [OK] 7-Day Payables Squeeze:  Due: \u20b9{metrics['upcoming_payables_7d']:,.2f} vs Cash: \u20b9{metrics['cash']:,.2f} (Shortfall: \u20b9{shortfall:,.2f})")

    # Cases Layer Reconciled Exposure
    cases_resp = client.get("/api/cases")
    assert cases_resp.status_code == 200
    cases = cases_resp.json()
    case_001 = next(c for c in cases if c["id"] == "CASE-2026-001")
    case_002 = next(c for c in cases if c["id"] == "CASE-2026-002")
    assert case_001["financial_impact"] == 1044000.0
    assert case_002["financial_impact"] == 1377000.0
    print(f"  [OK] Remediation Cases:       CASE-2026-001 = \u20b9{case_001['financial_impact']:,.2f} | CASE-2026-002 = \u20b9{case_002['financial_impact']:,.2f}")

    # 4. Frontend Serving Verification
    print("\n[4] Verifying Frontend Serving & JavaScript Pages...")
    routes_to_check = ["/", "/css/main.css", "/js/app.js", "/js/services/api.js", "/js/pages/dataStatus.js", "/js/pages/commandCenter.js", "/js/pages/money.js", "/js/pages/performance.js", "/js/pages/investigate.js"]
    for path in routes_to_check:
        r = client.get(path)
        assert r.status_code == 200, f"Failed to serve {path}: status {r.status_code}"
    print(f"  [OK] All {len(routes_to_check)} Frontend application & component assets served cleanly")

    print("\n" + "=" * 76)
    print("PHASE 4 AUDIT COMPLETE: 100% RECONCILED, ZERO SPECULATION, ZERO DRIFT")
    print("=" * 76)


if __name__ == "__main__":
    run_phase4_validation()
