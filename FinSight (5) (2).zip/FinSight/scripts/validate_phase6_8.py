"""FinSight Phases 6–8 Validation Script: Control Intelligence + Case Remediation + Cash Outlook.

Validates:
1. Canonical Control Model: 8 controls dynamically bound to knowledge documents.
2. Deterministic Control Evaluation: 8 controls assessed against September 2026 data.
3. Control Portfolio Summary: Breaches, exposures, and compliance breakdown.
4. Control-to-Case Spawning: Automatic instantiation of remediation case from assessment.
5. Extended Case Remediation Lifecycle: 7-state lifecycle with validation.
6. Remediation Action Plan: Action items tracked with owner, status, and completion evidence.
7. Immutable Audit Trail: Append-only log of events and notes with actor and timestamp.
8. Enforced Non-Silent Closure: Blocked closure without resolution summary and evidence.
9. Deterministic Cash Projections: 30, 60, and 90-day horizons.
10. Weekly Trajectory & Week-1 Liquidity Dip: 0.59x LCR dip at Week 1.
11. Multi-Scenario Sensitivity: Base, Conservative, and Improved Collections projections.
12. Policy-Governed Liquidity Indicator: Dynamic comparison against LIQ-CTRL-001.
13. AI Financial Tool #13: get_cash_forecast tool execution.
14. AI Cash Outlook Investigation: Multi-step investigation with get_cash_forecast dispatch.
15. End-to-End API Verification: Controls, Forecast, and Case Remediation endpoints.
"""

import sys
from datetime import date
from pathlib import Path

src_dir = str(Path(__file__).resolve().parent.parent / "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.models.canonical import FinancialConcept
from finsight.models.cases import CaseStatus, RemediationAction, CloseCaseRequest
from finsight.models.cash_forecast import ForecastScenario
from finsight.services.ai_tools_service import AIToolsService
from finsight.services.cases_service import CasesService
from finsight.services.cash_forecast_service import CashForecastService
from finsight.services.control_assessment_service import ControlAssessmentService
from finsight.services.investigation_service import InvestigationService
from finsight.services.knowledge_retriever import LocalKnowledgeRetriever
from finsight.services.refresh_service import RefreshService


def run_phase6_8_validation():
    print("=" * 80)
    print("FINSIGHT PHASES 6–8: CONTROL INTELLIGENCE + CASE REMEDIATION + CASH OUTLOOK")
    print("=" * 80)

    client = TestClient(app)
    refresh_svc = RefreshService()
    refresh_svc.execute_refresh()
    retriever = LocalKnowledgeRetriever()
    ctrl_svc = ControlAssessmentService(refresh_svc.engine, refresh_svc.metric_service, retriever)
    fc_svc = CashForecastService(refresh_svc.engine, refresh_svc.metric_service)
    from finsight.api.routes import get_cases_service
    cases_svc = get_cases_service()

    # -------------------------------------------------------------------------
    # Checkpoint 1 & 2: Canonical Controls & Deterministic Evaluation
    # -------------------------------------------------------------------------
    print("\n[1 & 2] Verifying Canonical Controls & Deterministic Evaluation...")
    controls = ctrl_svc.list_controls()
    assert len(controls) == 8, f"Expected 8 controls, found {len(controls)}"
    print(f"  [OK] Registered Canonical Controls: {len(controls)}")

    assessments = ctrl_svc.assess_all_controls("2026-09")
    assert len(assessments) == 8
    
    status_map = {a.control_id: a for a in assessments}
    
    # CONTROL-COLL-001
    coll = status_map["CONTROL-COLL-001"]
    assert coll.status.value == "BREACH"
    assert coll.financial_exposure == 1044000.00
    assert coll.policy_document_id == "COLL-POL-001"
    print(f"  [OK] CONTROL-COLL-001: {coll.status.value} (Exposure: ${coll.financial_exposure:,.2f}) -> Linked to {coll.policy_document_id}")

    # CONTROL-LIQ-001
    liq = status_map["CONTROL-LIQ-001"]
    assert liq.status.value == "BREACH"
    assert liq.observed_value == 0.59
    assert liq.threshold_value == 1.00
    assert liq.policy_document_id == "LIQ-CTRL-001"
    print(f"  [OK] CONTROL-LIQ-001:  {liq.status.value} (7d LCR: {liq.observed_value:.2f}x vs {liq.threshold_value:.2f}x) -> Linked to {liq.policy_document_id}")

    # CONTROL-INV-001
    inv = status_map["CONTROL-INV-001"]
    assert inv.status.value == "BREACH"
    assert inv.policy_document_id == "INV-POL-001"
    print(f"  [OK] CONTROL-INV-001:  {inv.status.value} (DIO: {inv.observed_value:.1f}d vs {inv.threshold_value:.1f}d) -> Linked to {inv.policy_document_id}")

    # CONTROL-GM-001
    gm = status_map["CONTROL-GM-001"]
    assert gm.status.value == "BREACH"
    assert gm.policy_document_id == "GM-POL-001"
    print(f"  [OK] CONTROL-GM-001:   {gm.status.value} (Gross Margin: {gm.observed_value:.2f}% vs {gm.threshold_value:.2f}%) -> Linked to {gm.policy_document_id}")

    # -------------------------------------------------------------------------
    # Checkpoint 3: Control Portfolio Summary
    # -------------------------------------------------------------------------
    print("\n[3] Verifying Control Portfolio Summary...")
    summary = ctrl_svc.get_summary("2026-09")
    assert summary.controls_reviewed == 8
    assert summary.controls_breached == 5
    assert summary.controls_requiring_review == 1
    assert summary.controls_passed == 2
    assert summary.total_financial_exposure == 4893780.00
    print(f"  [OK] Total Controls:    {summary.controls_reviewed}")
    print(f"  [OK] Breached Controls: {summary.controls_breached} (Exposure: ${summary.total_financial_exposure:,.2f})")
    print(f"  [OK] Under Review:      {summary.controls_requiring_review}")
    print(f"  [OK] Passed Controls:   {summary.controls_passed}")

    # -------------------------------------------------------------------------
    # Checkpoint 4 & 5: Control-to-Case Spawning & Lifecycle
    # -------------------------------------------------------------------------
    print("\n[4 & 5] Verifying Control-to-Case Spawning & Extended Lifecycle...")
    spawned_case = cases_svc.create_case_from_assessment(
        assessment=coll,
        assigned_owner="Senior Collections Manager",
        due_date="2026-10-10",
    )
    assert spawned_case.control_id == "CONTROL-COLL-001"
    assert spawned_case.status == CaseStatus.OPEN
    assert spawned_case.financial_exposure == 1044000.00
    assert len(spawned_case.remediation_plan) >= 1
    assert len(spawned_case.audit_notes) >= 3
    print(f"  [OK] Spawned Case ID:   {spawned_case.id} linked to {spawned_case.control_id}")
    print(f"  [OK] Initial Status:    {spawned_case.status.value}")
    print(f"  [OK] Remediation Plan:  {len(spawned_case.remediation_plan)} initial action items")
    print(f"  [OK] Audit Trail:       {len(spawned_case.audit_notes)} initial events logged")

    # -------------------------------------------------------------------------
    # Checkpoint 6 & 7: Remediation Action Plan & Immutable Audit Trail
    # -------------------------------------------------------------------------
    print("\n[6 & 7] Verifying Remediation Action Items & Audit Trail...")
    new_act = RemediationAction(
        action="Obtain legally binding promissory note with Apex CFO",
        owner="VP Commercial Finance",
        due_date="2026-10-05",
        status="COMPLETED",
        evidence="Promissory note #PN-2026-APX signed 2026-10-04",
    )
    case_with_action = cases_svc.add_remediation_action(
        spawned_case.id,
        new_act,
        actor="VP Commercial Finance",
    )
    assert any(a.action == new_act.action for a in case_with_action.remediation_plan)
    assert any(e.event_type == "ACTION_ADDED" for e in case_with_action.audit_notes)
    print(f"  [OK] Added Action Item: '{new_act.action}'")
    print(f"  [OK] Audit Trail Length: {len(case_with_action.audit_notes)} immutable entries")

    # -------------------------------------------------------------------------
    # Checkpoint 8: Enforced Non-Silent Closure
    # -------------------------------------------------------------------------
    print("\n[8] Verifying Enforced Non-Silent Closure...")
    from finsight.models.cases import UpdateCaseRequest
    try:
        cases_svc.update_case(spawned_case.id, UpdateCaseRequest(status=CaseStatus.CLOSED))
        assert False, "Silent closure should have been rejected!"
    except ValueError as e:
        print(f"  [OK] Silent Closure Blocked: {e}")

    closed_case = cases_svc.close_case(
        spawned_case.id,
        CloseCaseRequest(
            resolution_summary="Apex cleared $500,000 upfront tranche and signed 60-day debt schedule.",
            resolution_evidence="Wire ref #WF-99401 & Legal Restructuring Agreement #LGL-2026-094",
            reviewer="Chief Financial Officer",
        ),
        actor="Senior Collections Manager",
    )
    assert closed_case.status == CaseStatus.CLOSED
    assert closed_case.resolution_summary is not None
    assert closed_case.resolution_evidence is not None
    assert any(e.event_type == "CLOSED" for e in closed_case.audit_notes)
    print(f"  [OK] Valid Non-Silent Closure Succeeded: Status={closed_case.status.value}")
    print(f"  [OK] Resolution Evidence: {closed_case.resolution_evidence}")

    # -------------------------------------------------------------------------
    # Checkpoint 9 & 10: Cash Forecast & Week-1 Liquidity Dip
    # -------------------------------------------------------------------------
    print("\n[9 & 10] Verifying Deterministic Cash Projections & Week-1 Liquidity Dip...")
    fc_30 = fc_svc.generate_forecast(horizon_days=30, scenario="BASE")
    assert fc_30.starting_cash == 813750.00
    assert fc_30.projected_cash == 447612.51
    assert fc_30.expected_collections == 1380200.00
    assert fc_30.expected_payables == 1626337.50
    assert fc_30.recurring_outflows == 120000.00

    week1 = fc_30.weekly_projections[0]
    assert week1.week_number == 1
    assert week1.starting_cash == 813750.00
    assert week1.disbursements == 1377000.00
    assert week1.net_cash_flow == -1199970.00
    assert week1.ending_cash == -386220.00
    assert week1.lcr_ratio == 0.59
    print(f"  [OK] 30-Day Starting Cash:     ${fc_30.starting_cash:,.2f}")
    print(f"  [OK] 30-Day Projected Cash:    ${fc_30.projected_cash:,.2f}")
    print(f"  [OK] Week 1 Maturing AP:       ${week1.disbursements:,.2f}")
    print(f"  [OK] Week 1 Net Flow:          ${week1.net_cash_flow:,.2f}")
    print(f"  [OK] Week 1 Ending Cash (Dip): ${week1.ending_cash:,.2f}")
    print(f"  [OK] Week 1 LCR:               {week1.lcr_ratio:.2f}x (Emergency Floor < 0.75x)")

    # 60 and 90-day horizons
    fc_60 = fc_svc.generate_forecast(horizon_days=60, scenario="BASE")
    fc_90 = fc_svc.generate_forecast(horizon_days=90, scenario="BASE")
    assert fc_60.projected_cash == 814800.04
    assert fc_90.projected_cash == 558799.93
    print(f"  [OK] 60-Day Projected Cash:    ${fc_60.projected_cash:,.2f}")
    print(f"  [OK] 90-Day Projected Cash:    ${fc_90.projected_cash:,.2f}")

    # -------------------------------------------------------------------------
    # Checkpoint 11 & 12: Scenario Sensitivity & Policy Liquidity Risk
    # -------------------------------------------------------------------------
    print("\n[11 & 12] Verifying Multi-Scenario Sensitivity & Policy Liquidity Risk...")
    comp = fc_svc.compare_scenarios(horizon_days=30)
    sc_map = comp.scenarios
    assert "BASE" in sc_map
    assert "CONSERVATIVE" in sc_map
    assert "IMPROVED_COLLECTIONS" in sc_map
    assert sc_map["BASE"].projected_cash == 447612.51
    assert sc_map["CONSERVATIVE"].projected_cash == -52187.49
    assert sc_map["IMPROVED_COLLECTIONS"].projected_cash == 1156212.51
    assert sc_map["BASE"].liquidity_indicators["policy_breach_detected"] is True
    print(f"  [OK] BASE Scenario:                 ${sc_map['BASE'].projected_cash:,.2f} (LCR: {sc_map['BASE'].liquidity_indicators['lcr_7d']:.2f}x)")
    print(f"  [OK] CONSERVATIVE Scenario:         ${sc_map['CONSERVATIVE'].projected_cash:,.2f} (Deficit under 0% Apex recovery)")
    print(f"  [OK] IMPROVED_COLLECTIONS Scenario: ${sc_map['IMPROVED_COLLECTIONS'].projected_cash:,.2f} (Surplus under accelerated collections)")

    # -------------------------------------------------------------------------
    # Checkpoint 13 & 14: AI Tool #13 & AI Investigation Dispatch
    # -------------------------------------------------------------------------
    print("\n[13 & 14] Verifying AI Financial Tool #13 & Investigation Dispatch...")
    tools_svc = AIToolsService(refresh_svc, retriever)
    tool_methods = [
        "get_financial_metric", "compare_periods", "find_metric_drivers",
        "get_cash_position", "get_receivables", "get_payables",
        "get_overdue_items", "get_customer_exposure", "get_product_profitability",
        "get_upcoming_payments", "get_transaction_evidence", "search_finance_knowledge",
        "get_cash_forecast",
    ]
    for tm in tool_methods:
        assert hasattr(tools_svc, tm), f"Missing tool method: {tm}"
    print(f"  [OK] Registered AI Financial Tools: {len(tool_methods)} (includes 'get_cash_forecast')")

    tool_res = tools_svc.get_cash_forecast(horizon_days=30, scenario="BASE")
    assert tool_res["projected_cash"] == 447612.51
    assert tool_res["liquidity_indicators"]["lcr_7d"] == 0.59
    print(f"  [OK] Tool #13 Output: Projected Cash=${tool_res['projected_cash']:,.2f}, LCR={tool_res['liquidity_indicators']['lcr_7d']:.2f}x")

    # AI Investigation Dispatch
    from finsight.services.financial_intelligence_service import FinancialIntelligenceService
    intel_svc = FinancialIntelligenceService(refresh_svc.engine, refresh_svc.metric_service)
    inv_svc = InvestigationService(tools_svc, intel_svc)
    inv_res = inv_svc.execute_investigation("What is our cash outlook and 30-day liquidity forecast under the base scenario?", "2026-09")
    executed_tools = [s.tool_name for s in inv_res.steps]
    assert "get_cash_forecast" in executed_tools
    assert inv_res.intent == "CASH_OUTLOOK_INVESTIGATION"
    assert len(inv_res.answer) > 100
    assert len(inv_res.evidence) >= 1
    print(f"  [OK] AI Investigation Intent: {inv_res.intent}")
    print(f"  [OK] Dispatched Tools:        {executed_tools}")
    print(f"  [OK] Briefing Length:         {len(inv_res.answer)} chars grounded in verified data")

    # -------------------------------------------------------------------------
    # Checkpoint 15: End-to-End API Verification
    # -------------------------------------------------------------------------
    print("\n[15] Verifying API Endpoints via HTTP TestClient...")
    r_ctrl = client.get("/api/controls")
    assert r_ctrl.status_code == 200 and len(r_ctrl.json()) == 8
    print(f"  [OK] GET  /api/controls -> 200 ({len(r_ctrl.json())} controls)")

    r_assess = client.get("/api/control-assessments?period=2026-09")
    assert r_assess.status_code == 200 and len(r_assess.json()) == 8
    print(f"  [OK] GET  /api/control-assessments -> 200 ({len(r_assess.json())} assessments)")

    r_fc = client.get("/api/forecast/cash?horizon_days=30&scenario=BASE")
    assert r_fc.status_code == 200 and r_fc.json()["projected_cash"] == 447612.51
    print(f"  [OK] GET  /api/forecast/cash -> 200 (Projected: ${r_fc.json()['projected_cash']:,.2f})")

    r_sc = client.get("/api/forecast/scenarios?horizon_days=30")
    assert r_sc.status_code == 200 and len(r_sc.json()["scenarios"]) == 3
    print(f"  [OK] GET  /api/forecast/scenarios -> 200 (3 scenarios)")

    r_audit = client.get(f"/api/cases/{closed_case.id}/audit-trail")
    assert r_audit.status_code == 200 and len(r_audit.json()) >= 4
    print(f"  [OK] GET  /api/cases/{{id}}/audit-trail -> 200 ({len(r_audit.json())} audit notes)")

    print("\n" + "=" * 80)
    print("PHASES 6–8 VALIDATION COMPLETE: ALL 15 CHECKPOINTS DETERMINISTICALLY VERIFIED")
    print("=" * 80)


if __name__ == "__main__":
    run_phase6_8_validation()
