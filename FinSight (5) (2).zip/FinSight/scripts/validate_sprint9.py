"""FinSight Sprint 9 Validation Script: Performance & Driver Intelligence.

Validates:
1. Deterministic Financial Baseline Preservation (September 2026 ground truth).
2. "What Changed" Period-over-Period Engine (deterministic variance and trend direction).
3. Deterministic Materiality Filtering (configurable domain thresholds, zero LLM ranking).
4. Causal Multivariate Driver Decomposition (Gross Margin, Revenue, Gross Profit, COGS, Working Capital, Cash, DSO, CCC).
5. Exact Mathematical Reconciliation of Gross Profit Variance (Customer and Product sum to portfolio delta).
6. Customer Drivers & Margin Dilution Attribution (Apex Retail Group margin compression & overdue AR).
7. Product Drivers & Margin Contraction Attribution (Hardware COGS inflation vs Software stability).
8. Working Capital Driver Attribution (Receivables buildup, AP stretch, Cash conversion cycle).
9. Traceable Financial Evidence & Audit Trail (Open items, journal entries, product group P&L reconciliations).
10. Performance REST API Endpoints Verification via TestClient.
11. Frontend Source of Truth Verification (zero hardcoded financial facts in UI modules).
"""

import re
import sys
from pathlib import Path

src_dir = str(Path(__file__).resolve().parent.parent / "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.models.canonical import FinancialConcept
from finsight.models.metrics import MetricUnit, TrendDirection
from finsight.models.performance import (
    EntityContribution,
    MaterialityConfig,
    MetricDriverResponse,
    PerformanceSummaryResponse,
    WhatChangedItem,
)
from finsight.services.financial_intelligence_service import FinancialIntelligenceService
from finsight.services.performance_service import PerformanceService
from finsight.services.refresh_service import RefreshService


def run_sprint9_validation():
    print("=" * 80)
    print("FINSIGHT SPRINT 9: PERFORMANCE & DRIVER INTELLIGENCE VALIDATION")
    print("=" * 80)

    client = TestClient(app)
    refresh_svc = RefreshService()
    refresh_svc.execute_refresh()
    intel_svc = FinancialIntelligenceService(refresh_svc.engine, refresh_svc.metric_service)
    perf_svc = PerformanceService(refresh_svc.engine, refresh_svc.metric_service, intel_svc)

    # -------------------------------------------------------------------------
    # Checkpoint 1: Authoritative Baseline Preservation (2026-09)
    # -------------------------------------------------------------------------
    print("\n[1] Verifying Authoritative Financial Baseline Preservation (2026-09)...")
    end_date = refresh_svc.metric_service._get_period_end_date("2026-09")
    cash_val = refresh_svc.engine.calculate_balance_as_of(FinancialConcept.CASH, end_date)
    ar_detail = refresh_svc.metric_service.calculate_receivables("2026-09")
    ar_val = ar_detail.accounts_receivable.value
    inv_detail = refresh_svc.metric_service.calculate_inventory("2026-09")
    inv_val = inv_detail.inventory_value.value
    ap_detail = refresh_svc.metric_service.calculate_payables("2026-09")
    ccc_metric = refresh_svc.metric_service.get_metric_by_name("cash_conversion_cycle", "2026-09")
    pnl = refresh_svc.metric_service.calculate_profitability("2026-09")
    wc = refresh_svc.metric_service.calculate_working_capital("2026-09")
    ar_summary = refresh_svc.engine.get_ar_summary(end_date)

    assert cash_val == 813750.00, f"Cash mismatch: {cash_val}"
    assert ar_val == 2984000.00, f"Trade AR mismatch: {ar_val}"
    assert inv_val == 2656840.00, f"Inventory mismatch: {inv_val}"
    assert pnl.revenue.value == 1490000.00, f"Revenue mismatch: {pnl.revenue.value}"
    assert pnl.cogs.value == 889860.00, f"COGS mismatch: {pnl.cogs.value}"
    assert pnl.gross_profit.value == 600140.00, f"Gross profit mismatch: {pnl.gross_profit.value}"
    assert round(pnl.gross_margin_percent.value, 2) == 40.28, f"Gross margin mismatch: {pnl.gross_margin_percent.value}"
    assert round(ar_detail.dso.value, 1) == 60.1, f"DSO mismatch: {ar_detail.dso.value}"
    assert round(inv_detail.dio.value, 1) == 89.6, f"DIO mismatch: {inv_detail.dio.value}"
    assert round(ap_detail.dpo.value, 1) == 60.2, f"DPO mismatch: {ap_detail.dpo.value}"
    assert round(ccc_metric.value, 1) == 89.5, f"CCC mismatch: {ccc_metric.value}"
    assert ar_summary["total_overdue_ar"] == 1044000.00, f"Overdue AR mismatch: {ar_summary['total_overdue_ar']}"

    print(f"  [OK] Cash: ${cash_val:,.2f} | Trade AR: ${ar_val:,.2f} | Inventory: ${inv_val:,.2f}")
    print(f"  [OK] Revenue: ${pnl.revenue.value:,.2f} | COGS: ${pnl.cogs.value:,.2f} | Gross Profit: ${pnl.gross_profit.value:,.2f}")
    print(f"  [OK] Gross Margin: {pnl.gross_margin_percent.value:.2f}% | DSO: {ar_detail.dso.value:.1f}d | DIO: {inv_detail.dio.value:.1f}d | DPO: {ap_detail.dpo.value:.1f}d | CCC: {ccc_metric.value:.1f}d")
    print(f"  [OK] Overdue AR: ${ar_summary['total_overdue_ar']:,.2f}")

    # -------------------------------------------------------------------------
    # Checkpoint 2: What Changed Engine & Materiality Thresholds
    # -------------------------------------------------------------------------
    print("\n[2] Verifying 'What Changed' Engine & Materiality Thresholds...")
    all_changes = perf_svc.get_what_changed(period="2026-09", only_material=False)
    material_changes = perf_svc.get_what_changed(period="2026-09", only_material=True)

    assert len(all_changes) >= 12, f"Expected >= 12 tracked metrics, found {len(all_changes)}"
    assert len(material_changes) < len(all_changes), "Material filter did not reduce metric count"
    assert all(c.is_material for c in material_changes)

    gm_change = next((c for c in material_changes if c.metric_name == "gross_margin_percent"), None)
    assert gm_change is not None, "Gross margin not detected in material changes"
    assert gm_change.current_value == 40.28
    assert gm_change.previous_value == 42.05
    assert gm_change.absolute_change == -1.77
    assert gm_change.direction == TrendDirection.DECREASING
    print(f"  [OK] Tracked Metrics: {len(all_changes)} total | Material Changes: {len(material_changes)}")
    print(f"  [OK] Gross Margin Shift: {gm_change.formatted_previous} -> {gm_change.formatted_current} ({gm_change.formatted_change}) [{gm_change.materiality_reason}]")

    # -------------------------------------------------------------------------
    # Checkpoint 3: Causal Multivariate Driver Decomposition: Gross Margin
    # -------------------------------------------------------------------------
    print("\n[3] Verifying Causal Driver Decomposition for Gross Margin...")
    gm_drivers = perf_svc.get_metric_drivers("gross_margin_percent", period="2026-09")
    assert isinstance(gm_drivers, MetricDriverResponse)
    assert gm_drivers.metric_name == "gross_margin_percent"
    assert len(gm_drivers.primary_driver) > 0
    assert len(gm_drivers.candidate_drivers) >= 2
    assert len(gm_drivers.customer_contributors) >= 3
    assert len(gm_drivers.product_contributors) >= 2
    assert len(gm_drivers.evidence) >= 2

    print(f"  [OK] Primary Driver: '{gm_drivers.primary_driver}'")
    print(f"  [OK] Candidate Drivers Identified: {len(gm_drivers.candidate_drivers)}")
    for cd in gm_drivers.candidate_drivers:
        print(f"       * {cd.name}: {cd.description} (Impact: ${cd.impact_amount:,.2f})")

    # -------------------------------------------------------------------------
    # Checkpoint 4: Exact Mathematical Reconciliation of Gross Profit Delta
    # -------------------------------------------------------------------------
    print("\n[4] Verifying Exact Mathematical Reconciliation of Gross Profit Variance...")
    gp_drivers = perf_svc.get_metric_drivers("gross_profit", period="2026-09")
    total_gp_delta = gp_drivers.absolute_change  # -$22,260.00
    assert total_gp_delta == -22260.00, f"Expected -$22,260.00, got {total_gp_delta}"

    cust_sum = sum(c.change_amount for c in gp_drivers.customer_contributors)
    prod_sum = sum(p.change_amount for p in gp_drivers.product_contributors)

    assert abs(cust_sum - total_gp_delta) < 0.01, f"Customer sum {cust_sum} != portfolio {total_gp_delta}"
    assert abs(prod_sum - total_gp_delta) < 0.01, f"Product sum {prod_sum} != portfolio {total_gp_delta}"

    print(f"  [OK] Total Portfolio Gross Profit Change: ${total_gp_delta:+,.2f}")
    print(f"  [OK] Customer Contributions Sum:        ${cust_sum:+,.2f} (100.0% reconciled)")
    print(f"  [OK] Product Group Contributions Sum:    ${prod_sum:+,.2f} (100.0% reconciled)")

    # -------------------------------------------------------------------------
    # Checkpoint 5: Customer Drivers & Margin Dilution Attribution
    # -------------------------------------------------------------------------
    print("\n[5] Verifying Customer Profitability & Margin Dilution Drivers...")
    cust_drivers = perf_svc.get_customer_drivers(period="2026-09", metric="gross_profit")
    apex = next((c for c in cust_drivers if "Apex" in c.entity_name), None)
    assert apex is not None, "Apex Retail Group not found in customer drivers"
    assert apex.change_amount == -24600.00
    assert apex.gross_margin_pct == 24.00
    assert apex.previous_gross_margin_pct == 30.00
    assert apex.margin_change_pp == -6.00
    assert abs(apex.contribution_share_pct - 110.51) < 0.1

    # Overdue AR
    cust_od = perf_svc.get_customer_drivers(period="2026-09", metric="overdue_ar")
    apex_od = next((c for c in cust_od if "Apex" in c.entity_name), None)
    assert apex_od is not None
    assert apex_od.current_value == 1044000.00
    assert apex_od.contribution_share_pct == 100.00

    print(f"  [OK] Top Profit Diluter: {apex.entity_name} (GP Change: ${apex.change_amount:+,.2f}, Margin: {apex.previous_gross_margin_pct}% -> {apex.gross_margin_pct}%)")
    print(f"  [OK] Customer Share of Total Contraction: {apex.contribution_share_pct}%")
    print(f"  [OK] Overdue AR Concentration: {apex_od.entity_name} drives ${apex_od.current_value:,.2f} (100% of overdue exposure)")

    # -------------------------------------------------------------------------
    # Checkpoint 6: Product Drivers & Margin Contraction Attribution
    # -------------------------------------------------------------------------
    print("\n[6] Verifying Product Group Drivers & COGS Creep Attribution...")
    prod_drivers = perf_svc.get_product_drivers(period="2026-09", metric="gross_profit")
    hw = next((p for p in prod_drivers if "Hardware" in p.entity_name), None)
    sw = next((p for p in prod_drivers if "Software" in p.entity_name), None)
    assert hw is not None and sw is not None
    assert hw.change_amount == -24420.00
    assert sw.change_amount == +2160.00

    print(f"  [OK] Hardware Product Group: GP Change ${hw.change_amount:+,.2f} (Margin: {hw.previous_gross_margin_pct:.1f}% -> {hw.gross_margin_pct:.1f}%)")
    print(f"  [OK] Software Product Group: GP Change ${sw.change_amount:+,.2f} (Margin: {sw.previous_gross_margin_pct:.1f}% -> {sw.gross_margin_pct:.1f}%)")

    # -------------------------------------------------------------------------
    # Checkpoint 7: Working Capital & Cash Conversion Drivers
    # -------------------------------------------------------------------------
    print("\n[7] Verifying Working Capital & Cash Conversion Cycle Drivers...")
    nwc_drivers = perf_svc.get_metric_drivers("net_working_capital", period="2026-09")
    ccc_drivers = perf_svc.get_metric_drivers("cash_conversion_cycle", period="2026-09")
    cash_drivers = perf_svc.get_metric_drivers("cash_position", period="2026-09")

    assert len(nwc_drivers.candidate_drivers) >= 2
    assert len(ccc_drivers.candidate_drivers) >= 3
    assert len(cash_drivers.evidence) >= 1

    print(f"  [OK] Net Working Capital Drivers: {', '.join(cd.name for cd in nwc_drivers.candidate_drivers)}")
    print(f"  [OK] CCC Drivers: {', '.join(cd.name for cd in ccc_drivers.candidate_drivers)}")
    print(f"  [OK] Cash Position Drivers & Subledger Evidence: {len(cash_drivers.evidence)} traceable open items")

    # -------------------------------------------------------------------------
    # Checkpoint 8: Traceable Financial Evidence & Audit Trail
    # -------------------------------------------------------------------------
    print("\n[8] Verifying Traceable Financial Evidence & Audit Trail...")
    for ev in gm_drivers.evidence:
        assert ev.source_id is not None
        assert ev.source_type is not None
        assert len(ev.description) > 0
    print(f"  [OK] Verified {len(gm_drivers.evidence)} evidence items anchored to segment P&L and GL subledger records")

    # -------------------------------------------------------------------------
    # Checkpoint 9: REST API Endpoints Verification via TestClient
    # -------------------------------------------------------------------------
    print("\n[9] Verifying Performance REST API Endpoints via TestClient...")
    
    # GET /api/performance
    r1 = client.get("/api/performance?period=2026-09")
    assert r1.status_code == 200
    d1 = r1.json()
    assert d1["revenue"] == 1490000.00
    assert d1["gross_margin_pct"] == 40.28
    assert d1["gross_profit"] == 600140.00
    assert len(d1["what_changed"]) > 0
    print("  [OK] GET /api/performance -> 200 OK (Executive cockpit payload)")

    # GET /api/performance/what-changed
    r2 = client.get("/api/performance/what-changed?period=2026-09&only_material=true")
    assert r2.status_code == 200
    d2 = r2.json()
    assert isinstance(d2, list)
    assert all(it["is_material"] for it in d2)
    print(f"  [OK] GET /api/performance/what-changed?only_material=true -> 200 OK ({len(d2)} items)")

    # GET /api/performance/drivers
    r3 = client.get("/api/performance/drivers?metric=gross_margin_percent&period=2026-09")
    assert r3.status_code == 200
    d3 = r3.json()
    assert d3["metric_name"] == "gross_margin_percent"
    assert "primary_driver" in d3
    print("  [OK] GET /api/performance/drivers?metric=gross_margin_percent -> 200 OK")

    # GET /api/performance/customers
    r4 = client.get("/api/performance/customers?period=2026-09&metric=gross_profit")
    assert r4.status_code == 200
    d4 = r4.json()
    assert isinstance(d4, list)
    print(f"  [OK] GET /api/performance/customers -> 200 OK ({len(d4)} customers)")

    # GET /api/performance/products
    r5 = client.get("/api/performance/products?period=2026-09&metric=gross_profit")
    assert r5.status_code == 200
    d5 = r5.json()
    assert isinstance(d5, list)
    print(f"  [OK] GET /api/performance/products -> 200 OK ({len(d5)} product groups)")

    # -------------------------------------------------------------------------
    # Checkpoint 10: Frontend Integration & Zero Hardcoded Financial Values
    # -------------------------------------------------------------------------
    print("\n[10] Verifying Frontend Source of Truth (Zero Hardcoded Financials)...")
    perf_js_path = Path(src_dir) / "finsight" / "static" / "js" / "pages" / "performance.js"
    api_js_path = Path(src_dir) / "finsight" / "static" / "js" / "services" / "api.js"
    assert perf_js_path.exists(), "performance.js missing"
    assert api_js_path.exists(), "api.js missing"

    perf_js_content = perf_js_path.read_text(encoding="utf-8")
    api_js_content = api_js_path.read_text(encoding="utf-8")

    # Check that API methods exist in api.js
    assert "getPerformanceSummary" in api_js_content
    assert "getPerformanceWhatChanged" in api_js_content
    assert "getPerformanceDrivers" in api_js_content
    assert "getPerformanceCustomers" in api_js_content
    assert "getPerformanceProducts" in api_js_content
    print("  [OK] api.js exposes all required performance API client methods")

    # Check that performance.js does not hardcode static financial baseline numbers
    forbidden_numbers = ["1490000", "889860", "600140", "40.28", "813750", "2984000", "1044000"]
    for num in forbidden_numbers:
        # Search for raw literal assignment like revenue = 1490000 or "1490000"
        pattern = rf"\b{re.escape(num)}\b"
        match = re.search(pattern, perf_js_content)
        assert match is None, f"Found hardcoded baseline value '{num}' in performance.js!"
    print("  [OK] performance.js contains ZERO hardcoded financial numbers; dynamic rendering confirmed")

    print("\n" + "=" * 80)
    print("ALL SPRINT 9 PERFORMANCE & DRIVER INTELLIGENCE CHECKPOINTS PASSED (10/10)")
    print("=" * 80)
    return True


if __name__ == "__main__":
    success = run_sprint9_validation()
    sys.exit(0 if success else 1)
