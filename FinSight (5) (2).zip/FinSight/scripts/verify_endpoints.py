"""Verification script exercising all FinSight foundational API endpoints."""

import json
import sys
from pathlib import Path
from starlette.testclient import TestClient

src_dir = str(Path(__file__).parent.parent / "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from finsight.api.app import app


def verify_all_endpoints():
    client = TestClient(app)

    endpoints = [
        ("GET", "/health"),
        ("GET", "/api/status"),
        ("POST", "/api/refresh"),
        ("GET", "/api/financial-summary?period=2026-09"),
        ("GET", "/api/attention?period=2026-09"),
        ("GET", "/api/intelligence?period=2026-09"),
        ("GET", "/api/intelligence/report?period=2026-09"),
        ("GET", "/api/cases"),
        ("GET", "/api/cash?period=2026-09"),
        ("GET", "/api/receivables?period=2026-09"),
        ("GET", "/api/payables?period=2026-09"),
        ("GET", "/api/inventory?period=2026-09"),
        ("GET", "/api/profitability?period=2026-09"),
        ("GET", "/api/metrics?metric=dso&period=2026-09"),
        ("GET", "/api/data-quality"),
    ]

    print("\n================== FINSIGHT API VERIFICATION ==================")
    all_ok = True
    for method, path in endpoints:
        if method == "GET":
            response = client.get(path)
        else:
            response = client.post(path)

        status_flag = "PASS" if response.status_code == 200 else "FAIL"
        if response.status_code != 200:
            all_ok = False
        print(f"[{status_flag}] {method:<4} {path:<40} -> HTTP {response.status_code}")

    print("===============================================================")
    if all_ok:
        print("ALL API ENDPOINTS ARE FULLY OPERATIONAL AND RETURNING REAL FINANCIAL DATA.\n")
    else:
        print("SOME ENDPOINTS FAILED.\n")


if __name__ == "__main__":
    verify_all_endpoints()
