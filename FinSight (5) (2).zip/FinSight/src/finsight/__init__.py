"""FinSight — Financial Intelligence & Control.

Canonical financial model, deterministic metric engine, and AI-ready architecture.
"""

__version__ = "0.1.0"
