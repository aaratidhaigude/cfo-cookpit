"""Source adapters for FinSight."""

from finsight.adapters.base import BaseFinancialAdapter
from finsight.adapters.mock_adapter import MockFinancialAdapter
from finsight.adapters.sap_adapter import SAPODataAdapter

__all__ = ["BaseFinancialAdapter", "MockFinancialAdapter", "SAPODataAdapter"]
