"""Abstract Base Financial Adapter for FinSight.

Defines the contract for fetching financial entities from any underlying system
(Mock generator, flat files, SAP OData / CDS Views, ERP databases).
"""

from abc import ABC, abstractmethod
from datetime import date
from typing import Any, Dict, List, Optional

from finsight.models.canonical import (
    AccountMapping,
    APOpenItem,
    AROpenItem,
    Company,
    Customer,
    JournalEntry,
    Product,
    Vendor,
)


class BaseFinancialAdapter(ABC):
    """Abstract interface for extracting financial data into Canonical Models."""

    @property
    @abstractmethod
    def adapter_name(self) -> str:
        """Returns the identifier of the adapter implementation."""
        pass

    @abstractmethod
    def get_company(self) -> Company:
        """Retrieve company information."""
        pass

    @abstractmethod
    def get_customers(self) -> List[Customer]:
        """Retrieve customer master records."""
        pass

    @abstractmethod
    def get_vendors(self) -> List[Vendor]:
        """Retrieve vendor master records."""
        pass

    @abstractmethod
    def get_products(self) -> List[Product]:
        """Retrieve product master records."""
        pass

    @abstractmethod
    def get_account_mappings(self) -> List[AccountMapping]:
        """Retrieve chart of accounts mapping to canonical financial concepts."""
        pass

    @abstractmethod
    def get_journal_entries(self, period: Optional[str] = None) -> List[JournalEntry]:
        """Retrieve general ledger journal entries, optionally filtered by period ('YYYY-MM')."""
        pass

    @abstractmethod
    def get_ar_items(self, as_of_date: Optional[date] = None) -> List[AROpenItem]:
        """Retrieve accounts receivable items (open and cleared)."""
        pass

    @abstractmethod
    def get_ap_items(self, as_of_date: Optional[date] = None) -> List[APOpenItem]:
        """Retrieve accounts payable items (open and cleared)."""
        pass

    @abstractmethod
    def get_raw_dataset(self) -> Dict[str, Any]:
        """Retrieve raw snapshot dictionary of all loaded entity lists."""
        pass
