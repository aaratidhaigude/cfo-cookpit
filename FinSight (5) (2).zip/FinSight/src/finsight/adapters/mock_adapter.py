"""Deterministic Mock Financial Data Adapter for FinSight.

Generates 12 months of realistic ERP ledger and subledger data containing
the 9 required intentional business scenarios with complete referential integrity.
"""

from datetime import date, datetime, timedelta
import random
from typing import Any, Dict, List, Optional

from finsight.adapters.base import BaseFinancialAdapter
from finsight.models.canonical import (
    AccountCategory,
    AccountMapping,
    APOpenItem,
    AROpenItem,
    Company,
    Customer,
    FinancialConcept,
    JournalEntry,
    Product,
    Vendor,
)
from enum import Enum
from finsight.config import settings


class DeterministicScenario(str, Enum):
    """Governed deterministic operational financial scenarios for stress testing and forecasting."""
    NORMAL = "NORMAL"
    AR_DETERIORATION = "AR_DETERIORATION"
    INVENTORY_BUILDUP = "INVENTORY_BUILDUP"
    MARGIN_DECLINE = "MARGIN_DECLINE"
    LIQUIDITY_PRESSURE = "LIQUIDITY_PRESSURE"


class MockFinancialAdapter(BaseFinancialAdapter):
    """Generates and serves canonical financial models from deterministic synthetic data."""

    def __init__(self, seed: int = 42, reference_date: Optional[date] = None):
        self._seed = seed
        self._rnd = random.Random(seed)
        self._reference_date = reference_date or date(2026, 9, 30)
        self._company: Optional[Company] = None
        self._customers: List[Customer] = []
        self._vendors: List[Vendor] = []
        self._products: List[Product] = []
        self._account_mappings: List[AccountMapping] = []
        self._journal_entries: List[JournalEntry] = []
        self._ar_items: List[AROpenItem] = []
        self._ap_items: List[APOpenItem] = []
        self._generate_dataset()

    @property
    def adapter_name(self) -> str:
        return "mock_financial_adapter"

    def get_company(self) -> Company:
        return self._company  # type: ignore

    def get_customers(self) -> List[Customer]:
        return list(self._customers)

    def get_vendors(self) -> List[Vendor]:
        return list(self._vendors)

    def get_products(self) -> List[Product]:
        return list(self._products)

    def get_account_mappings(self) -> List[AccountMapping]:
        return list(self._account_mappings)

    def get_journal_entries(self, period: Optional[str] = None) -> List[JournalEntry]:
        if period:
            year_str, month_str = period.split("-")
            year, month = int(year_str), int(month_str)
            return [e for e in self._journal_entries if e.fiscal_year == year and e.fiscal_period == month]
        return list(self._journal_entries)

    def get_ar_items(self, as_of_date: Optional[date] = None) -> List[AROpenItem]:
        # Return all items; if as_of_date is passed, callers evaluate open status relative to as_of_date
        return list(self._ar_items)

    def get_ap_items(self, as_of_date: Optional[date] = None) -> List[APOpenItem]:
        return list(self._ap_items)

    def get_raw_dataset(self) -> Dict[str, Any]:
        return {
            "company": self._company.model_dump() if self._company else {},
            "customers": [c.model_dump() for c in self._customers],
            "vendors": [v.model_dump() for v in self._vendors],
            "products": [p.model_dump() for p in self._products],
            "account_mappings": [m.model_dump() for m in self._account_mappings],
            "journal_entries": [j.model_dump() for j in self._journal_entries],
            "ar_items": [ar.model_dump() for ar in self._ar_items],
            "ap_items": [ap.model_dump() for ap in self._ap_items],
            "meta": {
                "seed": self._seed,
                "reference_date": self._reference_date.isoformat(),
                "adapter": self.adapter_name,
            },
        }

    # -------------------------------------------------------------------------
    # Internal Generation Pipeline
    # -------------------------------------------------------------------------

    def _generate_dataset(self) -> None:
        self._company = Company(
            company_code="1000",
            company_name="FinSight Global Technologies Inc.",
            controlling_area="CA01",
            fiscal_calendar="K4",
            currency=settings.default_currency,
        )
        self._init_master_data()
        self._init_account_mappings()
        self._generate_12_month_ledger_and_subledgers()

    def _init_master_data(self) -> None:
        # Customers
        self._customers = [
            Customer(
                customer_id="CUST-101",
                customer_name="Apex Retail Group",
                segment="Enterprise",
                region="North America",
                payment_terms="NET30",
                industry="Retail & E-Commerce",
                credit_limit=2500000.0,
                risk_class="High Risk",
            ),
            Customer(
                customer_id="CUST-102",
                customer_name="Nordic Solutions AG",
                segment="Enterprise",
                region="EMEA",
                payment_terms="NET30",
                industry="Technology Solutions",
                credit_limit=1500000.0,
                risk_class="Low Risk",
            ),
            Customer(
                customer_id="CUST-103",
                customer_name="Vanguard Tech Corp",
                segment="Mid-Market",
                region="North America",
                payment_terms="NET45",
                industry="IT & Cloud Infrastructure",
                credit_limit=800000.0,
                risk_class="Medium Risk",
            ),
            Customer(
                customer_id="CUST-104",
                customer_name="OmniChannel Logistics",
                segment="Wholesale",
                region="North America",
                payment_terms="NET60",
                industry="Logistics & Distribution",
                credit_limit=1200000.0,
                risk_class="Medium Risk",
            ),
            Customer(
                customer_id="CUST-105",
                customer_name="Zenith Health Systems",
                segment="Enterprise",
                region="North America",
                payment_terms="NET30",
                industry="Healthcare & Life Sciences",
                credit_limit=1000000.0,
                risk_class="Low Risk",
            ),
            Customer(
                customer_id="CUST-106",
                customer_name="Pacific Rim Trading",
                segment="SMB",
                region="APAC",
                payment_terms="NET30",
                industry="Import & Export",
                credit_limit=500000.0,
                risk_class="Low Risk",
            ),
            Customer(
                customer_id="CUST-107",
                customer_name="BlueSky Telecom",
                segment="Mid-Market",
                region="EMEA",
                payment_terms="NET45",
                industry="Telecommunications",
                credit_limit=600000.0,
                risk_class="Medium Risk",
            ),
            Customer(
                customer_id="CUST-108",
                customer_name="Quantum Industrial",
                segment="Enterprise",
                region="North America",
                payment_terms="NET30",
                industry="Industrial Manufacturing",
                credit_limit=900000.0,
                risk_class="Low Risk",
            ),
        ]

        # Vendors
        self._vendors = [
            Vendor(
                vendor_id="VEND-201",
                vendor_name="Titan Semiconductor Ltd",
                category="Raw Materials",
                payment_terms="NET30",
                region="APAC",
                criticality="Critical",
            ),
            Vendor(
                vendor_id="VEND-202",
                vendor_name="Precision Metalworks",
                category="Raw Materials",
                payment_terms="NET30",
                region="North America",
                criticality="High",
            ),
            Vendor(
                vendor_id="VEND-203",
                vendor_name="Global Freight & Logistics",
                category="Logistics",
                payment_terms="NET15",
                region="Global",
                criticality="Medium",
            ),
            Vendor(
                vendor_id="VEND-204",
                vendor_name="CloudScale Infrastructure",
                category="IT Services",
                payment_terms="NET30",
                region="North America",
                criticality="Medium",
            ),
            Vendor(
                vendor_id="VEND-205",
                vendor_name="Apex Packaging Corp",
                category="Raw Materials",
                payment_terms="NET30",
                region="North America",
                criticality="Low",
            ),
            Vendor(
                vendor_id="VEND-206",
                vendor_name="Nexus Facilities Management",
                category="Facilities",
                payment_terms="NET30",
                region="North America",
                criticality="Low",
            ),
        ]

        # Products
        self._products = [
            Product(
                product_id="PRD-001",
                product_name="FinSight Core Analytics Platform",
                product_group="Software",
                profit_center="PC-100",
                material_id="MAT-SFT-001",
                material_group="MG-SW",
                product_family="Software & Platforms",
                standard_cost=25000.0,
                selling_price=90000.0,
                unit="LIC",
            ),
            Product(
                product_id="PRD-002",
                product_name="Industrial Edge Controller X7",
                product_group="Hardware",
                profit_center="PC-200",
                material_id="MAT-HW-002",
                material_group="MG-HW",
                product_family="Industrial Automation",
                standard_cost=1500.0,
                selling_price=3800.0,
                unit="EA",
            ),
            Product(
                product_id="PRD-003",
                product_name="Precision Telemetry Sensor",
                product_group="Hardware",
                profit_center="PC-200",
                material_id="MAT-HW-003",
                material_group="MG-HW",
                product_family="Telemetry & Sensors",
                standard_cost=450.0,
                selling_price=1200.0,
                unit="EA",
            ),
            Product(
                product_id="PRD-004",
                product_name="Commodity Micro-Server Unit",
                product_group="Hardware",
                profit_center="PC-300",
                material_id="MAT-HW-004",
                material_group="MG-HW",
                product_family="Enterprise Servers",
                standard_cost=2200.0,
                selling_price=2400.0,
                unit="EA",
            ),
            Product(
                product_id="PRD-005",
                product_name="Enterprise Integration Services",
                product_group="Services",
                profit_center="PC-100",
                material_id="MAT-SRV-005",
                material_group="MG-SRV",
                product_family="Professional Services",
                standard_cost=120.0,
                selling_price=250.0,
                unit="HR",
            ),
        ]

    def _init_account_mappings(self) -> None:
        start_date = date(2025, 1, 1)
        self._account_mappings = [
            AccountMapping(gl_account="101000", financial_concept=FinancialConcept.CASH, category=AccountCategory.ASSET, valid_from=start_date),
            AccountMapping(gl_account="102000", financial_concept=FinancialConcept.CASH, category=AccountCategory.ASSET, valid_from=start_date),
            AccountMapping(gl_account="110000", financial_concept=FinancialConcept.AR, category=AccountCategory.ASSET, valid_from=start_date),
            AccountMapping(gl_account="120000", financial_concept=FinancialConcept.INVENTORY, category=AccountCategory.ASSET, valid_from=start_date),
            AccountMapping(gl_account="121000", financial_concept=FinancialConcept.INVENTORY, category=AccountCategory.ASSET, valid_from=start_date),
            AccountMapping(gl_account="130000", financial_concept=FinancialConcept.OTHER_CURRENT_ASSET, category=AccountCategory.ASSET, valid_from=start_date),
            AccountMapping(gl_account="150000", financial_concept=FinancialConcept.NON_CURRENT_ASSET, category=AccountCategory.ASSET, valid_from=start_date),
            AccountMapping(gl_account="200000", financial_concept=FinancialConcept.AP, category=AccountCategory.LIABILITY, valid_from=start_date),
            AccountMapping(gl_account="210000", financial_concept=FinancialConcept.OTHER_CURRENT_LIABILITY, category=AccountCategory.LIABILITY, valid_from=start_date),
            AccountMapping(gl_account="220000", financial_concept=FinancialConcept.SHORT_TERM_DEBT, category=AccountCategory.LIABILITY, valid_from=start_date),
            AccountMapping(gl_account="250000", financial_concept=FinancialConcept.LONG_TERM_LIABILITY, category=AccountCategory.LIABILITY, valid_from=start_date),
            AccountMapping(gl_account="300000", financial_concept=FinancialConcept.EQUITY, category=AccountCategory.EQUITY, valid_from=start_date),
            AccountMapping(gl_account="310000", financial_concept=FinancialConcept.EQUITY, category=AccountCategory.EQUITY, valid_from=start_date),
            AccountMapping(gl_account="400000", financial_concept=FinancialConcept.REVENUE, category=AccountCategory.REVENUE, valid_from=start_date),
            AccountMapping(gl_account="410000", financial_concept=FinancialConcept.REVENUE, category=AccountCategory.REVENUE, valid_from=start_date),
            AccountMapping(gl_account="500000", financial_concept=FinancialConcept.COGS, category=AccountCategory.EXPENSE, valid_from=start_date),
            AccountMapping(gl_account="510000", financial_concept=FinancialConcept.COGS, category=AccountCategory.EXPENSE, valid_from=start_date),
            AccountMapping(gl_account="600000", financial_concept=FinancialConcept.OPEX, category=AccountCategory.EXPENSE, valid_from=start_date),
            AccountMapping(gl_account="610000", financial_concept=FinancialConcept.OPEX, category=AccountCategory.EXPENSE, valid_from=start_date),
            AccountMapping(gl_account="620000", financial_concept=FinancialConcept.OPEX, category=AccountCategory.EXPENSE, valid_from=start_date),
        ]

    def _generate_12_month_ledger_and_subledgers(self) -> None:
        """Generates 12 fiscal periods (2025-10 through 2026-09) incorporating all 9 scenarios."""
        # 12 monthly periods:
        # Months 1-12: (2025, 10) to (2026, 9)
        periods = [
            (2025, 10), (2025, 11), (2025, 12),
            (2026, 1),  (2026, 2),  (2026, 3),
            (2026, 4),  (2026, 5),  (2026, 6),
            (2026, 7),  (2026, 8),  (2026, 9),
        ]

        doc_counter = 100001
        inv_ar_counter = 50001
        inv_ap_counter = 70001

        # Opening balance document on 2025-10-01
        opening_doc = f"DOC-{doc_counter}"
        doc_counter += 1
        opening_entries = [
            # Cash: ₹2,200,000
            JournalEntry(
                company_code="1000", fiscal_year=2025, fiscal_period=10,
                posting_date=date(2025, 10, 1), document_id=opening_doc,
                gl_account="101000", debit_credit="S", amount=2200000.0, currency=settings.default_currency
            ),
            # Inventory: $1,100,000
            JournalEntry(
                company_code="1000", fiscal_year=2025, fiscal_period=10,
                posting_date=date(2025, 10, 1), document_id=opening_doc,
                gl_account="120000", debit_credit="S", amount=1100000.0, currency=settings.default_currency
            ),
            # AR: ₹750,000
            JournalEntry(
                company_code="1000", fiscal_year=2025, fiscal_period=10,
                posting_date=date(2025, 10, 1), document_id=opening_doc,
                gl_account="110000", debit_credit="S", amount=750000.0, currency=settings.default_currency
            ),
            # PPE: ₹2,000,000
            JournalEntry(
                company_code="1000", fiscal_year=2025, fiscal_period=10,
                posting_date=date(2025, 10, 1), document_id=opening_doc,
                gl_account="150000", debit_credit="S", amount=2000000.0, currency=settings.default_currency
            ),
            # AP: ₹650,000 (Credit)
            JournalEntry(
                company_code="1000", fiscal_year=2025, fiscal_period=10,
                posting_date=date(2025, 10, 1), document_id=opening_doc,
                gl_account="200000", debit_credit="H", amount=650000.0, currency=settings.default_currency
            ),
            # Long Term Debt: ₹1,500,000 (Credit)
            JournalEntry(
                company_code="1000", fiscal_year=2025, fiscal_period=10,
                posting_date=date(2025, 10, 1), document_id=opening_doc,
                gl_account="250000", debit_credit="H", amount=1500000.0, currency=settings.default_currency
            ),
            # Equity / Retained Earnings: $3,900,000 (Credit)
            JournalEntry(
                company_code="1000", fiscal_year=2025, fiscal_period=10,
                posting_date=date(2025, 10, 1), document_id=opening_doc,
                gl_account="300000", debit_credit="H", amount=3900000.0, currency=settings.default_currency
            ),
        ]
        self._journal_entries.extend(opening_entries)

        # Baseline monthly sales profiles by customer
        # CUST-101 (Apex): ~₹380k - $420k/mo (Scenario 1 & 2)
        # CUST-102 (Nordic): ~₹320k - $360k/mo (Scenario 6)
        # CUST-103 (Vanguard): ~₹120k/mo
        # CUST-104 (OmniChannel): ~₹240k/mo (Scenario 7: PRD-004 commodity, low margin)
        # CUST-105 (Zenith): ~₹110k/mo
        # CUST-106 (Pacific Rim): ~₹60k/mo
        # CUST-107 (BlueSky): ~₹70k/mo
        # CUST-108 (Quantum): ~₹80k/mo

        for period_idx, (year, month) in enumerate(periods):
            # Days in month
            if month in (1, 3, 5, 7, 8, 10, 12):
                days_in_month = 31
            elif month in (4, 6, 9, 11):
                days_in_month = 30
            else:
                days_in_month = 28

            period_str = f"{year}-{month:02d}"

            # Base revenue increases gradually from $1.20M to $1.38M over 12 months
            # In periods 10, 11, 12 (July, Aug, Sept 2026), Scenario 5 (Margin Compression) kicks in:
            # Revenue expands or is stable, but raw material costs from VEND-201 jump dramatically!

            # Iterate over customers to generate monthly sales & invoices
            for cust in self._customers:
                if cust.customer_id == "CUST-101":
                    # Apex Retail: ~₹380,000 - $440,000 (Scenario 1 & Scenario 9)
                    rev = 380000.0 + (period_idx * 5000.0)
                    product_id = "PRD-002"  # Edge Controller
                    cost_ratio = 0.58 if period_idx < 9 else (0.64 + (period_idx - 9) * 0.06) # Margin compression in late periods
                elif cust.customer_id == "CUST-102":
                    # Nordic Solutions: ~₹320,000 - $360,000 (Scenario 6: Healthy)
                    rev = 320000.0 + (period_idx * 3000.0)
                    product_id = "PRD-001"  # Analytics Platform (Software: high margin)
                    cost_ratio = 0.28  # Healthy 72% gross margin
                elif cust.customer_id == "CUST-104":
                    # OmniChannel Logistics: ~₹240,000 (Scenario 7: High Revenue / Low Profitability)
                    rev = 240000.0 + (period_idx * 2000.0)
                    product_id = "PRD-004"  # Commodity Server Blade
                    cost_ratio = 0.91  # 91% COGS -> only 9% Gross Margin!
                elif cust.customer_id == "CUST-103":
                    rev = 120000.0
                    product_id = "PRD-003"
                    cost_ratio = 0.60
                elif cust.customer_id == "CUST-105":
                    rev = 110000.0
                    product_id = "PRD-001"
                    cost_ratio = 0.35
                elif cust.customer_id == "CUST-106":
                    rev = 60000.0
                    product_id = "PRD-002"
                    cost_ratio = 0.60
                elif cust.customer_id == "CUST-107":
                    rev = 70000.0
                    product_id = "PRD-005"
                    cost_ratio = 0.45
                else:
                    rev = 80000.0
                    product_id = "PRD-003"
                    cost_ratio = 0.55

                cogs = round(rev * cost_ratio, 2)
                posting_day = min(15 + (self._rnd.randint(0, 10)), days_in_month)
                inv_date = date(year, month, posting_day)

                # Payment terms to due_date
                term_days = 30
                if "45" in cust.payment_terms:
                    term_days = 45
                elif "60" in cust.payment_terms:
                    term_days = 60
                due_date = inv_date + timedelta(days=term_days)

                inv_id = f"INV-AR-{inv_ar_counter}"
                inv_ar_counter += 1

                # Determine clearing / payment status based on scenarios:
                # Scenario 1: Apex Retail (CUST-101) payment deterioration
                # In earlier periods (0 to 7: Oct 2025 to May 2026), Apex paid on time or slight delay.
                # In periods 8, 9, 10, 11 (June, July, August, September 2026), Apex stopped paying!
                # Result: July, August, September invoices remain completely open as of reference date 2026-09-30!
                # In June, partially paid.
                open_amount = 0.0
                clearing_date = None

                if cust.customer_id == "CUST-101":
                    if period_idx >= 9:  # July, Aug, Sept 2026
                        open_amount = rev  # 100% open
                        clearing_date = None
                    elif period_idx == 8:  # June 2026
                        open_amount = round(rev * 0.45, 2)  # 45% still open and overdue (>90 days!)
                        clearing_date = None
                    else:
                        clearing_date = due_date + timedelta(days=self._rnd.randint(2, 8))
                elif cust.customer_id == "CUST-102":
                    # Scenario 6: Healthy Customer (Nordic Solutions)
                    # Consistently pays on time within terms (or 2-5 days early).
                    # Period 11 (September 2026) was issued mid-month with NET30, so due mid-October.
                    # It is open but NOT overdue! All prior periods (0 to 10) are cleared.
                    if period_idx == 11:
                        open_amount = rev
                        clearing_date = None
                    else:
                        clearing_date = due_date - timedelta(days=self._rnd.randint(1, 4))
                elif cust.customer_id == "CUST-103":
                    # Vanguard: pays with minor delay. Period 11 and 10 open.
                    if period_idx >= 10:
                        open_amount = rev
                        clearing_date = None
                    else:
                        clearing_date = due_date + timedelta(days=12)
                else:
                    # Other customers: typical payment cycle
                    if period_idx == 11:
                        open_amount = rev
                        clearing_date = None
                    elif period_idx == 10 and term_days >= 45:
                        open_amount = rev
                        clearing_date = None
                    else:
                        clearing_date = due_date + timedelta(days=self._rnd.randint(3, 10))

                ar_item = AROpenItem(
                    company_code="1000",
                    customer_id=cust.customer_id,
                    invoice_id=inv_id,
                    invoice_date=inv_date,
                    due_date=due_date,
                    clearing_date=clearing_date,
                    invoice_amount=rev,
                    open_amount=open_amount,
                    currency=settings.default_currency,
                )
                self._ar_items.append(ar_item)

                # GL Journal Entry for Revenue & AR
                doc_rev = f"DOC-{doc_counter}"
                doc_counter += 1
                self._journal_entries.extend([
                    # Debit AR Control (110000)
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=inv_date, document_id=doc_rev,
                        gl_account="110000", customer_id=cust.customer_id, product_id=product_id,
                        debit_credit="S", amount=rev, currency=settings.default_currency
                    ),
                    # Credit Revenue (400000)
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=inv_date, document_id=doc_rev,
                        gl_account="400000", customer_id=cust.customer_id, product_id=product_id,
                        profit_center="PC-100" if "001" in product_id or "005" in product_id else "PC-200",
                        debit_credit="H", amount=rev, currency=settings.default_currency
                    ),
                ])

                # GL Journal Entry for COGS & Inventory Relief
                doc_cogs = f"DOC-{doc_counter}"
                doc_counter += 1
                self._journal_entries.extend([
                    # Debit COGS (500000)
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=inv_date, document_id=doc_cogs,
                        gl_account="500000", customer_id=cust.customer_id, product_id=product_id,
                        debit_credit="S", amount=cogs, currency=settings.default_currency
                    ),
                    # Credit Finished Goods Inventory (120000)
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=inv_date, document_id=doc_cogs,
                        gl_account="120000", customer_id=cust.customer_id, product_id=product_id,
                        debit_credit="H", amount=cogs, currency=settings.default_currency
                    ),
                ])

                # If cleared, record Cash Inflow and AR relief
                paid_amount = rev - open_amount
                if paid_amount > 0:
                    cleared_dt = clearing_date or (inv_date + timedelta(days=20))
                    doc_pay = f"DOC-{doc_counter}"
                    doc_counter += 1
                    self._journal_entries.extend([
                        # Debit Cash (101000)
                        JournalEntry(
                            company_code="1000", fiscal_year=cleared_dt.year, fiscal_period=cleared_dt.month,
                            posting_date=cleared_dt, document_id=doc_pay,
                            gl_account="101000", customer_id=cust.customer_id,
                            debit_credit="S", amount=paid_amount, currency=settings.default_currency
                        ),
                        # Credit AR (110000)
                        JournalEntry(
                            company_code="1000", fiscal_year=cleared_dt.year, fiscal_period=cleared_dt.month,
                            posting_date=cleared_dt, document_id=doc_pay,
                            gl_account="110000", customer_id=cust.customer_id,
                            debit_credit="H", amount=paid_amount, currency=settings.default_currency
                        ),
                    ])

            # -----------------------------------------------------------------
            # Vendor Procurement & AP Subledger
            # -----------------------------------------------------------------
            # SCENARIO 4: INVENTORY BUILDUP
            # In periods 9, 10, 11 (July, Aug, Sept 2026), purchases ramp up heavily,
            # far outstripping sales, creating massive inventory buildup.
            inv_multiplier = 1.0
            if period_idx == 9:  # July
                inv_multiplier = 1.35
            elif period_idx == 10:  # August
                inv_multiplier = 1.55
            elif period_idx == 11:  # September
                inv_multiplier = 1.70

            for vend in self._vendors:
                if vend.vendor_id == "VEND-201":
                    # Titan Semiconductor: large procurement (Scenario 5 & 9)
                    base_pur = 480000.0 * inv_multiplier
                elif vend.vendor_id == "VEND-202":
                    # Precision Metalworks
                    base_pur = 240000.0 * inv_multiplier
                elif vend.vendor_id == "VEND-203":
                    # Global Freight
                    base_pur = 90000.0 * inv_multiplier
                elif vend.vendor_id == "VEND-204":
                    # CloudScale IT
                    base_pur = 65000.0
                elif vend.vendor_id == "VEND-205":
                    # Apex Packaging
                    base_pur = 95000.0 * inv_multiplier
                else:
                    # Nexus Facilities
                    base_pur = 35000.0

                pur_amount = round(base_pur, 2)
                posting_day = min(10 + self._rnd.randint(0, 10), days_in_month)
                vend_inv_date = date(year, month, posting_day)

                term_days = 30
                if "15" in vend.payment_terms:
                    term_days = 15
                elif "45" in vend.payment_terms:
                    term_days = 45
                vend_due_date = vend_inv_date + timedelta(days=term_days)

                ap_inv_id = f"INV-AP-{inv_ap_counter}"
                inv_ap_counter += 1

                ap_open_amount = 0.0
                ap_clearing_date = None

                # For the latest period (September 2026, period_idx == 11):
                # We intentionally craft SCENARIO 3: UPCOMING AP PRESSURE
                # Obligations due:
                # - Due today (2026-09-30)
                # - Due in 1-3 days (2026-10-01 to 2026-10-03)
                # - Due in 4-7 days (2026-10-04 to 2026-10-07)
                if period_idx == 11:
                    ap_open_amount = pur_amount
                    if vend.vendor_id == "VEND-202":
                        # Precision Metalworks: due TODAY (2026-09-30)
                        vend_due_date = self._reference_date
                    elif vend.vendor_id == "VEND-203":
                        # Global Freight: due in 2 days (2026-10-02)
                        vend_due_date = self._reference_date + timedelta(days=2)
                    elif vend.vendor_id == "VEND-201":
                        # Titan Semiconductor: split or due in 5 days (2026-10-05)
                        vend_due_date = self._reference_date + timedelta(days=5)
                    elif vend.vendor_id == "VEND-204":
                        # Due in 14 days
                        vend_due_date = self._reference_date + timedelta(days=14)
                    else:
                        vend_due_date = self._reference_date + timedelta(days=20)
                elif period_idx == 10:
                    # In August 2026, some items due in late Sept or overdue:
                    if vend.vendor_id == "VEND-205":
                        # Overdue vendor bill
                        ap_open_amount = pur_amount
                        vend_due_date = self._reference_date - timedelta(days=8)
                    else:
                        ap_clearing_date = vend_due_date - timedelta(days=2)
                else:
                    ap_clearing_date = vend_due_date

                ap_item = APOpenItem(
                    company_code="1000",
                    vendor_id=vend.vendor_id,
                    invoice_id=ap_inv_id,
                    invoice_date=vend_inv_date,
                    due_date=vend_due_date,
                    clearing_date=ap_clearing_date,
                    invoice_amount=pur_amount,
                    open_amount=ap_open_amount,
                    currency=settings.default_currency,
                )
                self._ap_items.append(ap_item)

                # GL Journal Entry for Procurement (Inventory / Expense vs AP)
                target_gl = "121000" if vend.category == "Raw Materials" else (
                    "600000" if vend.category == "Logistics" else (
                        "610000" if vend.category == "Facilities" else "620000"
                    )
                )
                doc_pur = f"DOC-{doc_counter}"
                doc_counter += 1
                self._journal_entries.extend([
                    # Debit Inventory or Expense
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=vend_inv_date, document_id=doc_pur,
                        gl_account=target_gl, vendor_id=vend.vendor_id,
                        debit_credit="S", amount=pur_amount, currency=settings.default_currency
                    ),
                    # Credit AP Control (200000)
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=vend_inv_date, document_id=doc_pur,
                        gl_account="200000", vendor_id=vend.vendor_id,
                        debit_credit="H", amount=pur_amount, currency=settings.default_currency
                    ),
                ])

                # If AP cleared, record Cash Outflow & AP relief
                ap_paid_amount = pur_amount - ap_open_amount
                if ap_paid_amount > 0:
                    ap_cleared_dt = ap_clearing_date or (vend_inv_date + timedelta(days=15))
                    doc_vend_pay = f"DOC-{doc_counter}"
                    doc_counter += 1
                    self._journal_entries.extend([
                        # Debit AP Control (200000)
                        JournalEntry(
                            company_code="1000", fiscal_year=ap_cleared_dt.year, fiscal_period=ap_cleared_dt.month,
                            posting_date=ap_cleared_dt, document_id=doc_vend_pay,
                            gl_account="200000", vendor_id=vend.vendor_id,
                            debit_credit="S", amount=ap_paid_amount, currency=settings.default_currency
                        ),
                        # Credit Cash (101000)
                        JournalEntry(
                            company_code="1000", fiscal_year=ap_cleared_dt.year, fiscal_period=ap_cleared_dt.month,
                            posting_date=ap_cleared_dt, document_id=doc_vend_pay,
                            gl_account="101000", vendor_id=vend.vendor_id,
                            debit_credit="H", amount=ap_paid_amount, currency=settings.default_currency
                        ),
                    ])

            # Strategic cash outflows in historical periods:
            # Period 4 (Feb 2026): CapEx modernization $1,000,000
            if period_idx == 4:
                doc_capex = f"DOC-{doc_counter}"
                doc_counter += 1
                capex_date = date(year, month, 20)
                self._journal_entries.extend([
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=capex_date, document_id=doc_capex,
                        gl_account="150000", debit_credit="S", amount=1000000.0, currency=settings.default_currency
                    ),
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=capex_date, document_id=doc_capex,
                        gl_account="101000", debit_credit="H", amount=1000000.0, currency=settings.default_currency
                    ),
                ])
            # Period 7 (May 2026): Debt reduction ₹600,000
            elif period_idx == 7:
                doc_debt = f"DOC-{doc_counter}"
                doc_counter += 1
                debt_date = date(year, month, 25)
                self._journal_entries.extend([
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=debt_date, document_id=doc_debt,
                        gl_account="250000", debit_credit="S", amount=600000.0, currency=settings.default_currency
                    ),
                    JournalEntry(
                        company_code="1000", fiscal_year=year, fiscal_period=month,
                        posting_date=debt_date, document_id=doc_debt,
                        gl_account="101000", debit_credit="H", amount=600000.0, currency=settings.default_currency
                    ),
                ])

            # -----------------------------------------------------------------
            # Monthly Operational Expenses (Payroll, Admin, Rent)
            # -----------------------------------------------------------------
            opex_amount = 185000.0
            doc_opex = f"DOC-{doc_counter}"
            doc_counter += 1
            opex_date = date(year, month, min(28, days_in_month))
            self._journal_entries.extend([
                # Debit G&A OPEX (610000)
                JournalEntry(
                    company_code="1000", fiscal_year=year, fiscal_period=month,
                    posting_date=opex_date, document_id=doc_opex,
                    gl_account="610000", debit_credit="S", amount=opex_amount, currency=settings.default_currency
                ),
                # Credit Cash (101000)
                JournalEntry(
                    company_code="1000", fiscal_year=year, fiscal_period=month,
                    posting_date=opex_date, document_id=doc_opex,
                    gl_account="101000", debit_credit="H", amount=opex_amount, currency=settings.default_currency
                ),
            ])
