"""FastAPI application package for FinSight."""

from finsight.api.app import app, create_app

__all__ = ["app", "create_app"]
