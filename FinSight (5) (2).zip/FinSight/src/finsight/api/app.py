from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.staticfiles import StaticFiles

from finsight.api.auth_routes import auth_router
from finsight.api.routes import get_knowledge_retriever, get_refresh_service, router
from finsight.auth.repository import get_auth_repository
from finsight.config import settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Warms up deterministic financial engine, metric calculations, and knowledge base on startup."""
    svc = get_refresh_service()
    # Eager calculation ensure everything is ready
    _ = svc.engine
    _ = svc.metric_service
    _ = svc.active_snapshot
    _ = get_knowledge_retriever()
    _ = get_auth_repository()
    yield


def create_app() -> FastAPI:
    """Creates and configures the FastAPI application instance."""
    app = FastAPI(
        title="FinSight — Financial Intelligence & Control API",
        description=(
            "Deterministic financial intelligence engine providing foundational metrics, "
            "canonical ERP data models, data quality governance, and AI-ready tool contracts."
        ),
        version=settings.version,
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # Configure explicit CORS for frontend clients / dashboards (Sprint 30)
    raw_origins = [o.strip() for o in settings.cors_allowed_origins.split(",") if o.strip()]
    if "*" in raw_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=False,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    else:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=raw_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    app.include_router(router)
    app.include_router(auth_router)

    # Mount static files for executive UI
    static_dir = Path(__file__).resolve().parent.parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir), html=True), name="static")
        if (static_dir / "js").exists():
            app.mount("/js", StaticFiles(directory=str(static_dir / "js")), name="js")
        if (static_dir / "css").exists():
            app.mount("/css", StaticFiles(directory=str(static_dir / "css")), name="css")
        app.mount("/", StaticFiles(directory=str(static_dir), html=True), name="root_static")

    return app


app = create_app()
