"""Authentication and RBAC REST API routes for FinSight."""

from typing import Any, Dict, List
from fastapi import APIRouter, Depends, HTTPException, status

from finsight.auth.dependencies import (
    bearer_scheme,
    get_current_user,
    require_role,
)
from finsight.auth.models import (
    LoginRequest,
    LoginResponse,
    User,
    UserProfile,
    UserRole,
)
from finsight.auth.repository import AuthRepository, get_auth_repository
from finsight.auth.security import verify_password
from finsight.config import settings

auth_router = APIRouter(tags=["Authentication & RBAC"])


@auth_router.post("/api/auth/login", response_model=LoginResponse)
def login(
    req: LoginRequest,
    repo: AuthRepository = Depends(get_auth_repository),
) -> LoginResponse:
    if repo.is_login_rate_limited(req.username):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many failed login attempts. Please wait 5 minutes before trying again.",
        )

    user = repo.get_user_by_username(req.username)
    if not user or not verify_password(req.password, user.password_hash):
        repo.record_failed_login(req.username)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    repo.clear_failed_logins(req.username)

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is deactivated.",
        )

    role_titles = {
        UserRole.ADMIN: "Finance Admin",
        UserRole.FINANCE_MANAGER: "Finance Manager",
        UserRole.FINANCE_ANALYST: "Finance Analyst",
    }
    session = repo.create_session(user)
    return LoginResponse(
        token=session.session_token,
        token_type="Bearer",
        expires_at=session.expires_at.isoformat(),
        user=UserProfile(
            id=user.id,
            username=user.username,
            email=user.email,
            full_name=user.full_name,
            role=user.role,
            is_active=user.is_active,
            display_title=f"{user.full_name} / {role_titles.get(user.role, user.role.value)}",
        ),
    )


@auth_router.post("/api/auth/logout")
def logout(
    auth: Any = Depends(bearer_scheme),
    repo: AuthRepository = Depends(get_auth_repository),
) -> Dict[str, Any]:
    """Invalidates the caller's session token."""
    if auth and auth.credentials:
        repo.invalidate_session(auth.credentials)
    return {"success": True, "message": "Logged out successfully."}


@auth_router.get("/api/auth/me", response_model=UserProfile)
def get_current_user_profile(
    current_user: User = Depends(get_current_user),
) -> UserProfile:
    """Returns the authenticated user's profile. Requires valid session."""
    role_titles = {
        UserRole.ADMIN: "Finance Admin",
        UserRole.FINANCE_MANAGER: "Finance Manager",
        UserRole.FINANCE_ANALYST: "Finance Analyst",
    }
    return UserProfile(
        id=current_user.id,
        username=current_user.username,
        email=current_user.email,
        full_name=current_user.full_name,
        role=current_user.role,
        is_active=current_user.is_active,
        display_title=f"{current_user.full_name} / {role_titles.get(current_user.role, current_user.role.value)}",
    )


@auth_router.get("/api/admin/users", response_model=List[UserProfile])
def list_system_users(
    _admin: User = Depends(require_role(UserRole.ADMIN)),
    repo: AuthRepository = Depends(get_auth_repository),
) -> List[UserProfile]:
    """Lists all users in the system. Restricted to ADMIN role."""
    return repo.list_users()


@auth_router.get("/api/admin/config")
def get_system_admin_config(
    _admin: User = Depends(require_role(UserRole.ADMIN)),
) -> Dict[str, Any]:
    """Returns runtime system configuration and governance flags. Restricted to ADMIN role."""
    return {
        "app_name": settings.app_name,
        "version": settings.version,
        "environment": settings.environment,
        "company_code": settings.company_code,
        "reference_date": settings.reference_date.isoformat(),
        "data_source": settings.data_source,
        "currency": settings.default_currency,
        "sap_mock_mode": settings.sap_mock_mode,
        "is_sap_live_configured": settings.is_sap_live_configured,
        "rbac_active": True,
        "governance_roles": [r.value for r in UserRole],
    }

