"""FastAPI Route Definitions for FinSight."""

from datetime import datetime, timezone
import re
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from finsight.auth.dependencies import get_current_user, get_optional_user, require_role
from finsight.auth.models import User, UserRole
from finsight.config import settings
from finsight.crm import CustomerCRMProfile, MockCRMAdapter
from finsight.models.attention import AttentionSummary
from finsight.models.cases import (
    AddRemediationActionRequest,
    CaseAuditEvent,
    CaseCategory,
    CaseSeverity,
    CaseStatus,
    CloseCaseRequest,
    CreateCaseRequest,
    FinancialCase,
    RemediationAction,
    UpdateCaseRequest,
)
from finsight.models.control import (
    Control,
    ControlAssessment,
    ControlSummary,
)
from finsight.models.cash_forecast import (
    CashForecast,
    CashForecastComparison,
    ForecastScenario,
)
from finsight.models.intelligence import FinancialIntelligenceReport
from finsight.models.investigation import (
    AskResponse,
    InvestigationRequest,
    InvestigationResult,
)
from finsight.models.knowledge import (
    KnowledgeDocument,
    KnowledgeSearchResult,
    KnowledgeSummary,
)
from finsight.models.metrics import (
    CFORatiosResponse,
    CashMetricDetail,
    DuPontAnalysis,
    FinancialSummary,
    InventoryMetricDetail,
    MetricHistoryResponse,
    MetricResult,
    PayablesMetricDetail,
    ProfitabilityMetricDetail,
    ReceivablesMetricDetail,
    WorkingCapitalDetail,
)
from finsight.models.performance import (
    EntityContribution,
    MetricDriverResponse,
    PerformanceSummaryResponse,
    WhatChangedItem,
)
from finsight.models.quality import DataQualityReport
from finsight.models.snapshot import FinancialSnapshot
from finsight.models.trust import (
    DataTrustSummaryResponse,
    GovernedAccountMapping,
    GovernedMetricDefinition,
    MappingStatus,
    MetricLineageResponse,
    MultiLayerReconciliationTie,
    PublishedGovernedMetric,
)
from finsight.knowledge.metric_catalog import (
    get_governed_metric_catalog,
    get_governed_metric_definition,
)
from finsight.services.ai_tools_service import AIToolsService
from finsight.services.cases_service import CasesService
from finsight.services.cash_forecast_service import CashForecastService
from finsight.services.control_assessment_service import ControlAssessmentService
from finsight.services.data_trust_service import DataTrustService
from finsight.services.financial_attention_service import FinancialAttentionService
from finsight.services.financial_intelligence_service import FinancialIntelligenceService
from finsight.services.financial_reconciliation_service import (
    FinancialReconciliationService,
    ReconciliationReport,
)
from finsight.services.investigation_service import InvestigationService
from finsight.services.knowledge_retriever import (
    BaseKnowledgeRetriever,
    LocalKnowledgeRetriever,
)
from finsight.services.performance_service import PerformanceService
from finsight.services.refresh_service import RefreshResponse, RefreshService
from finsight.crm import CustomerCRMProfile, MockCRMAdapter

router = APIRouter()

# Global singleton refresh service initialized at startup
_refresh_service: Optional[RefreshService] = None
_intelligence_service: Optional[FinancialIntelligenceService] = None
_attention_service: Optional[FinancialAttentionService] = None
_investigation_service: Optional[InvestigationService] = None
_knowledge_retriever: Optional[BaseKnowledgeRetriever] = None
_trust_service: Optional[DataTrustService] = None


def get_refresh_service() -> RefreshService:
    global _refresh_service
    if _refresh_service is None or _refresh_service._metric_service is None:
        _refresh_service = RefreshService()
        _refresh_service.execute_refresh()
    return _refresh_service


def get_intelligence_service(svc: RefreshService = Depends(get_refresh_service)) -> FinancialIntelligenceService:
    global _intelligence_service
    if not isinstance(svc, RefreshService):
        svc = get_refresh_service()
    if _intelligence_service is None or _intelligence_service.engine != svc.engine:
        _intelligence_service = FinancialIntelligenceService(svc.engine, svc.metric_service)
    return _intelligence_service


def get_attention_service(
    svc: RefreshService = Depends(get_refresh_service),
    intel: FinancialIntelligenceService = Depends(get_intelligence_service),
) -> FinancialAttentionService:
    global _attention_service
    if not isinstance(svc, RefreshService):
        svc = get_refresh_service()
    if not isinstance(intel, FinancialIntelligenceService):
        intel = get_intelligence_service(svc)
    if _attention_service is None or _attention_service.engine != svc.engine:
        _attention_service = FinancialAttentionService(svc.engine, svc.metric_service, intel)
    return _attention_service


def get_knowledge_retriever() -> BaseKnowledgeRetriever:
    global _knowledge_retriever
    if _knowledge_retriever is None:
        _knowledge_retriever = LocalKnowledgeRetriever()
    return _knowledge_retriever


def get_investigation_service(
    svc: RefreshService = Depends(get_refresh_service),
    intel: FinancialIntelligenceService = Depends(get_intelligence_service),
    kr: BaseKnowledgeRetriever = Depends(get_knowledge_retriever),
) -> InvestigationService:
    global _investigation_service
    if not isinstance(svc, RefreshService):
        svc = get_refresh_service()
    if not isinstance(intel, FinancialIntelligenceService):
        intel = get_intelligence_service(svc)
    if not isinstance(kr, BaseKnowledgeRetriever):
        kr = get_knowledge_retriever()
    if _investigation_service is None or _investigation_service.engine != svc.engine:
        ai_tools = AIToolsService(svc, knowledge_retriever=kr)
        _investigation_service = InvestigationService(ai_tools, intel)
    return _investigation_service


_cases_service: Optional[CasesService] = None


def get_cases_service() -> CasesService:
    global _cases_service
    if _cases_service is None:
        _cases_service = CasesService()
    return _cases_service


_control_service: Optional[ControlAssessmentService] = None
_forecast_service: Optional[CashForecastService] = None


def get_control_service(
    svc: RefreshService = Depends(get_refresh_service),
    kr: BaseKnowledgeRetriever = Depends(get_knowledge_retriever),
) -> ControlAssessmentService:
    global _control_service
    if not isinstance(svc, RefreshService):
        svc = get_refresh_service()
    if not isinstance(kr, BaseKnowledgeRetriever):
        kr = get_knowledge_retriever()
    if _control_service is None or _control_service.engine != svc.engine:
        _control_service = ControlAssessmentService(svc.engine, svc.metric_service, kr)
    return _control_service


def get_cash_forecast_service(
    svc: RefreshService = Depends(get_refresh_service),
) -> CashForecastService:
    global _forecast_service
    if not isinstance(svc, RefreshService):
        svc = get_refresh_service()
    if _forecast_service is None or _forecast_service.engine != svc.engine:
        _forecast_service = CashForecastService(svc.engine, svc.metric_service)
    return _forecast_service


_performance_service: Optional[PerformanceService] = None


def get_performance_service(
    svc: RefreshService = Depends(get_refresh_service),
    intel: FinancialIntelligenceService = Depends(get_intelligence_service),
) -> PerformanceService:
    global _performance_service
    if not isinstance(svc, RefreshService):
        svc = get_refresh_service()
    if not isinstance(intel, FinancialIntelligenceService):
        intel = get_intelligence_service(svc)
    if _performance_service is None or _performance_service.engine != svc.engine:
        _performance_service = PerformanceService(svc.engine, svc.metric_service, intel)
    return _performance_service


def get_data_trust_service(
    svc: RefreshService = Depends(get_refresh_service),
) -> DataTrustService:
    global _trust_service
    if not isinstance(svc, RefreshService):
        svc = get_refresh_service()
    if _trust_service is None or _trust_service.engine != svc.engine:
        _trust_service = DataTrustService(svc.engine, svc.metric_service)
    return _trust_service


_crm_adapter: Optional[MockCRMAdapter] = None


def get_crm_adapter() -> MockCRMAdapter:
    global _crm_adapter
    if _crm_adapter is None:
        _crm_adapter = MockCRMAdapter()
    return _crm_adapter



PERIOD_REGEX = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")


def validate_period(period: Optional[str], engine: Any = None) -> Optional[str]:
    """Validates fiscal period format (YYYY-MM) and checks against available ledger periods.

    Raises HTTP 400 for malformed/invalid format.
    Raises HTTP 404 if period is not available in the active ledger.
    """
    if period is None:
        return None
    if not PERIOD_REGEX.match(period):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid period format '{period}'. Expected YYYY-MM (e.g. '2026-03').",
        )
    if engine is not None and hasattr(engine, "available_periods") and engine.available_periods:
        if period not in engine.available_periods:
            raise HTTPException(
                status_code=404,
                detail=f"Period '{period}' not found in active ledger. Available periods: {list(engine.available_periods)}",
            )
    return period


def validate_horizon_days(horizon_days: int) -> int:
    """Validates cash forecast horizon (30, 60, or 90 days).

    Raises HTTP 400 if unsupported horizon is requested.
    """
    if horizon_days not in (30, 60, 90):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid forecast horizon '{horizon_days}'. FinSight supports 30, 60, or 90 days.",
        )
    return horizon_days


# -----------------------------------------------------------------------------
# Health & Status
# -----------------------------------------------------------------------------

@router.get("/health", tags=["System"])
@router.get("/api/health", tags=["System"], include_in_schema=False)
def health_check() -> Dict[str, Any]:
    """Lightweight liveness probe."""
    return {
        "status": "healthy",
        "app": settings.app_name,
        "version": settings.version,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.get("/api/public/config", tags=["System"])
def public_config() -> Dict[str, Any]:
    """Safe, minimal bootstrap configuration for login and UI initialization."""
    return settings.public_config()


@router.get("/api/status", tags=["System"])
def system_status(
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> Dict[str, Any]:
    """Operational status of the financial engine, active adapter, and dataset."""
    dq = svc.data_quality_report
    engine = svc.engine
    return {
        "status": "operational" if dq.status.value != "BLOCKED" else "blocked",
        "company_code": engine.company.company_code,
        "company_name": engine.company.company_name,
        "currency": engine.company.currency,
        "data_source": svc.adapter.adapter_name,
        "last_refresh_time": dq.last_successful_refresh,
        "data_quality_status": dq.status.value,
        "total_records": dq.total_records,
        "available_periods": engine.available_periods,
        "reference_date": settings.reference_date.isoformat(),
    }


# -----------------------------------------------------------------------------
# Ingestion & Refresh
# -----------------------------------------------------------------------------

@router.post("/api/refresh", response_model=RefreshResponse, tags=["Pipeline"])
def trigger_refresh(
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FINANCE_MANAGER)),
) -> RefreshResponse:
    """Executes the LOAD -> VALIDATE -> NORMALIZE -> CALCULATE -> READY pipeline."""
    global _intelligence_service, _attention_service, _investigation_service, _trust_service
    # Reset downstream cached services on refresh
    _intelligence_service = None
    _attention_service = None
    _investigation_service = None
    _trust_service = None
    return svc.execute_refresh()


@router.get("/api/snapshot", response_model=FinancialSnapshot, tags=["Financial Integrity"])
def get_active_snapshot(
    period: Optional[str] = Query(default=None, description="Fiscal period in YYYY-MM format"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> FinancialSnapshot:
    period = validate_period(period, svc.engine)
    if period:
        return svc.get_snapshot_for_period(period)
    return svc.active_snapshot


@router.get("/api/reconciliation", response_model=ReconciliationReport, tags=["Financial Integrity"])
def get_reconciliation_report(
    period: Optional[str] = Query(default=None, description="Fiscal period in YYYY-MM format"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> ReconciliationReport:
    """Executes deterministic 22-point financial reconciliation audit across GL and subledgers."""
    period = validate_period(period, svc.engine)
    recon_svc = FinancialReconciliationService(svc.engine, svc.metric_service, svc.active_snapshot)
    return recon_svc.execute_audit(period)



# -----------------------------------------------------------------------------
# Financial Statements & Summaries
# -----------------------------------------------------------------------------

@router.get("/api/financial-summary", response_model=FinancialSummary, tags=["Financial Metrics"])
@router.get("/api/financials", response_model=FinancialSummary, tags=["Financial Metrics"], include_in_schema=False)
@router.get("/api/summary", response_model=FinancialSummary, tags=["Financial Metrics"], include_in_schema=False)
def get_financial_summary(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> FinancialSummary:
    """Executive financial summary for CFO / Finance Lead."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.get_financial_summary(period=period)


@router.get("/api/cash", response_model=CashMetricDetail, tags=["Financial Metrics"])
def get_cash_metrics(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> CashMetricDetail:
    """Cash position and detailed bank account ledger balances."""
    period = validate_period(period, svc.engine)
    target_period = period or (svc.engine.available_periods[-1] if svc.engine.available_periods else "2026-09")
    cash_metric = svc.metric_service.calculate_cash_position(period=target_period)
    breakdown = cash_metric.dimensions.get("bank_accounts", [])
    return CashMetricDetail(
        cash_position=cash_metric,
        bank_accounts_breakdown=breakdown,
    )


@router.get("/api/working-capital", response_model=WorkingCapitalDetail, tags=["Financial Metrics"])
def get_working_capital_metrics(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> WorkingCapitalDetail:
    """Net working capital, current assets, current liabilities, and component breakdowns."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.calculate_working_capital(period=period)


@router.get("/api/ccc", response_model=MetricResult, tags=["Financial Metrics"])
def get_ccc_metrics(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> MetricResult:
    """Cash Conversion Cycle (CCC = DSO + DIO - DPO)."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.calculate_ccc(period=period)


@router.get("/api/receivables", response_model=ReceivablesMetricDetail, tags=["Financial Metrics"])
def get_receivables_metrics(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> ReceivablesMetricDetail:
    """AR open balance, overdue exposure, aging schedule, customer concentration, and DSO."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.calculate_receivables(period=period)


@router.get("/api/payables", response_model=PayablesMetricDetail, tags=["Financial Metrics"])
def get_payables_metrics(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> PayablesMetricDetail:
    """AP open balance, upcoming payment obligations (today, 1-3d, 4-7d), overdue payables, and DPO."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.calculate_payables(period=period)


@router.get("/api/inventory", response_model=InventoryMetricDetail, tags=["Financial Metrics"])
def get_inventory_metrics(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> InventoryMetricDetail:
    """Inventory asset balance, DIO, inventory-to-sales ratio, and growth decoupling."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.calculate_inventory(period=period)


@router.get("/api/profitability", response_model=ProfitabilityMetricDetail, tags=["Financial Metrics"])
def get_profitability_metrics(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> ProfitabilityMetricDetail:
    """Revenue, COGS, Gross Profit, Gross Margin %, customer concentration, and product margins."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.calculate_profitability(period=period)


@router.get("/api/metrics", tags=["Financial Metrics"])
def get_metrics_suite(
    metric: Optional[str] = Query(None, description="Specific metric name: dso, dpo, dio, gross_margin, cash, etc."),
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> Any:
    """Returns a specific metric or the entire foundational metric suite."""
    period = validate_period(period, svc.engine)
    target_period = period or (svc.engine.available_periods[-1] if svc.engine.available_periods else "2026-09")
    if metric:
        return svc.metric_service.get_metric_by_name(metric, target_period)

    # Return dictionary of all foundational metrics
    metric_names = [
        "cash_position", "net_working_capital", "current_assets", "current_liabilities",
        "accounts_receivable", "overdue_ar", "overdue_ar_percent", "dso",
        "accounts_payable", "upcoming_payables_7d", "overdue_payables", "dpo",
        "inventory_value", "dio",
        "revenue", "cogs", "gross_profit", "gross_margin_percent"
    ]
    return {
        "period": target_period,
        "metrics": {name: svc.metric_service.get_metric_by_name(name, target_period) for name in metric_names}
    }


@router.get("/api/ratios", response_model=CFORatiosResponse, tags=["Financial Metrics"])
@router.get("/api/financials/ratios", response_model=CFORatiosResponse, tags=["Financial Metrics"], include_in_schema=False)
def get_cfo_ratios_endpoint(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> CFORatiosResponse:
    """Governed CFO Ratio Cockpit categorized into 5 business groups: Liquidity, Working Capital, Profitability, Leverage, and Growth."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.get_cfo_ratios(period=period)


@router.get("/api/financials/dupont", response_model=DuPontAnalysis, tags=["Financial Metrics"])
@router.get("/api/dupont", response_model=DuPontAnalysis, tags=["Financial Metrics"], include_in_schema=False)
def get_dupont_analysis_endpoint(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> DuPontAnalysis:
    """Governed 3-tier DuPont Analysis tying Operating Margin, Asset Turnover, and Equity Multiplier to Operating ROE."""
    period = validate_period(period, svc.engine)
    return svc.metric_service.calculate_dupont_analysis(period=period)


@router.get("/api/metrics/{metric_name}/history", response_model=MetricHistoryResponse, tags=["Financial Metrics"])
def get_metric_history_endpoint(
    metric_name: str,
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> MetricHistoryResponse:
    """Multi-period historical trajectory, period-over-period deltas, and trend interpretation for any governed metric."""
    return svc.metric_service.get_metric_history(metric_name=metric_name)



# -----------------------------------------------------------------------------
# Performance & Driver Intelligence (Sprint 9)
# -----------------------------------------------------------------------------

@router.get("/api/performance", response_model=PerformanceSummaryResponse, tags=["Performance & Drivers"])
@router.get("/api/performance/summary", response_model=PerformanceSummaryResponse, tags=["Performance & Drivers"], include_in_schema=False)
def get_performance_summary(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    perf: PerformanceService = Depends(get_performance_service),
    current_user: User = Depends(get_current_user),
) -> PerformanceSummaryResponse:
    """Executive Performance & Driver Intelligence cockpit payload: What Changed + Why It Changed."""
    period = validate_period(period, perf.engine)
    return perf.get_performance_summary(period=period)


@router.get("/api/performance/what-changed", response_model=List[WhatChangedItem], tags=["Performance & Drivers"])
def get_performance_what_changed(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    only_material: bool = Query(False, description="Filter only to changes exceeding materiality thresholds"),
    perf: PerformanceService = Depends(get_performance_service),
    current_user: User = Depends(get_current_user),
) -> List[WhatChangedItem]:
    """Audited period-over-period financial variance with deterministic materiality classifications."""
    period = validate_period(period, perf.engine)
    return perf.get_what_changed(period=period, only_material=only_material)


@router.get("/api/performance/drivers", response_model=MetricDriverResponse, tags=["Performance & Drivers"])
def get_performance_metric_drivers(
    metric: str = Query("gross_margin_percent", description="Financial metric identifier (e.g. gross_margin_percent, revenue, cash, dso, net_working_capital, ccc)"),
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    perf: PerformanceService = Depends(get_performance_service),
    current_user: User = Depends(get_current_user),
) -> MetricDriverResponse:
    """Multivariate driver decomposition: primary driver, candidate factors, customer/product contributions, and evidence."""
    period = validate_period(period, perf.engine)
    return perf.get_metric_drivers(metric_name=metric, period=period)


@router.get("/api/performance/customers", response_model=List[EntityContribution], tags=["Performance & Drivers"])
def get_performance_customer_drivers(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    metric: str = Query("gross_profit", description="Attribution metric: gross_profit, revenue, overdue_ar"),
    perf: PerformanceService = Depends(get_performance_service),
    current_user: User = Depends(get_current_user),
) -> List[EntityContribution]:
    """Ranked customer contributions to gross profit, revenue, or overdue balance shifts."""
    period = validate_period(period, perf.engine)
    return perf.get_customer_drivers(period=period, metric=metric)


@router.get("/api/performance/products", response_model=List[EntityContribution], tags=["Performance & Drivers"])
def get_performance_product_drivers(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    metric: str = Query("gross_profit", description="Attribution metric: gross_profit, revenue, cogs"),
    perf: PerformanceService = Depends(get_performance_service),
    current_user: User = Depends(get_current_user),
) -> List[EntityContribution]:
    """Ranked product group contributions to gross profit, revenue, or COGS shifts."""
    period = validate_period(period, perf.engine)
    return perf.get_product_drivers(period=period, metric=metric)


# -----------------------------------------------------------------------------
# Layer 1: Financial Intelligence
# -----------------------------------------------------------------------------

@router.get("/api/intelligence", response_model=FinancialIntelligenceReport, tags=["Financial Intelligence"])
@router.get("/api/intelligence/report", response_model=FinancialIntelligenceReport, tags=["Financial Intelligence"], include_in_schema=False)
def get_financial_intelligence(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    intel: FinancialIntelligenceService = Depends(get_intelligence_service),
    current_user: User = Depends(get_current_user),
) -> FinancialIntelligenceReport:
    """Comprehensive financial intelligence report: period changes, trends, anomalies, drivers, and entity intelligence."""
    period = validate_period(period, intel.engine)
    return intel.generate_report(period=period)


# -----------------------------------------------------------------------------
# Layer 2: Financial Attention
# -----------------------------------------------------------------------------

@router.get("/api/attention", response_model=AttentionSummary, tags=["Financial Attention"])
@router.get("/api/financial-attention", response_model=AttentionSummary, tags=["Financial Attention"], include_in_schema=False)
def get_financial_attention(
    period: Optional[str] = Query(None, description="Fiscal period (e.g., '2026-09')"),
    severity: Optional[str] = Query(None, description="Filter by severity: CRITICAL, HIGH, MEDIUM, LOW"),
    type: Optional[str] = Query(None, description="Filter by attention type (e.g., CASH_PRESSURE, AR_DETERIORATION)"),
    status: Optional[str] = Query(None, description="Filter by status: OPEN, IN_REVIEW, RESOLVED, DISMISSED"),
    attn: FinancialAttentionService = Depends(get_attention_service),
    current_user: User = Depends(get_current_user),
) -> AttentionSummary:
    """Ranked portfolio of prioritized attention items with explainable scoring, drivers, and evidence."""
    period = validate_period(period, attn.engine)
    return attn.get_attention_summary(
        period=period,
        severity_filter=severity,
        type_filter=type,
        status_filter=status,
    )


# -----------------------------------------------------------------------------
# Layer 3: FinSight AI Investigation Engine
# -----------------------------------------------------------------------------

@router.post("/api/investigate", response_model=InvestigationResult, tags=["AI Investigator"])
def investigate_financial_question(
    req: InvestigationRequest,
    inv: InvestigationService = Depends(get_investigation_service),
    current_user: User = Depends(get_current_user),
) -> InvestigationResult:
    """Full-traceability investigation: plan, multi-tool execution, findings, evidence, and grounded explanation."""
    req.period = validate_period(req.period, inv.engine)
    return inv.execute_investigation(
        question=req.question,
        period=req.period,
        context=req.context,
    )


@router.post("/api/ai/ask", response_model=AskResponse, tags=["AI Investigator"])
def ask_ai_investigator(
    req: InvestigationRequest,
    inv: InvestigationService = Depends(get_investigation_service),
    current_user: User = Depends(get_current_user),
) -> AskResponse:
    """User-friendly AI question endpoint returning grounded answer, key findings, drivers, and next steps."""
    req.period = validate_period(req.period, inv.engine)
    return inv.ask(
        question=req.question,
        period=req.period,
        context=req.context,
    )


# -----------------------------------------------------------------------------
# Data Quality
# -----------------------------------------------------------------------------

@router.get("/api/data-quality", response_model=DataQualityReport, tags=["Data Quality"])
def get_data_quality_report(
    svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(get_current_user),
) -> DataQualityReport:
    """Diagnostic report showing record counts, referential integrity, and calculation blockers."""
    return svc.data_quality_report


# -----------------------------------------------------------------------------
# Financial Cases & Governance
# -----------------------------------------------------------------------------

@router.get("/api/cases", response_model=List[FinancialCase], tags=["Cases"])
@router.get("/api/actions", response_model=List[FinancialCase], tags=["Actions"], include_in_schema=False)
def list_financial_cases(
    status: Optional[CaseStatus] = None,
    severity: Optional[CaseSeverity] = None,
    category: Optional[CaseCategory] = None,
    cases_svc: CasesService = Depends(get_cases_service),
    current_user: User = Depends(get_current_user),
) -> List[FinancialCase]:
    """Retrieves list of financial remediation cases with optional filtering."""
    return cases_svc.list_cases(status=status, severity=severity, category=category)


@router.post("/api/cases", response_model=FinancialCase, tags=["Cases"])
@router.post("/api/actions", response_model=FinancialCase, tags=["Actions"], include_in_schema=False)
def create_financial_case(
    req: CreateCaseRequest,
    cases_svc: CasesService = Depends(get_cases_service),
    refresh_svc: RefreshService = Depends(get_refresh_service),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FINANCE_MANAGER, UserRole.FINANCE_ANALYST)),
) -> FinancialCase:
    """Creates a new financial remediation case linked to the authoritative snapshot."""
    verified_actor = current_user.full_name or current_user.username
    if refresh_svc and refresh_svc.active_snapshot:
        if not req.snapshot_id or req.snapshot_id == "SNAP-202609-001":
            req.snapshot_id = refresh_svc.active_snapshot.snapshot_id
    return cases_svc.create_case(req, actor=verified_actor)


@router.get("/api/cases/{case_id}", response_model=FinancialCase, tags=["Cases"])
@router.get("/api/actions/{case_id}", response_model=FinancialCase, tags=["Actions"], include_in_schema=False)
def get_financial_case(
    case_id: str,
    cases_svc: CasesService = Depends(get_cases_service),
    current_user: User = Depends(get_current_user),
) -> FinancialCase:
    """Retrieves a single financial remediation case by ID."""
    case = cases_svc.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail=f"Case '{case_id}' not found.")
    return case


@router.patch("/api/cases/{case_id}", response_model=FinancialCase, tags=["Cases"])
@router.patch("/api/actions/{case_id}", response_model=FinancialCase, tags=["Actions"], include_in_schema=False)
def update_financial_case(
    case_id: str,
    req: UpdateCaseRequest,
    cases_svc: CasesService = Depends(get_cases_service),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FINANCE_MANAGER, UserRole.FINANCE_ANALYST)),
) -> FinancialCase:
    """Updates a case's status, assignee, or appends a note."""
    verified_actor = current_user.full_name or current_user.username
    try:
        updated = cases_svc.update_case(case_id, req, actor=verified_actor)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not updated:
        raise HTTPException(status_code=404, detail=f"Case '{case_id}' not found.")
    return updated


@router.post("/api/cases/{case_id}/remediation-action", response_model=FinancialCase, tags=["Cases"])
@router.post("/api/actions/{case_id}/remediation-action", response_model=FinancialCase, tags=["Actions"], include_in_schema=False)
def add_case_remediation_action(
    case_id: str,
    req: AddRemediationActionRequest,
    cases_svc: CasesService = Depends(get_cases_service),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FINANCE_MANAGER, UserRole.FINANCE_ANALYST)),
) -> FinancialCase:
    """Appends a new remediation action item to the case with audit logging."""
    case = cases_svc.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail=f"Case '{case_id}' not found.")
    action = RemediationAction(
        action=req.action,
        owner=req.owner,
        due_date=req.due_date,
        status="OPEN",
        comment=req.comment,
    )
    verified_actor = current_user.full_name or current_user.username
    updated = cases_svc.add_remediation_action(case_id, action, actor=verified_actor)
    return updated


@router.post("/api/cases/{case_id}/close", response_model=FinancialCase, tags=["Cases"])
@router.post("/api/actions/{case_id}/close", response_model=FinancialCase, tags=["Actions"], include_in_schema=False)
def close_financial_case(
    case_id: str,
    req: CloseCaseRequest,
    cases_svc: CasesService = Depends(get_cases_service),
    current_user: User = Depends(get_current_user),
) -> FinancialCase:
    """Formally closes a case with verified resolution evidence and reviewer signoff."""
    if current_user.role not in (UserRole.ADMIN, UserRole.FINANCE_MANAGER):
        raise HTTPException(
            status_code=403,
            detail="Access denied: FINANCE_ANALYST is not authorized to close remediation cases. Manager or Admin approval required.",
        )
    verified_actor = current_user.full_name or current_user.username
    try:
        updated = cases_svc.close_case(case_id, req, actor=verified_actor)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not updated:
        raise HTTPException(status_code=404, detail=f"Case '{case_id}' not found.")
    return updated


@router.get("/api/cases/{case_id}/audit-trail", response_model=List[CaseAuditEvent], tags=["Cases"])
def get_case_audit_trail(
    case_id: str,
    cases_svc: CasesService = Depends(get_cases_service),
    current_user: User = Depends(get_current_user),
) -> List[CaseAuditEvent]:
    """Retrieves immutable append-only audit trail for a case."""
    case = cases_svc.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail=f"Case '{case_id}' not found.")
    return case.audit_notes



# -----------------------------------------------------------------------------
# Layer 4: Finance Knowledge & Policy Intelligence
# -----------------------------------------------------------------------------

@router.get("/api/knowledge/documents", response_model=List[KnowledgeDocument], tags=["Finance Knowledge"])
def list_knowledge_documents(
    status: Optional[str] = Query(None, description="Filter by status: ACTIVE, EXPIRED, SUPERSEDED, DRAFT"),
    kr: BaseKnowledgeRetriever = Depends(get_knowledge_retriever),
    current_user: User = Depends(get_current_user),
) -> List[KnowledgeDocument]:
    """Lists registered enterprise finance policy, SOP, and control documents."""
    return kr.list_documents(status=status)


@router.get("/api/knowledge/documents/{document_id}", response_model=KnowledgeDocument, tags=["Finance Knowledge"])
def get_knowledge_document(
    document_id: str,
    kr: BaseKnowledgeRetriever = Depends(get_knowledge_retriever),
    current_user: User = Depends(get_current_user),
) -> KnowledgeDocument:
    """Retrieves full text, metadata, and version details of a specific knowledge document."""
    doc = kr.get_document(document_id)
    if not doc:
        raise HTTPException(status_code=404, detail=f"Knowledge document '{document_id}' not found.")
    return doc


@router.get("/api/knowledge/search", response_model=List[KnowledgeSearchResult], tags=["Finance Knowledge"])
def search_knowledge_base(
    query: str = Query(..., description="Natural language search query"),
    domain: Optional[str] = Query(None, description="Optional domain filter: AR, AP, TREASURY, etc."),
    document_type: Optional[str] = Query(None, description="Filter by document type (POLICY, SOP, CONTROL, etc.)"),
    effective_date: Optional[str] = Query(None, description="As-of date in YYYY-MM-DD format (defaults to 2026-09-30)"),
    top_k: int = Query(5, description="Maximum number of relevant chunks to retrieve"),
    kr: BaseKnowledgeRetriever = Depends(get_knowledge_retriever),
    current_user: User = Depends(get_current_user),
) -> List[KnowledgeSearchResult]:
    """Semantic and lexical BM25 search across governed finance policy documents."""
    return kr.search(
        query=query,
        domain=domain,
        document_type=document_type,
        effective_date=effective_date,
        top_k=top_k,
    )


@router.get("/api/knowledge/summary", response_model=KnowledgeSummary, tags=["Finance Knowledge"])
def get_knowledge_governance_summary(
    kr: BaseKnowledgeRetriever = Depends(get_knowledge_retriever),
    current_user: User = Depends(get_current_user),
) -> KnowledgeSummary:
    """Returns governance inventory, status breakdown, and indexing health of knowledge base."""
    return kr.get_governance_summary()


# -----------------------------------------------------------------------------
# Layer 5: Control Intelligence Engine (Phase 6)
# -----------------------------------------------------------------------------

@router.get("/api/controls", response_model=List[Control], tags=["Control Intelligence"])
def list_controls(
    domain: Optional[str] = Query(None, description="Filter by domain: AR, TREASURY, WORKING_CAPITAL, etc."),
    severity: Optional[str] = Query(None, description="Filter by severity: CRITICAL, HIGH, MEDIUM, LOW"),
    status: Optional[str] = Query(None, description="Filter by status: ACTIVE, INACTIVE, DRAFT"),
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    ctrl_svc: ControlAssessmentService = Depends(get_control_service),
    current_user: User = Depends(get_current_user),
) -> List[Control]:
    """Lists registered canonical internal controls bound to governing policies."""
    period = validate_period(period, ctrl_svc.engine)
    return ctrl_svc.list_controls(domain=domain, severity=severity, status=status, period=period)


@router.get("/api/controls/{control_id}", response_model=Control, tags=["Control Intelligence"])
def get_control(
    control_id: str,
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    ctrl_svc: ControlAssessmentService = Depends(get_control_service),
    current_user: User = Depends(get_current_user),
) -> Control:
    """Retrieves a single internal control definition by ID."""
    period = validate_period(period, ctrl_svc.engine)
    ctrl = ctrl_svc.get_control(control_id, period=period)
    if not ctrl:
        raise HTTPException(status_code=404, detail=f"Control '{control_id}' not found.")
    return ctrl


@router.get("/api/control-assessments/summary", response_model=ControlSummary, tags=["Control Intelligence"])
def get_control_summary(
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    ctrl_svc: ControlAssessmentService = Depends(get_control_service),
    current_user: User = Depends(get_current_user),
) -> ControlSummary:
    """Returns portfolio control health summary (reviewed, breached, review, passed, exposure)."""
    period = validate_period(period, ctrl_svc.engine)
    return ctrl_svc.get_summary(period=period)


@router.get("/api/control-assessments", response_model=List[ControlAssessment], tags=["Control Intelligence"])
def list_control_assessments(
    status: Optional[str] = Query(None, description="Filter by assessment status: PASS, REVIEW, BREACH, NOT_EVALUATED"),
    severity: Optional[str] = Query(None, description="Filter by severity: CRITICAL, HIGH, MEDIUM, LOW"),
    domain: Optional[str] = Query(None, description="Filter by domain"),
    entity: Optional[str] = Query(None, description="Target counterparty entity"),
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    ctrl_svc: ControlAssessmentService = Depends(get_control_service),
    current_user: User = Depends(get_current_user),
) -> List[ControlAssessment]:
    """Evaluates and lists control assessments against deterministic financial facts."""
    period = validate_period(period, ctrl_svc.engine)
    assessments = ctrl_svc.assess_all_controls(period=period, entity=entity)
    if status:
        assessments = [a for a in assessments if a.status.value.upper() == status.upper()]
    if severity:
        assessments = [a for a in assessments if a.severity.value.upper() == severity.upper()]
    if domain:
        assessments = [a for a in assessments if a.domain.upper() == domain.upper()]
    return assessments


@router.get("/api/control-assessments/{assessment_id}", response_model=ControlAssessment, tags=["Control Intelligence"])
def get_control_assessment(
    assessment_id: str,
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    ctrl_svc: ControlAssessmentService = Depends(get_control_service),
    current_user: User = Depends(get_current_user),
) -> ControlAssessment:
    """Retrieves an individual control assessment by ID or control ID."""
    period = validate_period(period, ctrl_svc.engine)
    assessments = ctrl_svc.assess_all_controls(period=period)
    for a in assessments:
        if a.assessment_id.upper() == assessment_id.upper() or a.control_id.upper() == assessment_id.upper():
            return a
    raise HTTPException(status_code=404, detail=f"Assessment '{assessment_id}' not found.")


@router.post("/api/control-assessments/{assessment_id}/create-case", response_model=FinancialCase, tags=["Control Intelligence"])
def create_case_from_control_assessment(
    assessment_id: str,
    assigned_owner: Optional[str] = Query(None, description="Assignee/owner for the new case"),
    due_date: Optional[str] = Query(None, description="Target completion date in YYYY-MM-DD format"),
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    ctrl_svc: ControlAssessmentService = Depends(get_control_service),
    cases_svc: CasesService = Depends(get_cases_service),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FINANCE_MANAGER, UserRole.FINANCE_ANALYST)),
) -> FinancialCase:
    """Spawns an auditable remediation case directly from a breached control assessment."""
    period = validate_period(period, ctrl_svc.engine)
    assessments = ctrl_svc.assess_all_controls(period=period)
    target_assessment: Optional[ControlAssessment] = None
    for a in assessments:
        if a.assessment_id.upper() == assessment_id.upper() or a.control_id.upper() == assessment_id.upper():
            target_assessment = a
            break
    if not target_assessment:
        raise HTTPException(status_code=404, detail=f"Control assessment '{assessment_id}' not found.")

    verified_actor = current_user.full_name or current_user.username
    return cases_svc.create_case_from_assessment(
        assessment=target_assessment,
        assigned_owner=assigned_owner,
        due_date=due_date,
        actor=verified_actor,
    )


# -----------------------------------------------------------------------------
# Layer 6: Cash Outlook & Scenario Intelligence (Phase 8)
# -----------------------------------------------------------------------------

@router.get("/api/forecast/cash", response_model=CashForecast, tags=["Cash Forecast"])
def get_cash_forecast(
    horizon_days: int = Query(30, description="Forecast horizon in days (30, 60, or 90)"),
    scenario: str = Query("BASE", description="Scenario: BASE, CONSERVATIVE, or IMPROVED_COLLECTIONS"),
    period: Optional[str] = Query(None, description="Base period in YYYY-MM format"),
    fc_svc: CashForecastService = Depends(get_cash_forecast_service),
    current_user: User = Depends(get_current_user),
) -> CashForecast:
    """Generates transparent, auditable cash flow projections based on subledger aging schedules."""
    horizon_days = validate_horizon_days(horizon_days)
    period = validate_period(period, fc_svc.engine)
    try:
        scen_enum = ForecastScenario(scenario.upper())
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid scenario '{scenario}'. Allowed: BASE, CONSERVATIVE, IMPROVED_COLLECTIONS",
        )
    return fc_svc.generate_forecast(horizon_days=horizon_days, scenario=scen_enum, period=period)


@router.get("/api/forecast/scenarios", response_model=CashForecastComparison, tags=["Cash Forecast"])
def compare_forecast_scenarios(
    horizon_days: int = Query(30, description="Forecast horizon in days (30, 60, or 90)"),
    period: Optional[str] = Query(None, description="Base period in YYYY-MM format"),
    fc_svc: CashForecastService = Depends(get_cash_forecast_service),
    current_user: User = Depends(get_current_user),
) -> CashForecastComparison:
    """Returns simultaneous Base, Conservative, and Improved Collections projections for dashboard charting."""
    horizon_days = validate_horizon_days(horizon_days)
    period = validate_period(period, fc_svc.engine)
    return fc_svc.compare_scenarios(horizon_days=horizon_days, period=period)


@router.get("/api/forecast/liquidity-risk", tags=["Cash Forecast"])
def get_forecast_liquidity_risk(
    horizon_days: int = Query(30, description="Forecast horizon in days (30, 60, or 90)"),
    period: Optional[str] = Query(None, description="Base period in YYYY-MM format"),
    fc_svc: CashForecastService = Depends(get_cash_forecast_service),
    current_user: User = Depends(get_current_user),
) -> Dict[str, Any]:
    """Evaluates short-term liquidity risk indicators against LIQ-CTRL-001 policy threshold."""
    horizon_days = validate_horizon_days(horizon_days)
    period = validate_period(period, fc_svc.engine)
    base_fc = fc_svc.generate_forecast(horizon_days=horizon_days, scenario=ForecastScenario.BASE, period=period)
    return base_fc.liquidity_indicators


# -----------------------------------------------------------------------------
# Layer 7: Financial Data Trust & Metric Reconciliation (Sprint 10)
# -----------------------------------------------------------------------------

@router.get("/api/trust/summary", response_model=DataTrustSummaryResponse, tags=["Data Trust & Reconciliation"])
@router.get("/api/data-trust/summary", response_model=DataTrustSummaryResponse, tags=["Data Trust & Reconciliation"], include_in_schema=False)
def get_data_trust_summary(
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    trust_svc: DataTrustService = Depends(get_data_trust_service),
    current_user: User = Depends(get_current_user),
) -> DataTrustSummaryResponse:
    """Returns executive and controller-grade data trust posture for header badge and trust drawer."""
    period = validate_period(period, trust_svc.engine)
    return trust_svc.get_data_trust_summary(period=period)


@router.get("/api/trust/catalog", response_model=List[GovernedMetricDefinition], tags=["Data Trust & Reconciliation"])
def get_metric_catalog(
    current_user: User = Depends(get_current_user),
) -> List[GovernedMetricDefinition]:
    """Returns the authoritative registry of governed financial metric definitions."""
    return get_governed_metric_catalog()


@router.get("/api/trust/catalog/{metric_name}", response_model=GovernedMetricDefinition, tags=["Data Trust & Reconciliation"])
def get_metric_definition(
    metric_name: str,
    current_user: User = Depends(get_current_user),
) -> GovernedMetricDefinition:
    """Returns the formal governed definition, formula, and denominator rules for a specific metric."""
    defn = get_governed_metric_definition(metric_name)
    if not defn:
        raise HTTPException(
            status_code=404,
            detail=f"Governed metric definition '{metric_name}' not found.",
        )
    return defn


@router.get("/api/trust/mappings", tags=["Data Trust & Reconciliation"])
def get_governed_account_mappings(
    trust_svc: DataTrustService = Depends(get_data_trust_service),
    current_user: User = Depends(get_current_user),
) -> Dict[str, Any]:
    """Audits the GL Chart of Accounts, detecting mapped, unmapped, and ambiguous accounts."""
    mappings = trust_svc.get_account_mappings()
    total = len(mappings)
    mapped = sum(1 for m in mappings if m.mapping_status == MappingStatus.MAPPED)
    unmapped = sum(1 for m in mappings if m.mapping_status == MappingStatus.UNMAPPED)
    ambiguous = sum(1 for m in mappings if m.mapping_status == MappingStatus.AMBIGUOUS)
    coverage = round((mapped / total * 100.0), 1) if total > 0 else 0.0

    return {
        "total_accounts": total,
        "mapped_accounts": mapped,
        "unmapped_accounts": unmapped,
        "ambiguous_accounts": ambiguous,
        "coverage_percentage": coverage,
        "mappings": mappings,
    }


@router.get("/api/trust/reconciliation", response_model=List[MultiLayerReconciliationTie], tags=["Data Trust & Reconciliation"])
def get_reconciliation_ties(
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    tolerance: Optional[float] = Query(None, description="Custom tolerance threshold in dollars/units"),
    trust_svc: DataTrustService = Depends(get_data_trust_service),
    current_user: User = Depends(get_current_user),
) -> List[MultiLayerReconciliationTie]:
    """Runs and returns all 4-layer multi-layer deterministic reconciliation ties across core metrics."""
    period = validate_period(period, trust_svc.engine)
    return trust_svc.audit_all_reconciliation_ties(period=period, custom_tolerance=tolerance)


@router.get("/api/trust/metrics/{metric_name}/lineage", response_model=MetricLineageResponse, tags=["Data Trust & Reconciliation"])
def get_metric_lineage(
    metric_name: str,
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    trust_svc: DataTrustService = Depends(get_data_trust_service),
    current_user: User = Depends(get_current_user),
) -> MetricLineageResponse:
    """Traces full auditable provenance and mathematical origin for any governed metric."""
    period = validate_period(period, trust_svc.engine)
    defn = get_governed_metric_definition(metric_name)
    if not defn:
        raise HTTPException(
            status_code=404,
            detail=f"Governed metric definition '{metric_name}' not found.",
        )
    return trust_svc.get_metric_lineage(metric_name=metric_name, period=period)


@router.get("/api/trust/metrics", response_model=List[PublishedGovernedMetric], tags=["Data Trust & Reconciliation"])
def get_published_governed_metrics(
    period: Optional[str] = Query(None, description="Period in YYYY-MM format"),
    trust_svc: DataTrustService = Depends(get_data_trust_service),
    current_user: User = Depends(get_current_user),
) -> List[PublishedGovernedMetric]:
    """Returns all governed published metrics with publication trust states and verification tags."""
    period = validate_period(period, trust_svc.engine)
    return trust_svc.get_all_published_metrics(period=period)


# -----------------------------------------------------------------------------
# CRM Intelligence (Synthetic CRM Boundary)
# -----------------------------------------------------------------------------

@router.get("/api/crm/customers/{customer_id}", response_model=CustomerCRMProfile, tags=["CRM Context"])
def get_customer_crm_profile(
    customer_id: str,
    crm: MockCRMAdapter = Depends(get_crm_adapter),
    current_user: User = Depends(get_current_user),
) -> CustomerCRMProfile:
    """Returns synthetic enterprise CRM intelligence profile for a customer (contacts, pipeline, activities, health)."""
    profile = crm.get_customer_crm_profile(customer_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Customer CRM profile not found")
    return profile




