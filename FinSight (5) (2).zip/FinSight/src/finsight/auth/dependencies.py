"""FastAPI Authentication and RBAC route dependencies."""

from typing import Callable, Optional
from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from finsight.auth.models import User, UserProfile, UserRole
from finsight.auth.repository import AuthRepository, get_auth_repository

bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(
    auth: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    repo: AuthRepository = Depends(get_auth_repository),
) -> User:
    """Dependency that enforces a valid active session token, returning authenticated User.

    Raises HTTP 401 Unauthorized if token is missing, invalid, or expired.
    """
    if not auth or not auth.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required: missing Bearer token.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    session = repo.get_session(auth.credentials)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired authentication session.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = repo.get_user_by_id(session.user_id)
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is inactive or not found.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return user


def get_optional_user(
    auth: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    repo: AuthRepository = Depends(get_auth_repository),
) -> Optional[User]:
    """Dependency that extracts user if valid session exists, otherwise returns None."""
    if not auth or not auth.credentials:
        return None
    session = repo.get_session(auth.credentials)
    if not session:
        return None
    return repo.get_user_by_id(session.user_id)


def require_role(*allowed_roles: UserRole) -> Callable[[User], User]:
    """Dependency factory enforcing server-side Role-Based Access Control (RBAC).

    Raises HTTP 403 Forbidden if authenticated user does not possess one of the allowed roles.
    """
    allowed_values = {r.value if isinstance(r, UserRole) else str(r) for r in allowed_roles}

    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role.value not in allowed_values:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied: role '{current_user.role.value}' is not authorized for this resource. Required: {list(allowed_values)}",
            )
        return current_user

    return role_checker
