"""Authentication and Role-Based Access Control Models for FinSight."""

from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class UserRole(str, Enum):
    """Authoritative RBAC roles for executive and operational finance users."""

    ADMIN = "ADMIN"
    FINANCE_MANAGER = "FINANCE_MANAGER"
    FINANCE_ANALYST = "FINANCE_ANALYST"


class User(BaseModel):
    """Internal user model including hashed credentials."""

    id: str
    username: str
    email: str
    full_name: str
    role: UserRole
    password_hash: str
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)


class UserProfile(BaseModel):
    """Public user profile exposed through APIs without sensitive credentials."""

    id: str
    username: str
    email: str
    full_name: str
    role: UserRole
    is_active: bool = True
    display_title: str = ""


class UserSession(BaseModel):
    """Active user session tracking authentication tokens."""

    session_token: str
    user_id: str
    username: str
    role: UserRole
    created_at: datetime
    expires_at: datetime
    is_active: bool = True


class LoginRequest(BaseModel):
    """Credentials payload for login."""

    username: str = Field(..., description="User ID or username (e.g. admin, manager, analyst)")
    password: str = Field(..., description="User password")


class LoginResponse(BaseModel):
    """Authentication response returning bearer token and public user profile."""

    token: str
    token_type: str = "Bearer"
    expires_at: str
    user: UserProfile
