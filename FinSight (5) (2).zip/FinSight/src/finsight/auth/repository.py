"""SQLite persistence repository for users, roles, and active authentication sessions."""

import os
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
from typing import List, Optional

from finsight.auth.models import User, UserProfile, UserRole, UserSession
from finsight.auth.security import generate_session_token, hash_password
from finsight.config import settings


class AuthRepository:
    """Manages persistent SQLite storage of users and tokens for Sprint 11."""

    # In-memory failed login tracking for rate limiting (no Redis needed)
    _failed_attempts: dict = {}

    def __init__(self, db_path: Optional[str] = None) -> None:
        if db_path is None:
            # Default to data/finsight_auth.db relative to repo root
            data_dir = Path(__file__).resolve().parent.parent.parent.parent / "data"
            data_dir.mkdir(parents=True, exist_ok=True)
            self.db_path = str(data_dir / "finsight_auth.db")
        else:
            self.db_path = db_path

        self._init_db()
        self._seed_default_users()

    @contextmanager
    def _db_conn(self):
        conn = sqlite3.connect(self.db_path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_db(self) -> None:
        """Initializes database schema if tables do not exist."""
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    full_name TEXT NOT NULL,
                    role TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_token TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    username TEXT NOT NULL,
                    role TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS auth_rate_limits (
                    identifier TEXT PRIMARY KEY,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_attempt TEXT NOT NULL
                )
            """)
            conn.commit()

    def _seed_default_users(self) -> None:
        """Seeds initial realistic development and demo accounts with salted PBKDF2 hashes."""
        if not settings.seed_demo_data or settings.environment.lower() == "production" or not settings.enable_demo_credentials:
            return

        demo_accounts = [
            {
                "id": "usr_admin_001",
                "username": os.getenv("FINSIGHT_ADMIN_USER", "admin"),
                "email": "samarth@finsight.internal",
                "full_name": "Samarth",
                "role": UserRole.ADMIN.value,
                "password": os.getenv("FINSIGHT_ADMIN_PASSWORD", "demo123"),
            },
            {
                "id": "usr_mgr_002",
                "username": os.getenv("FINSIGHT_MGR_USER", "manager"),
                "email": "jordan.lee@finsight.internal",
                "full_name": "Jordan Lee",
                "role": UserRole.FINANCE_MANAGER.value,
                "password": os.getenv("FINSIGHT_MGR_PASSWORD", "demo123"),
            },
            {
                "id": "usr_anl_003",
                "username": os.getenv("FINSIGHT_ANL_USER", "analyst"),
                "email": "taylor.swift@finsight.internal",
                "full_name": "Taylor Swift",
                "role": UserRole.FINANCE_ANALYST.value,
                "password": os.getenv("FINSIGHT_ANL_PASSWORD", "demo123"),
            },
        ]

        now_str = datetime.now(timezone.utc).isoformat()
        with self._db_conn() as conn:
            cursor = conn.cursor()
            for acc in demo_accounts:
                cursor.execute("SELECT id FROM users WHERE username = ?", (acc["username"],))
                row = cursor.fetchone()
                if not row:
                    pwd_hash = hash_password(acc["password"])
                    cursor.execute(
                        """
                        INSERT INTO users (id, username, email, full_name, role, password_hash, is_active, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, 1, ?)
                        """,
                        (acc["id"], acc["username"], acc["email"], acc["full_name"], acc["role"], pwd_hash, now_str),
                    )
            conn.commit()

    def get_user_by_username(self, username: str) -> Optional[User]:
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE username = ?", (username.strip().lower(),))
            row = cursor.fetchone()
            if not row:
                return None
            return User(
                id=row["id"],
                username=row["username"],
                email=row["email"],
                full_name=row["full_name"],
                role=UserRole(row["role"]),
                password_hash=row["password_hash"],
                is_active=bool(row["is_active"]),
                created_at=datetime.fromisoformat(row["created_at"]),
            )

    def get_user_by_id(self, user_id: str) -> Optional[User]:
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            row = cursor.fetchone()
            if not row:
                return None
            return User(
                id=row["id"],
                username=row["username"],
                email=row["email"],
                full_name=row["full_name"],
                role=UserRole(row["role"]),
                password_hash=row["password_hash"],
                is_active=bool(row["is_active"]),
                created_at=datetime.fromisoformat(row["created_at"]),
            )

    def list_users(self) -> List[UserProfile]:
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, username, email, full_name, role, is_active FROM users ORDER BY username")
            rows = cursor.fetchall()
            role_titles = {
                UserRole.ADMIN.value: "Finance Admin",
                UserRole.FINANCE_MANAGER.value: "Finance Manager",
                UserRole.FINANCE_ANALYST.value: "Finance Analyst",
            }
            return [
                UserProfile(
                    id=r["id"],
                    username=r["username"],
                    email=r["email"],
                    full_name=r["full_name"],
                    role=UserRole(r["role"]),
                    is_active=bool(r["is_active"]),
                    display_title=f"{r['full_name']} / {role_titles.get(r['role'], r['role'])}",
                )
                for r in rows
            ]

    def create_session(self, user: User, expires_in_seconds: int = 86400) -> UserSession:
        token = generate_session_token()
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(seconds=expires_in_seconds)

        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO sessions (session_token, user_id, username, role, created_at, expires_at, is_active)
                VALUES (?, ?, ?, ?, ?, ?, 1)
                """,
                (token, user.id, user.username, user.role.value, now.isoformat(), expires_at.isoformat()),
            )
            conn.commit()

        return UserSession(
            session_token=token,
            user_id=user.id,
            username=user.username,
            role=user.role,
            created_at=now,
            expires_at=expires_at,
            is_active=True,
        )

    def get_session(self, token: str) -> Optional[UserSession]:
        if not token:
            return None
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM sessions WHERE session_token = ? AND is_active = 1", (token,))
            row = cursor.fetchone()
            if not row:
                return None

            expires_at = datetime.fromisoformat(row["expires_at"])
            # Check expiration
            if datetime.now(timezone.utc) > expires_at:
                # Mark expired
                cursor.execute("UPDATE sessions SET is_active = 0 WHERE session_token = ?", (token,))
                conn.commit()
                return None

            return UserSession(
                session_token=row["session_token"],
                user_id=row["user_id"],
                username=row["username"],
                role=UserRole(row["role"]),
                created_at=datetime.fromisoformat(row["created_at"]),
                expires_at=expires_at,
                is_active=bool(row["is_active"]),
            )

    def invalidate_session(self, token: str) -> bool:
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE sessions SET is_active = 0 WHERE session_token = ?", (token,))
            conn.commit()
            return cursor.rowcount > 0

    def cleanup_expired_sessions(self) -> int:
        """Purges expired or invalidated sessions from the database."""
        now_str = datetime.now(timezone.utc).isoformat()
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM sessions WHERE expires_at < ? OR is_active = 0", (now_str,))
            conn.commit()
            return cursor.rowcount

    def record_failed_login(self, username: str) -> None:
        """Records a failed login attempt with timestamp for rate limiting."""
        key = username.strip().lower()
        now = datetime.now(timezone.utc)
        now_str = now.isoformat()
        with self._db_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT attempts, last_attempt FROM auth_rate_limits WHERE identifier = ?", (key,))
            row = cur.fetchone()
            if row:
                try:
                    last_dt = datetime.fromisoformat(row["last_attempt"])
                    if now - last_dt > timedelta(seconds=300):
                        attempts = 1
                    else:
                        attempts = row["attempts"] + 1
                except Exception:
                    attempts = 1
                cur.execute(
                    "UPDATE auth_rate_limits SET attempts = ?, last_attempt = ? WHERE identifier = ?",
                    (attempts, now_str, key),
                )
            else:
                cur.execute(
                    "INSERT INTO auth_rate_limits (identifier, attempts, last_attempt) VALUES (?, 1, ?)",
                    (key, now_str),
                )
            conn.commit()

    def is_login_rate_limited(self, username: str, max_attempts: int = 5, window_seconds: int = 300) -> bool:
        """Checks if a username has exceeded maximum failed login attempts within window."""
        key = username.strip().lower()
        now = datetime.now(timezone.utc)
        with self._db_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT attempts, last_attempt FROM auth_rate_limits WHERE identifier = ?", (key,))
            row = cur.fetchone()
            if not row:
                return False
            try:
                last_dt = datetime.fromisoformat(row["last_attempt"])
                if now - last_dt > timedelta(seconds=window_seconds):
                    return False
                return row["attempts"] >= max_attempts
            except Exception:
                return False

    def clear_failed_logins(self, username: str) -> None:
        """Clears failed login attempts upon successful authentication."""
        key = username.strip().lower()
        with self._db_conn() as conn:
            conn.execute("DELETE FROM auth_rate_limits WHERE identifier = ?", (key,))
            conn.commit()


# Global repository instance
_auth_repo: Optional[AuthRepository] = None


def get_auth_repository() -> AuthRepository:
    global _auth_repo
    if _auth_repo is None:
        _auth_repo = AuthRepository()
    return _auth_repo
