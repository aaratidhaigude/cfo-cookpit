"""Cryptographic security utilities for password hashing and token generation."""

import hashlib
import hmac
import os
import secrets
from typing import Tuple

PBKDF2_ITERATIONS = 100_000


def hash_password(password: str, salt: bytes = None) -> str:
    """Hashes a password using PBKDF2-HMAC-SHA256 with a cryptographically secure salt.

    Format: pbkdf2:sha256:iterations$salt_hex$hash_hex
    """
    if salt is None:
        salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
    )
    return f"pbkdf2:sha256:{PBKDF2_ITERATIONS}${salt.hex()}${key.hex()}"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain password against its PBKDF2-HMAC-SHA256 hash using constant-time comparison."""
    try:
        header, salt_hex, hash_hex = hashed_password.split("$")
        algorithm, sub_algo, iterations = header.split(":")
        salt = bytes.fromhex(salt_hex)
        expected_key = bytes.fromhex(hash_hex)
        computed_key = hashlib.pbkdf2_hmac(
            sub_algo,
            plain_password.encode("utf-8"),
            salt,
            int(iterations),
        )
        return hmac.compare_digest(computed_key, expected_key)
    except Exception:
        return False


def generate_session_token() -> str:
    """Generates a high-entropy, URL-safe random token for active sessions."""
    return secrets.token_urlsafe(32)
