"""Configuration management for FinSight."""

import os
from datetime import date
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


class Settings(BaseModel):
    """Application runtime settings."""

    app_name: str = "FinSight"
    version: str = "0.2.0"
    environment: str = Field(default_factory=lambda: os.getenv("FINSIGHT_ENV", "development"))
    host: str = Field(default_factory=lambda: os.getenv("FINSIGHT_HOST", "0.0.0.0"))
    port: int = Field(default_factory=lambda: int(os.getenv("FINSIGHT_PORT", "8000")))
    company_code: str = Field(default_factory=lambda: os.getenv("FINSIGHT_COMPANY_CODE", "1000"))
    reference_date: date = Field(
        default_factory=lambda: date.fromisoformat(os.getenv("FINSIGHT_REFERENCE_DATE", "2026-09-30"))
    )
    random_seed: int = Field(default_factory=lambda: int(os.getenv("FINSIGHT_RANDOM_SEED", "42")))
    data_source: str = Field(default_factory=lambda: os.getenv("FINSIGHT_DATA_SOURCE", "mock"))
    log_level: str = Field(default_factory=lambda: os.getenv("FINSIGHT_LOG_LEVEL", "INFO"))

    # LLM & AI Investigator settings
    llm_provider: str = Field(default_factory=lambda: os.getenv("FINSIGHT_LLM_PROVIDER", "mock"))
    gemini_api_key: Optional[str] = Field(default_factory=lambda: os.getenv("GEMINI_API_KEY", None))
    openai_api_key: Optional[str] = Field(default_factory=lambda: os.getenv("OPENAI_API_KEY", None))
    llm_model: str = Field(default_factory=lambda: os.getenv("FINSIGHT_LLM_MODEL", "gemini-1.5-flash"))

    # Currency settings (Default INR / ₹ as per enterprise deployment)
    default_currency: str = Field(default_factory=lambda: os.getenv("FINSIGHT_CURRENCY", "INR"))
    currency_symbol: str = Field(default_factory=lambda: os.getenv("FINSIGHT_CURRENCY_SYMBOL", "₹"))

    # Security & CORS settings (Sprint 30)
    cors_allowed_origins: str = Field(
        default_factory=lambda: os.getenv(
            "FINSIGHT_CORS_ORIGINS",
            "http://localhost:8000,http://127.0.0.1:8000,http://localhost:3000,http://localhost:5173"
        )
    )

    # Demo / Benchmark Data Seeding (false in production)
    seed_demo_data: bool = Field(
        default_factory=lambda: os.getenv(
            "FINSIGHT_SEED_DEMO_DATA",
            "true" if os.getenv("FINSIGHT_ENV", "development").lower() != "production" else "false"
        ).lower() in ("true", "1", "yes")
    )

    # Demo Credentials UI Gating (Sprint 31)
    enable_demo_credentials: bool = Field(
        default_factory=lambda: os.getenv(
            "FINSIGHT_ENABLE_DEMO_CREDENTIALS",
            "true" if os.getenv("FINSIGHT_ENV", "development").lower() != "production" else "false"
        ).lower() in ("true", "1", "yes")
    )

    # SAP Integration Ready Configuration (Sprint 21)
    sap_base_url: Optional[str] = Field(default_factory=lambda: os.getenv("SAP_BASE_URL", None))
    sap_client: Optional[str] = Field(default_factory=lambda: os.getenv("SAP_CLIENT", "100"))
    sap_username: Optional[str] = Field(default_factory=lambda: os.getenv("SAP_USERNAME", None))
    sap_password: Optional[str] = Field(default_factory=lambda: os.getenv("SAP_PASSWORD", None))
    sap_verify_ssl: bool = Field(
        default_factory=lambda: os.getenv("SAP_VERIFY_SSL", "true").lower() in ("true", "1", "yes")
    )
    sap_mock_mode: bool = Field(
        default_factory=lambda: os.getenv("SAP_MOCK_MODE", "true").lower() in ("true", "1", "yes")
    )
    v4_url: Optional[str] = Field(default_factory=lambda: os.getenv("v4_url", None))
    v2_url: Optional[str] = Field(default_factory=lambda: os.getenv("v2_url", None))

    @property
    def is_sap_live_configured(self) -> bool:
        """Indicates whether a live SAP ERP connection is active (False when sap_mock_mode=True)."""
        return not self.sap_mock_mode and bool(self.sap_base_url and self.sap_username)

    def public_config(self) -> Dict[str, Any]:
        """Returns minimal, safe public metadata strictly for login/bootstrap UI."""
        return {
            "app_name": self.app_name,
            "version": self.version,
            "environment": self.environment,
            "enable_demo_credentials": self.enable_demo_credentials,
            "default_currency": self.default_currency,
            "currency_symbol": self.currency_symbol,
        }

    def safe_dict(self) -> Dict[str, Any]:
        """Returns non-sensitive configuration dictionary with secrets masked."""
        data = self.model_dump()
        data["is_sap_live_configured"] = self.is_sap_live_configured
        sensitive_keys = {"gemini_api_key", "openai_api_key", "sap_password"}
        for k in sensitive_keys:
            if data.get(k):
                data[k] = "********"
        return data


settings = Settings()


def get_settings() -> Settings:
    """Returns application runtime settings."""
    return settings


def format_currency(val: Optional[float], decimals: int = 2) -> str:
    """Standardized currency formatter for FinSight backend."""
    if val is None:
        return "N/A"
    sym = settings.currency_symbol
    return f"{sym}{val:,.{decimals}f}"



