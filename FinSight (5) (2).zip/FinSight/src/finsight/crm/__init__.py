"""FinSight Synthetic CRM Package."""

from finsight.crm.models import (
    AccountSignals,
    AccountStatus,
    CRMAccount,
    CRMActivity,
    CRMContact,
    CRMOpportunity,
    CustomerCRMProfile,
    RelationshipHealth,
)
from finsight.crm.crm_base import BaseCRMAdapter
from finsight.crm.crm_mock_adapter import MockCRMAdapter

__all__ = [
    "AccountSignals",
    "AccountStatus",
    "CRMAccount",
    "CRMActivity",
    "CRMContact",
    "CRMOpportunity",
    "CustomerCRMProfile",
    "RelationshipHealth",
    "BaseCRMAdapter",
    "MockCRMAdapter",
]
