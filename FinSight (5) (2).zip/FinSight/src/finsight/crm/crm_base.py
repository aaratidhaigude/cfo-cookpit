"""Base CRM Adapter Interface for FinSight Enterprise Intelligence."""

from abc import ABC, abstractmethod
from typing import List, Optional
from finsight.crm.models import (
    AccountSignals,
    CRMAccount,
    CRMActivity,
    CRMContact,
    CRMOpportunity,
    CustomerCRMProfile,
)


class BaseCRMAdapter(ABC):
    """Abstract boundary contract for CRM adapters (Synthetic, Salesforce, HubSpot, SAP CRM)."""

    @abstractmethod
    def get_account(self, customer_id: str) -> Optional[CRMAccount]:
        """Finds CRM Account linked to ERP Customer ID."""
        pass

    @abstractmethod
    def get_contacts(self, crm_account_id: str) -> List[CRMContact]:
        """Retrieves key stakeholder contacts for an account."""
        pass

    @abstractmethod
    def get_opportunities(self, crm_account_id: str) -> List[CRMOpportunity]:
        """Retrieves active and historical pipeline opportunities."""
        pass

    @abstractmethod
    def get_activities(self, crm_account_id: str) -> List[CRMActivity]:
        """Retrieves interaction log and dispute history."""
        pass

    @abstractmethod
    def get_signals(self, crm_account_id: str) -> AccountSignals:
        """Evaluates current relationship health and dispute signals."""
        pass

    @abstractmethod
    def get_customer_crm_profile(self, customer_id: str) -> Optional[CustomerCRMProfile]:
        """Retrieves the complete CRM context for an ERP Customer ID."""
        pass
