"""Deterministic Synthetic CRM Adapter for FinSight Enterprise Intelligence."""

from datetime import date
from typing import Dict, List, Optional
from finsight.crm.crm_base import BaseCRMAdapter
from finsight.crm.models import (
    AccountSignals,
    AccountStatus,
    CRMAccount,
    CRMActivity,
    CRMContact,
    CRMOpportunity,
    CustomerCRMProfile,
    RelationshipHealth,
)


class MockCRMAdapter(BaseCRMAdapter):
    """Provides realistic, deterministic synthetic CRM accounts, contacts, activities, and signals."""

    def __init__(self):
        self._accounts: Dict[str, CRMAccount] = {}
        self._contacts: Dict[str, List[CRMContact]] = {}
        self._opportunities: Dict[str, List[CRMOpportunity]] = {}
        self._activities: Dict[str, List[CRMActivity]] = {}
        self._signals: Dict[str, AccountSignals] = {}
        self._customer_to_account: Dict[str, str] = {}
        self._seed_scenarios()

    def _seed_scenarios(self) -> None:
        # Scenario 1: Risky Customer (Payment Dispute & Commercial Escalation)
        c101_acc = CRMAccount(
            crm_account_id="CRM-ACC-101",
            customer_id="CUST-101",
            legal_name="Apex Retail Group",
            trading_name="Apex Superstores",
            industry="Retail & Consumer Goods",
            segment="Strategic Enterprise Tier 1",
            region="North America",
            sales_region="West Coast",
            status=AccountStatus.DELINQUENT,
            customer_since="2022-03-15",
            account_owner="Sarah Jenkins (VP Commercial)",
            credit_class="CLASS_C",
            payment_terms="Net 30",
            credit_limit=3000000.0,
        )
        self._accounts["CRM-ACC-101"] = c101_acc
        self._customer_to_account["CUST-101"] = "CRM-ACC-101"

        self._contacts["CRM-ACC-101"] = [
            CRMContact(
                contact_id="CNT-101-01",
                crm_account_id="CRM-ACC-101",
                name="Marcus Vance",
                role="Chief Financial Officer",
                department="Finance & Treasury",
                email="marcus.vance@apexretail.internal",
                phone="+1 (415) 890-2341",
                is_finance_contact=True,
                is_executive_contact=True,
            ),
            CRMContact(
                contact_id="CNT-101-02",
                crm_account_id="CRM-ACC-101",
                name="Elena Rostova",
                role="Accounts Payable Manager",
                department="Disbursements",
                email="ap-escalations@apexretail.internal",
                phone="+1 (415) 890-2345",
                is_finance_contact=True,
                is_primary=False,
            ),
            CRMContact(
                contact_id="CNT-101-03",
                crm_account_id="CRM-ACC-101",
                name="David Chen",
                role="VP Global Merchandising",
                department="Procurement",
                email="dchen@apexretail.internal",
                phone="+1 (415) 890-2390",
                is_primary=True,
                is_procurement_contact=True,
            ),
        ]

        self._opportunities["CRM-ACC-101"] = [
            CRMOpportunity(
                opportunity_id="OPP-101-01",
                crm_account_id="CRM-ACC-101",
                name="FY27 Retail Supply Chain Expansion",
                stage="ON_HOLD_DISPUTE",
                expected_close_date="2026-12-15",
                probability=0.25,
                pipeline_value=2500000.0,
                owner="Sarah Jenkins",
                product_line="Enterprise Supply",
            )
        ]

        self._activities["CRM-ACC-101"] = [
            CRMActivity(
                activity_id="ACT-101-01",
                crm_account_id="CRM-ACC-101",
                activity_type="DISPUTE_LOG",
                subject="Invoice INV-AR-50065 Rebate Reconciliation Hold",
                activity_date="2026-09-22",
                owner="Sarah Jenkins",
                status="ESCALATED",
                outcome="AP Manager confirmed payment suspended pending credit memo validation of Q3 volume rebate.",
                linked_invoice_id="INV-AR-50065",
            ),
            CRMActivity(
                activity_id="ACT-101-02",
                crm_account_id="CRM-ACC-101",
                activity_type="ESCALATION",
                subject="Executive CFO Credit Warning Notice",
                activity_date="2026-09-28",
                owner="Finance Controller",
                status="PENDING",
                outcome="Delivered formal notice regarding overdue balances exceeding 60 days past terms.",
                linked_invoice_id="INV-AR-50065",
            ),
        ]

        self._signals["CRM-ACC-101"] = AccountSignals(
            payment_dispute=True,
            dispute_invoice_id="INV-AR-50065",
            dispute_reason="12% volume rebate deduction discrepancy claimed by customer AP",
            commercial_escalation=True,
            escalation_notes="CFO level intervention required to release ₹1,044,000 past-due invoices.",
            relationship_health=RelationshipHealth.AT_RISK,
            last_contact_date="2026-09-28",
            renewal_status="UNDER_REVIEW",
            pricing_review_pending=True,
            collection_discussion_active=True,
        )

        # Scenario 2: Healthy Customer (Nordic Solutions)
        c102_acc = CRMAccount(
            crm_account_id="CRM-ACC-102",
            customer_id="CUST-102",
            legal_name="Nordic Solutions AB",
            trading_name="Nordic Logistics",
            industry="Technology & Engineering",
            segment="Tier 1 Enterprise",
            region="EMEA",
            sales_region="Nordics",
            status=AccountStatus.ACTIVE,
            customer_since="2021-06-01",
            account_owner="Michael Chang",
            credit_class="CLASS_A",
            payment_terms="Net 30",
            credit_limit=6000000.0,
        )
        self._accounts["CRM-ACC-102"] = c102_acc
        self._customer_to_account["CUST-102"] = "CRM-ACC-102"

        self._contacts["CRM-ACC-102"] = [
            CRMContact(
                contact_id="CNT-102-01",
                crm_account_id="CRM-ACC-102",
                name="Astrid Lindqvist",
                role="Head of Procurement",
                department="Supply Chain",
                email="astrid.l@nordic.internal",
                phone="+46 8 123 4567",
                is_primary=True,
                is_procurement_contact=True,
            )
        ]
        self._opportunities["CRM-ACC-102"] = [
            CRMOpportunity(
                opportunity_id="OPP-102-01",
                crm_account_id="CRM-ACC-102",
                name="European Depot Expansion",
                stage="PROPOSAL",
                expected_close_date="2026-11-30",
                probability=0.80,
                pipeline_value=1200000.0,
                owner="Michael Chang",
            )
        ]
        self._activities["CRM-ACC-102"] = [
            CRMActivity(
                activity_id="ACT-102-01",
                crm_account_id="CRM-ACC-102",
                activity_type="MEETING",
                subject="Quarterly Business Review",
                activity_date="2026-09-15",
                owner="Michael Chang",
                status="COMPLETED",
                outcome="Relationship healthy; on-time payment track record praised.",
            )
        ]
        self._signals["CRM-ACC-102"] = AccountSignals(
            payment_dispute=False,
            commercial_escalation=False,
            relationship_health=RelationshipHealth.EXCELLENT,
            last_contact_date="2026-09-15",
            renewal_status="SECURED",
        )

        # Scenario 3: Commercially Problematic Customer (Vanguard Logistics)
        c103_acc = CRMAccount(
            crm_account_id="CRM-ACC-103",
            customer_id="CUST-103",
            legal_name="Vanguard Logistics Inc",
            trading_name="Vanguard Freight",
            industry="Transportation & Logistics",
            segment="Key Account",
            region="North America",
            sales_region="Midwest",
            status=AccountStatus.ACTIVE,
            customer_since="2023-08-10",
            account_owner="Robert Miller",
            credit_class="CLASS_B",
            payment_terms="Net 45",
            credit_limit=4000000.0,
        )
        self._accounts["CRM-ACC-103"] = c103_acc
        self._customer_to_account["CUST-103"] = "CRM-ACC-103"

        self._contacts["CRM-ACC-103"] = [
            CRMContact(
                contact_id="CNT-103-01",
                crm_account_id="CRM-ACC-103",
                name="James Thornton",
                role="VP Operations",
                department="Operations",
                email="jthornton@vanguard.internal",
                phone="+1 (312) 555-8901",
                is_primary=True,
            )
        ]
        self._opportunities["CRM-ACC-103"] = []
        self._activities["CRM-ACC-103"] = [
            CRMActivity(
                activity_id="ACT-103-01",
                crm_account_id="CRM-ACC-103",
                activity_type="CALL",
                subject="Freight Margin Contract Renegotiation",
                activity_date="2026-09-10",
                owner="Robert Miller",
                status="COMPLETED",
                outcome="Customer requested 5% discount due to industry volume softness.",
            )
        ]
        self._signals["CRM-ACC-103"] = AccountSignals(
            payment_dispute=False,
            commercial_escalation=False,
            relationship_health=RelationshipHealth.ATTENTION,
            last_contact_date="2026-09-10",
            pricing_review_pending=True,
        )

    def _ensure_customer_account(self, customer_id: str) -> str:
        if customer_id in self._customer_to_account:
            return self._customer_to_account[customer_id]

        # Generic dynamic fallback for any other customer
        acc_id = f"CRM-ACC-{customer_id.replace('CUST-', '')}"
        acc = CRMAccount(
            crm_account_id=acc_id,
            customer_id=customer_id,
            legal_name=f"Customer {customer_id}",
            trading_name=f"Trading {customer_id}",
            industry="General Commercial",
            segment="Standard Account",
            region="Global",
            sales_region="Regional",
            status=AccountStatus.ACTIVE,
            account_owner="Commercial Accounts Team",
            credit_class="CLASS_B",
            payment_terms="Net 30",
            credit_limit=2000000.0,
        )
        self._accounts[acc_id] = acc
        self._customer_to_account[customer_id] = acc_id
        self._contacts[acc_id] = [
            CRMContact(
                contact_id=f"CNT-{customer_id}-01",
                crm_account_id=acc_id,
                name="Finance Lead",
                role="Accounts Payable",
                department="Finance",
                email=f"ap@{customer_id.lower()}.internal",
                phone="+1 (555) 010-0000",
                is_finance_contact=True,
                is_primary=True,
            )
        ]
        self._opportunities[acc_id] = []
        self._activities[acc_id] = [
            CRMActivity(
                activity_id=f"ACT-{customer_id}-01",
                crm_account_id=acc_id,
                activity_type="ACCOUNT_REVIEW",
                subject="Annual Commercial Relationship Review",
                activity_date="2026-08-15",
                owner="Commercial Accounts Team",
                status="COMPLETED",
                outcome="Standard account terms maintained.",
            )
        ]

        self._signals[acc_id] = AccountSignals(
            payment_dispute=False,
            commercial_escalation=False,
            relationship_health=RelationshipHealth.HEALTHY,
        )
        return acc_id

    def get_account(self, customer_id: str) -> Optional[CRMAccount]:
        acc_id = self._ensure_customer_account(customer_id)
        return self._accounts.get(acc_id)

    def get_contacts(self, crm_account_id: str) -> List[CRMContact]:
        return self._contacts.get(crm_account_id, [])

    def get_opportunities(self, crm_account_id: str) -> List[CRMOpportunity]:
        return self._opportunities.get(crm_account_id, [])

    def get_activities(self, crm_account_id: str) -> List[CRMActivity]:
        return self._activities.get(crm_account_id, [])

    def get_signals(self, crm_account_id: str) -> AccountSignals:
        return self._signals.get(crm_account_id, AccountSignals())

    def get_customer_crm_profile(self, customer_id: str) -> Optional[CustomerCRMProfile]:
        acc_id = self._ensure_customer_account(customer_id)
        acc = self._accounts.get(acc_id)
        if not acc:
            return None
        return CustomerCRMProfile(
            account=acc,
            contacts=self.get_contacts(acc_id),
            opportunities=self.get_opportunities(acc_id),
            activities=self.get_activities(acc_id),
            signals=self.get_signals(acc_id),
        )

    get_customer_profile = get_customer_crm_profile

