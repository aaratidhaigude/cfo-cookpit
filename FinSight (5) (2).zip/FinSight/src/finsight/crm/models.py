﻿"""Pydantic Models for Synthetic CRM Layer in FinSight."""

from datetime import date
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class RelationshipHealth(str, Enum):
    EXCELLENT = "EXCELLENT"
    HEALTHY = "HEALTHY"
    ATTENTION = "ATTENTION"
    AT_RISK = "AT_RISK"
    CRITICAL = "CRITICAL"


class AccountStatus(str, Enum):
    ACTIVE = "ACTIVE"
    ON_HOLD = "ON_HOLD"
    DELINQUENT = "DELINQUENT"
    PROSPECT = "PROSPECT"


class CRMAccount(BaseModel):
    """CRM Master Account linked to ERP Customer."""
    crm_account_id: str = Field(description="Unique CRM account identifier, e.g. CRM-ACC-101")
    customer_id: str = Field(description="Foreign key to ERP Customer ID, e.g. CUST-101")
    legal_name: str
    trading_name: Optional[str] = None
    industry: str = "Enterprise Retail"
    segment: str = "Key Account"
    region: str = "North America"
    sales_region: str = "West Coast"
    status: AccountStatus = AccountStatus.ACTIVE
    customer_since: str = "2023-01-15"
    account_owner: str = "Sarah Jenkins (VP Commercial)"
    credit_class: str = "CLASS_B"
    payment_terms: str = "Net 30"
    credit_limit: float = 5000000.0


class CRMContact(BaseModel):
    """Individual stakeholder contact associated with an enterprise account."""
    contact_id: str
    crm_account_id: str
    name: str
    role: str
    department: str
    email: str
    phone: str
    is_primary: bool = False
    is_finance_contact: bool = False
    is_procurement_contact: bool = False
    is_executive_contact: bool = False


class CRMOpportunity(BaseModel):
    """Commercial pipeline opportunity."""
    opportunity_id: str
    crm_account_id: str
    name: str
    stage: str  # QUALIFICATION, PROPOSAL, NEGOTIATION, CLOSED_WON
    expected_close_date: str
    probability: float
    pipeline_value: float
    owner: str
    product_line: Optional[str] = None


class CRMActivity(BaseModel):
    """Customer interaction, meeting, escalation note, or touchpoint."""
    activity_id: str
    crm_account_id: str
    activity_type: str  # CALL, MEETING, EMAIL, DISPUTE_LOG, ESCALATION
    subject: str
    activity_date: str
    owner: str
    status: str  # COMPLETED, PENDING, ESCALATED
    outcome: str
    linked_invoice_id: Optional[str] = None


class AccountSignals(BaseModel):
    """Predictive and operational CRM telemetry signals."""
    payment_dispute: bool = False
    dispute_invoice_id: Optional[str] = None
    dispute_reason: Optional[str] = None
    commercial_escalation: bool = False
    escalation_notes: Optional[str] = None
    relationship_health: RelationshipHealth = RelationshipHealth.HEALTHY
    last_contact_date: Optional[str] = None
    renewal_status: str = "ACTIVE"
    pricing_review_pending: bool = False
    collection_discussion_active: bool = False


class CustomerCRMProfile(BaseModel):
    """Aggregated enterprise customer CRM dossier combining account, contacts, and telemetry."""
    account: CRMAccount
    contacts: List[CRMContact] = Field(default_factory=list)
    opportunities: List[CRMOpportunity] = Field(default_factory=list)
    activities: List[CRMActivity] = Field(default_factory=list)
    signals: AccountSignals
