"""Governed Enterprise Finance Knowledge Corpus.

Provides realistic, versioned mock enterprise finance policies, SOPs,
internal controls, and escalation rules for FinSight AI.
All documents are clearly marked as Demo Finance Governance.
"""

from typing import List
from finsight.models.knowledge import DocumentType, KnowledgeDocument


def get_default_knowledge_documents() -> List[KnowledgeDocument]:
    """Returns the authoritative enterprise finance knowledge corpus for 2026."""
    return [
        # 1. Collections Escalation Policy
        KnowledgeDocument(
            document_id="COLL-POL-001",
            title="Collections Escalation Policy",
            document_type=DocumentType.POLICY,
            domain="AR",
            version="2.1",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="Head of Credit & Collections",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Collections Escalation Policy (COLL-POL-001, v2.1)

## Section 1: Purpose and Operational Scope
This policy establishes mandatory operational protocols and escalation thresholds for past-due Trade Accounts Receivable (AR). The objective is to mitigate working capital deterioration, minimize DSO expansion, prevent bad debt write-offs, and establish clear criteria for commercial and legal escalations.

## Section 2: Customer Risk Segmentation
Customers are categorized into three credit risk tiers:
- **Tier 1 (Strategic Enterprise Accounts):** Key accounts with annual revenue > ₹1,000,000 and credit limits up to ₹2,000,000 (e.g. Apex Retail Group, Quantum Industrial). Dedicated Senior Credit Controller assigned.
- **Tier 2 (Commercial Growth Accounts):** Mid-tier accounts with annual revenue ₹250,000 to ₹1,000,000 and credit limits up to ₹500,000.
- **Tier 3 (Standard Transactional Accounts):** General commercial accounts with credit limits under ₹250,000. Standard dunning applies.

## Section 3: Material Overdue Escalation Thresholds & Shipment Holds
Collection actions escalate based on aging and aggregate past-due exposure:
- **Threshold 3.1 — Early Warning Dunning (1 to 15 Days Overdue):** Automated statement reminder and friendly notification to customer Accounts Payable department.
- **Threshold 3.2 — Formal Finance Escalation (16 to 30 Days Overdue or Balance > ₹250,000):** Formal collection dunning letter issued. Collections Specialist initiates phone outreach and requests confirmed payment remittance schedule.
- **Threshold 3.3 — Executive Critical Escalation & Mandatory Shipment Hold (> 45 Days Overdue AND Exposure > ₹500,000):**
  When a customer holds overdue balances exceeding **₹500,000.00** with at least one invoice aged greater than **45 days overdue**, the following actions are strictly mandatory:
  1. An **immediate administrative credit hold** must be placed on all pending and future merchandise shipment releases.
  2. Notification is dispatched within 24 hours to the Chief Commercial Officer (CCO) and Chief Financial Officer (CFO).
  3. An urgent executive collection meeting must be scheduled with customer C-level or AP leadership.
  4. A formal remediation case must be initiated in FinSight.
- **Threshold 3.4 — Legal Referral & Bad Debt Provisioning (> 90 Days Overdue):** Formal legal demand letter and reclassification to 100% expected credit loss reserve.

## Section 4: Required Evidence for Escalation
Before initiating an executive escalation or credit hold, the collections team must assemble the following verified evidence:
1. Certified Accounts Receivable subledger open item statement (BSID).
2. Itemized schedule of past-due invoices including invoice IDs, issuance dates, due dates, and open amounts.
3. Proof of delivery (POD) confirmations or signed bill of lading documentation.
4. Summary log of all prior written and verbal communication attempts with customer finance.

## Section 5: Mandatory Case Opening Requirement
When a customer account breaches Threshold 3.3 (> ₹500,000 past due and > 45 days overdue), the Credit Controller must open an official **CRITICAL** severity remediation case in FinSight within 1 business day, linking verified invoice evidence and assigning an executive owner.
""",
            metadata={
                "escalation_threshold_inr": 500000.0,
                "escalation_threshold_usd": 500000.0,
                "critical_days_overdue": 45,
                "formal_escalation_inr": 250000.0,
                "formal_escalation_usd": 250000.0,
                "mandatory_shipment_hold": True,
            },
        ),

        # 2. Accounts Receivable SOP
        KnowledgeDocument(
            document_id="AR-SOP-001",
            title="Accounts Receivable Standard Operating Procedure",
            document_type=DocumentType.SOP,
            domain="AR",
            version="1.5",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="Credit & Collections Manager",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_OPERATIONAL",
            text="""# Accounts Receivable Standard Operating Procedure (AR-SOP-001, v1.5)

## Section 1: Weekly Subledger Aging Review
Every Monday morning, the Credit & Collections team must review the authoritative subledger aging report across four discrete aging brackets:
- Current (0 to 30 days past due)
- Moderate Risk (31 to 60 days past due)
- High Risk (61 to 90 days past due)
- Critical Delinquency (> 90 days past due)

## Section 2: Collection Follow-Up Cadence
- Invoices reaching 7 days prior to due date: Send electronic statement preview.
- Invoices 1 to 14 days overdue: Weekly email reminders.
- Invoices 15 to 44 days overdue: Bi-weekly direct phone engagement with Accounts Payable supervisor.
- Invoices > 45 days overdue: Mandatory escalation to Credit Controller for executive intervention.

## Section 3: Billing Dispute Handling & Reconciliation
If a customer claims a billing dispute (pricing discrepancy, damaged goods, or missing purchase order number):
1. The invoice dispute must be logged in the financial ledger within 2 business days.
2. Commercial sales representative must confirm pricing terms against master service agreements within 5 business days.
3. Undisputed portions of the invoice balance remain subject to standard collection escalation.

## Section 4: General Ledger to Subledger Control Ties
At each month-end close, the sum of all open customer line items in the AR subledger (BSID) must tie to the general ledger Trade Accounts Receivable control account (GL 110000). Any reconciling variances (such as unitemized opening balances or clearing timing differences) must be explicitly classified and documented in the monthly financial reconciliation report.
""",
            metadata={
                "review_frequency": "WEEKLY",
                "aging_buckets": ["0-30", "31-60", "61-90", "90+"],
            },
        ),

        # 3. Vendor Payment Approval & Disbursement Policy
        KnowledgeDocument(
            document_id="AP-POL-001",
            title="Vendor Payment Approval and Disbursement Policy",
            document_type=DocumentType.POLICY,
            domain="AP",
            version="3.0",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="Corporate Controller",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Vendor Payment Approval and Disbursement Policy (AP-POL-001, v3.0)

## Section 1: Upcoming Disbursement Review Horizon
Treasury and Accounts Payable operate on a mandatory 7-calendar-day forward-looking disbursement schedule (covering reference date through reference date + 7 days). All supplier obligations maturing in this window must be validated against available liquid cash.

## Section 2: Delegation of Authority & Approval Thresholds
All outgoing disbursements require formal authorization based on payment amount:
- **Level 1 (Disbursements < ₹50,000):** Approved by Accounts Payable Supervisor.
- **Level 2 (Disbursements ₹50,000 to ₹250,000):** Dual approval by Accounts Payable Manager and Assistant Controller.
- **Level 3 (Disbursements > ₹250,000):** Dual approval by Corporate Controller and VP Treasury or CFO.

## Section 3: Vendor Prioritization during Liquidity Constraints
When available liquid cash is insufficient to cover 100% of upcoming 7-day obligations, disbursements must be prioritized according to supplier criticality:
1. **Tier 1 — Mission-Critical Production Suppliers:** Suppliers providing core fabrication inputs (e.g. Titan Semiconductor Ltd, Precision Metalworks) whose stoppage would halt factory manufacturing lines.
2. **Tier 2 — Critical Logistics & Freight:** Freight carriers transporting customer shipments (e.g. Global Freight & Logistics) where service interruption impacts customer delivery commitments.
3. **Tier 3 — General Operating & Overhead Vendors:** General consumable suppliers, software subscriptions, and administrative services.

## Section 4: Structured Split-Payment Negotiation Protocol
For obligations exceeding ₹250,000 due within 7 days where full settlement would compromise the liquidity safety buffer:
- Treasury is authorized to negotiate structured weekly split payments (e.g. 50% on due date, 50% in 14 days).
- Supplier consent must be confirmed in writing.
- Discounts forfeited and penalty interest must be evaluated prior to execution.
""",
            metadata={
                "approval_level_3_threshold": 250000.0,
                "disbursement_horizon_days": 7,
            },
        ),

        # 4. Liquidity Risk & Cash Runway Control Policy
        KnowledgeDocument(
            document_id="LIQ-CTRL-001",
            title="Liquidity Risk and Cash Runway Control Policy",
            document_type=DocumentType.CONTROL,
            domain="TREASURY",
            version="2.0",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="VP Treasury",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Liquidity Risk and Cash Runway Control Policy (LIQ-CTRL-001, v2.0)

## Section 1: Mandatory Liquidity Coverage Ratio (LCR)
Treasury enforces a continuous 7-day Liquidity Coverage Ratio (LCR) defined as:
$$\\text{LCR} = \\frac{\\text{Total Liquid Cash Reserves}}{\\text{Upcoming 7-Day Net Payables}}$$

- **Benchmark Operating Target:** LCR $\\ge 1.25\\text{x}$ (Provides safe operating buffer above all near-term commitments).
- **Minimum Safe Operational Floor:** LCR $\\ge 1.00\\text{x}$ (Cash fully covers all obligations due within 7 days).

## Section 2: Escalation Triggers and Risk Classification
- **Level 1 — Liquidity Squeeze Warning (LCR < 1.00x):**
  Triggered when available cash is less than 7-day maturing obligations (coverage deficit). Daily treasury reporting is mandated, non-essential discretionary payments are paused, and collections acceleration is initiated.
- **Level 2 — Critical Liquidity Emergency (LCR < 0.75x):**
  Triggered when cash covers less than 75% of upcoming 7-day obligations (e.g. current 0.59x coverage). Requires:
  1. Immediate convening of the Executive Treasury Committee (CFO, VP Treasury, Controller).
  2. Evaluation of immediate draw options on the existing revolving bank credit facility.
  3. Formal outreach to top vendors due in 7 days (e.g. Titan Semiconductor, Precision Metalworks) to execute split-payment agreements.
  4. Opening of an executive remediation case in FinSight (`LIQUIDITY` category, `HIGH` or `CRITICAL` severity).

## Section 3: Treasury Corrective Actions
When coverage drops below 1.00x, Treasury may not approve single-vendor disbursements exceeding ₹300,000 without written CFO concurrence.
""",
            metadata={
                "lcr_target": 1.25,
                "lcr_minimum_safe": 1.00,
                "lcr_emergency_threshold": 0.75,
            },
        ),

        # 5. Inventory Risk & Working Capital Policy
        KnowledgeDocument(
            document_id="INV-POL-001",
            title="Inventory Risk and Working Capital Policy",
            document_type=DocumentType.POLICY,
            domain="INVENTORY",
            version="1.8",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="VP Supply Chain & Operations",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Inventory Risk and Working Capital Policy (INV-POL-001, v1.8)

## Section 1: Working Capital Optimization & DIO Benchmark
Inventory represents a substantial commitment of working capital. The corporate operating benchmark for inventory efficiency is:
- **Operating Target Days Sales of Inventory (DIO):** $\\le 75.0\\text{ days}$
- **Upper Limit Tolerance:** $85.0\\text{ days}$

## Section 2: Inventory Buildup & Investigation Triggers
A formal operational inventory investigation is triggered when any of the following occur:
1. **DIO Threshold Breach:** Measured DIO exceeds **85.0 days** at fiscal period close (current September 2026 DIO is 89.6 days).
2. **Sales-Inventory Growth Decoupling:** Inventory book value increases month-over-month by $> 5.0\\%$ while monthly revenue is flat or declining.
3. **Carrying Drag:** Net working capital trapped in merchandise inventory exceeds ₹2,500,000.00.

## Section 3: Scope of Inventory Investigation
When an inventory buildup trigger is tripped, Finance and Operations must conduct a structured audit across:
- **Product Group Aging:** Inspect stock levels by category (Processors, Memory Modules, Electronic Assemblies, Storage).
- **Slow-Moving SKUs:** Identify items with zero shipments in the past 60 days.
- **Inbound Purchase Order Review:** Re-evaluate open supplier POs to defer or cancel excess raw materials deliveries.
- **Gross Margin Protection:** Ensure excess stock is not dumped at discounts that dilute operating gross margin below corporate thresholds.
""",
            metadata={
                "dio_target": 75.0,
                "dio_upper_tolerance": 85.0,
                "inventory_threshold_inr": 2500000.0,
                "inventory_threshold_usd": 2500000.0,
            },
        ),

        # 6. Gross Margin Control & Profitability Policy
        KnowledgeDocument(
            document_id="GM-POL-001",
            title="Gross Margin Control and Profitability Policy",
            document_type=DocumentType.POLICY,
            domain="PROFITABILITY",
            version="2.2",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="Head of Commercial Finance",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Gross Margin Control and Profitability Policy (GM-POL-001, v2.2)

## Section 1: Corporate Profitability Benchmark
The corporate target for consolidated operating gross margin is:
- **Consolidated Target Gross Margin:** $\\ge 40.0\\%$ (September 2026 actual: 40.28%).
- **Minimum Acceptable Gross Margin:** $38.0\\%$.

## Section 2: Margin Deterioration Materiality Thresholds
A formal Margin Dilution Investigation is triggered when:
1. **Period Compression:** Consolidated gross margin contracts by $> 1.5\\text{ percentage points}$ period-over-period.
2. **Account Margin Dilution:** Any enterprise customer account contributing > ₹200,000.00 in monthly gross revenue operates at a gross margin below **30.0%** (e.g. OmniChannel Logistics generating ₹262,000 at 27.5% margin).
3. **Product Line Deficit:** Any product category with negative or single-digit gross margins.

## Section 3: Remediation & Pricing Actions
When an account breaches the 30.0% margin floor:
- Commercial sales team must audit contracted fulfillment and packaging costs.
- Product pricing team must evaluate volume tier adjustments and indexation clauses.
- Opening of a `MARGIN` category case is recommended to track contract re-negotiation.
""",
            metadata={
                "target_gross_margin_pct": 40.0,
                "customer_margin_floor_pct": 30.0,
                "material_compression_pp": 1.5,
            },
        ),

        # 7. Customer Credit & Payment Terms Governance Policy
        KnowledgeDocument(
            document_id="CRED-POL-001",
            title="Customer Credit and Payment Terms Governance Policy",
            document_type=DocumentType.POLICY,
            domain="AR",
            version="1.4",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="Credit Risk Committee",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Customer Credit and Payment Terms Governance Policy (CRED-POL-001, v1.4)

## Section 1: Standard Payment Terms by Customer Segment
Standard contract terms are established as follows:
- **Tier 1 Strategic Customers:** NET30 days standard. Requires semi-annual credit review and audited financial statements.
- **Tier 2 Commercial Accounts:** NET30 days standard.
- **Tier 3 Small / Transactional:** NET15 days standard or payment upon order delivery.
Any departure from standard payment terms requires written approval from the Chief Financial Officer.

## Section 2: Credit Limit Administration & Automated Holds
- When aggregate open receivables (current + overdue) exceed 95% of approved credit limit, system flags account for review.
- When any past-due balance exceeds 30 days overdue, commercial credit is suspended and new sales orders require upfront deposit.
""",
            metadata={
                "standard_terms": "NET30",
                "credit_hold_days": 30,
            },
        ),

        # 8. Financial Remediation Case Governance SOP
        KnowledgeDocument(
            document_id="CASE-SOP-001",
            title="Financial Remediation Case Governance SOP",
            document_type=DocumentType.SOP,
            domain="GOVERNANCE",
            version="2.0",
            effective_from="2026-01-01",
            effective_to=None,
            status="ACTIVE",
            owner="Director of Financial Governance",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_GOVERNANCE",
            text="""# Financial Remediation Case Governance SOP (CASE-SOP-001, v2.0)

## Section 1: Mandatory Criteria for Opening Financial Cases
A formal remediation case must be opened in FinSight when any of the following occur:
1. **Delinquency Escalation:** Overdue customer receivables exceed ₹500,000.00 with aging > 45 days (Category: `RECEIVABLES`, Severity: `CRITICAL`).
2. **Liquidity Squeeze:** 7-Day Liquidity Coverage Ratio drops below 1.00x (Category: `LIQUIDITY`, Severity: `HIGH` or `CRITICAL`).
3. **Margin Dilution:** Large account revenue operates below 30.0% gross margin (Category: `MARGIN`, Severity: `MEDIUM`).

## Section 2: Incident Snapshot Integrity
- Every case records the initial monetary exposure as an **immutable historical incident snapshot** at creation time.
- Dynamic metric updates must be referenced via linked attention items (`linked_attention_id`) or investigation IDs rather than mutating the initial incident exposure amount.

## Section 3: Ownership and Remediation Roles
Cases are assigned to responsible functional leads:
- `RECEIVABLES` -> Credit Controller
- `LIQUIDITY` -> Treasury Manager
- `MARGIN` -> Procurement Lead / Commercial Controller

## Section 4: Documentation & Closure Requirements
Every case must record structured audit notes detailing actions taken. Closure requires verified subledger remediation (e.g. payment receipt confirmation or signed payment agreement).
""",
            metadata={
                "mandatory_categories": ["RECEIVABLES", "LIQUIDITY", "MARGIN"],
                "snapshot_integrity_required": True,
            },
        ),

        # 9. Superseded Policy (for testing versioning and effective date filtering)
        KnowledgeDocument(
            document_id="COLL-POL-001-v1.0",
            title="Collections Escalation Policy (Legacy 2024-2025)",
            document_type=DocumentType.POLICY,
            domain="AR",
            version="1.0",
            effective_from="2024-01-01",
            effective_to="2025-12-31",
            status="SUPERSEDED",
            owner="Head of Credit & Collections",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Collections Escalation Policy (Legacy v1.0)
Legacy escalation threshold was ₹100,000 and 30 days. This policy has been superseded by v2.1 effective 2026-01-01.
""",
            metadata={
                "superseded_by": "COLL-POL-001-v2.1",
            },
        ),

        # 10. Expired Document (for testing negative expired filtering)
        KnowledgeDocument(
            document_id="TAX-SOP-EXPIRED",
            title="Special Temporary Tax Assessment SOP (Expired)",
            document_type=DocumentType.SOP,
            domain="GOVERNANCE",
            version="1.0",
            effective_from="2024-01-01",
            effective_to="2025-12-31",
            status="EXPIRED",
            owner="Tax Director",
            source="Internal Enterprise Finance Knowledge Base (Demo Policy)",
            confidentiality="INTERNAL_CONFIDENTIAL",
            text="""# Special Temporary Tax Assessment SOP (Expired)
This temporary compliance procedure expired on 2025-12-31 and has no application in fiscal year 2026.
""",
            metadata={
                "is_expired": True,
            },
        ),
    ]
