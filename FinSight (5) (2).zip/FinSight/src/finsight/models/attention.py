"""Financial Attention Models for FinSight.

Transforms intelligence signals into prioritized, actionable attention items
ranked by deterministic business significance, exposure, and velocity.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from finsight.models.evidence import EvidenceItem


class AttentionSeverity(str, Enum):
    """Urgency / severity level."""
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class AttentionType(str, Enum):
    """Categorized financial attention issue types."""
    CASH_PRESSURE = "CASH_PRESSURE"
    AR_DETERIORATION = "AR_DETERIORATION"
    AP_PRESSURE = "AP_PRESSURE"
    INVENTORY_BUILDUP = "INVENTORY_BUILDUP"
    MARGIN_COMPRESSION = "MARGIN_COMPRESSION"
    CUSTOMER_CONCENTRATION = "CUSTOMER_CONCENTRATION"
    CUSTOMER_PAYMENT_DETERIORATION = "CUSTOMER_PAYMENT_DETERIORATION"
    HIGH_REVENUE_LOW_MARGIN = "HIGH_REVENUE_LOW_MARGIN"
    MATERIAL_FINANCIAL_CHANGE = "MATERIAL_FINANCIAL_CHANGE"
    DATA_QUALITY_ISSUE = "DATA_QUALITY_ISSUE"


class AttentionStatus(str, Enum):
    """Workflow state of an attention item."""
    OPEN = "OPEN"
    IN_REVIEW = "IN_REVIEW"
    RESOLVED = "RESOLVED"
    DISMISSED = "DISMISSED"


class AttentionItem(BaseModel):
    """A structured, prioritized financial finding requiring executive or operational attention."""
    id: str = Field(description="Unique deterministic identifier, e.g. 'ATTN-AR-202609-01'")
    type: AttentionType = Field(description="Classification of financial concern")
    title: str = Field(description="Short human-readable headline")
    severity: AttentionSeverity = Field(description="Priority severity level")
    priority_score: float = Field(description="Deterministic ranking score (0.0 to 100.0)")
    priority_reason: str = Field(description="Explainable rationale behind priority score")
    financial_impact: float = Field(description="Total monetary value at risk or involved")
    change: Optional[Dict[str, Any]] = Field(default=None, description="Comparative delta details if applicable")
    summary: str = Field(description="Detailed executive summary explaining the condition")
    drivers: List[str] = Field(default_factory=list, description="Primary drivers or contributors")
    entities: List[Dict[str, Any]] = Field(default_factory=list, description="Entities involved (customers, vendors, products)")
    evidence: List[EvidenceItem] = Field(default_factory=list, description="Audit evidence supporting the finding")
    period: str = Field(description="Fiscal period")
    status: AttentionStatus = Field(default=AttentionStatus.OPEN)
    # S12 Context Preservation & Alias Fields
    attention_id: Optional[str] = Field(default=None, description="Alias for id")
    financial_exposure: Optional[float] = Field(default=None, description="Alias for financial_impact")
    metric: Optional[str] = Field(default=None, description="Governed financial metric affected (e.g. dso, cash_position)")
    recommended_question: Optional[str] = Field(default=None, description="Direct query to launch investigation")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def model_post_init(self, __context: Any) -> None:
        if not self.attention_id:
            self.attention_id = self.id
        if self.financial_exposure is None:
            self.financial_exposure = self.financial_impact


class AttentionSummary(BaseModel):
    """Aggregated portfolio of attention items returned by API."""
    period: str
    total_items: int
    counts_by_severity: Dict[str, int] = Field(default_factory=dict)
    counts_by_type: Dict[str, int] = Field(default_factory=dict)
    total_financial_exposure: float
    items: List[AttentionItem] = Field(default_factory=list)
