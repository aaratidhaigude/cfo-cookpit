"""Canonical Financial Models for FinSight.

These models define the standardized financial representations independent of underlying
source adapters (e.g., Mock generator, SAP S/4HANA OData, CDS Views, Flat Files).
"""

from datetime import date
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator


class DebitCreditIndicator(str, Enum):
    """Debit/Credit indicator following standard ERP conventions (S=Debit, H=Credit, D/C also supported)."""
    DEBIT = "D"
    CREDIT = "C"
    SOLL = "S"   # SAP standard German: Soll (Debit)
    HABEN = "H"  # SAP standard German: Haben (Credit)


class FinancialConcept(str, Enum):
    """High-level financial concept mapped to GL accounts."""
    CASH = "CASH"
    AR = "AR"
    OTHER_RECEIVABLES = "OTHER_RECEIVABLES"
    INVENTORY = "INVENTORY"
    OTHER_CURRENT_ASSET = "OTHER_CURRENT_ASSET"
    NON_CURRENT_ASSET = "NON_CURRENT_ASSET"
    AP = "AP"
    OTHER_PAYABLES = "OTHER_PAYABLES"
    SHORT_TERM_DEBT = "SHORT_TERM_DEBT"
    OTHER_CURRENT_LIABILITY = "OTHER_CURRENT_LIABILITY"
    LONG_TERM_LIABILITY = "LONG_TERM_LIABILITY"
    EQUITY = "EQUITY"
    REVENUE = "REVENUE"
    COGS = "COGS"
    OPEX = "OPEX"
    TAX_INTEREST = "TAX_INTEREST"


class AccountCategory(str, Enum):
    """Balance Sheet & P&L categories."""
    ASSET = "ASSET"
    LIABILITY = "LIABILITY"
    EQUITY = "EQUITY"
    REVENUE = "REVENUE"
    EXPENSE = "EXPENSE"


class Company(BaseModel):
    """Legal entity / Company code definition."""
    company_code: str = Field(description="Unique code identifying the company (e.g. '1000')")
    company_name: str = Field(description="Legal entity name")
    currency: str = Field(default="INR", description="Default operational currency")
    controlling_area: str = Field(default="CA01", description="Controlling area (CO area)")
    fiscal_calendar: str = Field(default="K4", description="Fiscal year variant (e.g. K4: Calendar Year)")


class Customer(BaseModel):
    """Customer master record."""
    customer_id: str = Field(description="Unique customer identifier")
    customer_name: str = Field(description="Business or legal customer name")
    segment: str = Field(description="Market segment: Enterprise, Mid-Market, SMB, Wholesale, Retail")
    region: str = Field(description="Geographic region: North America, EMEA, APAC, LATAM")
    payment_terms: str = Field(description="Standard payment terms (e.g., NET30, NET45, NET60)")
    industry: Optional[str] = Field(default=None, description="Industry sector (e.g. Retail, Manufacturing, Technology)")
    credit_limit: float = Field(default=1000000.0, description="Approved credit exposure limit in local currency")
    risk_class: str = Field(default="B", description="Credit risk class: A (Low), B (Medium), C (High), D (Critical)")


class Vendor(BaseModel):
    """Vendor / Supplier master record."""
    vendor_id: str = Field(description="Unique vendor identifier")
    vendor_name: str = Field(description="Supplier or vendor trade name")
    category: str = Field(description="Spend category: Raw Materials, Logistics, IT Services, Facilities, Marketing")
    payment_terms: str = Field(description="Contracted payment terms (e.g., NET15, NET30, NET45)")
    region: str = Field(default="North America", description="Vendor operating region")
    criticality: str = Field(default="MEDIUM", description="Supply chain criticality: LOW, MEDIUM, HIGH, STRATEGIC")


class Product(BaseModel):
    """Product / Material master record."""
    product_id: str = Field(description="Unique product identifier")
    product_name: str = Field(description="Product or SKU name")
    product_group: str = Field(description="Product group or classification")
    profit_center: str = Field(description="Associated profit center code")
    material_id: Optional[str] = Field(default=None, description="SAP Material number (MATNR)")
    material_group: Optional[str] = Field(default=None, description="Material group code")
    product_family: Optional[str] = Field(default=None, description="Product family line")
    standard_cost: float = Field(default=0.0, description="Standard inventory valuation cost per unit")
    selling_price: float = Field(default=0.0, description="Standard selling price per unit")
    unit: str = Field(default="EA", description="Base unit of measure (e.g. EA, KG, L)")


class AccountMapping(BaseModel):
    """GL Account mapping to standardized canonical financial concepts."""
    gl_account: str = Field(description="General ledger account code")
    financial_concept: FinancialConcept = Field(description="Canonical financial concept")
    category: AccountCategory = Field(description="High-level financial statement category")
    valid_from: date = Field(description="Validity start date")
    valid_to: Optional[date] = Field(default=None, description="Validity end date (None = ongoing)")


class JournalEntry(BaseModel):
    """General Ledger posting line item (ACDOCA-aligned Universal Journal representation)."""
    company_code: str = Field(description="Company code")
    fiscal_year: int = Field(description="Fiscal year (e.g. 2026)")
    fiscal_period: int = Field(description="Fiscal period (1-12)")
    posting_date: date = Field(description="Accounting document posting date")
    document_id: str = Field(description="Unique journal entry document number (BELNR)")
    gl_account: str = Field(description="General ledger account number (RACCT)")
    line_item: int = Field(default=1, description="Document line item number (DOCLN / BUZEI)")
    document_date: Optional[date] = Field(default=None, description="Document issuance date (BLDAT)")
    due_date: Optional[date] = Field(default=None, description="Net payment due date (NETDT / FAEDT)")
    clearing_document: Optional[str] = Field(default=None, description="Clearing document number (AUGBL)")
    clearing_date: Optional[date] = Field(default=None, description="Date cleared (AUGDT)")
    open_cleared: str = Field(default="O", description="Open ('O') or Cleared ('C') item status")
    profit_center: Optional[str] = Field(default=None, description="Profit center allocation (PRCTR)")
    cost_center: Optional[str] = Field(default=None, description="Cost center allocation (KOSTL)")
    segment: Optional[str] = Field(default=None, description="Business segment")
    customer_id: Optional[str] = Field(default=None, description="Associated customer ID if subledger line (KUNNR)")
    vendor_id: Optional[str] = Field(default=None, description="Associated vendor ID if subledger line (LIFNR)")
    product_id: Optional[str] = Field(default=None, description="Associated product ID if product line (MATNR)")
    debit_credit: str = Field(description="Debit ('S' or 'D') or Credit ('H' or 'C') indicator")
    amount: float = Field(ge=0.0, description="Absolute transaction amount in local currency")
    currency: str = Field(default="INR", description="Currency code")

    @property
    def is_debit(self) -> bool:
        return self.debit_credit.upper() in ("D", "S")

    @property
    def is_credit(self) -> bool:
        return self.debit_credit.upper() in ("C", "H")

    @property
    def signed_amount(self) -> float:
        """Positive for debit, negative for credit."""
        return self.amount if self.is_debit else -self.amount


class AROpenItem(BaseModel):
    """Accounts Receivable open or cleared item from customer subledger."""
    company_code: str = Field(description="Company code")
    customer_id: str = Field(description="Customer identifier")
    invoice_id: str = Field(description="Invoice or billing document reference")
    invoice_date: date = Field(description="Invoice issue date")
    due_date: date = Field(description="Payment due date")
    clearing_date: Optional[date] = Field(default=None, description="Date invoice was settled (None if still open)")
    invoice_amount: float = Field(gt=0.0, description="Total invoiced gross amount")
    open_amount: float = Field(ge=0.0, description="Remaining unpaid balance")
    currency: str = Field(default="INR", description="Currency code")

    @field_validator("open_amount")
    @classmethod
    def validate_open_amount(cls, v: float, info) -> float:
        invoice_amt = info.data.get("invoice_amount")
        if invoice_amt is not None and v > (invoice_amt + 1e-4):
            raise ValueError(f"Open amount ({v}) cannot exceed invoice amount ({invoice_amt})")
        return v

    @property
    def is_open(self) -> bool:
        return self.open_amount > 0.0

    @property
    def is_cleared(self) -> bool:
        return self.open_amount == 0.0 or self.clearing_date is not None

    def days_overdue(self, as_of_date: date) -> int:
        """Returns positive number of days overdue as of reference date; 0 or negative if not overdue."""
        if not self.is_open:
            return 0
        return (as_of_date - self.due_date).days


class APOpenItem(BaseModel):
    """Accounts Payable open or cleared item from vendor subledger."""
    company_code: str = Field(description="Company code")
    vendor_id: str = Field(description="Vendor identifier")
    invoice_id: str = Field(description="Vendor invoice reference number")
    invoice_date: date = Field(description="Vendor invoice date")
    due_date: date = Field(description="Payment due date")
    clearing_date: Optional[date] = Field(default=None, description="Date invoice was paid/cleared (None if open)")
    invoice_amount: float = Field(gt=0.0, description="Total invoiced gross amount")
    open_amount: float = Field(ge=0.0, description="Remaining unpaid balance")
    currency: str = Field(default="INR", description="Currency code")

    @field_validator("open_amount")
    @classmethod
    def validate_open_amount(cls, v: float, info) -> float:
        invoice_amt = info.data.get("invoice_amount")
        if invoice_amt is not None and v > (invoice_amt + 1e-4):
            raise ValueError(f"Open amount ({v}) cannot exceed invoice amount ({invoice_amt})")
        return v

    @property
    def is_open(self) -> bool:
        return self.open_amount > 0.0

    @property
    def is_cleared(self) -> bool:
        return self.open_amount == 0.0 or self.clearing_date is not None

    def days_overdue(self, as_of_date: date) -> int:
        """Returns positive number of days overdue as of reference date; 0 or negative if not overdue."""
        if not self.is_open:
            return 0
        return (as_of_date - self.due_date).days

    def days_until_due(self, as_of_date: date) -> int:
        """Days remaining until due date. Negative if overdue."""
        return (self.due_date - as_of_date).days
