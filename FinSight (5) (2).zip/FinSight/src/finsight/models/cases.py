"""Financial Investigation and Remediation Cases Models for FinSight.

Enables tracking, assignment, remediation workflows, audit trails, and governance
around critical financial attention findings, control assessments, and AI investigations.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, model_validator


class CaseStatus(str, Enum):
    """Lifecycle states for financial remediation cases."""
    DETECTED = "DETECTED"
    INVESTIGATING = "INVESTIGATING"
    OPEN = "OPEN"
    IN_PROGRESS = "IN_PROGRESS"
    IN_REVIEW = "IN_REVIEW"
    ACTION_REQUIRED = "ACTION_REQUIRED"
    PENDING_REVIEW = "PENDING_REVIEW"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class CaseSeverity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class CaseCategory(str, Enum):
    RECEIVABLES = "RECEIVABLES"
    LIQUIDITY = "LIQUIDITY"
    CASH = "CASH"
    MARGIN = "MARGIN"
    INVENTORY = "INVENTORY"
    PAYABLES = "PAYABLES"
    GOVERNANCE = "GOVERNANCE"
    GENERAL = "GENERAL"


class CaseNote(BaseModel):
    """Note or unstructured comment item on a case."""
    id: str = Field(description="Unique note identifier")
    author: str = Field(description="Name or role of the note author")
    text: str = Field(description="Body text of note / update")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class RemediationAction(BaseModel):
    """Prescriptive operational remediation step on a case."""
    action: str = Field(description="Action description (e.g. 'Initiate collections escalation')")
    owner: str = Field(description="Assigned role or individual (e.g. 'Finance / AR Manager')")
    due_date: str = Field(description="Target completion date (YYYY-MM-DD)")
    status: str = Field(default="OPEN", description="OPEN, IN_PROGRESS, COMPLETED, CANCELLED")
    evidence: Optional[str] = Field(default=None, description="Artifact or document proving completion")
    comment: Optional[str] = Field(default=None, description="Progress notes or blockers")


class CaseAuditEvent(BaseModel):
    """Immutable, append-only audit event recording state changes and actions."""
    id: str = Field(description="Unique event ID (e.g. AUDIT-001)")
    event_type: str = Field(
        description="CASE_CREATED, CONTROL_ASSESSED, OWNER_ASSIGNED, ACTION_ADDED, STATUS_CHANGED, EVIDENCE_ADDED, REVIEW_REQUESTED, RESOLVED, CLOSED"
    )
    actor: str = Field(description="User or system service that triggered the event")
    details: str = Field(description="Detailed description of the change")
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class FinancialCase(BaseModel):
    """Structured, auditable financial remediation case."""
    id: str = Field(description="Unique case identifier (e.g. CASE-2026-001)")
    case_id: Optional[str] = Field(default=None, description="Alias for id")
    title: str = Field(description="Concise executive title")
    status: CaseStatus = Field(default=CaseStatus.OPEN)
    severity: CaseSeverity = Field(default=CaseSeverity.HIGH)
    category: CaseCategory = Field(default=CaseCategory.GENERAL)
    financial_exposure: float = Field(default=0.0, description="Immutable financial exposure captured at creation")
    financial_impact: float = Field(default=0.0, description="Alias for financial_exposure for backward compatibility")
    entity: Optional[str] = Field(default=None, description="Entity or counterparty involved (e.g. 'Apex Retail Group')")
    control_id: Optional[str] = Field(default=None, description="Associated control ID (e.g. 'CONTROL-COLL-001')")
    assessment_id: Optional[str] = Field(default=None, description="Associated control assessment ID")
    investigation_id: Optional[str] = Field(default=None, description="Originating AI investigation ID")
    financial_evidence_refs: List[str] = Field(default_factory=list, description="Referenced invoice/GL identifiers")
    policy_evidence_refs: List[str] = Field(default_factory=list, description="Referenced policy section/document IDs")
    owner: str = Field(default="Finance Team", description="Assigned executive owner")
    assignee: str = Field(default="Finance Team", description="Alias for owner for backward compatibility")
    due_date: Optional[str] = Field(default=None, description="Case remediation target due date (YYYY-MM-DD)")
    period: str = Field(default="2026-09", description="Fiscal period associated with finding")
    snapshot_id: str = Field(default="SNAP-202609-001", description="Authoritative financial snapshot reference")
    summary: str = Field(description="Executive problem statement and context")
    linked_attention_id: Optional[str] = Field(default=None, description="Linked attention item ID")
    linked_question: Optional[str] = Field(default=None, description="Original investigation inquiry")
    recommended_actions: List[str] = Field(default_factory=list, description="Initial prescriptive guidance")
    remediation_plan: List[RemediationAction] = Field(default_factory=list, description="Structured remediation action items")
    notes: List[CaseNote] = Field(default_factory=list, description="User notes")
    audit_notes: List[CaseAuditEvent] = Field(default_factory=list, description="Append-only immutable audit trail")
    resolution_summary: Optional[str] = Field(default=None, description="Mandatory summary required to close case")
    resolution_evidence: Optional[str] = Field(default=None, description="Mandatory documented evidence required to close case")
    reviewer: Optional[str] = Field(default=None, description="Executive reviewer who approved resolution")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @model_validator(mode="before")
    @classmethod
    def sync_aliases(cls, values: Any) -> Any:
        if isinstance(values, dict):
            # Sync id and case_id
            if "case_id" not in values or not values["case_id"]:
                values["case_id"] = values.get("id")
            if "id" not in values or not values["id"]:
                values["id"] = values.get("case_id")
            # Sync financial_exposure and financial_impact
            if "financial_exposure" in values and ("financial_impact" not in values or not values["financial_impact"]):
                values["financial_impact"] = values["financial_exposure"]
            elif "financial_impact" in values and ("financial_exposure" not in values or not values["financial_exposure"]):
                values["financial_exposure"] = values["financial_impact"]
            # Sync owner and assignee
            if "owner" in values and ("assignee" not in values or values["assignee"] == "Finance Team"):
                values["assignee"] = values["owner"]
            elif "assignee" in values and ("owner" not in values or values["owner"] == "Finance Team"):
                values["owner"] = values["assignee"]
        return values


class CreateCaseRequest(BaseModel):
    """Request payload to open a new remediation case."""
    title: str
    severity: CaseSeverity = CaseSeverity.HIGH
    category: CaseCategory = CaseCategory.GENERAL
    financial_impact: float = 0.0
    financial_exposure: Optional[float] = None
    entity: Optional[str] = None
    control_id: Optional[str] = None
    assessment_id: Optional[str] = None
    investigation_id: Optional[str] = None
    financial_evidence_refs: List[str] = Field(default_factory=list)
    policy_evidence_refs: List[str] = Field(default_factory=list)
    period: str = "2026-09"
    snapshot_id: str = "SNAP-202609-001"
    summary: str
    assignee: str = "Finance Team"
    owner: Optional[str] = None
    due_date: Optional[str] = None
    linked_attention_id: Optional[str] = None
    linked_question: Optional[str] = None
    recommended_actions: List[str] = Field(default_factory=list)
    remediation_plan: List[RemediationAction] = Field(default_factory=list)
    initial_note: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def normalize_create_fields(cls, values: Any) -> Any:
        if isinstance(values, dict):
            # Normalize category if provided as string
            cat = values.get("category")
            if isinstance(cat, str):
                cat_upper = cat.upper()
                if cat_upper in ("CASH", "TREASURY"):
                    values["category"] = CaseCategory.LIQUIDITY
                elif cat_upper in ("AR", "ACCOUNTS_RECEIVABLE", "RECEIVABLE"):
                    values["category"] = CaseCategory.RECEIVABLES
                elif cat_upper in ("AP", "ACCOUNTS_PAYABLE", "PAYABLE"):
                    values["category"] = CaseCategory.PAYABLES
                elif cat_upper in ("STOCK",):
                    values["category"] = CaseCategory.INVENTORY
            # Sync financial_exposure and financial_impact
            if "financial_exposure" in values and ("financial_impact" not in values or not values["financial_impact"]):
                values["financial_impact"] = values["financial_exposure"]
            elif "financial_impact" in values and ("financial_exposure" not in values or not values["financial_exposure"]):
                values["financial_exposure"] = values["financial_impact"]
            # Sync owner and assignee
            if "owner" in values and ("assignee" not in values or values["assignee"] == "Finance Team"):
                values["assignee"] = values["owner"]
            elif "assignee" in values and ("owner" not in values or values["owner"] == "Finance Team"):
                values["owner"] = values["assignee"]
        return values


class UpdateCaseRequest(BaseModel):
    """Request payload to update case metadata, state, remediation actions, or notes."""
    status: Optional[CaseStatus] = None
    severity: Optional[CaseSeverity] = None
    assignee: Optional[str] = None
    owner: Optional[str] = None
    due_date: Optional[str] = None
    recommended_actions: Optional[List[str]] = None
    new_note: Optional[str] = None
    note_author: Optional[str] = "Finance Lead"
    # Remediation action addition/update
    new_action: Optional[RemediationAction] = None
    # Resolution and closure requirements
    resolution_summary: Optional[str] = None
    resolution_evidence: Optional[str] = None
    reviewer: Optional[str] = None


class AddRemediationActionRequest(BaseModel):
    """Payload to add an operational action item to a case remediation plan."""
    action: str
    owner: str
    due_date: str
    status: str = "OPEN"
    evidence: Optional[str] = None
    comment: Optional[str] = None
    actor: Optional[str] = "User"


class CloseCaseRequest(BaseModel):
    """Payload to resolve and close a financial case (enforces non-silent closure)."""
    resolution_summary: Optional[str] = Field(default="", description="Mandatory documentation of why/how case was resolved")
    resolution_evidence: Optional[str] = Field(default="", description="Mandatory artifact or confirmation supporting resolution")
    reviewer: Optional[str] = Field(default=None, description="Executive reviewer signing off on case closure")
    actor: Optional[str] = "User"

