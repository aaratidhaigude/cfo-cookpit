"""Canonical Cash Forecast and Scenario Models for FinSight.

Enables transparent, auditable 30/60/90-day cash projections across
Base, Conservative, and Improved Collection scenarios grounded in deterministic
receivables aging, vendor payment schedules, and liquidity controls.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class ForecastHorizon(int, Enum):
    DAYS_30 = 30
    DAYS_60 = 60
    DAYS_90 = 90


class ForecastScenario(str, Enum):
    BASE = "BASE"
    CONSERVATIVE = "CONSERVATIVE"
    IMPROVED_COLLECTIONS = "IMPROVED_COLLECTIONS"


class WeeklyCashPoint(BaseModel):
    """Weekly cash flow interval point for charting and liquidity tracking."""
    week_number: int = Field(description="Week index (1 to 13)")
    week_start_date: str = Field(description="Start date of weekly interval (YYYY-MM-DD)")
    week_end_date: str = Field(description="End date of weekly interval (YYYY-MM-DD)")
    starting_cash: float = Field(description="Cash at beginning of week")
    collections: float = Field(description="Projected cash receipts from AR collections")
    disbursements: float = Field(description="Projected cash disbursements for maturing AP")
    recurring_outflows: float = Field(description="Known operating expenses and payroll")
    net_cash_flow: float = Field(description="Net change in cash: collections - disbursements - recurring")
    ending_cash: float = Field(description="Cash at end of week")
    lcr_ratio: Optional[float] = Field(default=None, description="Rolling 7-day Liquidity Coverage Ratio")


class CashForecast(BaseModel):
    """Deterministic, transparent multi-horizon cash forecast."""
    forecast_id: str = Field(description="Unique forecast identifier (e.g. FCST-202609-30D-BASE)")
    snapshot_id: str = Field(description="Authoritative source financial snapshot ID (e.g. SNAP-202609-001)")
    forecast_date: str = Field(description="Reference date of forecast (YYYY-MM-DD)")
    horizon_days: int = Field(description="Forecast horizon in days (30, 60, 90)")
    scenario: ForecastScenario = Field(default=ForecastScenario.BASE, description="BASE, CONSERVATIVE, IMPROVED_COLLECTIONS")
    starting_cash: float = Field(description="Liquid cash reserves as of forecast date (₹813,750.00)")
    expected_collections: float = Field(description="Total projected collections over horizon")
    expected_payables: float = Field(description="Total projected supplier disbursements over horizon")
    recurring_outflows: float = Field(description="Total fixed operational obligations (OPEX/payroll)")
    projected_cash: float = Field(description="Final ending cash balance at horizon end")
    lower_bound: float = Field(description="Conservative boundary estimate")
    upper_bound: float = Field(description="Optimistic boundary estimate")
    methodology: str = Field(
        default="Deterministic AR/AP aging schedule & counterparty payment velocity model",
        description="Transparent forecasting algorithm description",
    )
    confidence: str = Field(default="HIGH", description="Forecast confidence: HIGH, MEDIUM, LOW")
    assumptions: List[str] = Field(default_factory=list, description="Explicit itemized operational assumptions")
    weekly_projections: List[WeeklyCashPoint] = Field(default_factory=list, description="Weekly cash trajectory breakdown")
    liquidity_indicators: Dict[str, Any] = Field(default_factory=dict, description="LCR ratios, minimum cash point, and policy breach flags")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class CashForecastComparison(BaseModel):
    """Multi-scenario comparison for executive planning."""
    snapshot_id: str
    forecast_date: str
    starting_cash: float
    horizon_days: int
    scenarios: Dict[str, CashForecast] = Field(description="Forecasts keyed by scenario name (BASE, CONSERVATIVE, IMPROVED_COLLECTIONS)")
    summary_message: str
