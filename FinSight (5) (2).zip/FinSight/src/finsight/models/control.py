"""Canonical Control and Control Assessment Models for FinSight.

Enables continuous evaluation of deterministic financial facts against
governed finance policies, internal controls, and escalation thresholds.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class ControlSeverity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class ControlEvaluationType(str, Enum):
    THRESHOLD = "THRESHOLD"
    AGING = "AGING"
    COVERAGE = "COVERAGE"
    MATERIALITY = "MATERIALITY"
    APPROVAL = "APPROVAL"
    DATA_QUALITY = "DATA_QUALITY"
    POLICY_COMPLIANCE = "POLICY_COMPLIANCE"


class ControlStatus(str, Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    DEPRECATED = "DEPRECATED"


class AssessmentStatus(str, Enum):
    PASS = "PASS"
    REVIEW = "REVIEW"
    BREACH = "BREACH"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class Control(BaseModel):
    """Canonical definition of an internal financial control rule."""
    control_id: str = Field(description="Unique control identifier (e.g. CONTROL-COLL-001)")
    name: str = Field(description="Formal executive control title")
    domain: str = Field(description="Finance domain: AR, AP, TREASURY, WORKING_CAPITAL, PROFITABILITY, DATA_INTEGRITY, GOVERNANCE")
    description: str = Field(description="Operational summary of the control objective")
    policy_document_id: str = Field(description="Governing policy document ID (e.g. COLL-POL-001)")
    policy_version: str = Field(description="Governing policy version (e.g. 2.1)")
    effective_from: str = Field(description="Effective date of governing control (YYYY-MM-DD)")
    effective_to: Optional[str] = Field(default=None, description="Expiration date or None")
    severity: ControlSeverity = Field(default=ControlSeverity.HIGH)
    evaluation_type: ControlEvaluationType = Field(default=ControlEvaluationType.THRESHOLD)
    status: ControlStatus = Field(default=ControlStatus.ACTIVE)
    threshold_config: Dict[str, Any] = Field(default_factory=dict, description="Dynamic thresholds loaded from governing policy metadata")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ControlAssessment(BaseModel):
    """Structured result of evaluating financial facts against a control rule."""
    assessment_id: str = Field(description="Unique assessment identifier (e.g. ASSESS-202609-COLL-001)")
    control_id: str = Field(description="Evaluated control identifier")
    control_name: str = Field(description="Evaluated control title")
    domain: str = Field(description="Control domain")
    policy_document_id: str = Field(default="", description="Governing policy document ID")
    status: AssessmentStatus = Field(description="PASS, REVIEW, BREACH, INSUFFICIENT_DATA, NOT_APPLICABLE")
    severity: ControlSeverity = Field(description="Severity classification")
    financial_exposure: float = Field(default=0.0, description="Total monetary exposure subject to this control")
    threshold: Any = Field(default_factory=dict, description="Governing policy control thresholds")
    observed_value: Any = Field(default_factory=dict, description="Observed deterministic values from financial engine")
    threshold_value: Optional[Any] = Field(default=None, description="Scalar threshold value for convenient access")
    unit: str = Field(default="USD", description="Measurement unit: USD, DAYS, RATIO, PERCENTAGE, COUNT")
    policy_reference: str = Field(description="Governing document citation (e.g. COLL-POL-001 v2.1 Section 3)")
    financial_evidence_refs: List[str] = Field(default_factory=list, description="IDs of supporting financial items (invoices, GL accounts)")
    policy_evidence_refs: List[str] = Field(default_factory=list, description="IDs of policy chunks or sections")
    explanation: str = Field(description="Detailed explanation of the assessment result")
    required_action: str = Field(description="Mandatory remediation action specified by policy")
    entity: Optional[str] = Field(default=None, description="Entity or counterparty involved, if applicable")
    snapshot_id: str = Field(description="Authoritative financial snapshot evaluated")
    period: str = Field(description="Fiscal period evaluated (e.g. 2026-09)")
    case_required: bool = Field(default=False, description="Whether a remediation case must be opened under policy")
    exception_detected: bool = Field(default=False, description="Whether a control exception was triggered")
    evidence: Dict[str, Any] = Field(default_factory=dict, description="Detailed evaluation calculations and metrics")
    assessed_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())



class ControlSummary(BaseModel):
    """Executive portfolio summary of all evaluated controls."""
    controls_reviewed: int = Field(description="Total number of active controls evaluated")
    controls_breached: int = Field(description="Number of controls in BREACH status")
    controls_requiring_review: int = Field(description="Number of controls in REVIEW status")
    controls_passed: int = Field(description="Number of controls in PASS status")
    total_financial_exposure: float = Field(description="Aggregate financial exposure across breached/review controls")
    snapshot_id: str = Field(description="Evaluated snapshot ID")
    period: str = Field(description="Evaluated fiscal period")
    assessed_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def total_controls(self) -> int:
        return self.controls_reviewed

    @property
    def breached_controls(self) -> int:
        return self.controls_breached

    @property
    def review_controls(self) -> int:
        return self.controls_requiring_review

    @property
    def passed_controls(self) -> int:
        return self.controls_passed
