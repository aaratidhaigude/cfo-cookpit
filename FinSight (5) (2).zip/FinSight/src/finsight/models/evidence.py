"""Evidence and Audit Trail Models for FinSight.

Enables structured 'Follow the Money' auditability by anchoring every financial finding,
metric driver, attention item, and AI response to canonical transactions or items.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field


class EvidenceSourceType(str, Enum):
    """Source system record or analytical entity type."""
    AR_OPEN_ITEM = "AR_OPEN_ITEM"
    AP_OPEN_ITEM = "AP_OPEN_ITEM"
    JOURNAL_ENTRY = "JOURNAL_ENTRY"
    CUSTOMER_RECORD = "CUSTOMER_RECORD"
    VENDOR_RECORD = "VENDOR_RECORD"
    PRODUCT_RECORD = "PRODUCT_RECORD"
    METRIC_SERIES = "METRIC_SERIES"
    CALCULATION_FORMULA = "CALCULATION_FORMULA"
    DATA_QUALITY_ISSUE = "DATA_QUALITY_ISSUE"
    POLICY_DOCUMENT = "POLICY_DOCUMENT"
    FINANCIAL_DATA = "FINANCIAL_DATA"


class EvidenceItem(BaseModel):
    """Structured evidence item linking high-level claims to underlying records."""
    source_type: str = Field(description="Type of source record (e.g. AR_OPEN_ITEM, JOURNAL_ENTRY)")
    source_id: str = Field(description="Unique record key, document number, or invoice ID")
    entity: Optional[str] = Field(default=None, description="Entity name or identifier (customer, vendor, product)")
    metric: Optional[str] = Field(default=None, description="Related financial metric")
    value: Optional[float] = Field(default=None, description="Monetary or quantitative value of evidence")
    period: Optional[str] = Field(default=None, description="Fiscal period associated with evidence")
    description: str = Field(description="Human-readable factual statement of what this evidence proves")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional context fields (dates, status, aging)")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
