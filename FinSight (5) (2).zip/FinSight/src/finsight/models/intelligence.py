"""Financial Intelligence Models for FinSight.

Defines schemas for period-over-period changes, trend patterns, deterministic anomalies,
metric driver decompositions, and entity-level (customer & product) intelligence.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from finsight.models.evidence import EvidenceItem
from finsight.models.metrics import MetricUnit, TrendDirection


class TrendPattern(str, Enum):
    """Categorized historical trajectory across multiple periods."""
    PERSISTENT_INCREASE = "PERSISTENT_INCREASE"
    PERSISTENT_DECREASE = "PERSISTENT_DECREASE"
    ACCELERATION = "ACCELERATION"
    DETERIORATION = "DETERIORATION"
    RECOVERY = "RECOVERY"
    STABLE = "STABLE"


class AnomalySeverity(str, Enum):
    """Statistical/business severity of an observed anomaly."""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class PeriodChange(BaseModel):
    """Evaluated change for a financial metric between two consecutive periods."""
    metric_name: str = Field(description="Normalized identifier of metric")
    display_name: str = Field(description="Human-readable title")
    current_period: str = Field(description="Active period (e.g. '2026-09')")
    previous_period: str = Field(description="Prior period (e.g. '2026-08')")
    current_value: Optional[float] = Field(default=None)
    previous_value: Optional[float] = Field(default=None)
    absolute_change: Optional[float] = Field(default=None)
    percentage_change: Optional[float] = Field(default=None)
    direction: TrendDirection = Field(default=TrendDirection.FLAT)
    unit: MetricUnit = Field(default=MetricUnit.CURRENCY)
    currency: str = Field(default="USD")
    is_material: bool = Field(default=False, description="Whether change exceeds materiality criteria")
    materiality_reason: Optional[str] = Field(default=None, description="Deterministic rule explaining materiality")
    explanation: str = Field(description="Clear sentence describing the change with exact numbers")


class MetricTrend(BaseModel):
    """Multi-period trajectory analysis."""
    metric_name: str
    display_name: str
    pattern: TrendPattern
    periods_analyzed: List[str]
    values: List[float]
    consecutive_direction_count: int
    overall_change: float
    overall_pct_change: Optional[float] = None
    description: str


class AnomalyFinding(BaseModel):
    """Lightweight deterministic anomaly detection finding."""
    metric: str
    period: str
    actual: float
    baseline: float
    deviation_pct: float
    severity: AnomalySeverity
    reason: str
    method: str = Field(default="historical_rolling_deviation")
    threshold: Optional[float] = None


class AssociationType(str, Enum):
    """Causal wording guardrails."""
    CONTRIBUTED_TO = "contributed to"
    ASSOCIATED_WITH = "associated with"
    LARGEST_OBSERVED_DRIVER = "largest observed driver"
    OFFSETTING_FACTOR = "offsetting factor"


class CandidateDriver(BaseModel):
    """A quantified factor or entity contributing to a metric movement."""
    name: str
    description: str
    impact_amount: Optional[float] = None
    impact_pct: Optional[float] = None
    supporting_entities: List[str] = Field(default_factory=list)
    evidence: List[EvidenceItem] = Field(default_factory=list)
    association_type: str = Field(default="associated with")


class DriverAnalysisResult(BaseModel):
    """Deterministic decomposition of why a metric changed."""
    metric: str
    current_period: str
    previous_period: str
    change_amount: float
    change_pct: Optional[float] = None
    primary_driver: str
    candidate_drivers: List[CandidateDriver] = Field(default_factory=list)
    supporting_entities: List[Dict[str, Any]] = Field(default_factory=list)
    evidence_references: List[EvidenceItem] = Field(default_factory=list)
    summary: str


class CustomerIntelligence(BaseModel):
    """360-degree customer-level financial intelligence profile."""
    customer_id: str
    customer_name: str
    segment: str
    payment_terms: str
    period: str
    revenue: float
    revenue_share_pct: float
    cogs: float
    gross_profit: float
    gross_margin_pct: float
    open_ar: float
    ar_share_pct: float
    overdue_ar: float
    overdue_pct: float
    dso_estimate: Optional[float] = None
    payment_behavior_status: str = Field(description="HEALTHY, DETERIORATING, CHRONIC_OVERDUE, LOW_MARGIN")
    tags: List[str] = Field(default_factory=list)
    evidence: List[EvidenceItem] = Field(default_factory=list)


class ProductIntelligence(BaseModel):
    """Product and product-group level financial intelligence."""
    product_id: Optional[str] = None
    product_name: Optional[str] = None
    product_group: str
    period: str
    revenue: float
    cogs: float
    gross_profit: float
    gross_margin_pct: float
    growth_rate_pct: Optional[float] = None
    margin_change_pp: Optional[float] = None
    tags: List[str] = Field(default_factory=list)
    evidence: List[EvidenceItem] = Field(default_factory=list)


class FinancialIntelligenceReport(BaseModel):
    """Aggregated financial intelligence for a target period."""
    company_code: str
    period: str
    comparison_period: str
    period_changes: List[PeriodChange] = Field(default_factory=list)
    material_changes: List[PeriodChange] = Field(default_factory=list)
    trends: List[MetricTrend] = Field(default_factory=list)
    anomalies: List[AnomalyFinding] = Field(default_factory=list)
    driver_analyses: List[DriverAnalysisResult] = Field(default_factory=list)
    customer_intelligence: List[CustomerIntelligence] = Field(default_factory=list)
    product_intelligence: List[ProductIntelligence] = Field(default_factory=list)
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
