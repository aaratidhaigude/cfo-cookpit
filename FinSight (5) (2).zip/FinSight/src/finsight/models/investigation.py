"""FinSight AI Investigation Models.

Schemas for AI investigation plans, multi-step deterministic tool orchestration,
grounded financial findings, and structured explanations.
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from finsight.models.evidence import EvidenceItem


class InvestigationStep(BaseModel):
    """A discrete step in an investigation plan targeting a deterministic financial tool or knowledge retrieval."""
    step_number: int
    action: str = Field(description="Purpose of this step, e.g. 'Compare current cash vs previous period'")
    tool_name: str = Field(description="Name of tool to execute, e.g. 'compare_periods'")
    tool_args: Dict[str, Any] = Field(default_factory=dict, description="Arguments supplied to the tool")
    status: str = Field(default="PENDING", description="PENDING, COMPLETED, FAILED, SKIPPED")
    step_type: str = Field(default="FINANCIAL_TOOL", description="FINANCIAL_TOOL or KNOWLEDGE_RETRIEVAL")
    result_summary: Optional[str] = Field(default=None, description="Concise summary of tool findings")
    output: Optional[Dict[str, Any]] = Field(default=None, description="Raw tool execution output")


class InvestigationPlan(BaseModel):
    """Structured, observable plan executed by the AI investigator."""
    question: str
    intent: str
    target_period: Optional[str] = None
    steps: List[InvestigationStep] = Field(default_factory=list)


class InvestigationFinding(BaseModel):
    """An individual verified factual finding grounded in tool outputs."""
    claim: str = Field(description="Factual numerical or directional statement")
    metric: Optional[str] = None
    value: Optional[float] = None
    formatted_value: Optional[str] = None
    driver: Optional[str] = None
    entity: Optional[str] = None
    evidence_id: Optional[str] = None


class InvestigationRequest(BaseModel):
    """Request payload for /api/investigate and /api/ai/ask."""
    question: str = Field(description="Natural language question, e.g. 'Why did cash decrease?'")
    period: Optional[str] = Field(default=None, description="Optional target period (defaults to latest)")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Optional caller context")


class InvestigationResult(BaseModel):
    """Complete traceable response from the FinSight AI Investigation Engine."""
    question: str
    intent: str
    plan: InvestigationPlan
    steps: List[InvestigationStep] = Field(default_factory=list)
    tool_calls: List[Dict[str, Any]] = Field(default_factory=list)
    findings: List[InvestigationFinding] = Field(default_factory=list)
    evidence: List[EvidenceItem] = Field(default_factory=list)
    financial_evidence: List[EvidenceItem] = Field(default_factory=list)
    policy_evidence: List[EvidenceItem] = Field(default_factory=list)
    knowledge_sources: List[Dict[str, Any]] = Field(default_factory=list)
    assessment: Optional[str] = Field(default=None, description="Comparison of financial facts against policy rules")
    policy_context: Optional[str] = Field(default=None, description="Retrieved policy context")
    answer: str = Field(description="Grounded explanation strictly citing verified numbers")
    drivers: List[str] = Field(default_factory=list)
    suggested_next_steps: List[str] = Field(default_factory=list)
    # S12 Unified Investigation -> Action Fields
    finding: Optional[str] = Field(default=None, description="Concise statement of what happened")
    primary_driver: Optional[str] = Field(default=None, description="Main verified driver based on financial evidence")
    financial_impact: Optional[float] = Field(default=None, description="Quantified monetary exposure from deterministic engine")
    formatted_financial_impact: Optional[str] = Field(default=None, description="Formatted monetary exposure (e.g. ₹1,044,000.00)")
    contributors: List[Dict[str, Any]] = Field(default_factory=list, description="Counterparty/Customer/Product/Vendor contributors")
    evidence_state: str = Field(default="SUPPORTED", description="SUPPORTED, PARTIALLY_SUPPORTED, INSUFFICIENT_DATA, OUT_OF_SCOPE")
    assessment_status: Optional[str] = Field(default=None, description="PASSED, BREACH, REVIEW, INSUFFICIENT_DATA")
    control_id: Optional[str] = Field(default=None, description="Governing internal control ID (e.g. CONTROL-COLL-001)")
    control_name: Optional[str] = Field(default=None, description="Governing internal control title")
    control_status: Optional[str] = Field(default=None, description="Evaluated status of governing control")
    policy_reference: Optional[str] = Field(default=None, description="Governing policy document citation")
    suggested_action: Optional[Dict[str, Any]] = Field(default=None, description="Action proposal pre-fill for existing case lifecycle")
    request_id: Optional[str] = Field(default=None, description="Unique trace identifier for the investigation")
    latency_ms: Optional[float] = Field(default=None, description="Total execution latency in milliseconds")
    status: str = Field(default="COMPLETED", description="COMPLETED, FAILED, PARTIAL")
    grounding_state: str = Field(default="GROUNDED", description="GROUNDED, PARTIALLY_GROUNDED, UNGROUNDED")
    crm_evidence: List[Dict[str, Any]] = Field(default_factory=list, description="CRM context items linked to counterparty/account")
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class AskResponse(BaseModel):
    """Convenience user-facing structured response for /api/ai/ask."""
    answer: str
    evidence_state: str = Field(default="SUPPORTED", description="SUPPORTED, PARTIALLY_SUPPORTED, INSUFFICIENT_DATA, OUT_OF_SCOPE")
    key_findings: List[str] = Field(default_factory=list)
    drivers: List[str] = Field(default_factory=list)
    evidence: List[EvidenceItem] = Field(default_factory=list)
    financial_evidence: List[EvidenceItem] = Field(default_factory=list)
    policy_evidence: List[EvidenceItem] = Field(default_factory=list)
    knowledge_sources: List[Dict[str, Any]] = Field(default_factory=list)
    assessment: Optional[str] = None
    policy_context: Optional[str] = None
    suggested_next_steps: List[str] = Field(default_factory=list)
    # S12 Unified Investigation -> Action Fields
    finding: Optional[str] = None
    primary_driver: Optional[str] = None
    financial_impact: Optional[float] = None
    formatted_financial_impact: Optional[str] = None
    contributors: List[Dict[str, Any]] = Field(default_factory=list)
    assessment_status: Optional[str] = None
    control_id: Optional[str] = None
    control_name: Optional[str] = None
    control_status: Optional[str] = None
    policy_reference: Optional[str] = None
    suggested_action: Optional[Dict[str, Any]] = None
    request_id: Optional[str] = None
    latency_ms: Optional[float] = None
    status: str = "COMPLETED"
    grounding_state: str = "GROUNDED"
    crm_evidence: List[Dict[str, Any]] = Field(default_factory=list)
    question: str
    intent: str
    plan_summary: List[str] = Field(default_factory=list)
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
