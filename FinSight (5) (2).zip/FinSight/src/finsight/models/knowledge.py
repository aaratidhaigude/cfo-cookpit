"""Governed Financial Knowledge & Policy Intelligence Models.

Defines schemas for enterprise financial policies, SOPs, internal controls,
document versioning, chunking, and deterministic knowledge retrieval.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class DocumentType(str, Enum):
    """Categorization of governed enterprise finance knowledge documents."""
    POLICY = "POLICY"
    SOP = "SOP"
    CONTROL = "CONTROL"
    ACCOUNTING_GUIDANCE = "ACCOUNTING_GUIDANCE"
    PAYMENT_TERMS = "PAYMENT_TERMS"
    ESCALATION_RULE = "ESCALATION_RULE"
    GOVERNANCE = "GOVERNANCE"


class KnowledgeDocument(BaseModel):
    """A canonical enterprise finance policy, SOP, or governance document."""
    document_id: str = Field(description="Unique document identifier, e.g. 'COLL-POL-001'")
    title: str = Field(description="Official executive title of the document")
    document_type: DocumentType = Field(description="Type of knowledge document")
    domain: str = Field(description="Business domain: RECEIVABLES, PAYABLES, TREASURY, INVENTORY, PROFITABILITY, GOVERNANCE")
    version: str = Field(description="Semantic version string, e.g. '2.1'")
    effective_from: str = Field(description="Effective start date in ISO format YYYY-MM-DD")
    effective_to: Optional[str] = Field(default=None, description="Optional sunset date YYYY-MM-DD; None if open-ended")
    status: str = Field(default="ACTIVE", description="Document status: ACTIVE, DRAFT, SUPERSEDED, EXPIRED")
    owner: str = Field(description="Responsible role or department, e.g. 'Head of Credit & Collections'")
    source: str = Field(default="Internal Enterprise Finance Knowledge Base", description="Authoritative repository source")
    confidentiality: str = Field(default="INTERNAL_CONFIDENTIAL", description="Access restriction level")
    text: str = Field(description="Full text markdown content of the policy or procedure")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Custom document attributes, thresholds, and tags")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def is_effective_on(self, as_of_date: str) -> bool:
        """Determines if the document was active and effective on a given ISO date."""
        if self.status not in ("ACTIVE", "SUPERSEDED"):
            return False
        if as_of_date < self.effective_from:
            return False
        if self.effective_to and as_of_date > self.effective_to:
            return False
        return True


class DocumentChunk(BaseModel):
    """A discrete, semantically coherent section of a knowledge document retaining full lineage."""
    chunk_id: str = Field(description="Unique chunk identifier, e.g. 'COLL-POL-001-v2.1-SEC-3'")
    document_id: str = Field(description="Parent document identifier")
    document_title: str = Field(description="Parent document title")
    version: str = Field(description="Document version")
    section: str = Field(description="Section heading or title")
    effective_from: str = Field(description="Document effective start date YYYY-MM-DD")
    effective_to: Optional[str] = Field(default=None, description="Document effective end date YYYY-MM-DD")
    status: str = Field(default="ACTIVE", description="Chunk parent status")
    domain: str = Field(description="Business domain")
    document_type: str = Field(description="Document type")
    text: str = Field(description="Raw text content of the section")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Section specific metadata and thresholds")


class KnowledgeSearchResult(BaseModel):
    """Grounded result returned by the knowledge retrieval engine."""
    chunk_id: str
    document_id: str
    title: str
    version: str
    section: str
    relevance_score: float = Field(description="Deterministic relevance score (0.0 to 1.0)")
    effective_from: str
    effective_to: Optional[str] = None
    excerpt: str = Field(description="Relevant text excerpt from the section")
    metadata: Dict[str, Any] = Field(default_factory=dict)
    domain: str
    document_type: str


class KnowledgeSummary(BaseModel):
    """Governance status summary for the internal knowledge base."""
    total_documents: int
    active_documents: int
    expired_documents: int
    superseded_documents: int
    indexed_chunks: int
    last_indexed_at: str
    retrieval_status: str = "READY"
