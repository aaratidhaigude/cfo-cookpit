"""Metric and Financial Intelligence response models for FinSight."""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


from finsight.models.snapshot import FinancialSnapshot


class MetricStatus(str, Enum):
    """Metric calculation status."""
    CALCULATED = "CALCULATED"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    ZERO_DENOMINATOR = "ZERO_DENOMINATOR"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    ERROR = "ERROR"


class MetricUnit(str, Enum):
    """Measurement unit."""
    CURRENCY = "currency"
    PERCENTAGE = "percentage"
    DAYS = "days"
    RATIO = "ratio"
    COUNT = "count"


class TrendDirection(str, Enum):
    """Period-over-period direction."""
    INCREASING = "INCREASING"
    DECREASING = "DECREASING"
    FLAT = "FLAT"


class MetricComparison(BaseModel):
    """Period-over-period comparison details."""
    previous_period: str = Field(description="Previous period identifier, e.g. '2026-08'")
    previous_value: Optional[float] = Field(default=None, description="Previous period value")
    absolute_change: Optional[float] = Field(default=None, description="Current minus previous value")
    percentage_change: Optional[float] = Field(default=None, description="Percentage change ((curr - prev)/abs(prev))*100")
    trend: TrendDirection = Field(default=TrendDirection.FLAT, description="Direction of change")
    is_favorable: Optional[bool] = Field(default=None, description="Whether change is favorable financially")


class MetricResult(BaseModel):
    """Canonical deterministic metric result."""
    metric_name: str = Field(description="Normalized metric identifier, e.g. 'dso', 'gross_margin'")
    display_name: str = Field(description="Human-readable title, e.g. 'Days Sales Outstanding (DSO)'")
    value: Optional[float] = Field(default=None, description="Calculated numeric value, None if non-calculable")
    formatted_value: str = Field(description="Display-formatted value with unit/currency, e.g. '48.2 days', '32.7%'")
    unit: MetricUnit = Field(description="Unit of measurement")
    currency: str = Field(default="USD", description="Currency code for monetary metrics")
    period: str = Field(description="Target fiscal period or date, e.g. '2026-09'")
    comparison_period: Optional[str] = Field(default=None, description="Benchmark/prior period")
    status: MetricStatus = Field(default=MetricStatus.CALCULATED, description="Calculation outcome status")
    status_message: Optional[str] = Field(default=None, description="Explanation for non-calculated status")
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Raw inputs used in formula")
    definition: str = Field(description="Accounting / financial calculation formula & definition")
    source: str = Field(default="canonical_ledger", description="Data source adapter or layer")
    calculation_timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    comparison: Optional[MetricComparison] = Field(default=None, description="Comparative delta against prior period")
    dimensions: Dict[str, Any] = Field(default_factory=dict, description="Segment, customer, product, or aging breakdowns")
    data_quality: Dict[str, Any] = Field(default_factory=dict, description="Data sufficiency and health notes")
    reconciliation_status: Optional[str] = Field(default="RECONCILED", description="Reconciliation status: RECONCILED, REVIEW_REQUIRED, FAILED, INSUFFICIENT_DATA")
    health_status: Optional[str] = Field(default=None, description="HEALTHY, ATTENTION, CRITICAL, NEUTRAL, INSUFFICIENT_DATA")
    formula_human: Optional[str] = Field(default=None, description="Plain English calculation formula")


class AgingBucket(BaseModel):
    """AR or AP aging bucket summary."""
    bucket_name: str = Field(description="Bucket identifier, e.g. '0-30', '31-60', '61-90', '90+'")
    amount: float = Field(description="Total monetary exposure in bucket")
    item_count: int = Field(description="Number of open items in bucket")
    share_of_total_percent: float = Field(description="Percentage of total open balance")


class UpcomingBucket(BaseModel):
    """Cash outflow upcoming due bucket."""
    timeframe: str = Field(description="Timeframe label, e.g. 'Due Today', 'Due in 1-3 Days', 'Due in 4-7 Days'")
    amount: float = Field(description="Payable liability amount")
    item_count: int = Field(description="Count of vendor invoices due")


class ConcentrationItem(BaseModel):
    """Entity concentration record (customer, vendor, or product)."""
    entity_id: str
    entity_name: str
    amount: float
    percentage_of_total: float
    additional_context: Dict[str, Any] = Field(default_factory=dict)


class CashMetricDetail(BaseModel):
    """Cash position breakdown."""
    cash_position: MetricResult
    bank_accounts_breakdown: List[Dict[str, Any]] = Field(default_factory=list)
    cash_trend: List[Dict[str, Any]] = Field(default_factory=list)
    snapshot: Optional[FinancialSnapshot] = None


class WorkingCapitalDetail(BaseModel):
    """Working capital breakdown."""
    current_assets: MetricResult
    current_liabilities: MetricResult
    net_working_capital: MetricResult
    components: Dict[str, float] = Field(default_factory=dict)
    snapshot: Optional[FinancialSnapshot] = None


class ReceivablesMetricDetail(BaseModel):
    """AR metric suite."""
    accounts_receivable: MetricResult
    overdue_ar: MetricResult
    overdue_ar_percent: MetricResult
    dso: MetricResult
    aging_schedule: List[AgingBucket] = Field(default_factory=list)
    top_overdue_customers: List[ConcentrationItem] = Field(default_factory=list)
    customer_concentration: List[ConcentrationItem] = Field(default_factory=list)
    overdue_invoices: List[Dict[str, Any]] = Field(default_factory=list)
    snapshot: Optional[FinancialSnapshot] = None


class PayablesMetricDetail(BaseModel):
    """AP metric suite."""
    accounts_payable: MetricResult
    upcoming_payables_7d: MetricResult
    overdue_payables: MetricResult
    dpo: MetricResult
    upcoming_schedule: List[UpcomingBucket] = Field(default_factory=list)
    top_vendors_due: List[ConcentrationItem] = Field(default_factory=list)
    upcoming_invoices: List[Dict[str, Any]] = Field(default_factory=list)
    snapshot: Optional[FinancialSnapshot] = None


class InventoryMetricDetail(BaseModel):
    """Inventory metric suite."""
    inventory_value: MetricResult
    dio: MetricResult
    inventory_to_sales_ratio: MetricResult
    inventory_growth_rate: Optional[float] = None
    sales_growth_rate: Optional[float] = None
    snapshot: Optional[FinancialSnapshot] = None


class ProfitabilityMetricDetail(BaseModel):
    """P&L metric suite."""
    revenue: MetricResult
    cogs: MetricResult
    gross_profit: MetricResult
    gross_margin_percent: MetricResult
    top_customers_by_revenue: List[ConcentrationItem] = Field(default_factory=list)
    product_group_margins: List[Dict[str, Any]] = Field(default_factory=list)
    snapshot: Optional[FinancialSnapshot] = None


class FinancialSummary(BaseModel):
    """Executive financial summary for CFO / Finance Lead."""
    company_code: str
    company_name: str
    period: str
    comparison_period: Optional[str] = None
    reference_date: str
    currency: str
    cash_position: MetricResult
    net_working_capital: MetricResult
    current_ratio: Optional[MetricResult] = None
    dso: MetricResult
    dpo: MetricResult
    dio: MetricResult
    ccc: Optional[MetricResult] = None
    gross_margin_percent: MetricResult
    revenue: MetricResult
    accounts_receivable: MetricResult
    overdue_ar: MetricResult
    overdue_ar_percent: MetricResult
    accounts_payable: MetricResult
    upcoming_payables_7d: MetricResult
    inventory_value: MetricResult
    key_findings_preview: List[str] = Field(default_factory=list)
    snapshot: Optional[FinancialSnapshot] = None


class CFORatioGroup(BaseModel):
    """Business grouping of governed ratios for CFO cockpit."""
    category: str = Field(description="LIQUIDITY, WORKING_CAPITAL, PROFITABILITY, LEVERAGE, GROWTH")
    title: str = Field(description="Group executive title")
    description: str = Field(description="Business description of the ratio family")
    ratios: List[MetricResult] = Field(default_factory=list)


class CFORatiosResponse(BaseModel):
    """Comprehensive CFO Ratio Cockpit payload."""
    company_code: str
    company_name: str
    period: str
    comparison_period: Optional[str] = None
    currency: str = "USD"
    groups: List[CFORatioGroup] = Field(default_factory=list)
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class MetricHistoryPoint(BaseModel):
    """Historical data point for a metric time series."""
    period: str
    value: Optional[float] = None
    formatted_value: str
    status: MetricStatus = MetricStatus.CALCULATED
    absolute_change: Optional[float] = None
    percentage_change: Optional[float] = None
    trend: TrendDirection = TrendDirection.FLAT


class MetricHistoryResponse(BaseModel):
    """Multi-period historical trajectory and trend analysis for a metric."""
    metric_name: str
    display_name: str
    unit: MetricUnit
    currency: str = "USD"
    history: List[MetricHistoryPoint] = Field(default_factory=list)
    overall_change: Optional[float] = None
    overall_pct_change: Optional[float] = None
    overall_trend: str = "STABLE"
    interpretation: str
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def periods(self) -> List[str]:
        return [pt.period for pt in self.history]


class DuPontAnalysis(BaseModel):
    """Three-tier DuPont decomposition tying Operating Margin, Asset Turnover, and Equity Multiplier to Operating ROE."""
    period: str
    operating_income: float
    revenue: float
    total_assets: float
    total_equity: float
    operating_margin_pct: float
    asset_turnover: float
    equity_multiplier: float
    dupont_operating_roe: float
    governed_operating_roe: float
    variance: float
    is_tied: bool
    explanation: str
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

