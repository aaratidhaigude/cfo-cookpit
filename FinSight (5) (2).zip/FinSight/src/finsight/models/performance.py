"""Performance and Driver Intelligence Models for FinSight.

Defines schemas for:
- Executive Performance Summary
- What Changed Engine (deterministic period-over-period comparisons with configurable materiality)
- Why It Changed Driver Engine (multivariate decomposition into customer, product, and cost drivers)
- Segment Contributions (customer and product level profit/revenue attribution)
- Working Capital Movement Attribution
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from finsight.models.evidence import EvidenceItem
from finsight.models.intelligence import CandidateDriver
from finsight.models.metrics import MetricUnit, TrendDirection


class MaterialityConfig(BaseModel):
    """Configurable deterministic rules and thresholds for financial materiality."""
    currency_abs_threshold: float = Field(default=100000.0, description="Min absolute dollar change for materiality")
    currency_pct_threshold: float = Field(default=10.0, description="Min percentage change for currency metrics")
    currency_secondary_abs: float = Field(default=50000.0, description="Absolute floor when percentage threshold is met")
    margin_pp_threshold: float = Field(default=1.0, description="Percentage point movement in gross margin for materiality")
    days_abs_threshold: float = Field(default=5.0, description="Working capital days shift for materiality")
    days_pct_threshold: float = Field(default=10.0, description="Percentage shift in working capital days for materiality")
    overdue_ar_abs_threshold: float = Field(default=50000.0, description="Dollar threshold for overdue AR shifts")
    upcoming_ap_abs_threshold: float = Field(default=100000.0, description="Dollar threshold for upcoming AP commitments")


class WhatChangedItem(BaseModel):
    """Audited change in a financial metric between current and prior period."""
    metric_name: str
    display_name: str
    current_period: str
    previous_period: str
    current_value: float
    previous_value: float
    absolute_change: float
    percentage_change: Optional[float] = None
    formatted_current: str
    formatted_previous: str
    formatted_change: str
    direction: TrendDirection
    unit: MetricUnit
    currency: str = "USD"
    is_material: bool
    materiality_reason: Optional[str] = None
    explanation: str


class EntityContribution(BaseModel):
    """Quantified contribution of a specific customer, product, or segment to a portfolio metric change."""
    entity_type: str = Field(description="'CUSTOMER', 'PRODUCT_GROUP', 'PRODUCT', 'SUPPLIER'")
    entity_id: str
    entity_name: str
    segment: Optional[str] = None
    current_value: float
    previous_value: float
    change_amount: float
    change_pct: Optional[float] = None
    contribution_share_pct: Optional[float] = Field(
        default=None,
        description="Share of total portfolio change driven by this entity (e.g. drove 110% of profit decrease)",
    )
    gross_margin_pct: Optional[float] = None
    previous_gross_margin_pct: Optional[float] = None
    margin_change_pp: Optional[float] = None
    payment_status: Optional[str] = None
    explanation: str


class MetricDriverResponse(BaseModel):
    """Executive explainability package answering: Why did this metric change?"""
    metric_name: str
    display_name: str
    current_period: str
    previous_period: str
    current_value: float
    previous_value: float
    absolute_change: float
    percentage_change: Optional[float] = None
    formatted_current: str
    formatted_previous: str
    formatted_change: str
    primary_driver: str
    financial_impact: float
    summary: str
    candidate_drivers: List[CandidateDriver] = Field(default_factory=list)
    customer_contributors: List[EntityContribution] = Field(default_factory=list)
    product_contributors: List[EntityContribution] = Field(default_factory=list)
    evidence: List[EvidenceItem] = Field(default_factory=list)


class PerformanceSummaryResponse(BaseModel):
    """Complete executive performance intelligence package."""
    period: str
    comparison_period: str
    reference_date: str
    source: str
    revenue: float
    cogs: float
    gross_profit: float
    gross_margin_pct: float
    net_working_capital: float
    ccc: float
    what_changed: List[WhatChangedItem] = Field(default_factory=list)
    material_movements_count: int = 0
    default_driver: Optional[MetricDriverResponse] = None
    top_customer_drivers: List[EntityContribution] = Field(default_factory=list)
    top_product_drivers: List[EntityContribution] = Field(default_factory=list)
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
