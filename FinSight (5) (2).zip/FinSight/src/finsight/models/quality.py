"""Data quality and validation reporting models for FinSight."""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class IssueSeverity(str, Enum):
    """Data quality issue severity level."""
    CRITICAL = "CRITICAL"   # Blocks financial calculations
    WARNING = "WARNING"     # Anomaly or sub-optimal data quality
    INFO = "INFO"           # Informational observation


class DataQualityStatus(str, Enum):
    """Overall dataset readiness."""
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    BLOCKED = "BLOCKED"


class ValidationIssue(BaseModel):
    """Specific data quality anomaly or violation."""
    entity_type: str = Field(description="Entity name: JournalEntry, AROpenItem, APOpenItem, Customer, etc.")
    issue_type: str = Field(description="Classification: MISSING_FIELD, INVALID_VALUE, UNRESOLVED_REFERENCE, etc.")
    severity: IssueSeverity = Field(description="Severity impact on calculations")
    record_identifier: Optional[str] = Field(default=None, description="Key of the offending record")
    field_name: Optional[str] = Field(default=None, description="Field where violation occurred")
    message: str = Field(description="Human-readable explanation of error")
    sample_data: Optional[Dict[str, Any]] = Field(default=None, description="Contextual payload")


class EntityStats(BaseModel):
    """Record counts and completeness per entity."""
    record_count: int = Field(default=0)
    valid_count: int = Field(default=0)
    invalid_count: int = Field(default=0)
    duplicate_count: int = Field(default=0)


class DataQualityReport(BaseModel):
    """Overall data quality diagnostic report."""
    status: DataQualityStatus = Field(description="Overall health status")
    last_successful_refresh: Optional[str] = Field(default=None, description="ISO timestamp of last refresh")
    source: str = Field(description="Active data source adapter")
    total_records: int = Field(default=0)
    entity_stats: Dict[str, EntityStats] = Field(default_factory=dict)
    unresolved_references: List[ValidationIssue] = Field(default_factory=list)
    calculation_blockers: List[ValidationIssue] = Field(default_factory=list)
    warnings: List[ValidationIssue] = Field(default_factory=list)
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
