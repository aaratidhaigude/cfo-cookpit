"""Authoritative Financial Snapshot Models for FinSight.

Establishes an immutable, traceable snapshot metadata structure binding every
executive KPI, intelligence finding, and subledger detail to one authoritative
reporting period, dataset version, calculation status, and data quality state.
"""

from datetime import datetime, timezone
from typing import Optional
from pydantic import BaseModel, Field


class FinancialSnapshot(BaseModel):
    """Immutable metadata representing the active financial truth snapshot."""
    snapshot_id: str = Field(description="Unique snapshot identifier, e.g. 'SNAP-202609-001'")
    period: str = Field(description="Target reporting period, e.g. '2026-09'")
    period_start: str = Field(description="First calendar day of the reporting period, e.g. '2026-09-01'")
    period_end: str = Field(description="Last calendar day of the reporting period, e.g. '2026-09-30'")
    reference_date: str = Field(description="Authoritative reference as-of date, e.g. '2026-09-30'")
    source: str = Field(default="mock_financial_adapter", description="Source ERP adapter identifier")
    dataset_version: str = Field(default="v1.0-seed42", description="Dataset or ingestion revision identifier")
    generated_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
        description="UTC timestamp when the snapshot was generated",
    )
    calculation_status: str = Field(default="READY", description="READY, WARNING, or BLOCKED")
    data_quality_status: str = Field(default="HEALTHY", description="HEALTHY, DEGRADED, or BLOCKED")
    is_active: bool = Field(default=True, description="Whether this is the current active snapshot")
