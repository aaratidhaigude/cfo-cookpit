"""Financial Data Trust, Governed Metric Catalog & Reconciliation Models for FinSight.

Implements the formal data trust pipeline:
SOURCE -> NORMALIZE -> MAP -> DEFINE -> CALCULATE -> RECONCILE -> PUBLISH -> TRACE

Defines schemas for:
- Governed Account Mapping and Mapping States
- Governed Metric Definition Catalog
- Data Quality Pre-Flight & Calculation States
- Multi-Layer Reconciliation Invariants & Exceptions
- Publication Status
- End-to-End Metric Lineage & Traceability
- Data Trust Summary
"""

from datetime import date, datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from finsight.models.canonical import AccountCategory, FinancialConcept
from finsight.models.evidence import EvidenceItem
from finsight.models.metrics import MetricUnit, TrendDirection


class MappingStatus(str, Enum):
    """Governed status of a source account mapping."""
    MAPPED = "MAPPED"
    UNMAPPED = "UNMAPPED"
    AMBIGUOUS = "AMBIGUOUS"
    EXCLUDED = "EXCLUDED"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"


class PeriodType(str, Enum):
    """Temporal behavior of a financial metric."""
    POINT_IN_TIME = "POINT_IN_TIME"  # Balance Sheet balance as of period end (e.g. Cash, AR, Inventory)
    FLOW = "FLOW"                    # Cumulative activity over period (e.g. Revenue, COGS, Net Income)


class MetricCalculationState(str, Enum):
    """Pre-flight and calculation outcome state."""
    VALID = "VALID"
    INVALID = "INVALID"
    INCOMPLETE = "INCOMPLETE"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class PublicationStatus(str, Enum):
    """Governed trust and release status of a published metric."""
    PUBLISHED = "PUBLISHED"
    PUBLISHED_WITH_WARNING = "PUBLISHED_WITH_WARNING"
    HELD_FOR_REVIEW = "HELD_FOR_REVIEW"
    NOT_CALCULABLE = "NOT_CALCULABLE"


class ReconciliationStatus(str, Enum):
    """Outcome status of a multi-layer reconciliation check."""
    RECONCILED = "RECONCILED"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    FAILED = "FAILED"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"


# -----------------------------------------------------------------------------
# 1. Governed Account Mapping
# -----------------------------------------------------------------------------

class GovernedAccountMapping(BaseModel):
    """Governed mapping binding a source GL account to canonical concept and financial category."""
    mapping_id: str = Field(description="Unique mapping identifier, e.g. 'MAP-110000'")
    gl_account: str = Field(description="Source general ledger account code (e.g. '110000')")
    account_name: str = Field(description="Descriptive name of the general ledger account")
    financial_concept: Optional[FinancialConcept] = Field(default=None, description="Mapped canonical financial concept")
    category: Optional[AccountCategory] = Field(default=None, description="Financial statement category")
    mapping_status: MappingStatus = Field(default=MappingStatus.MAPPED, description="Current governance status")
    mapping_version: str = Field(default="v1.0", description="Version of the mapping rule")
    effective_from: date = Field(description="Effective start date")
    effective_to: Optional[date] = Field(default=None, description="Effective end date (None = active)")
    reason: Optional[str] = Field(default=None, description="Governance or audit rationale")
    downstream_metrics: List[str] = Field(default_factory=list, description="Metrics that consume this account")
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# -----------------------------------------------------------------------------
# 2. Governed Metric Definition Catalog
# -----------------------------------------------------------------------------

class GovernedMetricDefinition(BaseModel):
    """Authoritative, governed definition of a core financial metric."""
    metric_id: str = Field(description="Standardized code, e.g. 'METRIC-GM-01'")
    metric_name: str = Field(description="Machine identifier / slug, e.g. 'gross_margin_percent'")
    display_name: str = Field(description="CFO-facing executive title")
    description: str = Field(description="Business and accounting definition")
    formula: str = Field(description="Explicit mathematical formula")
    formula_human: str = Field(description="Plain-English explanation of calculation")
    input_concepts: List[FinancialConcept] = Field(description="Required canonical concepts")
    financial_statement_category: AccountCategory = Field(description="Primary financial statement category")
    unit: MetricUnit = Field(description="Measurement unit: CURRENCY, PERCENTAGE, DAYS, RATIO, COUNT")
    currency: str = Field(default="USD", description="Default operational currency")
    sign_convention: str = Field(default="POSITIVE_FAVORABLE", description="Interpretation of positive value")
    period_type: PeriodType = Field(description="POINT_IN_TIME (balance sheet) or FLOW (P&L)")
    denominator_rules: Optional[str] = Field(default=None, description="Guardrail rule for zero or missing denominator")
    version: str = Field(default="v1.0", description="Approved governance version")
    effective_date: str = Field(default="2025-01-01", description="Effective adoption date")
    is_active: bool = Field(default=True, description="Whether currently active in production catalog")


# -----------------------------------------------------------------------------
# 3. Multi-Layer Reconciliation Invariants & Exceptions
# -----------------------------------------------------------------------------

class MultiLayerReconciliationTie(BaseModel):
    """Deterministic comparison reconciling Source Balance <-> Mapped Balance <-> Metric Input <-> Published Value."""
    tie_id: str = Field(description="Unique tie rule identifier, e.g. 'TIE-AR-001'")
    metric_or_concept: str = Field(description="Subject metric or concept name")
    period: str = Field(description="Fiscal period")
    source_layer_name: str = Field(description="Source system or subledger name")
    source_value: float = Field(description="Raw source or subledger balance")
    mapped_layer_name: str = Field(description="Mapped general ledger concept name")
    mapped_value: float = Field(description="General ledger mapped concept balance")
    calculated_input_value: float = Field(description="Value supplied into metric formula")
    published_value: float = Field(description="Published authoritative value")
    variance: float = Field(description="Absolute discrepancy between source/mapped and published")
    tolerance: float = Field(default=0.01, description="Configured tolerance threshold")
    status: ReconciliationStatus = Field(description="RECONCILED, REVIEW_REQUIRED, FAILED, INSUFFICIENT_DATA")
    explanation: str = Field(description="Deterministic explanation of reconciliation outcome")
    evidence_references: List[str] = Field(default_factory=list, description="IDs of supporting records")


class ReconciliationException(BaseModel):
    """Deterministic exception detailing a reconciliation failure or variance."""
    exception_id: str = Field(description="Unique exception ID")
    tie_id: str = Field(description="Associated reconciliation tie ID")
    metric_or_concept: str = Field(description="Affected metric or concept")
    period: str = Field(description="Fiscal period")
    discrepancy_amount: float = Field(description="Numerical variance")
    tolerance: float = Field(description="Configured tolerance")
    severity: str = Field(description="'CRITICAL' or 'WARNING'")
    what_differs: str = Field(description="Clear explanation of the mismatch")
    why_it_differs: str = Field(default="Cause not established", description="Root cause or 'Cause not established'")
    downstream_impacts: List[str] = Field(default_factory=list, description="Downstream metrics or reports affected")
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# -----------------------------------------------------------------------------
# 4. End-to-End Metric Lineage & Traceability
# -----------------------------------------------------------------------------

class MetricInputTrace(BaseModel):
    """Trace of a specific input into a metric calculation."""
    concept: str
    display_name: str
    value: Optional[float]
    formatted_value: str
    source_accounts: List[str]
    source_records_count: int


class MetricLineageResponse(BaseModel):
    """Complete, auditable lineage package proving where a financial number came from."""
    metric_name: str
    display_name: str
    period: str
    published_value: Optional[float]
    formatted_value: str
    unit: MetricUnit
    publication_status: PublicationStatus
    publication_badge: str = Field(description="'Reconciled', 'Published with Warning', 'Held for Review', etc.")
    governed_definition: GovernedMetricDefinition
    calculation_state: MetricCalculationState
    formula_audit: str
    inputs: List[MetricInputTrace] = Field(default_factory=list)
    mapped_accounts: List[GovernedAccountMapping] = Field(default_factory=list)
    reconciliation_tie: Optional[MultiLayerReconciliationTie] = None
    evidence_trail: List[EvidenceItem] = Field(default_factory=list)
    provenance_chain: List[str] = Field(
        default_factory=list,
        description="Step-by-step audit string: Source -> Normalize -> Map -> Define -> Calculate -> Reconcile -> Publish",
    )
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# -----------------------------------------------------------------------------
# 5. Published Governed Metric
# -----------------------------------------------------------------------------

class PublishedGovernedMetric(BaseModel):
    """A governed financial metric ready for consumption by Financials or Performance."""
    metric_name: str
    display_name: str
    period: str
    value: Optional[float]
    formatted_value: str
    unit: MetricUnit
    publication_status: PublicationStatus
    calculation_state: MetricCalculationState
    formula: str
    period_type: PeriodType
    reconciliation_status: ReconciliationStatus
    lineage_available: bool = True


# -----------------------------------------------------------------------------
# 6. Data Trust Summary
# -----------------------------------------------------------------------------

class DataTrustSummaryResponse(BaseModel):
    """Executive & audit data trust posture for the application header and trust drawer."""
    period: str
    reference_date: str
    source_system: str
    last_refresh_timestamp: Optional[str]
    records_processed: int
    data_quality_status: str
    overall_trust_status: str = Field(description="'RECONCILED' (green), 'REVIEW_REQUIRED' (amber), 'BLOCKED' (red)")
    trust_badge_label: str = Field(description="e.g. 'Financial Data Reconciled' or 'Review Required'")
    total_accounts: int
    mapped_accounts_count: int
    unmapped_accounts_count: int
    ambiguous_accounts_count: int
    mapping_coverage_pct: float
    total_reconciliation_checks: int
    reconciled_checks_count: int
    failed_checks_count: int
    active_exceptions_count: int
    exceptions: List[ReconciliationException] = Field(default_factory=list)
    published_metrics_count: int
    published_with_warning_count: int
    held_for_review_count: int
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
