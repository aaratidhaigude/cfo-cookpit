"""AI-Ready Deterministic Tool Interface for FinSight.

Exposes clean, strongly-typed service contracts designed specifically for future
LLM tool-calling (Function Calling / Tool Use) without putting calculation logic into the model.
All answers return ground-truth calculations and audit evidence from canonical financial data.
"""

from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional

from finsight.models.canonical import FinancialConcept
from finsight.services.knowledge_retriever import (
    BaseKnowledgeRetriever,
    LocalKnowledgeRetriever,
)
from finsight.services.metric_service import MetricService
from finsight.services.refresh_service import RefreshService


class AIToolsService:
    """Tool service boundary exposing deterministic financial actions and governed policy retrieval to AI agents."""

    def __init__(
        self,
        refresh_service: RefreshService,
        knowledge_retriever: Optional[BaseKnowledgeRetriever] = None,
    ):
        self._refresh_service = refresh_service
        self._knowledge_retriever = knowledge_retriever or LocalKnowledgeRetriever()

    @property
    def knowledge_retriever(self) -> BaseKnowledgeRetriever:
        return self._knowledge_retriever

    @property
    def metric_service(self) -> MetricService:
        return self._refresh_service.metric_service

    @property
    def engine(self):
        return self._refresh_service.engine

    # 1. get_financial_metric
    def get_financial_metric(self, metric_name: str, period: Optional[str] = None) -> Dict[str, Any]:
        """Calculates a foundational financial metric for a given period."""
        metric = self.metric_service.get_metric_by_name(metric_name, period)
        return metric.model_dump()

    # 2. compare_periods
    def compare_periods(self, metric_name: str, period_a: str, period_b: str) -> Dict[str, Any]:
        """Compares a financial metric between two explicit fiscal periods (period_a vs period_b)."""
        res_a = self.metric_service.get_metric_by_name(metric_name, period_a)
        res_b = self.metric_service.get_metric_by_name(metric_name, period_b)

        val_a = res_a.value
        val_b = res_b.value

        abs_change = round(val_a - val_b, 4) if (val_a is not None and val_b is not None) else None
        pct_change = round(((val_a - val_b) / abs(val_b) * 100.0), 2) if (val_a is not None and val_b is not None and abs(val_b) > 1e-6) else None

        return {
            "metric_name": metric_name,
            "period_current": period_a,
            "period_previous": period_b,
            "current_value": val_a,
            "current_formatted": res_a.formatted_value,
            "previous_value": val_b,
            "previous_formatted": res_b.formatted_value,
            "absolute_change": abs_change,
            "percentage_change": pct_change,
            "unit": res_a.unit.value,
            "status": "COMPARISON_SUCCESS" if (val_a is not None and val_b is not None) else "INSUFFICIENT_DATA",
        }

    # 3. get_cash_position
    def get_cash_position(self, as_of_date: Optional[str] = None) -> Dict[str, Any]:
        """Returns cash position and breakdown of bank accounts as of a date."""
        target_date = date.fromisoformat(as_of_date) if as_of_date else None
        cash = self.metric_service.calculate_cash_position(as_of_date=target_date)
        return cash.model_dump()

    # 4. get_receivables
    def get_receivables(self, customer_id: Optional[str] = None, overdue_only: bool = False) -> Dict[str, Any]:
        """Returns customer receivables, with optional filtering by customer and overdue status."""
        ref_date = date(2026, 9, 30)
        items = []
        total_open = 0.0
        total_overdue = 0.0

        for ar in self.engine.ar_items:
            if customer_id and ar.customer_id != customer_id:
                continue
            if ar.is_open:
                days_od = ar.days_overdue(ref_date)
                is_od = days_od > 0
                if overdue_only and not is_od:
                    continue

                total_open += ar.open_amount
                if is_od:
                    total_overdue += ar.open_amount

                cust = self.engine.customers.get(ar.customer_id)
                items.append({
                    "invoice_id": ar.invoice_id,
                    "customer_id": ar.customer_id,
                    "customer_name": cust.customer_name if cust else "Unknown",
                    "invoice_date": ar.invoice_date.isoformat(),
                    "due_date": ar.due_date.isoformat(),
                    "invoice_amount": ar.invoice_amount,
                    "open_amount": ar.open_amount,
                    "days_overdue": max(0, days_od),
                    "status": "OVERDUE" if is_od else "CURRENT",
                })

        return {
            "total_open_amount": round(total_open, 2),
            "total_overdue_amount": round(total_overdue, 2),
            "item_count": len(items),
            "reference_date": ref_date.isoformat(),
            "items": sorted(items, key=lambda x: x["days_overdue"], reverse=True),
        }

    # 5. get_payables
    def get_payables(self, vendor_id: Optional[str] = None, overdue_only: bool = False) -> Dict[str, Any]:
        """Returns vendor payables, with optional filtering by vendor and overdue status."""
        ref_date = date(2026, 9, 30)
        items = []
        total_open = 0.0
        total_overdue = 0.0

        for ap in self.engine.ap_items:
            if vendor_id and ap.vendor_id != vendor_id:
                continue
            if ap.is_open:
                days_until = ap.days_until_due(ref_date)
                is_od = days_until < 0
                if overdue_only and not is_od:
                    continue

                total_open += ap.open_amount
                if is_od:
                    total_overdue += ap.open_amount

                vend = self.engine.vendors.get(ap.vendor_id)
                items.append({
                    "invoice_id": ap.invoice_id,
                    "vendor_id": ap.vendor_id,
                    "vendor_name": vend.vendor_name if vend else "Unknown",
                    "invoice_date": ap.invoice_date.isoformat(),
                    "due_date": ap.due_date.isoformat(),
                    "invoice_amount": ap.invoice_amount,
                    "open_amount": ap.open_amount,
                    "days_until_due": days_until,
                    "status": "OVERDUE" if is_od else ("DUE_TODAY" if days_until == 0 else "UPCOMING"),
                })

        return {
            "total_open_amount": round(total_open, 2),
            "total_overdue_amount": round(total_overdue, 2),
            "item_count": len(items),
            "reference_date": ref_date.isoformat(),
            "items": sorted(items, key=lambda x: x["days_until_due"]),
        }

    # 6. get_overdue_items
    def get_overdue_items(self, item_type: str = "ALL", min_days_overdue: int = 0) -> Dict[str, Any]:
        """Retrieves overdue AR and/or AP items exceeding min_days_overdue."""
        ref_date = date(2026, 9, 30)
        res_ar = []
        res_ap = []

        if item_type.upper() in ("ALL", "AR"):
            for ar in self.engine.ar_items:
                if ar.is_open:
                    days_od = ar.days_overdue(ref_date)
                    if days_od >= min_days_overdue and days_od > 0:
                        cust = self.engine.customers.get(ar.customer_id)
                        res_ar.append({
                            "invoice_id": ar.invoice_id,
                            "entity_id": ar.customer_id,
                            "entity_name": cust.customer_name if cust else "Unknown",
                            "open_amount": ar.open_amount,
                            "due_date": ar.due_date.isoformat(),
                            "days_overdue": days_od,
                        })

        if item_type.upper() in ("ALL", "AP"):
            for ap in self.engine.ap_items:
                if ap.is_open:
                    days_od = ap.days_overdue(ref_date)
                    if days_od >= min_days_overdue and days_od > 0:
                        vend = self.engine.vendors.get(ap.vendor_id)
                        res_ap.append({
                            "invoice_id": ap.invoice_id,
                            "entity_id": ap.vendor_id,
                            "entity_name": vend.vendor_name if vend else "Unknown",
                            "open_amount": ap.open_amount,
                            "due_date": ap.due_date.isoformat(),
                            "days_overdue": days_od,
                        })

        return {
            "reference_date": ref_date.isoformat(),
            "min_days_overdue": min_days_overdue,
            "ar_overdue_items": sorted(res_ar, key=lambda x: x["days_overdue"], reverse=True),
            "ap_overdue_items": sorted(res_ap, key=lambda x: x["days_overdue"], reverse=True),
            "total_ar_overdue": round(sum(x["open_amount"] for x in res_ar), 2),
            "total_ap_overdue": round(sum(x["open_amount"] for x in res_ap), 2),
        }

    # 7. get_upcoming_payments
    def get_upcoming_payments(self, horizon_days: int = 7) -> Dict[str, Any]:
        """Retrieves vendor liabilities due within horizon_days from reference date."""
        ref_date = date(2026, 9, 30)
        cutoff_date = ref_date + timedelta(days=horizon_days)
        upcoming = []
        total_due = 0.0

        for ap in self.engine.ap_items:
            if ap.is_open and ref_date <= ap.due_date <= cutoff_date:
                total_due += ap.open_amount
                vend = self.engine.vendors.get(ap.vendor_id)
                upcoming.append({
                    "invoice_id": ap.invoice_id,
                    "vendor_id": ap.vendor_id,
                    "vendor_name": vend.vendor_name if vend else "Unknown",
                    "due_date": ap.due_date.isoformat(),
                    "open_amount": ap.open_amount,
                    "days_remaining": (ap.due_date - ref_date).days,
                })

        return {
            "reference_date": ref_date.isoformat(),
            "horizon_days": horizon_days,
            "total_upcoming_amount": round(total_due, 2),
            "payment_count": len(upcoming),
            "payments": sorted(upcoming, key=lambda x: x["days_remaining"]),
        }

    # 8. get_customer_exposure
    def get_customer_exposure(self, customer_id: Optional[str] = None, top_n: int = 10) -> Dict[str, Any]:
        """Provides deep exposure analysis per customer: revenue, total open AR, overdue AR, aging breakdown."""
        ref_date = date(2026, 9, 30)
        ar_summary = self.engine.get_ar_summary(ref_date)
        cust_conc = ar_summary["customer_concentration"]

        if customer_id:
            cust_items = [c for c in cust_conc if c["entity_id"] == customer_id]
            if not cust_items:
                return {"status": "CUSTOMER_NOT_FOUND", "customer_id": customer_id}
            selected = cust_items[0]
            # Fetch detailed open invoices for this customer
            invoices = [
                {
                    "invoice_id": ar.invoice_id,
                    "invoice_date": ar.invoice_date.isoformat(),
                    "due_date": ar.due_date.isoformat(),
                    "invoice_amount": ar.invoice_amount,
                    "open_amount": ar.open_amount,
                    "days_overdue": max(0, ar.days_overdue(ref_date)),
                }
                for ar in self.engine.ar_items
                if ar.customer_id == customer_id and ar.is_open
            ]
            return {
                "customer_id": customer_id,
                "customer_name": selected["entity_name"],
                "total_open_ar": selected["amount"],
                "share_of_total_ar_pct": selected["percentage_of_total"],
                "overdue_ar": selected["additional_context"].get("overdue_amount", 0.0),
                "open_invoices": invoices,
            }

        return {
            "top_customers_by_ar": cust_conc[:top_n],
            "total_open_ar": ar_summary["total_open_ar"],
            "top_overdue_customers": ar_summary["top_overdue_customers"][:top_n],
        }

    # 9. get_product_profitability
    def get_product_profitability(self, product_id: Optional[str] = None, period: Optional[str] = None) -> Dict[str, Any]:
        """Returns product or product group level margins and revenue."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        breakdowns = self.engine.get_profitability_breakdowns(target_period)
        return {
            "period": target_period,
            "product_group_margins": breakdowns["product_group_margins"],
            "requested_product_id": product_id,
        }

    # 10. find_metric_drivers
    def find_metric_drivers(self, metric_name: str, current_period: str, previous_period: str) -> Dict[str, Any]:
        """Decomposes a period-over-period change into entity or component drivers."""
        m = metric_name.lower().strip()
        if m in ("gross_margin", "gross_margin_percent", "margin"):
            # Decompose gross margin compression
            pnl_curr = self.engine.get_pnl_for_period(current_period)
            pnl_prev = self.engine.get_pnl_for_period(previous_period)

            rev_curr, cogs_curr = pnl_curr["revenue"], pnl_curr["cogs"]
            rev_prev, cogs_prev = pnl_prev["revenue"], pnl_prev["cogs"]

            rev_growth = ((rev_curr - rev_prev) / rev_prev * 100.0) if rev_prev > 0 else 0.0
            cogs_growth = ((cogs_curr - cogs_prev) / cogs_prev * 100.0) if cogs_prev > 0 else 0.0

            gm_curr = ((rev_curr - cogs_curr) / rev_curr * 100.0) if rev_curr > 0 else 0.0
            gm_prev = ((rev_prev - cogs_prev) / rev_prev * 100.0) if rev_prev > 0 else 0.0

            return {
                "metric": "gross_margin_percent",
                "current_period": current_period,
                "previous_period": previous_period,
                "margin_change_percentage_points": round(gm_curr - gm_prev, 2),
                "revenue_growth_percent": round(rev_growth, 2),
                "cogs_growth_percent": round(cogs_growth, 2),
                "primary_driver": "COGS growing faster than Revenue" if cogs_growth > rev_growth else "Revenue contraction",
                "evidence": {
                    "current": pnl_curr,
                    "previous": pnl_prev,
                },
            }

        elif m in ("dso", "ar"):
            ar_curr = self.engine.get_ar_summary(date(2026, 9, 30))
            return {
                "metric": "dso",
                "primary_driver": "Overdue concentration in top customers",
                "top_overdue_contributors": ar_curr["top_overdue_customers"][:3],
            }

        return {
            "metric": metric_name,
            "status": "UNSUPPORTED_DECOMPOSITION",
            "message": f"Driver analysis for '{metric_name}' is not yet configured.",
        }

    # 11. get_transaction_evidence
    def get_transaction_evidence(self, document_id: Optional[str] = None, invoice_id: Optional[str] = None) -> Dict[str, Any]:
        """Fetches underlying journal entries or subledger lines as indisputable audit proof."""
        if document_id:
            lines = [je.model_dump() for je in self.engine.journal_entries if je.document_id == document_id]
            return {
                "document_id": document_id,
                "line_count": len(lines),
                "journal_lines": lines,
                "is_balanced": abs(sum(line["amount"] if line["debit_credit"] in ("S", "D") else -line["amount"] for line in lines)) < 0.01,
            }

        if invoice_id:
            # Check AR subledger
            ar_match = [ar.model_dump() for ar in self.engine.ar_items if ar.invoice_id == invoice_id]
            if ar_match:
                return {"invoice_id": invoice_id, "subledger": "AR", "item": ar_match[0]}
            ap_match = [ap.model_dump() for ap in self.engine.ap_items if ap.invoice_id == invoice_id]
            if ap_match:
                return {"invoice_id": invoice_id, "subledger": "AP", "item": ap_match[0]}

        return {
            "status": "RECORD_NOT_FOUND",
            "message": f"No document or invoice located for doc={document_id}, inv={invoice_id}",
        }

    # 12. search_finance_knowledge
    def search_finance_knowledge(
        self,
        query: str,
        domain: Optional[str] = None,
        effective_date: Optional[str] = None,
        document_type: Optional[str] = None,
        top_k: int = 5,
    ) -> Dict[str, Any]:
        """Searches governed finance knowledge base for policies, SOPs, controls, and rules."""
        results = self._knowledge_retriever.search(
            query=query,
            domain=domain,
            document_type=document_type,
            effective_date=effective_date,
            top_k=top_k,
        )
        return {
            "query": query,
            "domain": domain,
            "document_type": document_type,
            "effective_date": effective_date or "2026-09-30",
            "matched_count": len(results),
            "results": [r.model_dump() for r in results],
        }

    # 13. get_cash_forecast
    def get_cash_forecast(
        self,
        horizon_days: int = 30,
        scenario: str = "BASE",
        period: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generates deterministic 30/60/90-day cash projection for BASE, CONSERVATIVE, or IMPROVED_COLLECTIONS."""
        from finsight.models.cash_forecast import ForecastScenario
        from finsight.services.cash_forecast_service import CashForecastService

        sc_enum = ForecastScenario.BASE
        sc_upper = scenario.upper().strip()
        if sc_upper in ("CONSERVATIVE", "BEAR", "STRESS"):
            sc_enum = ForecastScenario.CONSERVATIVE
        elif sc_upper in ("IMPROVED_COLLECTIONS", "OPTIMISTIC", "ACCELERATED", "BULL", "IMPROVED"):
            sc_enum = ForecastScenario.IMPROVED_COLLECTIONS

        fc_svc = CashForecastService(self.engine, self.metric_service)
        fc = fc_svc.generate_forecast(horizon_days=horizon_days, scenario=sc_enum, period=period)
        return fc.model_dump()
