"""Financial Cases Service for FinSight.

Maintains persistent SQLite repository of financial remediation cases with immutable incident snapshots,
append-only audit trails, remediation action plans, and non-silent closure enforcement.
"""

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sqlite3
from typing import Dict, List, Optional
import uuid

from finsight.models.cases import (
    CaseAuditEvent,
    CaseCategory,
    CaseNote,
    CaseSeverity,
    CaseStatus,
    CloseCaseRequest,
    CreateCaseRequest,
    FinancialCase,
    RemediationAction,
    UpdateCaseRequest,
)
from finsight.models.control import ControlAssessment
from finsight.config import settings


class CasesService:
    """Manages lifecycle of executive financial remediation cases backed by SQLite persistence."""

    VALID_TRANSITIONS = {
        CaseStatus.OPEN: {
            CaseStatus.IN_REVIEW,
            CaseStatus.ACTION_REQUIRED,
            CaseStatus.IN_PROGRESS,
            CaseStatus.RESOLVED,
            CaseStatus.CLOSED,
        },
        CaseStatus.IN_REVIEW: {
            CaseStatus.ACTION_REQUIRED,
            CaseStatus.IN_PROGRESS,
            CaseStatus.RESOLVED,
            CaseStatus.CLOSED,
            CaseStatus.OPEN,
        },
        CaseStatus.ACTION_REQUIRED: {
            CaseStatus.IN_REVIEW,
            CaseStatus.IN_PROGRESS,
            CaseStatus.RESOLVED,
            CaseStatus.CLOSED,
            CaseStatus.OPEN,
        },
        CaseStatus.IN_PROGRESS: {
            CaseStatus.IN_REVIEW,
            CaseStatus.ACTION_REQUIRED,
            CaseStatus.RESOLVED,
            CaseStatus.CLOSED,
            CaseStatus.OPEN,
        },
        CaseStatus.PENDING_REVIEW: {
            CaseStatus.RESOLVED,
            CaseStatus.CLOSED,
            CaseStatus.IN_REVIEW,
            CaseStatus.OPEN,
        },
        CaseStatus.RESOLVED: {
            CaseStatus.CLOSED,
            CaseStatus.OPEN,
            CaseStatus.IN_REVIEW,
        },
        CaseStatus.CLOSED: set(),
    }

    def __init__(self, db_path: Optional[str] = None) -> None:
        if db_path is None:
            cases_env = os.getenv("FINSIGHT_CASES_DB")
            if cases_env:
                self.db_path = cases_env
            else:
                data_dir = Path(__file__).resolve().parent.parent.parent.parent / "data"
                data_dir.mkdir(parents=True, exist_ok=True)
                self.db_path = str(data_dir / "finsight_cases.db")
        else:
            self.db_path = db_path

        self._cases: Dict[str, FinancialCase] = {}
        self._init_db()

    @contextmanager
    def _db_conn(self):
        conn = sqlite3.connect(self.db_path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_db(self) -> None:
        """Initializes database schema and loads or seeds cases."""
        with self._db_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cases (
                    id TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    category TEXT NOT NULL,
                    entity TEXT,
                    owner TEXT,
                    due_date TEXT,
                    financial_exposure REAL,
                    data_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) AS cnt FROM cases")
            row = cursor.fetchone()
            count = row["cnt"] if row else 0

        if count == 0:
            if settings.seed_demo_data:
                self._seed_initial_cases()
        else:
            self._load_all_from_db()

    def _persist_case(self, case: FinancialCase) -> None:
        """Persists or updates a financial case in SQLite."""
        data_json = case.model_dump_json()
        with self._db_conn() as conn:
            conn.execute("""
                INSERT INTO cases (id, status, severity, category, entity, owner, due_date, financial_exposure, data_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    status = excluded.status,
                    severity = excluded.severity,
                    category = excluded.category,
                    entity = excluded.entity,
                    owner = excluded.owner,
                    due_date = excluded.due_date,
                    financial_exposure = excluded.financial_exposure,
                    data_json = excluded.data_json,
                    updated_at = excluded.updated_at
            """, (
                case.id,
                case.status.value,
                case.severity.value,
                case.category.value,
                case.entity,
                case.owner,
                case.due_date,
                case.financial_exposure,
                data_json,
                case.created_at,
                case.updated_at,
            ))

    def _load_all_from_db(self) -> None:
        """Loads all stored cases from SQLite."""
        with self._db_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT data_json FROM cases ORDER BY updated_at DESC")
            rows = cursor.fetchall()
            self._cases = {}
            for row in rows:
                case_dict = json.loads(row["data_json"])
                c = FinancialCase(**case_dict)
                self._cases[c.id] = c

    def reset(self) -> None:
        """Wipes SQLite case records and re-seeds baseline cases if demo data enabled."""
        with self._db_conn() as conn:
            conn.execute("DELETE FROM cases")
        self._cases = {}
        if settings.seed_demo_data:
            self._seed_initial_cases()

    def _seed_initial_cases(self) -> None:
        """Seeds initial realistic enterprise financial cases for 2026-09."""
        case_1 = FinancialCase(
            id="CASE-2026-001",
            title="Apex Retail Group Overdue AR Escalation",
            status=CaseStatus.OPEN,
            severity=CaseSeverity.CRITICAL,
            category=CaseCategory.RECEIVABLES,
            owner="Credit Controller",
            assignee="Credit Controller",
            financial_exposure=1044000.00,
            financial_impact=1044000.00,
            entity="Apex Retail Group",
            control_id="CONTROL-COLL-001",
            assessment_id="ASSESS-202609-COLL-001",
            financial_evidence_refs=["INV-AR-50065", "INV-AR-50073", "INV-AR-50081"],
            policy_evidence_refs=["COLL-POL-001-v2.1-chunk03", "COLL-POL-001-v2.1-chunk05"],
            period="2026-09",
            snapshot_id="SNAP-202609-001",
            due_date="2026-10-05",
            summary=(
                "Apex Retail Group holds ₹1,044,000 in past-due receivables across 3 overdue invoices (INV-AR-50065, "
                "INV-AR-50073, INV-AR-50081) aged up to 68 days. Represents 100% of all company overdue AR."
            ),
            linked_attention_id="ATTN-AR-202609-01",
            linked_question="Which customers are driving overdue AR?",
            recommended_actions=[
                "Schedule an urgent executive collection meeting with Apex Retail Group finance leadership.",
                "Verify proof of delivery for invoice INV-AR-50065 (₹189K, 68 days overdue).",
                "Place a temporary credit hold on new merchandise shipments pending a structured repayment plan.",
            ],
            remediation_plan=[
                RemediationAction(
                    action="Place administrative credit hold on pending merchandise shipments",
                    owner="Credit Controller",
                    due_date="2026-10-02",
                    status="COMPLETED",
                    evidence="ERP Credit Block Reference BLK-99014",
                    comment="Credit hold active; warehouse dispatch alerted.",
                ),
                RemediationAction(
                    action="Issue formal 24-hour C-level dunning notice to Apex CCO & AP Director",
                    owner="Head of Credit & Collections",
                    due_date="2026-10-03",
                    status="IN_PROGRESS",
                    evidence="Letter COLL-NT-50065 drafted",
                    comment="Scheduled review with VP Finance.",
                ),
                RemediationAction(
                    action="Execute executive reconciliation session with Apex procurement",
                    owner="VP Finance",
                    due_date="2026-10-05",
                    status="OPEN",
                    comment="Targeting confirmed wire remittance date for INV-AR-50065.",
                ),
            ],
            notes=[
                CaseNote(
                    id="NOTE-001",
                    author="System (Financial Attention)",
                    text="Case automatically initialized from Critical Attention item ATTN-AR-202609-01.",
                    created_at="2026-09-30T10:00:00Z",
                ),
                CaseNote(
                    id="NOTE-002",
                    author="Credit Controller",
                    text="Reached out to Apex AP director; customer requested ledger reconciliation statement.",
                    created_at="2026-10-01T14:30:00Z",
                ),
            ],
            audit_notes=[
                CaseAuditEvent(
                    id="AUDIT-001",
                    event_type="CASE_CREATED",
                    actor="System (Financial Attention)",
                    details="Case CASE-2026-001 opened for Apex Retail Group with immutable exposure ₹1,044,000.00.",
                    timestamp="2026-09-30T10:00:00Z",
                ),
                CaseAuditEvent(
                    id="AUDIT-002",
                    event_type="CONTROL_ASSESSED",
                    actor="ControlAssessmentService",
                    details="Breach confirmed against CONTROL-COLL-001 (COLL-POL-001 v2.1 Section 3).",
                    timestamp="2026-09-30T10:00:01Z",
                ),
                CaseAuditEvent(
                    id="AUDIT-003",
                    event_type="OWNER_ASSIGNED",
                    actor="System",
                    details="Assigned case ownership to Credit Controller.",
                    timestamp="2026-09-30T10:00:02Z",
                ),
            ],
            created_at="2026-09-30T10:00:00Z",
            updated_at="2026-10-01T14:30:00Z",
        )

        case_2 = FinancialCase(
            id="CASE-2026-002",
            title="7-Day Vendor Payable Cash Squeeze Mitigation",
            status=CaseStatus.IN_REVIEW,
            severity=CaseSeverity.HIGH,
            category=CaseCategory.LIQUIDITY,
            owner="Treasury Manager",
            assignee="Treasury Manager",
            financial_exposure=1377000.00,
            financial_impact=1377000.00,
            entity="Enterprise Treasury",
            control_id="CONTROL-LIQ-001",
            assessment_id="ASSESS-202609-LIQ-001",
            financial_evidence_refs=["GL-101000", "GL-102000", "GL-103000", "INV-AP-90042", "INV-AP-90055", "INV-AP-90061"],
            policy_evidence_refs=["LIQ-CTRL-001-v2.0-chunk02"],
            period="2026-09",
            snapshot_id="SNAP-202609-001",
            due_date="2026-10-04",
            summary=(
                "Vendor payables of ₹1,377,000 mature within the next 7 calendar days across 3 suppliers "
                "(Titan Semiconductor ₹816K, Precision Metalworks ₹408K, Global Freight ₹153K) against liquid cash reserves "
                "of ₹813,750, creating an imminent ₹563,250 liquidity shortfall unless disbursements are staggered."
            ),
            linked_attention_id="ATTN-CASH-202609-01",
            linked_question="What payments are due in the next 7 days?",
            recommended_actions=[
                "Engage Titan Semiconductor (₹816K due in 5 days) and Precision Metalworks (₹408K due today) to negotiate split payment schedules.",
                "Accelerate short-term collections from current accounts to cover near-term obligations.",
                "Review short-term working capital credit facility draw options.",
            ],
            remediation_plan=[
                RemediationAction(
                    action="Pause non-critical discretionary AP disbursements under LIQ-CTRL-001",
                    owner="Corporate Controller",
                    due_date="2026-10-01",
                    status="COMPLETED",
                    evidence="AP Payment Batch #902 held",
                ),
                RemediationAction(
                    action="Negotiate 50% split payment with Titan Semiconductor Ltd",
                    owner="Treasury Manager",
                    due_date="2026-10-03",
                    status="IN_PROGRESS",
                    comment="Supplier agreed in principle; awaiting written confirmation.",
                ),
            ],
            notes=[
                CaseNote(
                    id="NOTE-003",
                    author="Treasury Manager",
                    text="Cash forecast updated. Initiated discussions with primary banking partner on revolving line draw.",
                    created_at="2026-10-01T09:15:00Z",
                )
            ],
            audit_notes=[
                CaseAuditEvent(
                    id="AUDIT-004",
                    event_type="CASE_CREATED",
                    actor="System (Financial Attention)",
                    details="Case CASE-2026-002 created for Treasury Liquidity Squeeze (₹1,377,000.00 obligations).",
                    timestamp="2026-09-30T11:00:00Z",
                ),
                CaseAuditEvent(
                    id="AUDIT-005",
                    event_type="STATUS_CHANGED",
                    actor="Treasury Manager",
                    details="Status updated from OPEN to IN_REVIEW following liquidity committee review.",
                    timestamp="2026-10-01T09:15:00Z",
                ),
            ],
            created_at="2026-09-30T11:00:00Z",
            updated_at="2026-10-01T09:15:00Z",
        )

        case_3 = FinancialCase(
            id="CASE-2026-003",
            title="OmniChannel Logistics Margin Dilution",
            status=CaseStatus.OPEN,
            severity=CaseSeverity.MEDIUM,
            category=CaseCategory.MARGIN,
            owner="Procurement Lead",
            assignee="Procurement Lead",
            financial_exposure=262000.00,
            financial_impact=262000.00,
            entity="OmniChannel Logistics",
            control_id="CONTROL-GM-001",
            assessment_id="ASSESS-202609-GM-001",
            financial_evidence_refs=["GL-400000", "GL-500000"],
            policy_evidence_refs=["GM-POL-001-v2.2-chunk02"],
            period="2026-09",
            snapshot_id="SNAP-202609-001",
            due_date="2026-10-15",
            summary=(
                "OmniChannel Logistics contributes ₹262,000 in revenue at a low gross margin of 27.5% "
                "(below company benchmark 40.3%), compressing overall operating gross margin."
            ),
            linked_attention_id="ATTN-PROFIT-202609-01",
            linked_question="Which customers or products have the lowest margins?",
            recommended_actions=[
                "Audit fulfillment service contracts and contracted component price guarantees.",
                "Re-evaluate volume pricing tiers and price indexation clauses for low-margin logistics accounts.",
                "Initiate price indexation clause review for Q4 renewals.",
            ],
            remediation_plan=[
                RemediationAction(
                    action="Audit logistics fulfillment cost breakdown for Q3",
                    owner="Commercial Controller",
                    due_date="2026-10-10",
                    status="OPEN",
                ),
            ],
            notes=[
                CaseNote(
                    id="NOTE-004",
                    author="Procurement Lead",
                    text="Supplier contracts under review with commercial legal team.",
                    created_at="2026-10-01T16:00:00Z",
                )
            ],
            audit_notes=[
                CaseAuditEvent(
                    id="AUDIT-006",
                    event_type="CASE_CREATED",
                    actor="System",
                    details="Case CASE-2026-003 opened for Margin Dilution at OmniChannel Logistics (₹262,000.00).",
                    timestamp="2026-09-30T12:00:00Z",
                ),
            ],
            created_at="2026-09-30T12:00:00Z",
            updated_at="2026-10-01T16:00:00Z",
        )

        self._cases[case_1.id] = case_1
        self._cases[case_2.id] = case_2
        self._cases[case_3.id] = case_3
        self._persist_case(case_1)
        self._persist_case(case_2)
        self._persist_case(case_3)

    def list_cases(
        self,
        status: Optional[CaseStatus] = None,
        severity: Optional[CaseSeverity] = None,
        category: Optional[CaseCategory] = None,
        entity: Optional[str] = None,
    ) -> List[FinancialCase]:
        """Returns all registered remediation cases filtered by optional criteria."""
        items = list(self._cases.values())
        if status:
            items = [c for c in items if c.status == status]
        if severity:
            items = [c for c in items if c.severity == severity]
        if category:
            items = [c for c in items if c.category == category]
        if entity:
            items = [c for c in items if c.entity and entity.lower() in c.entity.lower()]
        # Sort by updated_at descending
        return sorted(items, key=lambda c: c.updated_at, reverse=True)

    def get_case(self, case_id: str) -> Optional[FinancialCase]:
        """Retrieves a single case by ID."""
        return self._cases.get(case_id)

    def create_case(self, req: CreateCaseRequest, actor: Optional[str] = None) -> FinancialCase:
        """Creates a new financial case preserving immutable snapshot and exposure."""
        case_num = len(self._cases) + 1
        new_id = f"CASE-{datetime.now(timezone.utc).year}-{case_num:03d}"
        now_iso = datetime.now(timezone.utc).isoformat()

        exposure = req.financial_exposure if req.financial_exposure is not None else req.financial_impact
        owner_name = req.owner or req.assignee or "Finance Team"
        verified_actor = actor or owner_name

        notes: List[CaseNote] = []
        if req.initial_note:
            notes.append(
                CaseNote(
                    id=f"NOTE-{uuid.uuid4().hex[:6]}",
                    author=verified_actor,
                    text=req.initial_note,
                    created_at=now_iso,
                )
            )

        audit_notes: List[CaseAuditEvent] = [
            CaseAuditEvent(
                id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                event_type="CASE_CREATED",
                actor=verified_actor,
                details=f"Case {new_id} opened: '{req.title}' with immutable exposure ₹{exposure:,.2f}.",
                timestamp=now_iso,
            )
        ]

        if req.control_id:
            audit_notes.append(
                CaseAuditEvent(
                    id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                    event_type="CONTROL_ASSESSED",
                    actor="ControlAssessmentService",
                    details=f"Linked to governing control {req.control_id}.",
                    timestamp=now_iso,
                )
            )

        audit_notes.append(
            CaseAuditEvent(
                id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                event_type="OWNER_ASSIGNED",
                actor="System",
                details=f"Assigned owner: {owner_name}.",
                timestamp=now_iso,
            )
        )

        new_case = FinancialCase(
            id=new_id,
            case_id=new_id,
            title=req.title,
            status=CaseStatus.OPEN,
            severity=req.severity,
            category=req.category,
            financial_exposure=exposure,
            financial_impact=exposure,
            entity=req.entity,
            control_id=req.control_id,
            assessment_id=req.assessment_id,
            investigation_id=req.investigation_id,
            financial_evidence_refs=req.financial_evidence_refs,
            policy_evidence_refs=req.policy_evidence_refs,
            owner=owner_name,
            assignee=owner_name,
            due_date=req.due_date,
            period=req.period,
            snapshot_id=req.snapshot_id,
            summary=req.summary,
            linked_attention_id=req.linked_attention_id,
            linked_question=req.linked_question,
            recommended_actions=req.recommended_actions,
            remediation_plan=req.remediation_plan,
            notes=notes,
            audit_notes=audit_notes,
            created_at=now_iso,
            updated_at=now_iso,
        )

        self._cases[new_case.id] = new_case
        self._persist_case(new_case)
        return new_case

    def create_case_from_assessment(
        self,
        assessment: ControlAssessment,
        owner: Optional[str] = None,
        due_date: Optional[str] = None,
        assigned_owner: Optional[str] = None,
        actor: Optional[str] = None,
    ) -> FinancialCase:
        """Constructs an auditable remediation case directly from a ControlAssessment."""
        assigned_owner = assigned_owner or owner or (
            "Credit Controller" if assessment.domain == "AR"
            else "Treasury Manager" if assessment.domain == "TREASURY"
            else "Commercial Controller" if assessment.domain == "PROFITABILITY"
            else "Supply Chain Lead" if assessment.domain == "WORKING_CAPITAL"
            else "Finance Lead"
        )

        category = (
            CaseCategory.RECEIVABLES if assessment.domain == "AR"
            else CaseCategory.LIQUIDITY if assessment.domain == "TREASURY"
            else CaseCategory.INVENTORY if assessment.domain == "WORKING_CAPITAL"
            else CaseCategory.MARGIN if assessment.domain == "PROFITABILITY"
            else CaseCategory.PAYABLES if assessment.domain == "AP"
            else CaseCategory.GOVERNANCE
        )

        severity = (
            CaseSeverity.CRITICAL if assessment.severity == "CRITICAL"
            else CaseSeverity.HIGH if assessment.severity == "HIGH"
            else CaseSeverity.MEDIUM
        )

        title = f"{assessment.control_name} Remediation"
        if assessment.entity:
            title = f"{assessment.entity} — {title}"

        req = CreateCaseRequest(
            title=title,
            severity=severity,
            category=category,
            financial_impact=assessment.financial_exposure,
            financial_exposure=assessment.financial_exposure,
            entity=assessment.entity,
            control_id=assessment.control_id,
            assessment_id=assessment.assessment_id,
            financial_evidence_refs=assessment.financial_evidence_refs,
            policy_evidence_refs=assessment.policy_evidence_refs,
            period=assessment.period,
            snapshot_id=assessment.snapshot_id,
            summary=assessment.explanation,
            owner=assigned_owner,
            assignee=assigned_owner,
            due_date=due_date or "2026-10-05",
            recommended_actions=[assessment.required_action],
            remediation_plan=[
                RemediationAction(
                    action=assessment.required_action,
                    owner=assigned_owner,
                    due_date=due_date or "2026-10-05",
                    status="OPEN",
                )
            ],
            initial_note=f"Case automatically generated from {assessment.control_id} assessment breach.",
        )
        return self.create_case(req, actor=actor)

    def update_case(
        self,
        case_id: str,
        req: UpdateCaseRequest,
        actor: Optional[str] = None,
    ) -> Optional[FinancialCase]:
        """Updates case metadata, state, remediation actions, or notes with audit enforcement."""
        case = self._cases.get(case_id)
        if not case:
            return None

        # Closed case editing rule
        if case.status == CaseStatus.CLOSED:
            raise ValueError("Cannot modify a closed case. Status is CLOSED.")

        now_iso = datetime.now(timezone.utc).isoformat()
        actor = actor or req.note_author or "Finance Lead"

        # Status transition validation
        if req.status is not None and req.status != case.status:
            allowed = self.VALID_TRANSITIONS.get(case.status, set())
            if req.status not in allowed:
                raise ValueError(
                    f"Invalid status transition from {case.status.value} to {req.status.value}."
                )

        # Non-silent closure enforcement
        if req.status in (CaseStatus.CLOSED, CaseStatus.RESOLVED):
            res_summary = req.resolution_summary or (req.new_note if req.note_author else None) or case.resolution_summary
            res_evidence = req.resolution_evidence or (f"NOTE-{req.note_author}" if req.new_note and req.note_author else None) or case.resolution_evidence
            if not res_summary and not res_evidence:
                raise ValueError(
                    "Cannot resolve or close case without documented resolution_summary and verified resolution_evidence. "
                    "FinSight strictly enforces non-silent case closure."
                )
            elif not res_summary:
                raise ValueError(
                    "Cannot resolve or close case without documented resolution_summary. "
                    "FinSight strictly enforces non-silent case closure."
                )
            elif not res_evidence:
                raise ValueError(
                    "Cannot resolve or close case without verified resolution_evidence. "
                    "FinSight strictly enforces non-silent case closure."
                )

        # Status transition
        if req.status is not None and req.status != case.status:
            old_status = case.status
            case.status = req.status
            case.audit_notes.append(
                CaseAuditEvent(
                    id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                    event_type="STATUS_CHANGED",
                    actor=actor,
                    details=f"Status transitioned from {old_status.value} to {req.status.value}.",
                    timestamp=now_iso,
                )
            )

        if req.severity is not None:
            case.severity = req.severity
        if req.owner is not None or req.assignee is not None:
            new_owner = req.owner or req.assignee
            if new_owner and new_owner != case.owner:
                case.owner = new_owner
                case.assignee = new_owner
                case.audit_notes.append(
                    CaseAuditEvent(
                        id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                        event_type="OWNER_ASSIGNED",
                        actor=actor,
                        details=f"Reassigned owner to {new_owner}.",
                        timestamp=now_iso,
                    )
                )

        if req.due_date is not None:
            case.due_date = req.due_date

        if req.recommended_actions is not None:
            case.recommended_actions = req.recommended_actions

        # Append new remediation action
        if req.new_action:
            case.remediation_plan.append(req.new_action)
            case.audit_notes.append(
                CaseAuditEvent(
                    id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                    event_type="ACTION_ADDED",
                    actor=actor,
                    details=f"Remediation action added: '{req.new_action.action}' assigned to {req.new_action.owner}.",
                    timestamp=now_iso,
                )
            )

        # Resolution details
        if req.resolution_summary:
            case.resolution_summary = req.resolution_summary
        if req.resolution_evidence:
            case.resolution_evidence = req.resolution_evidence
        if req.reviewer:
            case.reviewer = req.reviewer

        if req.status == CaseStatus.RESOLVED:
            case.audit_notes.append(
                CaseAuditEvent(
                    id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                    event_type="RESOLVED",
                    actor=actor,
                    details=f"Case marked RESOLVED by {actor}. Summary: {case.resolution_summary or 'Remediation completed.'}",
                    timestamp=now_iso,
                )
            )
        elif req.status == CaseStatus.CLOSED:
            case.audit_notes.append(
                CaseAuditEvent(
                    id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                    event_type="CLOSED",
                    actor=actor,
                    details=f"Case formally CLOSED. Reviewer: {case.reviewer or actor}. Evidence: {case.resolution_evidence}",
                    timestamp=now_iso,
                )
            )

        if req.new_note:
            case.notes.append(
                CaseNote(
                    id=f"NOTE-{uuid.uuid4().hex[:6]}",
                    author=actor,
                    text=req.new_note,
                    created_at=now_iso,
                )
            )
            case.audit_notes.append(
                CaseAuditEvent(
                    id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                    event_type="NOTE_ADDED",
                    actor=actor,
                    details=f"Note appended by {actor}: '{req.new_note[:80]}...'",
                    timestamp=now_iso,
                )
            )

        case.updated_at = now_iso
        self._cases[case_id] = case
        self._persist_case(case)
        return case

    def add_remediation_action(
        self,
        case_id: str,
        action: RemediationAction,
        actor: str = "User",
    ) -> Optional[FinancialCase]:
        """Appends a new remediation action item to case with audit logging."""
        case = self._cases.get(case_id)
        if not case:
            return None

        # Closed case editing rule
        if case.status == CaseStatus.CLOSED:
            raise ValueError("Cannot modify a closed case. Status is CLOSED.")

        case.remediation_plan.append(action)
        now_iso = datetime.now(timezone.utc).isoformat()
        case.audit_notes.append(
            CaseAuditEvent(
                id=f"AUDIT-{uuid.uuid4().hex[:6]}",
                event_type="ACTION_ADDED",
                actor=actor,
                details=f"Action item added: '{action.action}' (Due: {action.due_date}, Owner: {action.owner}).",
                timestamp=now_iso,
            )
        )
        case.updated_at = now_iso
        self._cases[case_id] = case
        self._persist_case(case)
        return case

    def close_case(
        self,
        case_id: str,
        req: CloseCaseRequest,
        actor: str = "User",
    ) -> Optional[FinancialCase]:
        """Formally closes a case with verified resolution evidence and reviewer signoff."""
        if not req.resolution_summary or not req.resolution_summary.strip():
            raise ValueError(
                "Cannot resolve or close case without documented resolution_summary. "
                "FinSight strictly enforces non-silent case closure."
            )
        if not req.resolution_evidence or not req.resolution_evidence.strip():
            raise ValueError(
                "Cannot resolve or close case without verified resolution_evidence. "
                "FinSight strictly enforces non-silent case closure."
            )
        update_req = UpdateCaseRequest(
            status=CaseStatus.CLOSED,
            resolution_summary=req.resolution_summary.strip(),
            resolution_evidence=req.resolution_evidence.strip(),
            reviewer=req.reviewer,
            note_author=actor,
        )
        return self.update_case(case_id, update_req, actor=actor)
