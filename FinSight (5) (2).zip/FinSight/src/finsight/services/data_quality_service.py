"""Data Quality & Integrity Service for FinSight.

Performs deterministic audits on canonical financial datasets, verifying referential integrity,
double-entry balance rules, date semantics, and identifies calculation blockers.
"""

from collections import defaultdict
from datetime import date
from typing import Any, Dict, List, Optional, Set

from finsight.models.canonical import (
    AccountMapping,
    APOpenItem,
    AROpenItem,
    Company,
    Customer,
    JournalEntry,
    Product,
    Vendor,
)
from finsight.models.quality import (
    DataQualityReport,
    DataQualityStatus,
    EntityStats,
    IssueSeverity,
    ValidationIssue,
)


class DataQualityService:
    """Evaluates canonical financial data for errors, discrepancies, and calculation blockers."""

    def __init__(self, last_refresh_timestamp: Optional[str] = None):
        self._last_refresh_timestamp = last_refresh_timestamp

    def evaluate(
        self,
        company: Optional[Company],
        customers: List[Customer],
        vendors: List[Vendor],
        products: List[Product],
        account_mappings: List[AccountMapping],
        journal_entries: List[JournalEntry],
        ar_items: List[AROpenItem],
        ap_items: List[APOpenItem],
        source_name: str = "mock_financial_adapter",
    ) -> DataQualityReport:
        """Runs the validation rules suite across all financial entities."""
        entity_stats: Dict[str, EntityStats] = {}
        unresolved_references: List[ValidationIssue] = []
        calculation_blockers: List[ValidationIssue] = []
        warnings: List[ValidationIssue] = []

        # 1. Company Validation
        if not company:
            calculation_blockers.append(
                ValidationIssue(
                    entity_type="Company",
                    issue_type="MISSING_ENTITY",
                    severity=IssueSeverity.CRITICAL,
                    message="No company master record provided. Financial statements cannot be scoped.",
                )
            )
            entity_stats["Company"] = EntityStats(record_count=0, valid_count=0, invalid_count=1)
        else:
            entity_stats["Company"] = EntityStats(record_count=1, valid_count=1, invalid_count=0)

        # 2. Master Data ID Sets & Duplicate Checks
        customer_ids: Set[str] = set()
        cust_invalid = 0
        cust_dups = 0
        for c in customers:
            if not c.customer_id:
                cust_invalid += 1
                warnings.append(ValidationIssue(
                    entity_type="Customer",
                    issue_type="MISSING_ID",
                    severity=IssueSeverity.WARNING,
                    message="Customer missing ID.",
                ))
            elif c.customer_id in customer_ids:
                cust_dups += 1
                warnings.append(ValidationIssue(
                    entity_type="Customer",
                    issue_type="DUPLICATE_ID",
                    severity=IssueSeverity.WARNING,
                    record_identifier=c.customer_id,
                    message=f"Duplicate customer identifier: {c.customer_id}",
                ))
            else:
                customer_ids.add(c.customer_id)
        entity_stats["Customer"] = EntityStats(
            record_count=len(customers),
            valid_count=len(customers) - cust_invalid - cust_dups,
            invalid_count=cust_invalid,
            duplicate_count=cust_dups,
        )

        vendor_ids: Set[str] = set()
        vend_invalid = 0
        vend_dups = 0
        for v in vendors:
            if not v.vendor_id:
                vend_invalid += 1
                warnings.append(ValidationIssue(
                    entity_type="Vendor",
                    issue_type="MISSING_ID",
                    severity=IssueSeverity.WARNING,
                    message="Vendor missing ID.",
                ))
            elif v.vendor_id in vendor_ids:
                vend_dups += 1
                warnings.append(ValidationIssue(
                    entity_type="Vendor",
                    issue_type="DUPLICATE_ID",
                    severity=IssueSeverity.WARNING,
                    record_identifier=v.vendor_id,
                    message=f"Duplicate vendor identifier: {v.vendor_id}",
                ))
            else:
                vendor_ids.add(v.vendor_id)
        entity_stats["Vendor"] = EntityStats(
            record_count=len(vendors),
            valid_count=len(vendors) - vend_invalid - vend_dups,
            invalid_count=vend_invalid,
            duplicate_count=vend_dups,
        )

        product_ids: Set[str] = set()
        prod_invalid = 0
        prod_dups = 0
        for p in products:
            if not p.product_id:
                prod_invalid += 1
            elif p.product_id in product_ids:
                prod_dups += 1
            else:
                product_ids.add(p.product_id)
        entity_stats["Product"] = EntityStats(
            record_count=len(products),
            valid_count=len(products) - prod_invalid - prod_dups,
            invalid_count=prod_invalid,
            duplicate_count=prod_dups,
        )

        # 3. Account Mappings & Chart of Accounts
        gl_accounts: Set[str] = set()
        concepts_present: Set[str] = set()
        mapping_invalid = 0
        for m in account_mappings:
            if not m.gl_account:
                mapping_invalid += 1
            gl_accounts.add(m.gl_account)
            concepts_present.add(m.financial_concept.value)

        entity_stats["AccountMapping"] = EntityStats(
            record_count=len(account_mappings),
            valid_count=len(account_mappings) - mapping_invalid,
            invalid_count=mapping_invalid,
        )

        # Check required financial concepts
        essential_concepts = {"CASH", "AR", "AP", "INVENTORY", "REVENUE", "COGS"}
        missing_concepts = essential_concepts - concepts_present
        if missing_concepts:
            calculation_blockers.append(
                ValidationIssue(
                    entity_type="AccountMapping",
                    issue_type="MISSING_CONCEPT_MAPPING",
                    severity=IssueSeverity.CRITICAL,
                    message=f"Crucial financial concepts missing from Account Mappings: {', '.join(sorted(missing_concepts))}",
                )
            )

        # 4. Journal Entries Audit
        je_invalid = 0
        doc_balances: Dict[str, float] = defaultdict(float)
        unmapped_gls: Set[str] = set()

        for je in journal_entries:
            # Required fields & values
            if not je.document_id or not je.gl_account or je.amount < 0:
                je_invalid += 1
                continue

            # Double-entry accumulation
            doc_balances[je.document_id] += je.signed_amount

            # Date and period integrity check (ACDOCA calendar alignment)
            if je.posting_date.year != je.fiscal_year or je.posting_date.month != je.fiscal_period:
                je_invalid += 1
                warnings.append(
                    ValidationIssue(
                        entity_type="JournalEntry",
                        issue_type="MISMATCHED_POSTING_PERIOD",
                        severity=IssueSeverity.WARNING,
                        record_identifier=je.document_id,
                        field_name="fiscal_period",
                        message=f"Journal document {je.document_id} posting date {je.posting_date} does not align with fiscal year {je.fiscal_year} and period {je.fiscal_period}.",
                    )
                )

            # Referential integrity: GL Account
            if je.gl_account not in gl_accounts:
                unmapped_gls.add(je.gl_account)

            # Referential integrity: Customer ID
            if je.customer_id and je.customer_id not in customer_ids:
                unresolved_references.append(
                    ValidationIssue(
                        entity_type="JournalEntry",
                        issue_type="UNRESOLVED_CUSTOMER",
                        severity=IssueSeverity.WARNING,
                        record_identifier=je.document_id,
                        field_name="customer_id",
                        message=f"Journal document {je.document_id} references unknown customer: {je.customer_id}",
                    )
                )

            # Referential integrity: Vendor ID
            if je.vendor_id and je.vendor_id not in vendor_ids:
                unresolved_references.append(
                    ValidationIssue(
                        entity_type="JournalEntry",
                        issue_type="UNRESOLVED_VENDOR",
                        severity=IssueSeverity.WARNING,
                        record_identifier=je.document_id,
                        field_name="vendor_id",
                        message=f"Journal document {je.document_id} references unknown vendor: {je.vendor_id}",
                    )
                )

            # Referential integrity: Product ID
            if je.product_id and je.product_id not in product_ids:
                unresolved_references.append(
                    ValidationIssue(
                        entity_type="JournalEntry",
                        issue_type="UNRESOLVED_PRODUCT",
                        severity=IssueSeverity.WARNING,
                        record_identifier=je.document_id,
                        field_name="product_id",
                        message=f"Journal document {je.document_id} references unknown product: {je.product_id}",
                    )
                )

        if unmapped_gls:
            calculation_blockers.append(
                ValidationIssue(
                    entity_type="JournalEntry",
                    issue_type="UNMAPPED_GL_ACCOUNTS",
                    severity=IssueSeverity.CRITICAL,
                    message=f"Found journal entries posting to unmapped GL accounts: {', '.join(sorted(unmapped_gls))}",
                )
            )

        # Double-entry balance check (Debits must equal Credits per document within 0.01 tolerance)
        unbalanced_docs = [doc_id for doc_id, bal in doc_balances.items() if abs(bal) > 0.01]
        if unbalanced_docs:
            calculation_blockers.append(
                ValidationIssue(
                    entity_type="JournalEntry",
                    issue_type="UNBALANCED_JOURNAL_DOCUMENTS",
                    severity=IssueSeverity.CRITICAL,
                    message=f"{len(unbalanced_docs)} journal documents violate double-entry balancing (Debits != Credits). Sample: {unbalanced_docs[:5]}",
                )
            )

        entity_stats["JournalEntry"] = EntityStats(
            record_count=len(journal_entries),
            valid_count=len(journal_entries) - je_invalid,
            invalid_count=je_invalid,
        )

        # 5. Accounts Receivable Subledger Audit
        ar_invalid = 0
        ar_invoice_ids: Set[str] = set()
        for ar in ar_items:
            # Invoice amount check
            if ar.invoice_amount <= 0 or ar.open_amount < 0 or ar.open_amount > (ar.invoice_amount + 0.01):
                ar_invalid += 1
                warnings.append(
                    ValidationIssue(
                        entity_type="AROpenItem",
                        issue_type="INVALID_AMOUNT",
                        severity=IssueSeverity.CRITICAL,
                        record_identifier=ar.invoice_id,
                        message=f"AR item {ar.invoice_id} has invalid amounts: inv={ar.invoice_amount}, open={ar.open_amount}",
                    )
                )
            # Date chronology check
            if ar.clearing_date and ar.clearing_date < ar.invoice_date:
                ar_invalid += 1
                warnings.append(
                    ValidationIssue(
                        entity_type="AROpenItem",
                        issue_type="INVALID_CLEARING_DATE",
                        severity=IssueSeverity.WARNING,
                        record_identifier=ar.invoice_id,
                        message=f"AR clearing date {ar.clearing_date} is prior to invoice date {ar.invoice_date}",
                    )
                )
            # Referential integrity: Customer ID
            if ar.customer_id not in customer_ids:
                unresolved_references.append(
                    ValidationIssue(
                        entity_type="AROpenItem",
                        issue_type="UNRESOLVED_CUSTOMER",
                        severity=IssueSeverity.WARNING,
                        record_identifier=ar.invoice_id,
                        field_name="customer_id",
                        message=f"AR invoice {ar.invoice_id} references unknown customer: {ar.customer_id}",
                    )
                )
            ar_invoice_ids.add(ar.invoice_id)

        entity_stats["AROpenItem"] = EntityStats(
            record_count=len(ar_items),
            valid_count=len(ar_items) - ar_invalid,
            invalid_count=ar_invalid,
        )

        # 6. Accounts Payable Subledger Audit
        ap_invalid = 0
        ap_invoice_ids: Set[str] = set()
        for ap in ap_items:
            # Amount bounds
            if ap.invoice_amount <= 0 or ap.open_amount < 0 or ap.open_amount > (ap.invoice_amount + 0.01):
                ap_invalid += 1
                warnings.append(
                    ValidationIssue(
                        entity_type="APOpenItem",
                        issue_type="INVALID_AMOUNT",
                        severity=IssueSeverity.CRITICAL,
                        record_identifier=ap.invoice_id,
                        message=f"AP item {ap.invoice_id} has invalid amounts: inv={ap.invoice_amount}, open={ap.open_amount}",
                    )
                )
            # Date chronology
            if ap.clearing_date and ap.clearing_date < ap.invoice_date:
                ap_invalid += 1
                warnings.append(
                    ValidationIssue(
                        entity_type="APOpenItem",
                        issue_type="INVALID_CLEARING_DATE",
                        severity=IssueSeverity.WARNING,
                        record_identifier=ap.invoice_id,
                        message=f"AP clearing date {ap.clearing_date} is prior to invoice date {ap.invoice_date}",
                    )
                )
            # Referential integrity: Vendor ID
            if ap.vendor_id not in vendor_ids:
                unresolved_references.append(
                    ValidationIssue(
                        entity_type="APOpenItem",
                        issue_type="UNRESOLVED_VENDOR",
                        severity=IssueSeverity.WARNING,
                        record_identifier=ap.invoice_id,
                        field_name="vendor_id",
                        message=f"AP invoice {ap.invoice_id} references unknown vendor: {ap.vendor_id}",
                    )
                )
            ap_invoice_ids.add(ap.invoice_id)

        entity_stats["APOpenItem"] = EntityStats(
            record_count=len(ap_items),
            valid_count=len(ap_items) - ap_invalid,
            invalid_count=ap_invalid,
        )

        # Overall Status
        if calculation_blockers:
            overall_status = DataQualityStatus.BLOCKED
        elif warnings or unresolved_references:
            overall_status = DataQualityStatus.DEGRADED
        else:
            overall_status = DataQualityStatus.HEALTHY

        total_records = sum(stats.record_count for stats in entity_stats.values())

        return DataQualityReport(
            status=overall_status,
            last_successful_refresh=self._last_refresh_timestamp,
            source=source_name,
            total_records=total_records,
            entity_stats=entity_stats,
            unresolved_references=unresolved_references,
            calculation_blockers=calculation_blockers,
            warnings=warnings,
        )
