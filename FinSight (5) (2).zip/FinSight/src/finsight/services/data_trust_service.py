"""Financial Data Trust, Governed Metric & Multi-Layer Reconciliation Service for FinSight.

Implements the formal enterprise data trust pipeline:
SOURCE -> NORMALIZE -> MAP -> DEFINE -> CALCULATE -> RECONCILE -> PUBLISH -> TRACE

Orchestrates:
1. Governed Account Mapping Management (auditing GL chart of accounts, detecting unmapped accounts)
2. Governed Metric Catalog Integration (binding formulas, sign conventions, denominator guardrails)
3. Data Quality Pre-Flight Checks (preventing silent zero conversion on missing/zero denominators)
4. Multi-Layer Deterministic Reconciliation Ties (Source <-> Mapped <-> Metric Input <-> Published)
5. Deterministic Reconciliation Exception Diagnostics (what differs, variance, downstream impact)
6. Publication Trust States (PUBLISHED, PUBLISHED_WITH_WARNING, HELD_FOR_REVIEW, NOT_CALCULABLE)
7. End-to-End Metric Lineage & Provenance Chains
8. Executive & Audit Data Trust Summary
"""

from collections import defaultdict
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

from finsight.knowledge.metric_catalog import (
    get_governed_metric_catalog,
    get_governed_metric_definition,
)
from finsight.models.canonical import AccountCategory, FinancialConcept
from finsight.models.evidence import EvidenceItem, EvidenceSourceType
from finsight.models.metrics import MetricStatus, MetricUnit
from finsight.models.trust import (
    DataTrustSummaryResponse,
    GovernedAccountMapping,
    GovernedMetricDefinition,
    MappingStatus,
    MetricCalculationState,
    MetricInputTrace,
    MetricLineageResponse,
    MultiLayerReconciliationTie,
    PeriodType,
    PublicationStatus,
    PublishedGovernedMetric,
    ReconciliationException,
    ReconciliationStatus,
)
from finsight.services.financial_engine import FinancialEngine
from finsight.services.financial_reconciliation_service import FinancialReconciliationService
from finsight.services.metric_service import MetricService


class DataTrustService:
    """Orchestrates financial data governance, account mapping integrity, and metric lineage."""

    def __init__(
        self,
        engine: FinancialEngine,
        metric_service: MetricService,
        reconciliation_tolerance: float = 0.01,
    ):
        self.engine = engine
        self.metric_service = metric_service
        self.reconciliation_tolerance = reconciliation_tolerance
        self._governed_mappings_cache: Optional[List[GovernedAccountMapping]] = None

    # -------------------------------------------------------------------------
    # 1. GOVERNED ACCOUNT MAPPINGS ENGINE (Steps 4 & 5)
    # -------------------------------------------------------------------------

    def get_account_mappings(self) -> List[GovernedAccountMapping]:
        """Audits and returns all governed account mappings with current mapping status."""
        if self._governed_mappings_cache is not None:
            return list(self._governed_mappings_cache)

        # 1. Accounts defined in the active mapping table
        configured_mappings = self.engine.account_mappings
        if isinstance(configured_mappings, dict):
            configured_accounts = configured_mappings
        else:
            configured_accounts = {m.gl_account: m for m in configured_mappings}

        # 2. Accounts actually posted to across GL journal entries
        posted_accounts: Set[str] = set()
        for je in self.engine.journal_entries:
            posted_accounts.add(je.gl_account)

        account_names = {
            "101000": "Operating Checking Account",
            "102000": "Money Market Treasury Reserve",
            "110000": "Trade Accounts Receivable",
            "120000": "Raw Materials Inventory",
            "121000": "Finished Goods Inventory",
            "130000": "Prepaid Expenses & Current Deposits",
            "150000": "Property, Plant & Equipment (PP&E)",
            "200000": "Trade Accounts Payable",
            "210000": "Accrued Operating Liabilities",
            "220000": "Revolving Credit Facility (Short-Term Debt)",
            "250000": "Senior Term Note (Long-Term Liability)",
            "300000": "Common Stock Capital",
            "310000": "Retained Earnings",
            "400000": "Product Sales Revenue",
            "410000": "Service & Maintenance Revenue",
            "500000": "Cost of Goods Sold (Direct Costs)",
            "600000": "Operating Expenses (SG&A Overhead)",
        }

        governed: List[GovernedAccountMapping] = []

        # Audit configured mappings
        for acc_id, m in configured_accounts.items():
            downstream = self._resolve_downstream_metrics(m.financial_concept)
            # Check if active in postings
            status = MappingStatus.MAPPED
            governed.append(
                GovernedAccountMapping(
                    mapping_id=f"MAP-{acc_id}",
                    gl_account=acc_id,
                    account_name=account_names.get(acc_id, f"GL Account {acc_id}"),
                    financial_concept=m.financial_concept,
                    category=m.category,
                    mapping_status=status,
                    mapping_version="v1.0",
                    effective_from=m.valid_from,
                    effective_to=m.valid_to,
                    reason="Approved chart of accounts canonical mapping",
                    downstream_metrics=downstream,
                )
            )

        # Audit unmapped postings
        unmapped_ids = posted_accounts - set(configured_accounts.keys())
        for unmapped_id in sorted(unmapped_ids):
            governed.append(
                GovernedAccountMapping(
                    mapping_id=f"MAP-{unmapped_id}",
                    gl_account=unmapped_id,
                    account_name=f"Unmapped General Ledger Account {unmapped_id}",
                    financial_concept=None,
                    category=None,
                    mapping_status=MappingStatus.UNMAPPED,
                    mapping_version="N/A",
                    effective_from=date(2025, 1, 1),
                    effective_to=None,
                    reason="GL posting observed with no registered canonical concept in mapping table",
                    downstream_metrics=[],
                )
            )

        self._governed_mappings_cache = governed
        return list(governed)

    def _resolve_downstream_metrics(self, concept: FinancialConcept) -> List[str]:
        """Finds all governed metrics that consume a canonical financial concept."""
        downstream: List[str] = []
        for defn in get_governed_metric_catalog():
            if concept in defn.input_concepts:
                downstream.append(defn.metric_name)
        return downstream

    # -------------------------------------------------------------------------
    # 2. GOVERNED METRIC PRE-FLIGHT & QUALITY EVALUATION (Steps 6, 7 & 8)
    # -------------------------------------------------------------------------

    def get_published_metric(
        self,
        metric_name: str,
        period: Optional[str] = None,
    ) -> PublishedGovernedMetric:
        """Computes, validates, and publishes a governed metric with explicit data quality checks."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        defn = get_governed_metric_definition(metric_name)
        if not defn:
            return PublishedGovernedMetric(
                metric_name=metric_name,
                display_name=f"Unknown ({metric_name})",
                period=target_period,
                value=None,
                formatted_value="NOT_FOUND",
                unit=MetricUnit.COUNT,
                publication_status=PublicationStatus.NOT_CALCULABLE,
                calculation_state=MetricCalculationState.NOT_APPLICABLE,
                formula="N/A",
                period_type=PeriodType.FLOW,
                reconciliation_status=ReconciliationStatus.INSUFFICIENT_DATA,
                lineage_available=False,
            )

        # 1. Pre-flight data quality check (Zero denominator / missing inputs)
        calc_state, state_reason = self._check_metric_preflight(defn, target_period)

        if calc_state != MetricCalculationState.VALID:
            return PublishedGovernedMetric(
                metric_name=defn.metric_name,
                display_name=defn.display_name,
                period=target_period,
                value=None,
                formatted_value="INSUFFICIENT_DATA",
                unit=defn.unit,
                publication_status=PublicationStatus.NOT_CALCULABLE,
                calculation_state=calc_state,
                formula=defn.formula,
                period_type=defn.period_type,
                reconciliation_status=ReconciliationStatus.INSUFFICIENT_DATA,
                lineage_available=True,
            )

        # 2. Deterministic calculation via MetricService
        raw_res = self.metric_service.get_metric_by_name(defn.metric_name, target_period)
        metric_val = raw_res.value

        # 3. Multi-layer reconciliation tie evaluation
        recon_tie = self.get_reconciliation_tie(defn.metric_name, target_period)
        recon_status = recon_tie.status if recon_tie else ReconciliationStatus.RECONCILED

        # 4. Resolve Publication Status
        if recon_status == ReconciliationStatus.RECONCILED:
            pub_status = PublicationStatus.PUBLISHED
        elif recon_status == ReconciliationStatus.REVIEW_REQUIRED:
            pub_status = PublicationStatus.PUBLISHED_WITH_WARNING
        else:
            pub_status = PublicationStatus.HELD_FOR_REVIEW

        # Formatted value
        if defn.unit == MetricUnit.CURRENCY:
            fmt_val = f"₹{metric_val:,.2f}" if metric_val is not None else "N/A"
        elif defn.unit == MetricUnit.PERCENTAGE:
            fmt_val = f"{metric_val:.2f}%" if metric_val is not None else "N/A"
        elif defn.unit == MetricUnit.DAYS:
            fmt_val = f"{metric_val:.1f} days" if metric_val is not None else "N/A"
        else:
            fmt_val = str(metric_val) if metric_val is not None else "N/A"

        return PublishedGovernedMetric(
            metric_name=defn.metric_name,
            display_name=defn.display_name,
            period=target_period,
            value=round(metric_val, 4) if metric_val is not None else None,
            formatted_value=fmt_val,
            unit=defn.unit,
            publication_status=pub_status,
            calculation_state=MetricCalculationState.VALID,
            formula=defn.formula,
            period_type=defn.period_type,
            reconciliation_status=recon_status,
            lineage_available=True,
        )

    def get_all_published_metrics(
        self,
        period: Optional[str] = None,
    ) -> List[PublishedGovernedMetric]:
        """Calculates and returns all governed published metrics for a period."""
        catalog = get_governed_metric_catalog()
        return [self.get_published_metric(defn.metric_name, period) for defn in catalog]

    def _check_metric_preflight(
        self,
        defn: GovernedMetricDefinition,
        period: str,
    ) -> Tuple[MetricCalculationState, Optional[str]]:
        """Pre-flight check preventing silent conversion of zero or missing inputs."""
        pnl = self.engine.get_pnl_for_period(period)
        rev = pnl.get("revenue", 0.0)
        cogs = pnl.get("cogs", 0.0)

        # Denominator rules check
        if defn.metric_name in ("gross_margin_percent", "dso"):
            if rev <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    f"Denominator Revenue (₹{rev:,.2f}) is non-positive; metric is non-calculable.",
                )

        if defn.metric_name in ("dio", "dpo"):
            if cogs <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    f"Denominator COGS (₹{cogs:,.2f}) is non-positive; metric is non-calculable.",
                )

        if defn.metric_name == "cash_conversion_cycle":
            if rev <= 0 or cogs <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    "Component inputs for DSO or DIO have non-positive denominators.",
                )

        target_date = self.metric_service._get_period_end_date(period)

        if defn.metric_name in ("current_ratio", "quick_ratio"):
            wc = self.engine.get_working_capital_components(target_date)
            cl = wc.get("total_current_liabilities", 0.0)
            if cl <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    f"Denominator Current Liabilities (₹{cl:,.2f}) is non-positive; metric is non-calculable.",
                )

        if defn.metric_name == "ar_turnover":
            ar_summary = self.engine.get_ar_summary(target_date)
            trade_ar = ar_summary.get("total_open_ar", 0.0)
            if trade_ar <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    f"Denominator Trade AR (₹{trade_ar:,.2f}) is non-positive; metric is non-calculable.",
                )

        if defn.metric_name == "ap_turnover":
            ap_summary = self.engine.get_ap_summary(target_date)
            trade_ap = ap_summary.get("total_open_ap", 0.0)
            if trade_ap <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    f"Denominator Trade AP (₹{trade_ap:,.2f}) is non-positive; metric is non-calculable.",
                )

        if defn.metric_name in ("roe", "debt_to_equity"):
            equity = self.engine.calculate_balance_as_of(FinancialConcept.EQUITY, target_date)
            if equity <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    f"Denominator Total Equity (₹{equity:,.2f}) is non-positive; metric is non-calculable.",
                )

        if defn.metric_name == "interest_coverage":
            return (
                MetricCalculationState.INSUFFICIENT_DATA,
                "Interest Expense input is unavailable in active general ledger.",
            )

        if defn.metric_name == "revenue_growth":
            prev_p = self.metric_service._get_previous_period(period)
            if not prev_p or prev_p not in self.engine.available_periods:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    "Prior period revenue is unavailable for comparative growth calculation.",
                )
            prev_pnl = self.engine.get_pnl_for_period(prev_p)
            if prev_pnl.get("revenue", 0.0) <= 0:
                return (
                    MetricCalculationState.INSUFFICIENT_DATA,
                    "Prior period revenue is zero or negative; cannot calculate growth percentage.",
                )

        if defn.metric_name == "budget_variance":
            return (
                MetricCalculationState.INSUFFICIENT_DATA,
                "Board-approved budget plan data is not configured in the active ledger.",
            )

        return MetricCalculationState.VALID, None

    # -------------------------------------------------------------------------
    # 3. MULTI-LAYER DETERMINISTIC RECONCILIATION (Steps 9 & 10)
    # -------------------------------------------------------------------------

    def get_reconciliation_tie(
        self,
        metric_or_concept: str,
        period: Optional[str] = None,
        custom_tolerance: Optional[float] = None,
    ) -> Optional[MultiLayerReconciliationTie]:
        """Compares Source Subledger <-> Mapped GL <-> Metric Input <-> Published Value."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = self.metric_service._get_period_end_date(target_period)
        tolerance = custom_tolerance if custom_tolerance is not None else self.reconciliation_tolerance
        m = metric_or_concept.lower().strip()

        # Check: Cash
        if m in ("cash", "cash_position"):
            source_cash, _ = self.engine.get_cash_position(target_date)
            mapped_cash = self.engine.calculate_balance_as_of(FinancialConcept.CASH, target_date)
            published = self.metric_service.calculate_cash_position(target_period, target_date).value or 0.0
            variance = round(abs(source_cash - mapped_cash), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-CASH-001",
                metric_or_concept="cash_position",
                period=target_period,
                source_layer_name="Commercial Bank Accounts Subledger",
                source_value=round(source_cash, 2),
                mapped_layer_name="GL 101000 + 102000 (CASH Concept)",
                mapped_value=round(mapped_cash, 2),
                calculated_input_value=round(mapped_cash, 2),
                published_value=round(published, 2),
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Cash subledger tie: source ₹{source_cash:,.2f} vs GL mapped ₹{mapped_cash:,.2f} (variance: ₹{variance:,.2f}).",
                evidence_references=["BANK-OP-01", "BANK-MM-02", "GL-101000", "GL-102000"],
            )

        # Check: Trade Accounts Receivable
        if m in ("ar", "accounts_receivable", "trade_ar"):
            ar_summary = self.engine.get_ar_summary(target_date)
            source_ar = ar_summary["total_open_ar"]
            wc_comps = self.engine.get_working_capital_components(target_date)
            mapped_trade_ar = wc_comps["trade_receivables"]
            published = self.metric_service.calculate_receivables(target_period, target_date).accounts_receivable.value or 0.0
            variance = round(abs(source_ar - mapped_trade_ar), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-AR-001",
                metric_or_concept="accounts_receivable",
                period=target_period,
                source_layer_name="Customer Subledger Open Items (BSID)",
                source_value=round(source_ar, 2),
                mapped_layer_name="GL 110000 (Trade Receivables Concept)",
                mapped_value=round(mapped_trade_ar, 2),
                calculated_input_value=round(mapped_trade_ar, 2),
                published_value=round(published, 2),
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Trade AR subledger tie: open items ₹{source_ar:,.2f} vs GL Trade AR ₹{mapped_trade_ar:,.2f}.",
                evidence_references=["BSID-SUBLEDGER", "GL-110000", "RECON-SUB-GL-01"],
            )

        # Check: Trade Accounts Payable
        if m in ("ap", "accounts_payable", "trade_ap"):
            ap_summary = self.engine.get_ap_summary(target_date)
            source_ap = ap_summary["total_open_ap"]
            wc_comps = self.engine.get_working_capital_components(target_date)
            mapped_ap = wc_comps["trade_payables"]
            published = self.metric_service.calculate_payables(target_period, target_date).accounts_payable.value or 0.0
            variance = round(abs(source_ap - mapped_ap), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-AP-001",
                metric_or_concept="accounts_payable",
                period=target_period,
                source_layer_name="Vendor Subledger Open Items (BSIK)",
                source_value=round(source_ap, 2),
                mapped_layer_name="GL 200000 (Trade Payables Concept)",
                mapped_value=round(mapped_ap, 2),
                calculated_input_value=round(mapped_ap, 2),
                published_value=round(published, 2),
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Trade AP subledger tie: open items ₹{source_ap:,.2f} vs GL Trade AP ₹{mapped_ap:,.2f}.",
                evidence_references=["BSIK-SUBLEDGER", "GL-200000"],
            )

        # Check: Inventory
        if m in ("inventory", "inventory_value"):
            wc_comps = self.engine.get_working_capital_components(target_date)
            source_inv = wc_comps["inventory"]
            mapped_inv = self.engine.calculate_balance_as_of(FinancialConcept.INVENTORY, target_date)
            published = self.metric_service.calculate_inventory(target_period, target_date).inventory_value.value or 0.0
            variance = round(abs(source_inv - mapped_inv), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-INV-001",
                metric_or_concept="inventory_value",
                period=target_period,
                source_layer_name="Perpetual Inventory Ledger",
                source_value=round(source_inv, 2),
                mapped_layer_name="GL 120000 + 121000 (INVENTORY Concept)",
                mapped_value=round(mapped_inv, 2),
                calculated_input_value=round(mapped_inv, 2),
                published_value=round(published, 2),
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Inventory subledger tie: stock balances ₹{source_inv:,.2f} vs GL Inventory ₹{mapped_inv:,.2f}.",
                evidence_references=["INV-VALUATION", "GL-120000", "GL-121000"],
            )

        # Check: Revenue
        if m in ("revenue", "sales"):
            pnl = self.engine.get_pnl_for_period(target_period)
            source_rev = pnl["revenue"]
            profit_breakdowns = self.engine.get_profitability_breakdowns(target_period)
            mapped_rev = sum(c["amount"] for c in profit_breakdowns["top_customers_by_revenue"])
            published = self.metric_service.calculate_profitability(target_period).revenue.value or 0.0
            variance = round(abs(source_rev - mapped_rev), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-REV-001",
                metric_or_concept="revenue",
                period=target_period,
                source_layer_name="Customer Billing Records",
                source_value=round(source_rev, 2),
                mapped_layer_name="GL 400000 + 410000 (REVENUE Concept)",
                mapped_value=round(mapped_rev, 2),
                calculated_input_value=round(source_rev, 2),
                published_value=round(published, 2),
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Revenue reconciliation tie: customer sales ₹{source_rev:,.2f} vs GL Revenue ₹{mapped_rev:,.2f}.",
                evidence_references=["GL-400000", "GL-410000", "RECON-CUST-REV-01"],
            )

        # Check: Gross Margin
        if m in ("gross_margin", "gross_margin_percent", "gm"):
            pnl = self.engine.get_pnl_for_period(target_period)
            rev = pnl["revenue"]
            gp = pnl["gross_profit"]
            source_margin = round((gp / rev * 100.0), 2) if rev > 0 else 0.0
            published = self.metric_service.calculate_profitability(target_period).gross_margin_percent.value or 0.0
            variance = round(abs(source_margin - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-GM-001",
                metric_or_concept="gross_margin_percent",
                period=target_period,
                source_layer_name="GL P&L Statement Arithmetic",
                source_value=source_margin,
                mapped_layer_name="Gross Profit / Revenue Formula Tie",
                mapped_value=source_margin,
                calculated_input_value=source_margin,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Gross Margin formula tie: calculated {source_margin:.2f}% vs published {published:.2f}%.",
                evidence_references=["RECON-GM-01", "GL-400000", "GL-500000"],
            )

        # Check: Cash Conversion Cycle
        if m in ("ccc", "cash_conversion_cycle"):
            wc = self.metric_service.calculate_working_capital(target_period, target_date)
            dso = self.metric_service.calculate_receivables(target_period, target_date).dso.value or 0.0
            dio = self.metric_service.calculate_inventory(target_period, target_date).dio.value or 0.0
            dpo = self.metric_service.calculate_payables(target_period, target_date).dpo.value or 0.0
            formula_ccc = round(dso + dio - dpo, 1)
            published = self.metric_service.calculate_ccc(target_period, target_date).value or 0.0
            variance = round(abs(formula_ccc - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-CCC-001",
                metric_or_concept="cash_conversion_cycle",
                period=target_period,
                source_layer_name="Subledger Cycle Ratios",
                source_value=formula_ccc,
                mapped_layer_name="DSO + DIO - DPO Formula Tie",
                mapped_value=formula_ccc,
                calculated_input_value=formula_ccc,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"CCC component tie: DSO ({dso:.1f}d) + DIO ({dio:.1f}d) - DPO ({dpo:.1f}d) = {formula_ccc:.1f} days vs published {published:.1f} days.",
                evidence_references=["RECON-CCC-01", "DSO-TIE", "DIO-TIE", "DPO-TIE"],
            )

        # Check: Current Ratio
        if m in ("current_ratio", "cr"):
            wc = self.metric_service.calculate_working_capital(target_period, target_date)
            ca = wc.current_assets.value or 0.0
            cl = wc.current_liabilities.value or 0.0
            calc_cr = round(ca / cl, 2) if cl > 0 else 0.0
            published = self.metric_service.calculate_current_ratio(target_period, target_date).value or 0.0
            variance = round(abs(calc_cr - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-CR-001",
                metric_or_concept="current_ratio",
                period=target_period,
                source_layer_name="GL Balance Sheet Arithmetic (CA / CL)",
                source_value=calc_cr,
                mapped_layer_name="Current Assets / Current Liabilities Concept Tie",
                mapped_value=calc_cr,
                calculated_input_value=calc_cr,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Current Ratio component tie: CA (₹{ca:,.2f}) / CL (₹{cl:,.2f}) = {calc_cr:.2f}x vs published {published:.2f}x.",
                evidence_references=["RECON-CA-01", "RECON-CL-02", "GL-101000", "GL-110000", "GL-200000"],
            )

        # Check: Quick Ratio
        if m in ("quick_ratio", "qr"):
            qr_res = self.metric_service.calculate_quick_ratio(target_period, target_date)
            qa = qr_res.inputs.get("quick_assets", 0.0)
            cl = qr_res.inputs.get("current_liabilities", 0.0)
            calc_qr = round(qa / cl, 2) if cl > 0 else 0.0
            published = qr_res.value or 0.0
            variance = round(abs(calc_qr - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-QR-001",
                metric_or_concept="quick_ratio",
                period=target_period,
                source_layer_name="GL Quick Assets Arithmetic ((Cash + AR + Other AR) / CL)",
                source_value=calc_qr,
                mapped_layer_name="Quick Assets / Current Liabilities Concept Tie",
                mapped_value=calc_qr,
                calculated_input_value=calc_qr,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Quick Ratio component tie: Quick Assets (₹{qa:,.2f}) / CL (₹{cl:,.2f}) = {calc_qr:.2f}x vs published {published:.2f}x.",
                evidence_references=["RECON-CA-01", "RECON-CL-02", "GL-101000", "GL-110000"],
            )

        # Check: Net Working Capital
        if m in ("nwc", "net_working_capital"):
            wc = self.metric_service.calculate_working_capital(target_period, target_date)
            ca = wc.current_assets.value or 0.0
            cl = wc.current_liabilities.value or 0.0
            calc_nwc = round(ca - cl, 2)
            published = wc.net_working_capital.value or 0.0
            variance = round(abs(calc_nwc - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-NWC-001",
                metric_or_concept="net_working_capital",
                period=target_period,
                source_layer_name="Current Assets - Current Liabilities Subledger Tie",
                source_value=calc_nwc,
                mapped_layer_name="CA minus CL Canonical Concept Difference",
                mapped_value=calc_nwc,
                calculated_input_value=calc_nwc,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Net Working Capital tie: CA (₹{ca:,.2f}) - CL (₹{cl:,.2f}) = ₹{calc_nwc:,.2f} vs published ₹{published:,.2f}.",
                evidence_references=["RECON-NWC-01", "GL-101000", "GL-110000", "GL-200000"],
            )

        # Check: DSO
        if m in ("dso", "days_sales_outstanding"):
            rec = self.metric_service.calculate_receivables(target_period, target_date)
            ar_val = rec.accounts_receivable.value or 0.0
            pnl = self.engine.get_pnl_for_period(target_period)
            rev = pnl["revenue"]
            days = self.metric_service._get_days_in_period(target_period)
            calc_dso = round((ar_val / rev) * days, 1) if rev > 0 else 0.0
            published = rec.dso.value or 0.0
            variance = round(abs(calc_dso - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-DSO-001",
                metric_or_concept="dso",
                period=target_period,
                source_layer_name="Customer Open Invoices (BSID)",
                source_value=calc_dso,
                mapped_layer_name="Trade AR / Monthly Credit Sales × Days Formula Tie",
                mapped_value=calc_dso,
                calculated_input_value=calc_dso,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"DSO component tie: (Trade AR ₹{ar_val:,.2f} / Revenue ₹{rev:,.2f}) × {days} days = {calc_dso:.1f} days vs published {published:.1f} days.",
                evidence_references=["BSID-SUBLEDGER", "GL-110000", "GL-400000"],
            )

        # Check: DIO
        if m in ("dio", "days_inventory_outstanding"):
            inv = self.metric_service.calculate_inventory(target_period, target_date)
            inv_val = inv.inventory_value.value or 0.0
            pnl = self.engine.get_pnl_for_period(target_period)
            cogs = pnl["cogs"]
            days = self.metric_service._get_days_in_period(target_period)
            calc_dio = round((inv_val / cogs) * days, 1) if cogs > 0 else 0.0
            published = inv.dio.value or 0.0
            variance = round(abs(calc_dio - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-DIO-001",
                metric_or_concept="dio",
                period=target_period,
                source_layer_name="Inventory Subledger Stock Tie",
                source_value=calc_dio,
                mapped_layer_name="Inventory / Period COGS × Days Formula Tie",
                mapped_value=calc_dio,
                calculated_input_value=calc_dio,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"DIO component tie: (Inventory ₹{inv_val:,.2f} / COGS ₹{cogs:,.2f}) × {days} days = {calc_dio:.1f} days vs published {published:.1f} days.",
                evidence_references=["INV-VALUATION", "GL-120000", "GL-500000"],
            )

        # Check: DPO
        if m in ("dpo", "days_payable_outstanding"):
            pay = self.metric_service.calculate_payables(target_period, target_date)
            ap_val = pay.accounts_payable.value or 0.0
            pnl = self.engine.get_pnl_for_period(target_period)
            cogs = pnl["cogs"]
            days = self.metric_service._get_days_in_period(target_period)
            calc_dpo = round((ap_val / cogs) * days, 1) if cogs > 0 else 0.0
            published = pay.dpo.value or 0.0
            variance = round(abs(calc_dpo - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-DPO-001",
                metric_or_concept="dpo",
                period=target_period,
                source_layer_name="Vendor Open Items (BSIK)",
                source_value=calc_dpo,
                mapped_layer_name="Trade AP / Period COGS × Days Formula Tie",
                mapped_value=calc_dpo,
                calculated_input_value=calc_dpo,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"DPO component tie: (Trade AP ₹{ap_val:,.2f} / COGS ₹{cogs:,.2f}) × {days} days = {calc_dpo:.1f} days vs published {published:.1f} days.",
                evidence_references=["BSIK-SUBLEDGER", "GL-200000", "GL-500000"],
            )

        # Check: Debt to Equity
        if m in ("debt_to_equity", "de"):
            de_res = self.metric_service.calculate_debt_to_equity(target_period, target_date)
            td = de_res.inputs.get("total_debt", 0.0)
            eq = de_res.inputs.get("equity", 0.0)
            calc_de = round(td / eq, 2) if eq > 0 else 0.0
            published = de_res.value or 0.0
            variance = round(abs(calc_de - published), 2)
            status = ReconciliationStatus.RECONCILED if variance <= tolerance else ReconciliationStatus.FAILED
            return MultiLayerReconciliationTie(
                tie_id="TIE-DE-001",
                metric_or_concept="debt_to_equity",
                period=target_period,
                source_layer_name="Total Debt / Total Equity Arithmetic",
                source_value=calc_de,
                mapped_layer_name="Debt to Equity Concept Tie",
                mapped_value=calc_de,
                calculated_input_value=calc_de,
                published_value=published,
                variance=variance,
                tolerance=tolerance,
                status=status,
                explanation=f"Debt-to-Equity tie: Total Debt (₹{td:,.2f}) / Equity (₹{eq:,.2f}) = {calc_de:.2f}x vs published {published:.2f}x.",
                evidence_references=["GL-220000", "GL-250000", "GL-300000", "GL-310000"],
            )

        return None

    def audit_all_reconciliation_ties(
        self,
        period: Optional[str] = None,
        custom_tolerance: Optional[float] = None,
    ) -> List[MultiLayerReconciliationTie]:
        """Runs all multi-layer reconciliation checks across core financial metrics."""
        tracked = [
            "cash_position",
            "accounts_receivable",
            "accounts_payable",
            "inventory_value",
            "revenue",
            "gross_margin_percent",
            "cash_conversion_cycle",
        ]
        ties: List[MultiLayerReconciliationTie] = []
        for name in tracked:
            tie = self.get_reconciliation_tie(name, period, custom_tolerance)
            if tie:
                ties.append(tie)
        return ties

    # -------------------------------------------------------------------------
    # 4. END-TO-END METRIC LINEAGE DRILL-DOWN (Steps 12 & 13)
    # -------------------------------------------------------------------------

    def get_metric_lineage(
        self,
        metric_name: str,
        period: Optional[str] = None,
    ) -> MetricLineageResponse:
        """Constructs an auditable lineage trace proving where a financial metric originated."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = self.metric_service._get_period_end_date(target_period)
        defn = get_governed_metric_definition(metric_name) or GovernedMetricDefinition(
            metric_id="METRIC-CUSTOM",
            metric_name=metric_name,
            display_name=metric_name.replace("_", " ").title(),
            description="Operational financial metric",
            formula="Direct calculation",
            formula_human="Calculated from ledger",
            input_concepts=[],
            financial_statement_category=AccountCategory.ASSET,
            unit=MetricUnit.CURRENCY,
            period_type=PeriodType.FLOW,
        )

        pub_metric = self.get_published_metric(defn.metric_name, target_period)
        recon_tie = self.get_reconciliation_tie(defn.metric_name, target_period)

        # 1. Resolve inputs
        input_traces: List[MetricInputTrace] = []
        pnl = self.engine.get_pnl_for_period(target_period)
        wc = self.engine.get_working_capital_components(target_date)

        for concept in defn.input_concepts:
            matching_maps = [m for m in self.get_account_mappings() if m.financial_concept == concept]
            src_accounts = [m.gl_account for m in matching_maps]

            # Count journal lines
            line_count = sum(1 for je in self.engine.journal_entries if je.gl_account in src_accounts)

            # Resolve concept value
            if concept == FinancialConcept.REVENUE:
                val = pnl["revenue"]
            elif concept == FinancialConcept.COGS:
                val = pnl["cogs"]
            elif concept == FinancialConcept.CASH:
                val = wc["cash"]
            elif concept == FinancialConcept.AR:
                val = wc["trade_receivables"]
            elif concept == FinancialConcept.AP:
                val = wc["trade_payables"]
            elif concept == FinancialConcept.INVENTORY:
                val = wc["inventory"]
            elif concept == FinancialConcept.OTHER_RECEIVABLES:
                val = wc["other_receivables"]
            elif concept == FinancialConcept.OTHER_PAYABLES:
                val = wc["other_payables"]
            else:
                val = self.engine.calculate_balance_as_of(concept, target_date)

            input_traces.append(
                MetricInputTrace(
                    concept=concept.value,
                    display_name=concept.value.replace("_", " ").title(),
                    value=round(val, 2) if val is not None else None,
                    formatted_value=f"₹{val:,.2f}" if val is not None else "N/A",
                    source_accounts=src_accounts,
                    source_records_count=line_count,
                )
            )

        # 2. Mapped accounts used by this metric
        relevant_mappings = [
            m for m in self.get_account_mappings()
            if m.financial_concept in defn.input_concepts
        ]

        # 3. Evidence trail
        evidence_trail: List[EvidenceItem] = []
        if defn.metric_name in ("gross_margin_percent", "revenue", "gross_profit", "cogs"):
            for prd in self.engine.products.values():
                evidence_trail.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.PRODUCT_RECORD.value,
                        source_id=prd.product_id,
                        entity=prd.product_name,
                        metric=defn.metric_name,
                        period=target_period,
                        description=f"Product SKU {prd.product_id} in {prd.product_group} profit center {prd.profit_center}",
                    )
                )
        elif defn.metric_name in ("accounts_receivable", "overdue_ar", "dso"):
            ar_summary = self.engine.get_ar_summary(target_date)
            for c in ar_summary["top_overdue_customers"]:
                evidence_trail.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.AR_OPEN_ITEM.value,
                        source_id=c["entity_id"],
                        entity=c["entity_name"],
                        value=c["amount"],
                        metric="overdue_ar",
                        period=target_period,
                        description=f"Overdue customer exposure for {c['entity_name']} totaling ₹{c['amount']:,.2f}",
                    )
                )
        elif defn.metric_name in ("cash_position", "cash"):
            _, bank_accounts = self.engine.get_cash_position(target_date)
            for b in bank_accounts:
                acc_id = b.get("gl_account") or b.get("account_id") or "GL-101000"
                acc_name = b.get("account_name") or b.get("bank_name") or "Commercial Bank Account"
                bal = float(b.get("balance", 0.0))
                evidence_trail.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.JOURNAL_ENTRY.value,
                        source_id=acc_id,
                        entity=acc_name,
                        value=bal,
                        metric="cash_position",
                        period=target_period,
                        description=f"Bank statement tie for {acc_name}: ₹{bal:,.2f}",
                    )
                )

        # 4. Provenance step list
        provenance = [
            f"1. Source: Ingested source ledger lines from {self.engine.company.company_name} ({self.engine.company.currency})",
            f"2. Normalize: Standardized journal postings into canonical Debit/Credit lines",
            f"3. Map: Mapped {len(relevant_mappings)} GL accounts into canonical concepts {[c.value for c in defn.input_concepts]}",
            f"4. Define: Governed formula '{defn.formula}' (version {defn.version})",
            f"5. Calculate: Deterministic execution yielded {pub_metric.formatted_value}",
            f"6. Reconcile: {recon_tie.explanation if recon_tie else 'Mathematical identity verified'}",
            f"7. Publish: Release approved with status {pub_metric.publication_status.value}",
        ]

        badge_label = "Reconciled" if pub_metric.publication_status == PublicationStatus.PUBLISHED else "Review Required"

        return MetricLineageResponse(
            metric_name=defn.metric_name,
            display_name=defn.display_name,
            period=target_period,
            published_value=pub_metric.value,
            formatted_value=pub_metric.formatted_value,
            unit=defn.unit,
            publication_status=pub_metric.publication_status,
            publication_badge=badge_label,
            governed_definition=defn,
            calculation_state=pub_metric.calculation_state,
            formula_audit=f"{defn.formula} | Denominator rule: {defn.denominator_rules}",
            inputs=input_traces,
            mapped_accounts=relevant_mappings,
            reconciliation_tie=recon_tie,
            evidence_trail=evidence_trail,
            provenance_chain=provenance,
        )

    # -------------------------------------------------------------------------
    # 5. DATA TRUST SUMMARY (Step 14)
    # -------------------------------------------------------------------------

    def get_data_trust_summary(self, period: Optional[str] = None) -> DataTrustSummaryResponse:
        """Assembles executive and controller-grade data trust posture for header badge and drawer."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = self.metric_service._get_period_end_date(target_period)

        # Mappings audit
        mappings = self.get_account_mappings()
        mapped_count = sum(1 for m in mappings if m.mapping_status == MappingStatus.MAPPED)
        unmapped_count = sum(1 for m in mappings if m.mapping_status == MappingStatus.UNMAPPED)
        ambiguous_count = sum(1 for m in mappings if m.mapping_status == MappingStatus.AMBIGUOUS)
        total_accounts = len(mappings)
        cov_pct = round((mapped_count / total_accounts * 100.0), 1) if total_accounts > 0 else 0.0

        # Reconciliation ties audit
        ties = self.audit_all_reconciliation_ties(target_period)
        reconciled_count = sum(1 for t in ties if t.status == ReconciliationStatus.RECONCILED)
        failed_count = sum(1 for t in ties if t.status in (ReconciliationStatus.FAILED, ReconciliationStatus.REVIEW_REQUIRED))

        # Generate exceptions
        exceptions: List[ReconciliationException] = []
        for t in ties:
            if t.status in (ReconciliationStatus.FAILED, ReconciliationStatus.REVIEW_REQUIRED):
                exceptions.append(
                    ReconciliationException(
                        exception_id=f"EXC-{t.tie_id}",
                        tie_id=t.tie_id,
                        metric_or_concept=t.metric_or_concept,
                        period=target_period,
                        discrepancy_amount=t.variance,
                        tolerance=t.tolerance,
                        severity="CRITICAL" if t.status == ReconciliationStatus.FAILED else "WARNING",
                        what_differs=f"{t.source_layer_name} (₹{t.source_value:,.2f}) differs from {t.mapped_layer_name} (₹{t.mapped_value:,.2f}) by ₹{t.variance:,.2f}.",
                        why_it_differs="Subledger posting discrepancy or unmapped transaction lines",
                        downstream_impacts=self._resolve_downstream_metrics_from_name(t.metric_or_concept),
                    )
                )

        # If there are unmapped accounts, add a mapping exception
        if unmapped_count > 0:
            unmapped_list = [m.gl_account for m in mappings if m.mapping_status == MappingStatus.UNMAPPED]
            exceptions.append(
                ReconciliationException(
                    exception_id="EXC-MAPPING-001",
                    tie_id="TIE-MAPPING",
                    metric_or_concept="chart_of_accounts",
                    period=target_period,
                    discrepancy_amount=float(unmapped_count),
                    tolerance=0.0,
                    severity="WARNING",
                    what_differs=f"{unmapped_count} general ledger account(s) ({', '.join(unmapped_list)}) lack canonical mapping.",
                    why_it_differs="New GL account introduced without governance approval in mapping dictionary",
                    downstream_impacts=["Financial Statement Completeness", "Net Working Capital"],
                )
            )

        # Published metrics summary
        catalog = get_governed_metric_catalog()
        pub_count = len(catalog) if failed_count == 0 and unmapped_count == 0 else max(0, len(catalog) - failed_count)
        warn_count = failed_count if failed_count > 0 else (1 if unmapped_count > 0 else 0)

        # Overall Trust Status
        if failed_count > 0 or unmapped_count > 0:
            overall_status = "REVIEW_REQUIRED"
            badge_label = "Review Required"
        else:
            overall_status = "RECONCILED"
            badge_label = "Financial Data Reconciled"

        total_records = len(self.engine.journal_entries) + len(self.engine.ar_items) + len(self.engine.ap_items)

        return DataTrustSummaryResponse(
            period=target_period,
            reference_date=target_date.isoformat(),
            source_system="Mock Financial ERP Adapter (SAP-Ready)",
            last_refresh_timestamp=datetime.now(timezone.utc).isoformat(),
            records_processed=total_records,
            data_quality_status="HEALTHY" if unmapped_count == 0 else "DEGRADED",
            overall_trust_status=overall_status,
            trust_badge_label=badge_label,
            total_accounts=total_accounts,
            mapped_accounts_count=mapped_count,
            unmapped_accounts_count=unmapped_count,
            ambiguous_accounts_count=ambiguous_count,
            mapping_coverage_pct=cov_pct,
            total_reconciliation_checks=len(ties),
            reconciled_checks_count=reconciled_count,
            failed_checks_count=failed_count,
            active_exceptions_count=len(exceptions),
            exceptions=exceptions,
            published_metrics_count=pub_count,
            published_with_warning_count=warn_count,
            held_for_review_count=failed_count,
        )

    def _resolve_downstream_metrics_from_name(self, metric_or_concept: str) -> List[str]:
        """Returns downstream metric names impacted by a concept or metric variance."""
        m = metric_or_concept.lower()
        if "ar" in m or "receivable" in m:
            return ["Days Sales Outstanding (DSO)", "Net Working Capital (NWC)", "Cash Conversion Cycle (CCC)"]
        if "ap" in m or "payable" in m:
            return ["Days Payables Outstanding (DPO)", "Net Working Capital (NWC)", "Cash Conversion Cycle (CCC)"]
        if "inv" in m:
            return ["Days Inventory Outstanding (DIO)", "Net Working Capital (NWC)", "Cash Conversion Cycle (CCC)"]
        if "cash" in m:
            return ["Net Working Capital (NWC)", "Liquidity Coverage Ratio (LCR)", "Cash Runway"]
        if "revenue" in m:
            return ["Gross Margin %", "Gross Profit", "DSO"]
        return ["Executive Financial Summary"]
