"""Financial Attention Service for FinSight.

Layer 2 Core: Transforms intelligence findings into prioritized, structured Attention Items
ranked by an explainable, deterministic scoring mechanism.
"""

from datetime import date
from typing import Any, Dict, List, Optional, Tuple

from finsight.models.attention import (
    AttentionItem,
    AttentionSeverity,
    AttentionStatus,
    AttentionSummary,
    AttentionType,
)
from finsight.models.canonical import FinancialConcept
from finsight.models.evidence import EvidenceItem, EvidenceSourceType
from finsight.models.intelligence import PeriodChange
from finsight.services.financial_engine import FinancialEngine
from finsight.services.financial_intelligence_service import FinancialIntelligenceService
from finsight.services.metric_service import MetricService
from finsight.config import format_currency, settings


class FinancialAttentionService:
    """Evaluates and ranks prioritized financial attention items."""

    def __init__(
        self,
        engine: FinancialEngine,
        metric_service: MetricService,
        intelligence_service: FinancialIntelligenceService,
    ):
        self.engine = engine
        self.metric_service = metric_service
        self.intelligence_service = intelligence_service

    def get_attention_summary(
        self,
        period: Optional[str] = None,
        severity_filter: Optional[str] = None,
        type_filter: Optional[str] = None,
        status_filter: Optional[str] = None,
    ) -> AttentionSummary:
        """Generates ranked portfolio of financial attention items with optional filtering."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        items = self._evaluate_attention_items(target_period)

        # Apply optional filters
        if severity_filter:
            items = [it for it in items if it.severity.value.upper() == severity_filter.upper()]
        if type_filter:
            items = [it for it in items if it.type.value.upper() == type_filter.upper()]
        if status_filter:
            items = [it for it in items if it.status.value.upper() == status_filter.upper()]

        # Compute summary metrics
        counts_by_severity: Dict[str, int] = {}
        counts_by_type: Dict[str, int] = {}
        total_exposure = 0.0

        for it in items:
            s_val = it.severity.value
            counts_by_severity[s_val] = counts_by_severity.get(s_val, 0) + 1

            t_val = it.type.value
            counts_by_type[t_val] = counts_by_type.get(t_val, 0) + 1

            total_exposure += it.financial_impact

        return AttentionSummary(
            period=target_period,
            total_items=len(items),
            counts_by_severity=counts_by_severity,
            counts_by_type=counts_by_type,
            total_financial_exposure=round(total_exposure, 2),
            items=items,
        )

    def _evaluate_attention_items(self, target_period: str) -> List[AttentionItem]:
        """Runs deterministic evaluation rules across intelligence and metric signals."""
        items: List[AttentionItem] = []
        ref_date = self.metric_service._get_period_end_date(target_period)
        prev_period = self.metric_service._get_previous_period(target_period)

        # 1. CASH_PRESSURE
        cash_res = self.metric_service.calculate_cash_position(period=target_period)
        ap_res = self.metric_service.calculate_payables(period=target_period)
        cash_val = cash_res.value or 0.0
        ap_7d = ap_res.upcoming_payables_7d.value or 0.0
        cash_change = cash_res.comparison.absolute_change if cash_res.comparison else 0.0

        if ap_7d > (cash_val * 0.8) or (cash_val < 1000000.0 and cash_change < -200000.0):
            cov_ratio = (cash_val / ap_7d) if ap_7d > 0 else 999.0
            evidence = []
            for v in ap_res.top_vendors_due[:2]:
                evidence.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.VENDOR_RECORD.value,
                        source_id=v.entity_id,
                        entity=v.entity_name,
                        metric="upcoming_payables_7d",
                        value=v.amount,
                        period=target_period,
                        description=f"Obligation to {v.entity_name} due in next 7 days (₹{v.amount:,.2f})",
                    )
                )

            priority_reason = (
                f"Critical priority: Cash position (₹{cash_val:,.0f}) is insufficient to cover 7-day upcoming "
                f"payables of ₹{ap_7d:,.0f} (coverage ratio {cov_ratio:.2f}x). Cash depleted by ₹{abs(cash_change):,.0f} this period."
            )

            score, sev = self._calculate_ranking_score(
                base_severity=AttentionSeverity.CRITICAL,
                financial_impact=ap_7d,
                has_concentration=True,
                is_persistent=True,
            )

            items.append(
                AttentionItem(
                    id=f"ATTN-CASH-{target_period.replace('-', '')}-01",
                    type=AttentionType.CASH_PRESSURE,
                    title="Liquidity & Cash Runway Pressure",
                    severity=sev,
                    priority_score=score,
                    priority_reason=priority_reason,
                    financial_impact=round(ap_7d, 2),
                    change={"cash_delta": cash_change, "coverage_ratio": round(cov_ratio, 2)},
                    summary=(
                        f"Acute cash buffer compression: liquid cash reserves of ₹{cash_val:,.0f} face imminent "
                        f"payables of ₹{ap_7d:,.0f} maturing within 7 days. AR collection delays and inventory "
                        f"buildup have trapped operational liquidity."
                    ),
                    drivers=[
                        f"₹{ap_7d:,.0f} vendor obligations due in 7 days",
                        f"Cash declined by ₹{abs(cash_change):,.0f} (-34.7%)",
                        "Capital trapped in overdue customer receivables",
                    ],
                    entities=[v.model_dump() for v in ap_res.top_vendors_due[:3]],
                    evidence=evidence,
                    period=target_period,
                    status=AttentionStatus.OPEN,
                    metric="cash_position",
                    recommended_question="Why did cash decrease?",
                )
            )

        # 2. AR_DETERIORATION & CUSTOMER_PAYMENT_DETERIORATION
        ar_summary = self.engine.get_ar_summary(ref_date)
        total_open_ar = ar_summary["total_open_ar"]
        total_overdue = ar_summary["total_overdue_ar"]
        top_od = ar_summary["top_overdue_customers"]
        dso_res = self.metric_service.get_metric_by_name("dso", target_period)
        dso_val = dso_res.value or 0.0

        if total_overdue > 300000.0 or ar_summary["overdue_percentage"] > 25.0:
            top_cust = top_od[0] if top_od else None
            top_cust_name = top_cust["entity_name"] if top_cust else "Top Customer"
            top_cust_od = top_cust["amount"] if top_cust else 0.0
            top_cust_share = top_cust["percentage_of_total"] if top_cust else 0.0

            evidence = []
            for ar in self.engine.ar_items:
                if top_cust and ar.customer_id == top_cust["entity_id"] and ar.is_open and ar.days_overdue(ref_date) > 0:
                    evidence.append(
                        EvidenceItem(
                            source_type=EvidenceSourceType.AR_OPEN_ITEM.value,
                            source_id=ar.invoice_id,
                            entity=top_cust_name,
                            metric="overdue_ar",
                            value=ar.open_amount,
                            period=target_period,
                            description=f"Invoice {ar.invoice_id} overdue by {ar.days_overdue(ref_date)} days (₹{ar.open_amount:,.2f})",
                            metadata={"due_date": ar.due_date.isoformat()},
                        )
                    )

            priority_reason = (
                f"High priority because ₹{total_overdue:,.0f} of AR is overdue ({ar_summary['overdue_percentage']:.1f}% of total AR), "
                f"{top_cust_share:.1f}% is concentrated in {top_cust_name}, and DSO has reached {dso_val:.1f} days."
            )

            score, sev = self._calculate_ranking_score(
                base_severity=AttentionSeverity.HIGH,
                financial_impact=total_overdue,
                has_concentration=top_cust_share >= 60.0,
                has_aged_items=True,
                is_persistent=True,
            )

            items.append(
                AttentionItem(
                    id=f"ATTN-AR-{target_period.replace('-', '')}-01",
                    type=AttentionType.AR_DETERIORATION,
                    title="Receivables Aging Deterioration",
                    severity=sev,
                    priority_score=score,
                    priority_reason=priority_reason,
                    financial_impact=round(total_overdue, 2),
                    change={"overdue_ar": total_overdue, "dso": dso_val},
                    summary=(
                        f"Accounts receivable aging has severely deteriorated: ₹{total_overdue:,.0f} is overdue, "
                        f"driven primarily by {top_cust_name} which accounts for ₹{top_cust_od:,.0f} ({top_cust_share:.1f}% of overdue exposure)."
                    ),
                    drivers=[
                        f"₹{total_overdue:,.0f} overdue balance",
                        f"{top_cust_share:.1f}% concentration in {top_cust_name}",
                        f"DSO elevated at {dso_val:.1f} days",
                    ],
                    entities=top_od[:3],
                    evidence=evidence[:4],
                    period=target_period,
                    status=AttentionStatus.OPEN,
                    metric="dso",
                    recommended_question="Which customers are driving overdue AR?",
                )
            )

        # 3. CUSTOMER_PAYMENT_DETERIORATION (Specific to Apex Retail Group CUST-101)
        cust_intelligence = self.intelligence_service.analyze_customers(target_period)
        apex_profile = next((c for c in cust_intelligence if c.customer_id == "CUST-101"), None)
        if apex_profile and apex_profile.overdue_ar > 300000.0:
            priority_reason = (
                f"High priority: Apex Retail Group holds ₹{apex_profile.overdue_ar:,.0f} in overdue invoices "
                f"({apex_profile.overdue_pct:.1f}% of its balance) spanning multiple aging intervals beyond 60 days."
            )
            score, sev = self._calculate_ranking_score(
                base_severity=AttentionSeverity.HIGH,
                financial_impact=apex_profile.overdue_ar,
                has_concentration=True,
                has_aged_items=True,
                is_persistent=True,
            )

            items.append(
                AttentionItem(
                    id=f"ATTN-CUST-{target_period.replace('-', '')}-01",
                    type=AttentionType.CUSTOMER_PAYMENT_DETERIORATION,
                    title=f"Chronic Payment Delay: {apex_profile.customer_name}",
                    severity=sev,
                    priority_score=score,
                    priority_reason=priority_reason,
                    financial_impact=round(apex_profile.overdue_ar, 2),
                    change={"overdue_pct": apex_profile.overdue_pct, "open_ar": apex_profile.open_ar},
                    summary=(
                        f"{apex_profile.customer_name} is our top revenue contributor (₹{apex_profile.revenue:,.0f}) but "
                        f"exhibits severe collection delinquency with ₹{apex_profile.overdue_ar:,.0f} past terms."
                    ),
                    drivers=[
                        f"₹{apex_profile.overdue_ar:,.0f} overdue invoices",
                        "Invoices aged past 60 and 90 days",
                        f"DSO estimate exceeds {apex_profile.dso_estimate or 0:.0f} days",
                    ],
                    entities=[{"customer_id": apex_profile.customer_id, "customer_name": apex_profile.customer_name}],
                    evidence=apex_profile.evidence[:3],
                    period=target_period,
                    status=AttentionStatus.OPEN,
                    metric="overdue_ar",
                    recommended_question="Why is Apex overdue and what should finance do according to policy?",
                )
            )

        # 4. INVENTORY_BUILDUP
        inv_detail = self.metric_service.calculate_inventory(target_period)
        inv_growth = inv_detail.inventory_growth_rate or 0.0
        sales_growth = inv_detail.sales_growth_rate or 0.0
        dio_val = inv_detail.dio.value or 0.0
        inv_val = inv_detail.inventory_value.value or 0.0

        if inv_growth > sales_growth and dio_val > 40.0:
            priority_reason = (
                f"High priority: Inventory reached ₹{inv_val:,.0f} (DIO: {dio_val:.1f} days). "
                f"Inventory grew by {inv_growth:.1f}% while sales grew by only {sales_growth:.1f}%."
            )
            score, sev = self._calculate_ranking_score(
                base_severity=AttentionSeverity.HIGH,
                financial_impact=inv_val,
                has_concentration=False,
                is_persistent=True,
            )

            items.append(
                AttentionItem(
                    id=f"ATTN-INV-{target_period.replace('-', '')}-01",
                    type=AttentionType.INVENTORY_BUILDUP,
                    title="Inventory Buildup & Working Capital Drag",
                    severity=sev,
                    priority_score=score,
                    priority_reason=priority_reason,
                    financial_impact=round(inv_val, 2),
                    change={"inventory_growth_rate": inv_growth, "sales_growth_rate": sales_growth, "dio": dio_val},
                    summary=(
                        f"Inventory balance expanded to ₹{inv_val:,.0f}, decoupling from underlying revenue growth. "
                        f"Days Inventory Outstanding (DIO) rose to {dio_val:.1f} days, locking up operating cash."
                    ),
                    drivers=[
                        f"Inventory growth ({inv_growth:.1f}%) decoupled from sales ({sales_growth:.1f}%)",
                        f"DIO stretched to {dio_val:.1f} days",
                        "Procurement inflows exceeding monthly absorption",
                    ],
                    entities=[{"department": "Supply Chain / Procurement"}],
                    evidence=[],
                    period=target_period,
                    status=AttentionStatus.OPEN,
                    metric="inventory_value",
                    recommended_question="Why is inventory increasing?",
                )
            )

        # 5. MARGIN_COMPRESSION
        pnl = self.metric_service.calculate_profitability(target_period)
        gm_pct = pnl.gross_margin_percent.value or 0.0
        comp = pnl.gross_margin_percent.comparison
        margin_change = comp.absolute_change if comp else 0.0

        if margin_change < -2.0 or (pnl.revenue.value and pnl.cogs.value and (pnl.cogs.value / pnl.revenue.value > 0.65)):
            cogs_val = pnl.cogs.value or 0.0
            rev_val = pnl.revenue.value or 0.0
            priority_reason = (
                f"High priority: Gross margin compressed by {abs(margin_change):.1f} percentage points "
                f"from {comp.previous_value if comp else 0.0:.1f}% to {gm_pct:.1f}% due to COGS growth outpacing sales."
            )
            score, sev = self._calculate_ranking_score(
                base_severity=AttentionSeverity.HIGH,
                financial_impact=cogs_val,
                has_concentration=False,
                is_persistent=True,
            )

            items.append(
                AttentionItem(
                    id=f"ATTN-MARGIN-{target_period.replace('-', '')}-01",
                    type=AttentionType.MARGIN_COMPRESSION,
                    title="Gross Margin Compression",
                    severity=sev,
                    priority_score=score,
                    priority_reason=priority_reason,
                    financial_impact=round(cogs_val, 2),
                    change={"gross_margin_change_pp": margin_change, "gross_margin_pct": gm_pct},
                    summary=(
                        f"Gross margin declined to {gm_pct:.1f}%. While top-line revenue expanded to ₹{rev_val:,.0f}, "
                        f"COGS inflation eroded gross profitability."
                    ),
                    drivers=[
                        f"Gross margin fell by {abs(margin_change):.1f} percentage points",
                        "COGS cost growth outpaced revenue gains",
                        "Commodity product group margin contraction",
                    ],
                    entities=[{"metric": "COGS", "amount": cogs_val}],
                    evidence=[],
                    period=target_period,
                    status=AttentionStatus.OPEN,
                    metric="gross_margin_percent",
                    recommended_question="Where did gross margin decline?",
                )
            )

        # 6. HIGH_REVENUE_LOW_MARGIN (OmniChannel Logistics CUST-104)
        omni = next((c for c in cust_intelligence if c.customer_id == "CUST-104"), None)
        if omni and omni.revenue > 150000.0 and omni.gross_margin_pct < 20.0:
            priority_reason = (
                f"Medium priority: OmniChannel Logistics generates high revenue (₹{omni.revenue:,.0f}) "
                f"but operates at an uncharacteristically thin gross margin of {omni.gross_margin_pct:.1f}%."
            )
            score, sev = self._calculate_ranking_score(
                base_severity=AttentionSeverity.MEDIUM,
                financial_impact=omni.revenue,
                has_concentration=False,
                is_persistent=False,
            )

            items.append(
                AttentionItem(
                    id=f"ATTN-PROFIT-{target_period.replace('-', '')}-01",
                    type=AttentionType.HIGH_REVENUE_LOW_MARGIN,
                    title=f"Low Margin Drag: {omni.customer_name}",
                    severity=sev,
                    priority_score=score,
                    priority_reason=priority_reason,
                    financial_impact=round(omni.revenue, 2),
                    change={"gross_margin_pct": omni.gross_margin_pct, "revenue": omni.revenue},
                    summary=(
                        f"{omni.customer_name} constitutes substantial volume (₹{omni.revenue:,.0f}) but generates "
                        f"only ₹{omni.gross_profit:,.0f} gross profit ({omni.gross_margin_pct:.1f}% margin), diluting portfolio returns."
                    ),
                    drivers=[
                        f"Thin margin of {omni.gross_margin_pct:.1f}%",
                        f"Substantial revenue volume of ₹{omni.revenue:,.0f}",
                        "Pricing or product mix discount pressure",
                    ],
                    entities=[{"customer_id": omni.customer_id, "customer_name": omni.customer_name}],
                    evidence=[],
                    period=target_period,
                    status=AttentionStatus.OPEN,
                    metric="gross_margin_percent",
                    recommended_question="Which customers have high revenue but poor payment behaviour?",
                )
            )

        # 7. AP_PRESSURE (Vendor Concentration)
        if ap_res.top_vendors_due:
            top_v = ap_res.top_vendors_due[0]
            if top_v.amount > 300000.0:
                priority_reason = (
                    f"High priority: ₹{top_v.amount:,.0f} ({top_v.percentage_of_total:.1f}% of upcoming payables) "
                    f"is due to single vendor {top_v.entity_name} within 7 days."
                )
                score, sev = self._calculate_ranking_score(
                    base_severity=AttentionSeverity.HIGH,
                    financial_impact=top_v.amount,
                    has_concentration=top_v.percentage_of_total >= 50.0,
                    is_persistent=False,
                )

                items.append(
                    AttentionItem(
                        id=f"ATTN-AP-{target_period.replace('-', '')}-01",
                        type=AttentionType.AP_PRESSURE,
                        title=f"Concentrated Vendor Payables: {top_v.entity_name}",
                        severity=sev,
                        priority_score=score,
                        priority_reason=priority_reason,
                        financial_impact=round(top_v.amount, 2),
                        change={"upcoming_7d": top_v.amount, "vendor_share_pct": top_v.percentage_of_total},
                        summary=(
                            f"Significant short-term cash outflow required: ₹{top_v.amount:,.0f} due to {top_v.entity_name} "
                            f"in next 7 days."
                        ),
                        drivers=[
                            f"₹{top_v.amount:,.0f} due to {top_v.entity_name}",
                            f"{top_v.percentage_of_total:.1f}% of total upcoming payables",
                        ],
                        entities=[top_v.model_dump()],
                        evidence=[],
                        period=target_period,
                        status=AttentionStatus.OPEN,
                        metric="upcoming_payables_7d",
                        recommended_question="What payments are due in the next 7 days?",
                    )
                )

        # Sort items deterministically by priority score descending
        items.sort(key=lambda it: it.priority_score, reverse=True)
        return items

    def _calculate_ranking_score(
        self,
        base_severity: AttentionSeverity,
        financial_impact: float,
        has_concentration: bool = False,
        has_aged_items: bool = False,
        is_persistent: bool = False,
    ) -> Tuple[float, AttentionSeverity]:
        """Calculates deterministic explainable priority score (0-100)."""
        # Base severity component (0-40)
        sev_weights = {
            AttentionSeverity.CRITICAL: 40.0,
            AttentionSeverity.HIGH: 30.0,
            AttentionSeverity.MEDIUM: 20.0,
            AttentionSeverity.LOW: 10.0,
        }
        score = sev_weights.get(base_severity, 20.0)

        # Financial impact component (0-30): scaled up to $1M
        impact_score = min(30.0, (financial_impact / 1000000.0) * 30.0)
        score += impact_score

        # Concentration & aging multipliers (0-20)
        if has_concentration:
            score += 10.0
        if has_aged_items:
            score += 10.0

        # Persistence bonus (0-10)
        if is_persistent:
            score += 10.0

        score = round(min(100.0, score), 1)

        # Calibrate severity according to composite score
        if score >= 85.0:
            final_sev = AttentionSeverity.CRITICAL
        elif score >= 65.0:
            final_sev = AttentionSeverity.HIGH
        elif score >= 40.0:
            final_sev = AttentionSeverity.MEDIUM
        else:
            final_sev = AttentionSeverity.LOW

        return score, final_sev
