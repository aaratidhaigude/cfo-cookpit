"""Financial Intelligence Service for FinSight.

Layer 1 Core: Analyzes deterministic financial engine outputs to detect:
1. Period changes with explainable materiality
2. Multi-period historical trend patterns
3. Lightweight deterministic statistical anomalies
4. Explainable metric driver decompositions
5. Customer-level 360-degree financial intelligence
6. Product and product-group profitability intelligence
"""

import math
from datetime import date
from typing import Any, Dict, List, Optional, Tuple

from finsight.models.canonical import FinancialConcept
from finsight.models.evidence import EvidenceItem, EvidenceSourceType
from finsight.models.intelligence import (
    AnomalyFinding,
    AnomalySeverity,
    AssociationType,
    CandidateDriver,
    CustomerIntelligence,
    DriverAnalysisResult,
    FinancialIntelligenceReport,
    MetricTrend,
    PeriodChange,
    ProductIntelligence,
    TrendPattern,
)
from finsight.models.metrics import MetricResult, MetricUnit, TrendDirection
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


class FinancialIntelligenceService:
    """Reusable intelligence service operating strictly on deterministic financial metrics."""

    def __init__(self, engine: FinancialEngine, metric_service: MetricService):
        self.engine = engine
        self.metric_service = metric_service

    # -------------------------------------------------------------------------
    # Period Change & Materiality Engine
    # -------------------------------------------------------------------------

    def detect_period_changes(self, period: Optional[str] = None) -> List[PeriodChange]:
        """Compares current period vs prior period across all core financial metrics."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        prev_period = self.metric_service._get_previous_period(target_period)
        if not prev_period:
            return []

        tracked_metrics = [
            ("revenue", "Revenue", MetricUnit.CURRENCY),
            ("cogs", "Cost of Goods Sold (COGS)", MetricUnit.CURRENCY),
            ("gross_profit", "Gross Profit", MetricUnit.CURRENCY),
            ("gross_margin_percent", "Gross Margin %", MetricUnit.PERCENTAGE),
            ("cash_position", "Cash Balance", MetricUnit.CURRENCY),
            ("accounts_receivable", "Accounts Receivable", MetricUnit.CURRENCY),
            ("overdue_ar", "Overdue AR", MetricUnit.CURRENCY),
            ("accounts_payable", "Accounts Payable", MetricUnit.CURRENCY),
            ("upcoming_payables_7d", "Upcoming Payables (7-Day)", MetricUnit.CURRENCY),
            ("inventory_value", "Inventory Balance", MetricUnit.CURRENCY),
            ("dso", "Days Sales Outstanding (DSO)", MetricUnit.DAYS),
            ("dpo", "Days Payables Outstanding (DPO)", MetricUnit.DAYS),
            ("dio", "Days Inventory Outstanding (DIO)", MetricUnit.DAYS),
            ("net_working_capital", "Net Working Capital", MetricUnit.CURRENCY),
        ]

        results: List[PeriodChange] = []

        for m_name, display_name, unit in tracked_metrics:
            curr_res = self.metric_service.get_metric_by_name(m_name, target_period)
            prev_res = self.metric_service.get_metric_by_name(m_name, prev_period)

            curr_val = curr_res.value
            prev_val = prev_res.value

            if curr_val is None or prev_val is None:
                continue

            abs_change = round(curr_val - prev_val, 2)
            pct_change = round(((curr_val - prev_val) / abs(prev_val) * 100.0), 2) if abs(prev_val) > 1e-6 else None

            if abs(abs_change) < 1e-4:
                direction = TrendDirection.FLAT
            elif abs_change > 0:
                direction = TrendDirection.INCREASING
            else:
                direction = TrendDirection.DECREASING

            is_material, reason = self._evaluate_materiality(
                metric_name=m_name,
                curr_val=curr_val,
                prev_val=prev_val,
                abs_change=abs_change,
                pct_change=pct_change,
                unit=unit,
            )

            # Generate concise explainable finding text
            explanation = self._format_change_explanation(
                display_name=display_name,
                abs_change=abs_change,
                pct_change=pct_change,
                unit=unit,
                curr_val=curr_val,
                prev_val=prev_val,
                currency=self.engine.company.currency,
            )

            results.append(
                PeriodChange(
                    metric_name=m_name,
                    display_name=display_name,
                    current_period=target_period,
                    previous_period=prev_period,
                    current_value=curr_val,
                    previous_value=prev_val,
                    absolute_change=abs_change,
                    percentage_change=pct_change,
                    direction=direction,
                    unit=unit,
                    currency=self.engine.company.currency,
                    is_material=is_material,
                    materiality_reason=reason if is_material else None,
                    explanation=explanation,
                )
            )

        return results

    def detect_material_changes(self, period: Optional[str] = None) -> List[PeriodChange]:
        """Returns only the changes that meet deterministic materiality thresholds."""
        all_changes = self.detect_period_changes(period)
        return [c for c in all_changes if c.is_material]

    def _evaluate_materiality(
        self,
        metric_name: str,
        curr_val: float,
        prev_val: float,
        abs_change: float,
        pct_change: Optional[float],
        unit: MetricUnit,
    ) -> Tuple[bool, Optional[str]]:
        """Deterministic, rule-based materiality engine."""
        abs_diff = abs(abs_change)
        pct_diff = abs(pct_change) if pct_change is not None else 0.0

        if metric_name in ("dso", "dpo", "dio"):
            # Working capital day metrics
            if abs_diff >= 5.0 or pct_diff >= 12.0:
                return True, f"Working capital efficiency shifted by {abs_diff:.1f} days ({pct_diff:.1f}%)"
            return False, None

        if metric_name == "gross_margin_percent":
            # Margin in percentage points
            if abs_diff >= 1.5:
                return True, f"Gross margin moved by {abs_diff:.1f} percentage points"
            return False, None

        if metric_name == "overdue_ar":
            if abs_diff >= 50000.0 or (pct_diff >= 20.0 and abs_diff >= 25000.0):
                return True, f"Overdue exposure shifted by ₹{abs_diff:,.0f} ({pct_diff:.1f}%)"
            return False, None

        if metric_name == "upcoming_payables_7d":
            if abs_diff >= 100000.0 or (pct_diff >= 20.0 and abs_diff >= 50000.0):
                return True, f"Short-term liability shifted by ₹{abs_diff:,.0f} ({pct_diff:.1f}%)"
            return False, None

        # General monetary metrics (cash, ar, ap, inventory, revenue, cogs, gross_profit, net_working_capital)
        if unit == MetricUnit.CURRENCY:
            if abs_diff >= 150000.0 or (pct_diff >= 15.0 and abs_diff >= 75000.0):
                return True, f"Material monetary variance of ₹{abs_diff:,.0f} ({pct_diff:.1f}%)"
            return False, None

        return False, None

    def _format_change_explanation(
        self,
        display_name: str,
        abs_change: float,
        pct_change: Optional[float],
        unit: MetricUnit,
        curr_val: float,
        prev_val: float,
        currency: str,
    ) -> str:
        """Constructs audit-grade natural phrasing using deterministic values."""
        sign = "+" if abs_change > 0 else ""
        pct_str = f" ({sign}{pct_change:.1f}%)" if pct_change is not None else ""

        if unit == MetricUnit.DAYS:
            verb = "increased" if abs_change > 0 else "decreased"
            return f"{display_name} {verb} by {abs(abs_change):.1f} days{pct_str} from {prev_val:.1f} to {curr_val:.1f} days."
        elif unit == MetricUnit.PERCENTAGE:
            verb = "expanded" if abs_change > 0 else "compressed"
            return f"{display_name} {verb} by {abs(abs_change):.1f} percentage points from {prev_val:.1f}% to {curr_val:.1f}%."
        else:
            verb = "increased" if abs_change > 0 else "decreased"
            return f"{display_name} {verb} by ₹{abs(abs_change):,.0f}{pct_str} from ₹{prev_val:,.0f} to ₹{curr_val:,.0f}."

    # -------------------------------------------------------------------------
    # Trend Detection Engine
    # -------------------------------------------------------------------------

    def detect_trends(self, metric_names: Optional[List[str]] = None) -> List[MetricTrend]:
        """Analyzes historical trajectories across all available periods in the ledger."""
        available_periods = self.engine.available_periods
        if len(available_periods) < 3:
            return []

        target_metrics = metric_names or [
            "cash_position",
            "accounts_receivable",
            "overdue_ar",
            "dso",
            "accounts_payable",
            "dpo",
            "inventory_value",
            "dio",
            "gross_margin_percent",
            "revenue",
            "cogs",
        ]

        trends: List[MetricTrend] = []

        for m_name in target_metrics:
            values: List[float] = []
            valid_periods: List[str] = []

            for p in available_periods:
                m_res = self.metric_service.get_metric_by_name(m_name, p)
                if m_res.value is not None:
                    values.append(m_res.value)
                    valid_periods.append(p)

            if len(values) < 3:
                continue

            pattern, consecutive_count, desc = self._classify_trend_pattern(m_name, values, valid_periods)
            overall_change = round(values[-1] - values[0], 2)
            overall_pct = (
                round((values[-1] - values[0]) / abs(values[0]) * 100.0, 2)
                if abs(values[0]) > 1e-6 else None
            )

            # Look up display name
            sample_res = self.metric_service.get_metric_by_name(m_name, available_periods[-1])

            trends.append(
                MetricTrend(
                    metric_name=m_name,
                    display_name=sample_res.display_name,
                    pattern=pattern,
                    periods_analyzed=valid_periods,
                    values=values,
                    consecutive_direction_count=consecutive_count,
                    overall_change=overall_change,
                    overall_pct_change=overall_pct,
                    description=desc,
                )
            )

        return trends

    def _classify_trend_pattern(
        self, metric_name: str, values: List[float], periods: List[str]
    ) -> Tuple[TrendPattern, int, str]:
        """Classifies directional persistence, acceleration, or deterioration."""
        n = len(values)
        diffs = [values[i] - values[i - 1] for i in range(1, n)]

        # Check trailing consecutive changes
        trailing_inc = 0
        for d in reversed(diffs):
            if d > 1e-4:
                trailing_inc += 1
            else:
                break

        trailing_dec = 0
        for d in reversed(diffs):
            if d < -1e-4:
                trailing_dec += 1
            else:
                break

        # Check acceleration: last 3 diffs are positive and increasing
        if len(diffs) >= 3 and diffs[-1] > diffs[-2] > diffs[-3] > 0:
            return (
                TrendPattern.ACCELERATION,
                trailing_inc,
                f"Accelerating upward trajectory across the last 3 periods (+{diffs[-1]:,.1f} in latest period).",
            )

        # Metrics where increase represents deterioration: dso, overdue_ar, dio
        is_bad_when_rising = metric_name in ("dso", "overdue_ar", "dio", "cogs")
        # Metrics where decrease represents deterioration: gross_margin_percent, cash_position
        is_bad_when_falling = metric_name in ("gross_margin_percent", "cash_position", "gross_profit")

        if trailing_inc >= 3:
            pattern = TrendPattern.DETERIORATION if is_bad_when_rising else TrendPattern.PERSISTENT_INCREASE
            qualifier = "deteriorating" if is_bad_when_rising else "persistent increase"
            return (
                pattern,
                trailing_inc,
                f"Exhibited {qualifier} across {trailing_inc} consecutive periods ({periods[-trailing_inc]} to {periods[-1]}).",
            )

        if trailing_dec >= 3:
            pattern = TrendPattern.DETERIORATION if is_bad_when_falling else TrendPattern.PERSISTENT_DECREASE
            qualifier = "deteriorating" if is_bad_when_falling else "persistent decrease"
            return (
                pattern,
                trailing_dec,
                f"Exhibited {qualifier} across {trailing_dec} consecutive periods ({periods[-trailing_dec]} to {periods[-1]}).",
            )

        # Check recovery: was declining previously, but turned positive in last 1-2 periods
        if len(diffs) >= 3 and diffs[-1] > 0 and (diffs[-2] < 0 and diffs[-3] < 0):
            return (
                TrendPattern.RECOVERY,
                1,
                f"Showing turnaround/recovery in {periods[-1]} after preceding contraction.",
            )

        return (
            TrendPattern.STABLE,
            max(trailing_inc, trailing_dec),
            f"Fluctuating within normal range across {n} periods.",
        )

    # -------------------------------------------------------------------------
    # Anomaly Detection Engine
    # -------------------------------------------------------------------------

    def detect_anomalies(self, period: Optional[str] = None) -> List[AnomalyFinding]:
        """Detects deterministic financial anomalies against historical moving baselines."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        all_periods = self.engine.available_periods
        if target_period not in all_periods:
            return []

        target_idx = all_periods.index(target_period)
        if target_idx < 3:
            # Need at least 3 historical reference points
            return []

        historical_periods = all_periods[:target_idx]

        tracked_metrics = [
            ("inventory_value", "Inventory", 50000.0),
            ("accounts_receivable", "Accounts Receivable", 100000.0),
            ("overdue_ar", "Overdue AR", 50000.0),
            ("cash_position", "Cash Balance", 100000.0),
            ("cogs", "Cost of Goods Sold", 100000.0),
            ("gross_margin_percent", "Gross Margin %", 2.0),
            ("dso", "Days Sales Outstanding", 5.0),
            ("dio", "Days Inventory Outstanding", 5.0),
        ]

        anomalies: List[AnomalyFinding] = []

        for m_name, display_name, min_material_threshold in tracked_metrics:
            hist_vals: List[float] = []
            for hp in historical_periods:
                res = self.metric_service.get_metric_by_name(m_name, hp)
                if res.value is not None:
                    hist_vals.append(res.value)

            if len(hist_vals) < 3:
                continue

            current_res = self.metric_service.get_metric_by_name(m_name, target_period)
            if current_res.value is None:
                continue

            actual = current_res.value
            baseline = sum(hist_vals) / len(hist_vals)

            if abs(baseline) < 1e-4:
                continue

            deviation = actual - baseline
            abs_dev = abs(deviation)
            deviation_pct = round((abs_dev / abs(baseline)) * 100.0, 2)

            # Sample standard deviation
            variance = sum((x - baseline) ** 2 for x in hist_vals) / (len(hist_vals) - 1)
            std_dev = math.sqrt(variance) if variance > 0 else 0.0

            z_score = (abs_dev / std_dev) if std_dev > 1e-4 else 0.0

            # Determine anomaly severity deterministically
            if abs_dev >= min_material_threshold:
                severity: Optional[AnomalySeverity] = None

                if deviation_pct >= 50.0 or z_score >= 2.5:
                    severity = AnomalySeverity.HIGH
                elif deviation_pct >= 30.0 or z_score >= 1.8:
                    severity = AnomalySeverity.MEDIUM
                elif deviation_pct >= 20.0 or z_score >= 1.3:
                    severity = AnomalySeverity.LOW

                if severity is not None:
                    direction_str = "above" if deviation > 0 else "below"
                    unit_str = "%" if current_res.unit == MetricUnit.PERCENTAGE else (" days" if current_res.unit == MetricUnit.DAYS else "")
                    prefix = "" if unit_str else "₹"

                    reason = (
                        f"{display_name} ({prefix}{actual:,.1f}{unit_str}) is materially {direction_str} its historical "
                        f"baseline ({prefix}{baseline:,.1f}{unit_str}), deviating by {deviation_pct:.1f}%."
                    )

                    anomalies.append(
                        AnomalyFinding(
                            metric=m_name,
                            period=target_period,
                            actual=round(actual, 2),
                            baseline=round(baseline, 2),
                            deviation_pct=deviation_pct,
                            severity=severity,
                            reason=reason,
                            method="historical_rolling_deviation",
                            threshold=min_material_threshold,
                        )
                    )

        return anomalies

    # -------------------------------------------------------------------------
    # Driver Analysis Engine
    # -------------------------------------------------------------------------

    def analyze_metric_drivers(
        self, metric_name: str, period: Optional[str] = None
    ) -> DriverAnalysisResult:
        """Deterministic driver decomposition answering: WHY DID THIS METRIC CHANGE?"""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        prev_period = self.metric_service._get_previous_period(target_period) or target_period

        m = metric_name.lower().strip()

        if m in ("cash", "cash_position"):
            return self._analyze_cash_drivers(target_period, prev_period)
        elif m in ("gross_margin", "gross_margin_percent", "margin"):
            return self._analyze_gross_margin_drivers(target_period, prev_period)
        elif m in ("ar", "accounts_receivable", "dso"):
            return self._analyze_ar_drivers(target_period, prev_period)
        elif m in ("inventory", "inventory_value", "dio"):
            return self._analyze_inventory_drivers(target_period, prev_period)
        elif m in ("ap", "accounts_payable", "dpo"):
            return self._analyze_ap_drivers(target_period, prev_period)
        else:
            # Generic fallback driver decomposition
            curr_res = self.metric_service.get_metric_by_name(m, target_period)
            prev_res = self.metric_service.get_metric_by_name(m, prev_period)
            c_val = curr_res.value or 0.0
            p_val = prev_res.value or 0.0
            diff = c_val - p_val
            pct = round((diff / abs(p_val)) * 100.0, 2) if abs(p_val) > 1e-6 else None

            return DriverAnalysisResult(
                metric=metric_name,
                current_period=target_period,
                previous_period=prev_period,
                change_amount=round(diff, 2),
                change_pct=pct,
                primary_driver=f"Metric shifted by {diff:+,.2f}",
                candidate_drivers=[],
                supporting_entities=[],
                evidence_references=[],
                summary=f"General driver analysis for '{metric_name}' across {prev_period} to {target_period}.",
            )

    def _analyze_cash_drivers(self, current_period: str, previous_period: str) -> DriverAnalysisResult:
        """Decomposes cash movements into working capital absorption and operational flows."""
        curr_cash = self.metric_service.calculate_cash_position(period=current_period).value or 0.0
        prev_cash = self.metric_service.calculate_cash_position(period=previous_period).value or 0.0
        cash_delta = round(curr_cash - prev_cash, 2)
        cash_pct = round((cash_delta / abs(prev_cash)) * 100.0, 2) if abs(prev_cash) > 1e-6 else None

        ref_date = self.metric_service._get_period_end_date(current_period)
        prev_date = self.metric_service._get_period_end_date(previous_period)

        # Working capital absorption components
        curr_ar = self.engine.calculate_balance_as_of(FinancialConcept.AR, ref_date)
        prev_ar = self.engine.calculate_balance_as_of(FinancialConcept.AR, prev_date)
        ar_delta = curr_ar - prev_ar  # Positive delta = trapped cash

        curr_inv = self.engine.calculate_balance_as_of(FinancialConcept.INVENTORY, ref_date)
        prev_inv = self.engine.calculate_balance_as_of(FinancialConcept.INVENTORY, prev_date)
        inv_delta = curr_inv - prev_inv  # Positive delta = cash tied up in inventory

        curr_ap = self.engine.calculate_balance_as_of(FinancialConcept.AP, ref_date)
        prev_ap = self.engine.calculate_balance_as_of(FinancialConcept.AP, prev_date)
        ap_delta = curr_ap - prev_ap  # Negative delta = cash used to pay AP

        ap_summary = self.engine.get_ap_summary(ref_date)
        upcoming_7d = ap_summary["upcoming_payables_7d"]

        ar_summary = self.engine.get_ar_summary(ref_date)
        overdue_ar = ar_summary["total_overdue_ar"]

        candidate_drivers: List[CandidateDriver] = []
        evidence_list: List[EvidenceItem] = []
        entities: List[Dict[str, Any]] = []

        # 1. Receivables absorption
        if ar_delta > 50000.0:
            top_od = ar_summary["top_overdue_customers"][:2]
            supporting = [c["entity_name"] for c in top_od]
            entities.extend(top_od)

            # Evidence from top overdue invoices
            for c in top_od:
                cid = c["entity_id"]
                cust_invs = [ar for ar in self.engine.ar_items if ar.customer_id == cid and ar.is_open]
                for inv in cust_invs[:2]:
                    evidence_list.append(
                        EvidenceItem(
                            source_type=EvidenceSourceType.AR_OPEN_ITEM.value,
                            source_id=inv.invoice_id,
                            entity=c["entity_name"],
                            metric="overdue_ar",
                            value=inv.open_amount,
                            period=current_period,
                            description=f"Overdue invoice for {c['entity_name']} totaling ₹{inv.open_amount:,.2f} ({inv.days_overdue(ref_date)} days overdue)",
                            metadata={"due_date": inv.due_date.isoformat(), "customer_id": cid},
                        )
                    )

            candidate_drivers.append(
                CandidateDriver(
                    name="Receivables Buildup & Overdue Aging",
                    description=f"AR grew by ₹{ar_delta:,.0f}, trapping liquid capital. Overdue receivables stand at ₹{overdue_ar:,.0f}.",
                    impact_amount=ar_delta,
                    supporting_entities=supporting,
                    evidence=[e for e in evidence_list if e.source_type == EvidenceSourceType.AR_OPEN_ITEM.value],
                    association_type=AssociationType.CONTRIBUTED_TO.value,
                )
            )

        # 2. Inventory buildup
        if inv_delta > 50000.0:
            candidate_drivers.append(
                CandidateDriver(
                    name="Inventory Cash Absorption",
                    description=f"Inventory increased by ₹{inv_delta:,.0f} as procurement outpaced immediate sales demand.",
                    impact_amount=inv_delta,
                    supporting_entities=["Supply Chain", "Warehouse Operations"],
                    evidence=[],
                    association_type=AssociationType.CONTRIBUTED_TO.value,
                )
            )

        # 3. Upcoming AP obligations
        if upcoming_7d > 200000.0:
            top_vends = ap_summary["top_vendors_due"][:2]
            supporting_vends = [v["entity_name"] for v in top_vends]
            entities.extend(top_vends)

            for v in top_vends:
                vid = v["entity_id"]
                vend_invs = [ap for ap in self.engine.ap_items if ap.vendor_id == vid and ap.is_open]
                for inv in vend_invs[:2]:
                    evidence_list.append(
                        EvidenceItem(
                            source_type=EvidenceSourceType.AP_OPEN_ITEM.value,
                            source_id=inv.invoice_id,
                            entity=v["entity_name"],
                            metric="upcoming_payables_7d",
                            value=inv.open_amount,
                            period=current_period,
                            description=f"Vendor liability due to {v['entity_name']} totaling ₹{inv.open_amount:,.2f}",
                            metadata={"due_date": inv.due_date.isoformat(), "vendor_id": vid},
                        )
                    )

            candidate_drivers.append(
                CandidateDriver(
                    name="Imminent Accounts Payable Obligations",
                    description=f"₹{upcoming_7d:,.0f} in vendor payables mature within the next 7 days, exerting acute cash pressure.",
                    impact_amount=upcoming_7d,
                    supporting_entities=supporting_vends,
                    evidence=[e for e in evidence_list if e.source_type == EvidenceSourceType.AP_OPEN_ITEM.value],
                    association_type=AssociationType.ASSOCIATED_WITH.value,
                )
            )

        # Sort candidate drivers by impact
        candidate_drivers.sort(key=lambda d: abs(d.impact_amount or 0.0), reverse=True)
        if candidate_drivers:
            candidate_drivers[0].association_type = AssociationType.LARGEST_OBSERVED_DRIVER.value
            primary_driver = candidate_drivers[0].name
        else:
            primary_driver = "Operational cash disbursements and timing differences"

        summary = (
            f"Cash moved by ₹{cash_delta:,.0f} ({cash_pct:+.1f}%) from ₹{prev_cash:,.0f} to ₹{curr_cash:,.0f}. "
            f"The largest observed contributor was {primary_driver.lower()}."
        )

        return DriverAnalysisResult(
            metric="cash_position",
            current_period=current_period,
            previous_period=previous_period,
            change_amount=cash_delta,
            change_pct=cash_pct,
            primary_driver=primary_driver,
            candidate_drivers=candidate_drivers,
            supporting_entities=entities,
            evidence_references=evidence_list,
            summary=summary,
        )

    def _analyze_gross_margin_drivers(self, current_period: str, previous_period: str) -> DriverAnalysisResult:
        """Decomposes margin compression into product group inflation and customer mix."""
        pnl_curr = self.metric_service.calculate_profitability(current_period)
        pnl_prev = self.metric_service.calculate_profitability(previous_period)

        gm_curr = pnl_curr.gross_margin_percent.value or 0.0
        gm_prev = pnl_prev.gross_margin_percent.value or 0.0
        gm_change_pp = round(gm_curr - gm_prev, 2)

        rev_curr = pnl_curr.revenue.value or 0.0
        rev_prev = pnl_prev.revenue.value or 0.0
        rev_growth = round(((rev_curr - rev_prev) / rev_prev) * 100.0, 2) if rev_prev > 0 else 0.0

        cogs_curr = pnl_curr.cogs.value or 0.0
        cogs_prev = pnl_prev.cogs.value or 0.0
        cogs_growth = round(((cogs_curr - cogs_prev) / cogs_prev) * 100.0, 2) if cogs_prev > 0 else 0.0

        candidate_drivers: List[CandidateDriver] = []
        evidence_list: List[EvidenceItem] = []
        entities: List[Dict[str, Any]] = []

        # 1. Cost of Goods Sold acceleration vs Revenue
        if cogs_growth > rev_growth:
            diff_pp = round(cogs_growth - rev_growth, 2)
            candidate_drivers.append(
                CandidateDriver(
                    name="COGS Growth Outpacing Revenue",
                    description=f"COGS increased by {cogs_growth:+.1f}% (₹{cogs_curr - cogs_prev:+,.0f}) while Revenue only grew by {rev_growth:+.1f}% (₹{rev_curr - rev_prev:+,.0f}).",
                    impact_amount=round(cogs_curr - cogs_prev, 2),
                    supporting_entities=["Procurement", "Manufacturing"],
                    association_type=AssociationType.LARGEST_OBSERVED_DRIVER.value,
                )
            )

        # 2. Product group margin breakdown
        prod_intelligence = self.analyze_products(current_period)
        deteriorating_prods = [p for p in prod_intelligence if p.margin_change_pp is not None and p.margin_change_pp < -2.0]
        if deteriorating_prods:
            top_det = sorted(deteriorating_prods, key=lambda x: x.margin_change_pp or 0.0)[0]
            candidate_drivers.append(
                CandidateDriver(
                    name=f"Margin Compression in {top_det.product_group}",
                    description=f"Product group '{top_det.product_group}' gross margin contracted by {abs(top_det.margin_change_pp):.1f} pp to {top_det.gross_margin_pct:.1f}%.",
                    impact_amount=round(top_det.gross_profit, 2),
                    supporting_entities=[top_det.product_group],
                    association_type=AssociationType.CONTRIBUTED_TO.value,
                )
            )

        # 3. Low margin customer mix
        cust_intelligence = self.analyze_customers(current_period)
        low_margin_custs = [c for c in cust_intelligence if "HIGH_REVENUE_LOW_MARGIN" in c.tags]
        if low_margin_custs:
            top_lm = low_margin_custs[0]
            entities.append({"entity_id": top_lm.customer_id, "entity_name": top_lm.customer_name, "margin": top_lm.gross_margin_pct})
            candidate_drivers.append(
                CandidateDriver(
                    name=f"Customer Mix Dilution ({top_lm.customer_name})",
                    description=f"{top_lm.customer_name} accounts for ₹{top_lm.revenue:,.0f} of revenue at a slim gross margin of {top_lm.gross_margin_pct:.1f}%.",
                    impact_amount=round(top_lm.revenue, 2),
                    supporting_entities=[top_lm.customer_name],
                    association_type=AssociationType.ASSOCIATED_WITH.value,
                )
            )

        primary_driver = candidate_drivers[0].name if candidate_drivers else "COGS cost inflation"

        summary = (
            f"Gross margin shifted by {gm_change_pp:+.1f} percentage points from {gm_prev:.1f}% to {gm_curr:.1f}%. "
            f"The primary contributor was {primary_driver.lower()}."
        )

        return DriverAnalysisResult(
            metric="gross_margin_percent",
            current_period=current_period,
            previous_period=previous_period,
            change_amount=gm_change_pp,
            change_pct=None,
            primary_driver=primary_driver,
            candidate_drivers=candidate_drivers,
            supporting_entities=entities,
            evidence_references=evidence_list,
            summary=summary,
        )

    def _analyze_ar_drivers(self, current_period: str, previous_period: str) -> DriverAnalysisResult:
        """Decomposes receivables and DSO expansion into customer overdue aging and concentration."""
        ref_date = self.metric_service._get_period_end_date(current_period)
        prev_date = self.metric_service._get_period_end_date(previous_period)

        ar_curr = self.engine.calculate_balance_as_of(FinancialConcept.AR, ref_date)
        ar_prev = self.engine.calculate_balance_as_of(FinancialConcept.AR, prev_date)
        ar_delta = round(ar_curr - ar_prev, 2)
        ar_pct = round((ar_delta / abs(ar_prev)) * 100.0, 2) if abs(ar_prev) > 1e-6 else None

        dso_curr = self.metric_service.get_metric_by_name("dso", current_period).value or 0.0
        dso_prev = self.metric_service.get_metric_by_name("dso", previous_period).value or 0.0
        dso_delta = round(dso_curr - dso_prev, 1)

        ar_summary = self.engine.get_ar_summary(ref_date)
        total_overdue = ar_summary["total_overdue_ar"]
        overdue_pct = ar_summary["overdue_percentage"]

        candidate_drivers: List[CandidateDriver] = []
        evidence_list: List[EvidenceItem] = []
        entities: List[Dict[str, Any]] = []

        # Customer overdue concentration
        top_od = ar_summary["top_overdue_customers"]
        if top_od:
            top_cust = top_od[0]
            entities.append(top_cust)
            cust_name = top_cust["entity_name"]
            cust_od_amt = top_cust["amount"]
            cust_od_share = top_cust["percentage_of_total"]

            # Pull invoice evidence
            for ar in self.engine.ar_items:
                if ar.customer_id == top_cust["entity_id"] and ar.is_open and ar.days_overdue(ref_date) > 0:
                    evidence_list.append(
                        EvidenceItem(
                            source_type=EvidenceSourceType.AR_OPEN_ITEM.value,
                            source_id=ar.invoice_id,
                            entity=cust_name,
                            metric="overdue_ar",
                            value=ar.open_amount,
                            period=current_period,
                            description=f"Invoice {ar.invoice_id} for {cust_name} overdue by {ar.days_overdue(ref_date)} days (₹{ar.open_amount:,.2f})",
                            metadata={"due_date": ar.due_date.isoformat(), "customer_id": ar.customer_id},
                        )
                    )

            candidate_drivers.append(
                CandidateDriver(
                    name=f"Customer Overdue Concentration ({cust_name})",
                    description=f"{cust_name} represents ₹{cust_od_amt:,.0f} ({cust_od_share:.1f}%) of all overdue receivables.",
                    impact_amount=cust_od_amt,
                    impact_pct=cust_od_share,
                    supporting_entities=[cust_name],
                    evidence=[e for e in evidence_list if e.entity == cust_name],
                    association_type=AssociationType.LARGEST_OBSERVED_DRIVER.value,
                )
            )

        # Aging schedule migration
        buckets = {b["bucket_name"]: b for b in ar_summary["aging_buckets"]}
        aged_amt = (buckets.get("61-90", {}).get("amount", 0.0) + buckets.get("90+", {}).get("amount", 0.0))
        if aged_amt > 100000.0:
            candidate_drivers.append(
                CandidateDriver(
                    name="Aging Bracket Deterioration (>60 Days)",
                    description=f"₹{aged_amt:,.0f} of receivables have aged past 60 days overdue.",
                    impact_amount=round(aged_amt, 2),
                    supporting_entities=[],
                    evidence=[],
                    association_type=AssociationType.CONTRIBUTED_TO.value,
                )
            )

        primary_driver = candidate_drivers[0].name if candidate_drivers else "Growth in customer billings"

        summary = (
            f"AR increased by ₹{ar_delta:,.0f} ({ar_pct:+.1f}%) and DSO expanded by {dso_delta:+.1f} days (to {dso_curr:.1f} days). "
            f"The largest observed driver was {primary_driver.lower()}."
        )

        return DriverAnalysisResult(
            metric="accounts_receivable",
            current_period=current_period,
            previous_period=previous_period,
            change_amount=ar_delta,
            change_pct=ar_pct,
            primary_driver=primary_driver,
            candidate_drivers=candidate_drivers,
            supporting_entities=entities,
            evidence_references=evidence_list,
            summary=summary,
        )

    def _analyze_inventory_drivers(self, current_period: str, previous_period: str) -> DriverAnalysisResult:
        """Decomposes inventory buildup and DIO increase."""
        inv_detail = self.metric_service.calculate_inventory(current_period)
        curr_inv = inv_detail.inventory_value.value or 0.0
        prev_inv = inv_detail.inventory_value.comparison.previous_value if inv_detail.inventory_value.comparison else curr_inv
        inv_delta = round(curr_inv - prev_inv, 2)
        inv_pct = inv_detail.inventory_value.comparison.percentage_change if inv_detail.inventory_value.comparison else None

        dio_curr = inv_detail.dio.value or 0.0
        dio_prev = inv_detail.dio.comparison.previous_value if inv_detail.dio.comparison else dio_curr
        dio_delta = round(dio_curr - dio_prev, 1)

        candidate_drivers: List[CandidateDriver] = []
        entities: List[Dict[str, Any]] = []

        # Growth decoupling
        inv_growth = inv_detail.inventory_growth_rate or 0.0
        sales_growth = inv_detail.sales_growth_rate or 0.0

        if inv_growth > sales_growth:
            candidate_drivers.append(
                CandidateDriver(
                    name="Inventory Growth Decoupling from Sales",
                    description=f"Inventory grew by {inv_growth:+.1f}% while sales grew by only {sales_growth:+.1f}%, resulting in inventory accumulation.",
                    impact_amount=inv_delta,
                    supporting_entities=["Purchasing", "Warehouse"],
                    association_type=AssociationType.LARGEST_OBSERVED_DRIVER.value,
                )
            )

        # Procurement concentration
        ref_date = self.metric_service._get_period_end_date(current_period)
        ap_summary = self.engine.get_ap_summary(ref_date)
        if ap_summary["top_vendors_due"]:
            top_vend = ap_summary["top_vendors_due"][0]
            entities.append(top_vend)
            candidate_drivers.append(
                CandidateDriver(
                    name=f"Procurement Inflow from {top_vend['entity_name']}",
                    description=f"Elevated raw materials/components procurement concentrated with key supplier {top_vend['entity_name']}.",
                    impact_amount=top_vend["amount"],
                    supporting_entities=[top_vend["entity_name"]],
                    association_type=AssociationType.CONTRIBUTED_TO.value,
                )
            )

        primary_driver = candidate_drivers[0].name if candidate_drivers else "Seasonal inventory replenishment"

        summary = (
            f"Inventory increased by ₹{inv_delta:,.0f} ({inv_pct:+.1f}%) and DIO increased by {dio_delta:+.1f} days (to {dio_curr:.1f} days). "
            f"The primary driver was {primary_driver.lower()}."
        )

        return DriverAnalysisResult(
            metric="inventory_value",
            current_period=current_period,
            previous_period=previous_period,
            change_amount=inv_delta,
            change_pct=inv_pct,
            primary_driver=primary_driver,
            candidate_drivers=candidate_drivers,
            supporting_entities=entities,
            evidence_references=[],
            summary=summary,
        )

    def _analyze_ap_drivers(self, current_period: str, previous_period: str) -> DriverAnalysisResult:
        """Decomposes payables movement and vendor obligations."""
        pay_detail = self.metric_service.calculate_payables(current_period)
        curr_ap = pay_detail.accounts_payable.value or 0.0
        prev_ap = pay_detail.accounts_payable.comparison.previous_value if pay_detail.accounts_payable.comparison else curr_ap
        ap_delta = round(curr_ap - prev_ap, 2)
        ap_pct = pay_detail.accounts_payable.comparison.percentage_change if pay_detail.accounts_payable.comparison else None

        candidate_drivers: List[CandidateDriver] = []
        entities: List[Dict[str, Any]] = []

        upcoming_7d = pay_detail.upcoming_payables_7d.value or 0.0
        top_vends = pay_detail.top_vendors_due

        if upcoming_7d > 100000.0:
            candidate_drivers.append(
                CandidateDriver(
                    name="Upcoming Vendor Settlement Commitments",
                    description=f"₹{upcoming_7d:,.0f} in vendor invoices are due within the next 7 days.",
                    impact_amount=upcoming_7d,
                    supporting_entities=[v.entity_name for v in top_vends[:2]],
                    association_type=AssociationType.LARGEST_OBSERVED_DRIVER.value,
                )
            )

        summary = f"Accounts payable balance moved by ₹{ap_delta:,.0f} with ₹{upcoming_7d:,.0f} maturing in 7 days."

        return DriverAnalysisResult(
            metric="accounts_payable",
            current_period=current_period,
            previous_period=previous_period,
            change_amount=ap_delta,
            change_pct=ap_pct,
            primary_driver=candidate_drivers[0].name if candidate_drivers else "Vendor procurement cycles",
            candidate_drivers=candidate_drivers,
            supporting_entities=[v.model_dump() for v in top_vends],
            evidence_references=[],
            summary=summary,
        )

    # -------------------------------------------------------------------------
    # Customer Intelligence Engine
    # -------------------------------------------------------------------------

    def analyze_customers(self, period: Optional[str] = None) -> List[CustomerIntelligence]:
        """Calculates 360-degree customer intelligence metrics (revenue, margin, overdue exposure, tags)."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        ref_date = self.metric_service._get_period_end_date(target_period)

        # Revenue & COGS per customer
        pnl = self.engine.get_profitability_breakdowns(target_period)
        cust_pnl_map = {c["entity_id"]: c for c in pnl["top_customers_by_revenue"]}

        # Total revenue for share calculation
        total_rev = sum(c["amount"] for c in pnl["top_customers_by_revenue"])

        # AR summary as of period end date
        ar_summary = self.engine.get_ar_summary(ref_date)
        total_open_ar = ar_summary["total_open_ar"]
        cust_ar_map = {c["entity_id"]: c for c in ar_summary["customer_concentration"]}
        cust_od_map = {c["entity_id"]: c for c in ar_summary["top_overdue_customers"]}

        profiles: List[CustomerIntelligence] = []

        for cust_id, cust in self.engine.customers.items():
            # Revenue metrics
            pnl_info = cust_pnl_map.get(cust_id)
            revenue = pnl_info["amount"] if pnl_info else 0.0
            rev_share = pnl_info["percentage_of_total"] if pnl_info else 0.0
            cogs = pnl_info["additional_context"].get("cogs", 0.0) if pnl_info else 0.0
            gp = pnl_info["additional_context"].get("gross_profit", 0.0) if pnl_info else 0.0
            gm_pct = pnl_info["additional_context"].get("gross_margin_percent", 0.0) if pnl_info else 0.0

            # AR metrics
            ar_info = cust_ar_map.get(cust_id)
            open_ar = ar_info["amount"] if ar_info else 0.0
            ar_share = ar_info["percentage_of_total"] if ar_info else 0.0

            od_info = cust_od_map.get(cust_id)
            overdue_ar = od_info["amount"] if od_info else 0.0
            overdue_pct = round((overdue_ar / open_ar * 100.0), 2) if open_ar > 0 else 0.0

            # DSO estimate
            days_in_period = self.metric_service._get_days_in_period(target_period)
            dso_est = round((open_ar / revenue * days_in_period), 1) if revenue > 0 else None

            # Classification & Tags
            tags: List[str] = []

            # Scenario 1: Customer Payment Deterioration (Apex CUST-101)
            if overdue_ar > 200000.0 and overdue_pct > 40.0:
                tags.append("HIGH_REVENUE_HIGH_OVERDUE")
                tags.append("CUSTOMER_PAYMENT_DETERIORATION")

            # Scenario 7: High Revenue / Low Margin (OmniChannel CUST-104)
            if revenue > 150000.0 and gm_pct < 20.0:
                tags.append("HIGH_REVENUE_LOW_MARGIN")

            # Scenario 6: Healthy Customer (Nordic CUST-102)
            if revenue > 100000.0 and gm_pct >= 40.0 and overdue_ar == 0.0:
                tags.append("HEALTHY")

            if ar_share > 40.0 or rev_share > 30.0:
                tags.append("HIGH_EXPOSURE_CONCENTRATION")

            if overdue_pct > 70.0 and overdue_ar > 50000.0:
                tags.append("CHRONIC_OVERDUE")

            # Overall payment status
            if "CUSTOMER_PAYMENT_DETERIORATION" in tags or "CHRONIC_OVERDUE" in tags:
                payment_status = "DETERIORATING"
            elif "HIGH_REVENUE_LOW_MARGIN" in tags:
                payment_status = "LOW_MARGIN"
            elif "HEALTHY" in tags or overdue_ar == 0.0:
                payment_status = "HEALTHY"
            else:
                payment_status = "NORMAL"

            # Invoices evidence
            evidence: List[EvidenceItem] = []
            for ar in self.engine.ar_items:
                if ar.customer_id == cust_id and ar.is_open:
                    days_od = ar.days_overdue(ref_date)
                    evidence.append(
                        EvidenceItem(
                            source_type=EvidenceSourceType.AR_OPEN_ITEM.value,
                            source_id=ar.invoice_id,
                            entity=cust.customer_name,
                            metric="accounts_receivable",
                            value=ar.open_amount,
                            period=target_period,
                            description=f"Invoice {ar.invoice_id}: ₹{ar.open_amount:,.2f} ({'OVERDUE ' + str(days_od) + 'd' if days_od > 0 else 'CURRENT'})",
                            metadata={"days_overdue": max(0, days_od), "due_date": ar.due_date.isoformat()},
                        )
                    )

            profiles.append(
                CustomerIntelligence(
                    customer_id=cust_id,
                    customer_name=cust.customer_name,
                    segment=cust.segment,
                    payment_terms=cust.payment_terms,
                    period=target_period,
                    revenue=round(revenue, 2),
                    revenue_share_pct=round(rev_share, 2),
                    cogs=round(cogs, 2),
                    gross_profit=round(gp, 2),
                    gross_margin_pct=round(gm_pct, 2),
                    open_ar=round(open_ar, 2),
                    ar_share_pct=round(ar_share, 2),
                    overdue_ar=round(overdue_ar, 2),
                    overdue_pct=round(overdue_pct, 2),
                    dso_estimate=dso_est,
                    payment_behavior_status=payment_status,
                    tags=tags,
                    evidence=evidence,
                )
            )

        # Sort by open AR descending
        profiles.sort(key=lambda p: p.open_ar, reverse=True)
        return profiles

    # -------------------------------------------------------------------------
    # Product Intelligence Engine
    # -------------------------------------------------------------------------

    def analyze_products(self, period: Optional[str] = None) -> List[ProductIntelligence]:
        """Calculates product and product group intelligence (revenue, margin, growth, deterioration)."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        prev_period = self.metric_service._get_previous_period(target_period)

        curr_breakdown = self.engine.get_profitability_breakdowns(target_period)
        prev_breakdown = self.engine.get_profitability_breakdowns(prev_period) if prev_period else None

        prev_group_map = {}
        if prev_breakdown:
            for g in prev_breakdown["product_group_margins"]:
                prev_group_map[g["product_group"]] = g

        results: List[ProductIntelligence] = []

        for grp in curr_breakdown["product_group_margins"]:
            g_name = grp["product_group"]
            rev = grp["revenue"]
            cogs = grp["cogs"]
            gp = grp["gross_profit"]
            gm_pct = grp["gross_margin_percent"]

            prev_g = prev_group_map.get(g_name)
            growth_pct = None
            margin_change = None

            if prev_g:
                p_rev = prev_g["revenue"]
                p_gm = prev_g["gross_margin_percent"]
                if p_rev > 0:
                    growth_pct = round(((rev - p_rev) / p_rev) * 100.0, 2)
                margin_change = round(gm_pct - p_gm, 2)

            tags: List[str] = []
            if gm_pct < 20.0 and rev > 100000.0:
                tags.append("HIGH_REVENUE_LOW_MARGIN")
            if margin_change is not None and margin_change < -2.0:
                tags.append("MARGIN_DETERIORATION")
            if growth_pct is not None and growth_pct > 10.0 and margin_change is not None and margin_change < -1.0:
                tags.append("HIGH_GROWTH_DECLINING_MARGIN")
            if gm_pct >= 45.0:
                tags.append("HIGH_MARGIN")

            results.append(
                ProductIntelligence(
                    product_id=None,
                    product_name=None,
                    product_group=g_name,
                    period=target_period,
                    revenue=round(rev, 2),
                    cogs=round(cogs, 2),
                    gross_profit=round(gp, 2),
                    gross_margin_pct=round(gm_pct, 2),
                    growth_rate_pct=growth_pct,
                    margin_change_pp=margin_change,
                    tags=tags,
                    evidence=[],
                )
            )

        # Also calculate individual product profitability
        from collections import defaultdict
        entries = self.engine._entries_by_period.get(target_period, [])
        prev_entries = self.engine._entries_by_period.get(prev_period, []) if prev_period else []

        prod_rev: Dict[str, float] = defaultdict(float)
        prod_cogs: Dict[str, float] = defaultdict(float)
        prev_prod_rev: Dict[str, float] = defaultdict(float)
        prev_prod_cogs: Dict[str, float] = defaultdict(float)

        for je in entries:
            mapping = self.engine.account_mappings.get(je.gl_account)
            if not mapping or not je.product_id:
                continue
            if mapping.financial_concept == FinancialConcept.REVENUE and je.is_credit:
                prod_rev[je.product_id] += je.amount
            elif mapping.financial_concept == FinancialConcept.COGS and je.is_debit:
                prod_cogs[je.product_id] += je.amount

        for je in prev_entries:
            mapping = self.engine.account_mappings.get(je.gl_account)
            if not mapping or not je.product_id:
                continue
            if mapping.financial_concept == FinancialConcept.REVENUE and je.is_credit:
                prev_prod_rev[je.product_id] += je.amount
            elif mapping.financial_concept == FinancialConcept.COGS and je.is_debit:
                prev_prod_cogs[je.product_id] += je.amount

        for pid, prod in self.engine.products.items():
            r = prod_rev.get(pid, 0.0)
            c = prod_cogs.get(pid, 0.0)
            gp = r - c
            gm = (gp / r * 100.0) if r > 0 else 0.0

            p_r = prev_prod_rev.get(pid, 0.0)
            p_c = prev_prod_cogs.get(pid, 0.0)
            p_gm = ((p_r - p_c) / p_r * 100.0) if p_r > 0 else 0.0
            g_pct = round(((r - p_r) / p_r * 100.0), 2) if p_r > 0 else None
            m_change = round(gm - p_gm, 2) if p_r > 0 else None

            p_tags: List[str] = []
            if gm < 20.0 and r > 100000.0:
                p_tags.append("HIGH_REVENUE_LOW_MARGIN")
            if m_change is not None and m_change < -2.0:
                p_tags.append("MARGIN_DETERIORATION")
            if gm >= 45.0:
                p_tags.append("HIGH_MARGIN")

            results.append(
                ProductIntelligence(
                    product_id=pid,
                    product_name=prod.product_name,
                    product_group=prod.product_group,
                    period=target_period,
                    revenue=round(r, 2),
                    cogs=round(c, 2),
                    gross_profit=round(gp, 2),
                    gross_margin_pct=round(gm, 2),
                    growth_rate_pct=g_pct,
                    margin_change_pp=m_change,
                    tags=p_tags,
                    evidence=[],
                )
            )

        return results

    # -------------------------------------------------------------------------
    # Comprehensive Financial Intelligence Report
    # -------------------------------------------------------------------------

    def generate_report(self, period: Optional[str] = None) -> FinancialIntelligenceReport:
        """Aggregates period changes, trends, anomalies, drivers, and entity intelligence."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        prev_period = self.metric_service._get_previous_period(target_period) or target_period

        period_changes = self.detect_period_changes(target_period)
        material_changes = [c for c in period_changes if c.is_material]
        trends = self.detect_trends()
        anomalies = self.detect_anomalies(target_period)

        # Drivers for key financial metrics
        driver_metrics = ["cash_position", "gross_margin_percent", "accounts_receivable", "inventory_value"]
        drivers = [self.analyze_metric_drivers(m, target_period) for m in driver_metrics]

        customers = self.analyze_customers(target_period)
        products = self.analyze_products(target_period)

        return FinancialIntelligenceReport(
            company_code=self.engine.company.company_code,
            period=target_period,
            comparison_period=prev_period,
            period_changes=period_changes,
            material_changes=material_changes,
            trends=trends,
            anomalies=anomalies,
            driver_analyses=drivers,
            customer_intelligence=customers,
            product_intelligence=products,
        )
