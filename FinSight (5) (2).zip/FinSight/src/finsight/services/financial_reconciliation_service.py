"""Financial Reconciliation Engine & Service for FinSight.

Audits and proves mathematical and architectural consistency across:
- General Ledger & Subledgers (BSID / BSIK)
- Foundational Financial Equations (NWC, Gross Margin, CCC, DSO, DIO, DPO)
- Aggregation & Concentration Invariants (Customer, Vendor, Product)
- Cross-Layer Alignment (Metrics <-> Attention <-> Cases <-> Investigation <-> Evidence)
"""

from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from finsight.models.canonical import FinancialConcept
from finsight.models.snapshot import FinancialSnapshot
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


class ReconciliationCheck(BaseModel):
    """Deterministic check result validating an exact financial identity or invariant."""
    check_id: str = Field(description="Unique rule code, e.g. 'RECON-NWC-01'")
    category: str = Field(description="BALANCE_SHEET, PNL, WORKING_CAPITAL, AGING, CONCENTRATION, CROSS_LAYER, SUBLEDGER")
    name: str = Field(description="Descriptive name of the reconciliation check")
    description: str = Field(description="Detailed explanation of the relationship being verified")
    status: str = Field(description="'PASS' or 'FAIL'")
    expected_value: float = Field(description="Expected authoritative target value")
    computed_value: float = Field(description="Computed aggregate value")
    variance: float = Field(description="Absolute difference (computed - expected)")
    tolerance: float = Field(default=0.01, description="Acceptable numerical delta threshold")
    details: Dict[str, Any] = Field(default_factory=dict, description="Component breakdowns and evidence references")


class ReconciliationReport(BaseModel):
    """Authoritative reconciliation statement across the enterprise financial dataset."""
    snapshot_id: str
    period: str
    reference_date: str
    status: str = Field(description="'RECONCILED' or 'DISCREPANCY'")
    total_checks: int
    passed_checks: int
    failed_checks: int
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    checks: List[ReconciliationCheck] = Field(default_factory=list)
    summary_metrics: Dict[str, Any] = Field(default_factory=dict)


class FinancialReconciliationService:
    """Service that orchestrates comprehensive deterministic financial audits."""

    def __init__(self, engine: FinancialEngine, metric_service: MetricService, active_snapshot: Optional[FinancialSnapshot] = None):
        self.engine = engine
        self.metric_service = metric_service
        self.active_snapshot = active_snapshot

    def execute_audit(self, period: Optional[str] = None, as_of_date: Optional[date] = None) -> ReconciliationReport:
        """Executes all 22+ deterministic financial reconciliation tests."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self.metric_service._get_period_end_date(target_period)
        days_in_period = self.metric_service._get_days_in_period(target_period)

        checks: List[ReconciliationCheck] = []

        # Pull raw foundational figures from engine
        wc_comps = self.engine.get_working_capital_components(target_date)
        pnl = self.engine.get_pnl_for_period(target_period)
        ar_summary = self.engine.get_ar_summary(target_date)
        ap_summary = self.engine.get_ap_summary(target_date)
        profit_breakdowns = self.engine.get_profitability_breakdowns(target_period)
        cash_val, bank_accounts = self.engine.get_cash_position(target_date)

        # ---------------------------------------------------------------------
        # 1. BALANCE SHEET & WORKING CAPITAL RECONCILIATIONS
        # ---------------------------------------------------------------------

        # Check 1: Current Assets = Cash + Trade AR + Other Receivables + Inventory + Other CA
        ca_expected = round(wc_comps["cash"] + wc_comps["trade_receivables"] + wc_comps["other_receivables"] + wc_comps["inventory"] + wc_comps["other_current_assets"], 2)
        ca_actual = round(wc_comps["total_current_assets"], 2)
        var_1 = round(abs(ca_actual - ca_expected), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-CA-01",
            category="BALANCE_SHEET",
            name="Current Assets Component Tie",
            description=f"Total Current Assets must exactly equal Cash (₹{wc_comps['cash']:,.2f}) + Trade AR (₹{wc_comps['trade_receivables']:,.2f}) + Other Receivables (₹{wc_comps['other_receivables']:,.2f}) + Inventory (₹{wc_comps['inventory']:,.2f}) + Other CA (₹{wc_comps['other_current_assets']:,.2f}).",
            status="PASS" if var_1 <= 0.01 else "FAIL",
            expected_value=ca_expected,
            computed_value=ca_actual,
            variance=var_1,
            details={
                "cash": wc_comps["cash"],
                "trade_receivables": wc_comps["trade_receivables"],
                "other_receivables": wc_comps["other_receivables"],
                "accounts_receivable_gl": wc_comps["accounts_receivable"],
                "inventory": wc_comps["inventory"],
                "other_ca": wc_comps["other_current_assets"],
            }
        ))

        # Check 2: Current Liabilities = Trade AP + Other Payables + Short Term Debt
        cl_expected = round(wc_comps["trade_payables"] + wc_comps["other_payables"] + wc_comps["short_term_debt"], 2)
        cl_actual = round(wc_comps["total_current_liabilities"], 2)
        var_2 = round(abs(cl_actual - cl_expected), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-CL-01",
            category="BALANCE_SHEET",
            name="Current Liabilities Component Tie",
            description=f"Total Current Liabilities must exactly equal Trade AP (₹{wc_comps['trade_payables']:,.2f}) + Other Payables (₹{wc_comps['other_payables']:,.2f}) + Short Term Debt (₹{wc_comps['short_term_debt']:,.2f}).",
            status="PASS" if var_2 <= 0.01 else "FAIL",
            expected_value=cl_expected,
            computed_value=cl_actual,
            variance=var_2,
            details={
                "trade_payables": wc_comps["trade_payables"],
                "other_payables": wc_comps["other_payables"],
                "accounts_payable_gl": wc_comps["accounts_payable"],
                "short_debt": wc_comps["short_term_debt"],
                "other_cl": wc_comps["other_current_liabilities"],
            }
        ))

        # Check 3: Net Working Capital = Current Assets - Current Liabilities
        nwc_expected = round(ca_actual - cl_actual, 2)
        nwc_actual = round(wc_comps["net_working_capital"], 2)
        var_3 = round(abs(nwc_actual - nwc_expected), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-NWC-01",
            category="WORKING_CAPITAL",
            name="Net Working Capital Identity",
            description="Net Working Capital must exactly equal Total Current Assets minus Total Current Liabilities.",
            status="PASS" if var_3 <= 0.01 else "FAIL",
            expected_value=nwc_expected,
            computed_value=nwc_actual,
            variance=var_3,
            details={"current_assets": ca_actual, "current_liabilities": cl_actual}
        ))

        # Check 4: Cash GL Accounts = Sum of Bank Account Balances
        bank_sum = round(sum(b["balance"] for b in bank_accounts), 2)
        var_4 = round(abs(cash_val - bank_sum), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-CASH-01",
            category="BALANCE_SHEET",
            name="Cash Position Bank Ledger Tie",
            description="Total cash position must equal the sum of active bank GL accounts (Operating, Reserve, Payroll).",
            status="PASS" if var_4 <= 0.01 else "FAIL",
            expected_value=cash_val,
            computed_value=bank_sum,
            variance=var_4,
            details={"accounts": bank_accounts}
        ))

        # ---------------------------------------------------------------------
        # 2. P&L & PROFITABILITY RECONCILIATIONS
        # ---------------------------------------------------------------------

        # Check 5: Gross Profit = Revenue - COGS
        gp_expected = round(pnl["revenue"] - pnl["cogs"], 2)
        gp_actual = round(pnl["gross_profit"], 2)
        var_5 = round(abs(gp_actual - gp_expected), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-GP-01",
            category="PNL",
            name="Gross Profit Identity",
            description="Gross Profit must exactly equal Revenue minus Cost of Goods Sold.",
            status="PASS" if var_5 <= 0.01 else "FAIL",
            expected_value=gp_expected,
            computed_value=gp_actual,
            variance=var_5,
            details={"revenue": pnl["revenue"], "cogs": pnl["cogs"]}
        ))

        # Check 6: Gross Margin % = (Gross Profit / Revenue) * 100
        gm_expected = round((gp_actual / pnl["revenue"] * 100.0), 2) if pnl["revenue"] > 0 else 0.0
        gm_metric = self.metric_service.calculate_profitability(target_period).gross_margin_percent
        gm_actual = round(gm_metric.value or 0.0, 2)
        var_6 = round(abs(gm_actual - gm_expected), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-GM-01",
            category="PNL",
            name="Gross Margin Percentage Formula",
            description="Gross Margin % must equal (Gross Profit / Revenue) * 100.",
            status="PASS" if var_6 <= 0.01 else "FAIL",
            expected_value=gm_expected,
            computed_value=gm_actual,
            variance=var_6,
            details={"formula": f"({gp_actual} / {pnl['revenue']}) * 100"}
        ))

        # Check 7: Product Group Revenues Sum = Total Revenue
        prod_rev_sum = round(sum(p["revenue"] for p in profit_breakdowns["product_group_margins"]), 2)
        var_7 = round(abs(prod_rev_sum - pnl["revenue"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-PROD-REV-01",
            category="CONCENTRATION",
            name="Product Group Revenue Completeness",
            description="Sum of product group revenues must reconcile 100% to P&L top-line revenue.",
            status="PASS" if var_7 <= 0.01 else "FAIL",
            expected_value=pnl["revenue"],
            computed_value=prod_rev_sum,
            variance=var_7,
            details={"product_groups": profit_breakdowns["product_group_margins"]}
        ))

        # Check 8: Customer Revenues Sum = Total Revenue
        cust_rev_sum = round(sum(c["amount"] for c in profit_breakdowns["top_customers_by_revenue"]), 2)
        var_8 = round(abs(cust_rev_sum - pnl["revenue"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-CUST-REV-01",
            category="CONCENTRATION",
            name="Customer Revenue Completeness",
            description="Sum of customer revenues must reconcile 100% to P&L top-line revenue.",
            status="PASS" if var_8 <= 0.01 else "FAIL",
            expected_value=pnl["revenue"],
            computed_value=cust_rev_sum,
            variance=var_8,
            details={"customer_count": len(profit_breakdowns["top_customers_by_revenue"])}
        ))

        # ---------------------------------------------------------------------
        # 3. CASH CONVERSION CYCLE & WORKING CAPITAL CYCLE RECONCILIATIONS
        # ---------------------------------------------------------------------

        # Check 9: DSO = (AR / Revenue) * Days in Period
        dso_expected = round((ar_summary["total_open_ar"] / pnl["revenue"] * days_in_period), 1) if pnl["revenue"] > 0 else 0.0
        dso_metric = self.metric_service.calculate_receivables(target_period, target_date).dso
        dso_actual = round(dso_metric.value or 0.0, 1)
        var_9 = round(abs(dso_actual - dso_expected), 1)
        checks.append(ReconciliationCheck(
            check_id="RECON-DSO-01",
            category="WORKING_CAPITAL",
            name="Days Sales Outstanding (DSO) Formula",
            description="DSO must equal (Accounts Receivable / Revenue) * Days in Period.",
            status="PASS" if var_9 <= 0.1 else "FAIL",
            expected_value=dso_expected,
            computed_value=dso_actual,
            variance=var_9,
            details={"ar": ar_summary["total_open_ar"], "revenue": pnl["revenue"], "days": days_in_period}
        ))

        # Check 10: DIO = (Inventory / COGS) * Days in Period
        inv_val = wc_comps["inventory"]
        dio_expected = round((inv_val / pnl["cogs"] * days_in_period), 1) if pnl["cogs"] > 0 else 0.0
        dio_metric = self.metric_service.calculate_inventory(target_period, target_date).dio
        dio_actual = round(dio_metric.value or 0.0, 1)
        var_10 = round(abs(dio_actual - dio_expected), 1)
        checks.append(ReconciliationCheck(
            check_id="RECON-DIO-01",
            category="WORKING_CAPITAL",
            name="Days Inventory Outstanding (DIO) Formula",
            description="DIO must equal (Inventory / COGS) * Days in Period.",
            status="PASS" if var_10 <= 0.1 else "FAIL",
            expected_value=dio_expected,
            computed_value=dio_actual,
            variance=var_10,
            details={"inventory": inv_val, "cogs": pnl["cogs"], "days": days_in_period}
        ))

        # Check 11: DPO = (AP / COGS) * Days in Period
        ap_val = ap_summary["total_open_ap"]
        dpo_expected = round((ap_val / pnl["cogs"] * days_in_period), 1) if pnl["cogs"] > 0 else 0.0
        dpo_metric = self.metric_service.calculate_payables(target_period, target_date).dpo
        dpo_actual = round(dpo_metric.value or 0.0, 1)
        var_11 = round(abs(dpo_actual - dpo_expected), 1)
        checks.append(ReconciliationCheck(
            check_id="RECON-DPO-01",
            category="WORKING_CAPITAL",
            name="Days Payable Outstanding (DPO) Formula",
            description="DPO must equal (Accounts Payable / COGS) * Days in Period.",
            status="PASS" if var_11 <= 0.1 else "FAIL",
            expected_value=dpo_expected,
            computed_value=dpo_actual,
            variance=var_11,
            details={"ap": ap_val, "cogs": pnl["cogs"], "days": days_in_period}
        ))

        # Check 12: CCC = DSO + DIO - DPO
        ccc_expected = round(dso_actual + dio_actual - dpo_actual, 1)
        ccc_metric = self.metric_service.calculate_ccc(target_period, target_date)
        ccc_actual = round(ccc_metric.value or 0.0, 1)
        var_12 = round(abs(ccc_actual - ccc_expected), 1)
        checks.append(ReconciliationCheck(
            check_id="RECON-CCC-01",
            category="WORKING_CAPITAL",
            name="Cash Conversion Cycle (CCC) Identity",
            description="CCC must exactly equal DSO + DIO - DPO.",
            status="PASS" if var_12 <= 0.1 else "FAIL",
            expected_value=ccc_expected,
            computed_value=ccc_actual,
            variance=var_12,
            details={"dso": dso_actual, "dio": dio_actual, "dpo": dpo_actual}
        ))

        # ---------------------------------------------------------------------
        # 4. SUBLEDGER AGING & CONCENTRATION RECONCILIATIONS
        # ---------------------------------------------------------------------

        # Check 13: AR Aging Buckets Sum = Total Overdue AR
        aging_sum = round(sum(b["amount"] for b in ar_summary["aging_buckets"]), 2)
        var_13 = round(abs(aging_sum - ar_summary["total_overdue_ar"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-AR-AGING-01",
            category="AGING",
            name="AR Aging Schedule Completeness",
            description="Sum of all overdue AR aging intervals (0-30, 31-60, 61-90, 90+) must equal Total Overdue AR.",
            status="PASS" if var_13 <= 0.01 else "FAIL",
            expected_value=ar_summary["total_overdue_ar"],
            computed_value=aging_sum,
            variance=var_13,
            details={"aging_buckets": ar_summary["aging_buckets"]}
        ))

        # Check 14: Overdue AR = Sum of past-due open items
        overdue_invoices = self.engine.get_overdue_invoices(target_date)
        overdue_inv_sum = round(sum(inv["amount"] for inv in overdue_invoices), 2)
        var_14 = round(abs(overdue_inv_sum - ar_summary["total_overdue_ar"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-AR-OVERDUE-01",
            category="AGING",
            name="Overdue AR Line Item Sum",
            description="Total Overdue AR must equal the exact sum of individual open delinquent invoices.",
            status="PASS" if var_14 <= 0.01 else "FAIL",
            expected_value=ar_summary["total_overdue_ar"],
            computed_value=overdue_inv_sum,
            variance=var_14,
            details={"overdue_invoice_count": len(overdue_invoices)}
        ))

        # Check 15: Customer Open AR Balances Sum = Total Open AR
        cust_open_sum = round(sum(c["amount"] for c in ar_summary["customer_concentration"]), 2)
        var_15 = round(abs(cust_open_sum - ar_summary["total_open_ar"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-AR-CUST-01",
            category="CONCENTRATION",
            name="Customer Open AR Allocation Completeness",
            description="Sum of individual customer open AR balances must equal Total Open AR in subledger.",
            status="PASS" if var_15 <= 0.01 else "FAIL",
            expected_value=ar_summary["total_open_ar"],
            computed_value=cust_open_sum,
            variance=var_15,
            details={"customer_count": len(ar_summary["customer_concentration"])}
        ))

        # Check 16: Customer Overdue Concentration = Total Overdue AR
        cust_od_sum = round(sum(c["amount"] for c in ar_summary["top_overdue_customers"]), 2)
        var_16 = round(abs(cust_od_sum - ar_summary["total_overdue_ar"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-AR-CUST-OD-01",
            category="CONCENTRATION",
            name="Customer Overdue Exposure Completeness",
            description="Sum of customer overdue exposures must reconcile 100% to Total Overdue AR.",
            status="PASS" if var_16 <= 0.01 else "FAIL",
            expected_value=ar_summary["total_overdue_ar"],
            computed_value=cust_od_sum,
            variance=var_16,
            details={"top_overdue_customers": ar_summary["top_overdue_customers"]}
        ))

        # Check 17: Top Delinquent Customer Overdue Invoices Reconciliation
        top_od_list = ar_summary.get("top_overdue_customers", [])
        if top_od_list:
            top_cust = top_od_list[0]
            top_cid = top_cust.get("entity_id")
            top_name = top_cust.get("entity_name", top_cid)
            top_invoices = [inv for inv in overdue_invoices if inv["customer_id"] == top_cid]
            top_od_sum = round(sum(inv["amount"] for inv in top_invoices), 2)
            top_expected = round(top_cust.get("amount", top_od_sum), 2)
            var_17 = round(abs(top_od_sum - top_expected), 2)
            checks.append(ReconciliationCheck(
                check_id="RECON-TOP-CUST-OD-01",
                category="CROSS_LAYER",
                name="Top Delinquent Customer Subledger Tie",
                description=f"Top delinquent customer ({top_name}) overdue subledger item sum matches its aging exposure across {len(top_invoices)} invoices.",
                status="PASS" if var_17 <= 0.01 and len(top_invoices) > 0 else "FAIL",
                expected_value=top_expected,
                computed_value=top_od_sum,
                variance=var_17,
                details={"entity_id": top_cid, "entity_name": top_name, "invoice_count": len(top_invoices), "invoices": [inv["invoice_id"] for inv in top_invoices]}
            ))
        else:
            checks.append(ReconciliationCheck(
                check_id="RECON-TOP-CUST-OD-01",
                category="CROSS_LAYER",
                name="Top Delinquent Customer Subledger Tie",
                description="No overdue customers exist in this period.",
                status="PASS",
                expected_value=0.0,
                computed_value=0.0,
                variance=0.0,
                details={}
            ))

        # Check 18: AP Upcoming 7-Day Invoices Sum = Upcoming Payables 7D
        upcoming_invoices = self.engine.get_upcoming_invoices_7d(target_date)
        up_inv_sum = round(sum(inv["amount"] for inv in upcoming_invoices), 2)
        var_18 = round(abs(up_inv_sum - ap_summary["upcoming_payables_7d"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-AP-7D-01",
            category="AGING",
            name="AP 7-Day Invoices Line Item Tie",
            description="Upcoming 7-Day Payables metric must equal the exact sum of invoices maturing in 0-7 days.",
            status="PASS" if var_18 <= 0.01 else "FAIL",
            expected_value=ap_summary["upcoming_payables_7d"],
            computed_value=up_inv_sum,
            variance=var_18,
            details={"invoices": [inv["invoice_id"] for inv in upcoming_invoices]}
        ))

        # Check 19: AP Upcoming Schedule Buckets Sum (Today, 1-3d, 4-7d) = Upcoming 7D Payables
        up_sched_7d_sum = round(sum(
            s["amount"] for s in ap_summary["upcoming_schedule"]
            if s["timeframe"] in ("Due Today", "Due in 1-3 Days", "Due in 4-7 Days")
        ), 2)
        var_19 = round(abs(up_sched_7d_sum - ap_summary["upcoming_payables_7d"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-AP-SCHED-01",
            category="AGING",
            name="AP Upcoming Schedule 7-Day Completeness",
            description="Sum of 0-7 day upcoming schedule buckets must equal Upcoming 7D Payables metric.",
            status="PASS" if var_19 <= 0.01 else "FAIL",
            expected_value=ap_summary["upcoming_payables_7d"],
            computed_value=up_sched_7d_sum,
            variance=var_19,
            details={"schedule": ap_summary["upcoming_schedule"]}
        ))

        # Check 20: Vendor Upcoming 7-Day Concentration Sum = Upcoming 7D Payables
        vend_up_sum = round(sum(v["amount"] for v in ap_summary["top_vendors_due"]), 2)
        var_20 = round(abs(vend_up_sum - ap_summary["upcoming_payables_7d"]), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-AP-VEND-01",
            category="CONCENTRATION",
            name="Vendor 7-Day Payable Concentration Completeness",
            description="Sum of top vendor 7-day payment obligations must equal Total Upcoming 7D Payables.",
            status="PASS" if var_20 <= 0.01 else "FAIL",
            expected_value=ap_summary["upcoming_payables_7d"],
            computed_value=vend_up_sum,
            variance=var_20,
            details={"vendors": ap_summary["top_vendors_due"]}
        ))

        # ---------------------------------------------------------------------
        # 5. TRIAL BALANCE & DOUBLE-ENTRY SYMMETRY
        # ---------------------------------------------------------------------

        # Check 21: Trial Balance Total Debits = Total Credits
        total_debits = round(sum(je.amount for je in self.engine.journal_entries if je.is_debit), 2)
        total_credits = round(sum(je.amount for je in self.engine.journal_entries if je.is_credit), 2)
        tb_delta = round(abs(total_debits - total_credits), 2)
        checks.append(ReconciliationCheck(
            check_id="RECON-TB-01",
            category="SUBLEDGER",
            name="Double-Entry Trial Balance Symmetrical Tie",
            description="Total debits across all ingested general ledger journal entries must equal total credits.",
            status="PASS" if tb_delta <= 0.01 else "FAIL",
            expected_value=total_debits,
            computed_value=total_credits,
            variance=tb_delta,
            details={"total_debits": total_debits, "total_credits": total_credits}
        ))

        # Check 22: Subledger to Active Trade Journal Entries Reconciliation
        # Verifies that independently derived GL Trade AR ties to the customer AR subledger
        ar_recon = self.engine.get_ar_reconciliation(target_date)
        gl_trade_expected = round(ar_recon["gl_ar_balance"] - ar_recon["classified_other_receivables"], 2)
        subledger_trade_sum = round(ar_summary["total_open_ar"], 2)
        sub_gl_variance = round(abs(gl_trade_expected - subledger_trade_sum), 2)

        checks.append(ReconciliationCheck(
            check_id="RECON-SUB-GL-01",
            category="SUBLEDGER",
            name="Subledger to GL Control Account Tie",
            description=f"Trade customer subledger open balances (₹{subledger_trade_sum:,.2f}) must reconcile to GL Trade AR Control (₹{gl_trade_expected:,.2f}).",
            status="PASS" if sub_gl_variance <= 0.01 else "FAIL",
            expected_value=gl_trade_expected,
            computed_value=subledger_trade_sum,
            variance=sub_gl_variance,
            details={
                "gl_ar_control": ar_recon["gl_ar_balance"],
                "classified_other_ar": ar_recon["classified_other_receivables"],
                "expected_trade_ar": gl_trade_expected,
                "subledger_open_ar": subledger_trade_sum,
                "variance": sub_gl_variance,
            }
        ))

        # Check 23: GL AR to Trade AR Subledger Reconciliation & Classification
        ar_recon = self.engine.get_ar_reconciliation(target_date)
        gl_ar_val = ar_recon["gl_ar_balance"]
        trade_ar_val = ar_recon["trade_ar_subledger"]
        other_ar_val = ar_recon["classified_other_receivables"]
        checks.append(ReconciliationCheck(
            check_id="RECON-AR-GL-01",
            category="SUBLEDGER",
            name="GL AR to Trade AR Subledger Reconciliation",
            description=(
                f"GL AR Control (₹{gl_ar_val:,.2f}) reconciles to Trade AR Subledger (₹{trade_ar_val:,.2f}) "
                f"plus explicitly classified Other Receivables (₹{other_ar_val:,.2f})."
            ),
            status="PASS" if ar_recon["unreconciled_variance"] <= 0.01 else "FAIL",
            expected_value=gl_ar_val,
            computed_value=round(trade_ar_val + other_ar_val, 2),
            variance=ar_recon["unreconciled_variance"],
            details=ar_recon,
        ))

        # Check 24: GL AP to Trade AP Subledger Reconciliation & Classification
        ap_recon = self.engine.get_ap_reconciliation(target_date)
        gl_ap_val = ap_recon["gl_ap_balance"]
        trade_ap_val = ap_recon["trade_ap_subledger"]
        other_ap_val = ap_recon["classified_other_payables"]
        checks.append(ReconciliationCheck(
            check_id="RECON-AP-GL-01",
            category="SUBLEDGER",
            name="GL AP to Trade AP Subledger Reconciliation",
            description=(
                f"GL AP Control (₹{gl_ap_val:,.2f}) reconciles to Trade AP Subledger (₹{trade_ap_val:,.2f}) "
                f"plus explicitly classified Other Payables (₹{other_ap_val:,.2f})."
            ),
            status="PASS" if ap_recon["unreconciled_variance"] <= 0.01 else "FAIL",
            expected_value=gl_ap_val,
            computed_value=round(trade_ap_val + other_ap_val, 2),
            variance=ap_recon["unreconciled_variance"],
            details=ap_recon,
        ))

        passed = sum(1 for c in checks if c.status == "PASS")
        failed = sum(1 for c in checks if c.status == "FAIL")

        snap_id = self.active_snapshot.snapshot_id if self.active_snapshot else f"SNAP-{target_period.replace('-', '')}-001"

        return ReconciliationReport(
            snapshot_id=snap_id,
            period=target_period,
            reference_date=target_date.isoformat(),
            status="RECONCILED" if failed == 0 else "DISCREPANCY",
            total_checks=len(checks),
            passed_checks=passed,
            failed_checks=failed,
            checks=checks,
            summary_metrics={
                "cash": cash_val,
                "net_working_capital": nwc_actual,
                "current_assets": ca_actual,
                "current_liabilities": cl_actual,
                "gl_ar": wc_comps["accounts_receivable"],
                "trade_ar": ar_summary["total_open_ar"],
                "other_receivables": wc_comps["other_receivables"],
                "open_ar": ar_summary["total_open_ar"],
                "overdue_ar": ar_summary["total_overdue_ar"],
                "gl_ap": wc_comps["accounts_payable"],
                "trade_ap": ap_summary["total_open_ap"],
                "other_payables": wc_comps["other_payables"],
                "open_ap": ap_summary["total_open_ap"],
                "upcoming_payables_7d": ap_summary["upcoming_payables_7d"],
                "inventory": inv_val,
                "revenue": pnl["revenue"],
                "cogs": pnl["cogs"],
                "gross_profit": gp_actual,
                "gross_margin_percent": gm_actual,
                "dso": dso_actual,
                "dio": dio_actual,
                "dpo": dpo_actual,
                "ccc": ccc_actual,
            }
        )
