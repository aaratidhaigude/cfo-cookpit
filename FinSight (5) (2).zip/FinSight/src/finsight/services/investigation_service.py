"""FinSight AI Investigation Service.

Layer 3 Core: The deterministic AI Investigator.
Orchestrates:
Question -> Intent Interpretation -> Investigation Plan -> Deterministic Tool Execution ->
Evidence Collection -> Structured Findings -> Grounded LLM Explanation.

Strict Financial Grounding Rules:
- The LLM explains. The financial engine calculates.
- Every number must be traceable to tool outputs.
- Never invent numbers or fabricate transactions.
"""

import logging
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("finsight.investigation")

from finsight.models.control import AssessmentStatus
from finsight.models.evidence import EvidenceItem, EvidenceSourceType
from finsight.models.investigation import (
    AskResponse,
    InvestigationFinding,
    InvestigationPlan,
    InvestigationRequest,
    InvestigationResult,
    InvestigationStep,
)
from finsight.services.ai_tools_service import AIToolsService
from finsight.services.control_assessment_service import ControlAssessmentService
from finsight.services.financial_intelligence_service import FinancialIntelligenceService
from finsight.services.llm_provider import BaseLLMProvider, get_llm_provider
from finsight.config import format_currency, settings


class InvestigationService:
    """Core FinSight AI Investigator service."""

    def __init__(
        self,
        ai_tools_service: AIToolsService,
        intelligence_service: FinancialIntelligenceService,
        llm_provider: Optional[BaseLLMProvider] = None,
        control_service: Optional[ControlAssessmentService] = None,
    ):
        self.ai_tools = ai_tools_service
        self.intelligence = intelligence_service
        self.llm = llm_provider or get_llm_provider()
        self._control_service = control_service

    @property
    def engine(self):
        return self.ai_tools.engine

    @property
    def metric_service(self):
        return self.ai_tools.metric_service

    @property
    def control_service(self) -> ControlAssessmentService:
        if self._control_service is None:
            self._control_service = ControlAssessmentService(self.engine, self.metric_service)
        return self._control_service

    # -------------------------------------------------------------------------
    # Intent Interpretation & Plan Construction
    # -------------------------------------------------------------------------

    def interpret_intent(self, question: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Classifies natural language financial question into a structured intent."""
        q = question.lower().strip()

        # Check contextual hints if provided
        if context:
            ctx_metric = str(context.get("metric", "")).lower()
            ctx_attn = str(context.get("attention_id", ""))
            ctx_ent = str(context.get("entity", "")).lower()
            if ctx_attn == "CASH_PRESSURE" or ctx_metric in ("cash", "cash_position"):
                if any(w in q for w in ["why", "decrease", "drop", "change", "what", "how"]):
                    return "CASH_DECREASE_INVESTIGATION"
            if ctx_attn == "AR_DETERIORATION" or ctx_metric in ("dso", "ar", "accounts_receivable"):
                if any(w in q for w in ["why", "increase", "lag", "change", "what", "how"]):
                    return "DSO_INCREASE_INVESTIGATION"
            if ctx_attn in ("MARGIN_COMPRESSION", "HIGH_REVENUE_LOW_MARGIN") or ctx_metric in ("gross_margin_percent", "margin", "cogs"):
                if any(w in q for w in ["why", "decline", "compress", "change", "where", "what", "how"]):
                    return "MARGIN_DECLINE_INVESTIGATION"
            if ctx_attn == "INVENTORY_BUILDUP" or ctx_metric in ("inventory", "inventory_value", "dio"):
                if any(w in q for w in ["why", "increase", "buildup", "grow", "change", "what", "how"]):
                    return "INVENTORY_BUILDUP_INVESTIGATION"
            if ctx_attn == "CUSTOMER_PAYMENT_DETERIORATION" or "apex" in ctx_ent or context.get("entity_id") == "CUST-101":
                return "APEX_POLICY_ESCALATION"

        # Out-of-scope non-financial topics
        if any(w in q for w in ["weather", "sports", "capital of", "recipe", "movie", "translate", "write code", "programming language"]):
            return "OUT_OF_SCOPE_INQUIRY"

        # Unsupported forward-looking revenue/sales forecasts (FinSight lacks multi-quarter revenue projection plans)
        if any(w in q for w in ["next quarter", "future quarter", "next year", "upcoming quarter"]) and any(w in q for w in ["revenue", "sales", "earnings"]):
            return "UNSUPPORTED_REVENUE_FORECAST"

        # Check for policy/control/escalation context
        is_policy = any(k in q for k in [
            "policy", "sop", "control", "governance", "rule", "rules", "procedure",
            "escalat", "compliant", "compliance", "should finance do", "can we release",
            "release shipment", "shipment hold", "credit hold", "threshold",
            "approval requirement", "payment terms", "remediation", "action plan",
        ])

        if ("apex" in q) and (is_policy or "what should" in q or "shipment" in q or "hold" in q or "action" in q or "escalat" in q or "case" in q):
            return "APEX_POLICY_ESCALATION"
        elif "can we release" in q or "release shipment" in q or "shipment hold" in q:
            return "APEX_POLICY_ESCALATION"

        # Pure policy / knowledge inquiries:
        # e.g. "What is our collections escalation policy?", "What is our corporate travel policy?", etc.
        is_pure_policy = (
            q.startswith("what is the policy")
            or q.startswith("what is our policy")
            or q.startswith("what are the policies")
            or q.startswith("what are our policies")
            or q.startswith("what does the policy")
            or q.startswith("what policy")
            or "corporate travel" in q
            or "tax provisioning" in q
            or (is_policy and (q.startswith("what is") or q.startswith("what are") or q.startswith("explain the"))
                and not any(k in q for k in ["why", "who", "which", "are we", "can we", "apex", "due in", "today", "current", "how much"]))
        )
        if is_pure_policy:
            return "POLICY_KNOWLEDGE_INQUIRY"
        elif is_policy and ("liquidity" in q or ("cash" in q and ("runway" in q or "coverage" in q or "lcr" in q))):
            return "LIQUIDITY_POLICY_HYBRID"
        elif is_policy and ("payment" in q or "payable" in q or "ap" in q or "disbursement" in q or "vendor" in q):
            return "PAYMENT_APPROVAL_POLICY_HYBRID"
        elif is_policy and ("inventory" in q or "dio" in q or "stock" in q):
            return "INVENTORY_POLICY_HYBRID"
        elif is_policy and ("margin" in q or "profitab" in q):
            return "MARGIN_POLICY_HYBRID"
        elif is_policy and ("overdue" in q or "ar" in q or "receivable" in q or "collection" in q):
            return "OVERDUE_POLICY_HYBRID"
        elif is_policy:
            return "POLICY_KNOWLEDGE_INQUIRY"

        # Cash Forecast & Outlook (Phase 8)
        if ("forecast" in q or "outlook" in q or "project" in q or "constrained" in q or "next 30" in q or "next 60" in q or "next 90" in q) and "cash" in q:
            return "CASH_OUTLOOK_INVESTIGATION"

        # Financial-only intents (Phase 2-4)
        if "cash" in q and ("decrease" in q or "drop" in q or "fell" in q or "low" in q or "decline" in q or "why" in q):
            return "CASH_DECREASE_INVESTIGATION"
        elif "dso" in q and ("increase" in q or "rise" in q or "high" in q or "deteriorat" in q or "why" in q):
            return "DSO_INCREASE_INVESTIGATION"
        elif "overdue" in q and ("customer" in q or "who" in q or "which" in q or "driver" in q or "ar" in q):
            return "OVERDUE_AR_DRIVERS"
        elif "high revenue" in q and ("poor" in q or "low margin" in q or "payment" in q or "behaviour" in q or "behavior" in q):
            return "HIGH_REV_POOR_PAYMENT"
        elif ("margin" in q or "gross margin" in q) and ("decline" in q or "compress" in q or "fall" in q or "drop" in q or "where" in q or "why" in q):
            return "MARGIN_DECLINE_INVESTIGATION"
        elif "product" in q and ("profitab" in q or "hurt" in q or "loss" in q or "margin" in q):
            return "PRODUCT_PROFITABILITY_ISSUE"
        elif "payment" in q and ("due" in q or "7 days" in q or "next" in q or "upcoming" in q):
            return "UPCOMING_PAYMENTS_INQUIRY"
        elif "inventory" in q and ("increase" in q or "buildup" in q or "grow" in q or "why" in q or "high" in q):
            return "INVENTORY_BUILDUP_INVESTIGATION"
        elif "exposure" in q or "risk" in q or "where is" in q or "biggest" in q:
            return "BIGGEST_EXPOSURE_INVESTIGATION"
        elif "change" in q and ("month" in q or "period" in q or "what" in q):
            return "PERIOD_CHANGE_OVERVIEW"
        return "GENERAL_FINANCIAL_INQUIRY"

    def create_investigation_plan(
        self,
        question: str,
        period: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> InvestigationPlan:
        """Constructs an observable step-by-step investigation plan targeting deterministic tools."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        prev_period = self.metric_service._get_previous_period(target_period) or target_period
        intent = self.interpret_intent(question, context=context)

        steps: List[InvestigationStep] = []

        if intent in ("OUT_OF_SCOPE_INQUIRY", "UNSUPPORTED_REVENUE_FORECAST"):
            steps = []
        elif intent == "APEX_POLICY_ESCALATION":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Analyze customer exposure and concentration for Apex Retail Group",
                    tool_name="get_customer_exposure",
                    tool_args={"customer_id": "CUST-101"},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=2,
                    action="Retrieve detailed overdue invoice records for Apex Retail Group",
                    tool_name="get_receivables",
                    tool_args={"customer_id": "CUST-101", "overdue_only": True},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=3,
                    action="Retrieve Collections Escalation Policy and shipment hold thresholds",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": "collections escalation policy overdue threshold shipment hold credit hold", "domain": "AR", "top_k": 3},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "LIQUIDITY_POLICY_HYBRID":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Retrieve verified cash position",
                    tool_name="get_cash_position",
                    tool_args={},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=2,
                    action="Retrieve upcoming 7-day vendor obligations",
                    tool_name="get_upcoming_payments",
                    tool_args={"horizon_days": 7},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=3,
                    action="Retrieve Liquidity Risk and Cash Runway Control Policy",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": "liquidity risk cash runway control threshold coverage ratio", "domain": "TREASURY", "top_k": 3},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "PAYMENT_APPROVAL_POLICY_HYBRID":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Retrieve upcoming vendor liabilities due within 7 days",
                    tool_name="get_upcoming_payments",
                    tool_args={"horizon_days": 7},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=2,
                    action="Retrieve Vendor Payment Approval and Disbursement Policy",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": "vendor payment approval policy disbursement thresholds authorization", "domain": "AP", "top_k": 3},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "INVENTORY_POLICY_HYBRID":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Compare inventory valuation against prior period",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "inventory_value", "period_a": target_period, "period_b": prev_period},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=2,
                    action="Evaluate Days Inventory Outstanding (DIO) metric",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "dio", "period_a": target_period, "period_b": prev_period},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=3,
                    action="Retrieve Inventory Risk and Working Capital Policy",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": "inventory risk working capital policy DIO target threshold", "domain": "WORKING_CAPITAL", "top_k": 3},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "MARGIN_POLICY_HYBRID":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Compare gross margin percentage against prior period",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "gross_margin_percent", "period_a": target_period, "period_b": prev_period},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=2,
                    action="Identify drivers of gross margin compression",
                    tool_name="find_metric_drivers",
                    tool_args={"metric_name": "gross_margin_percent", "current_period": target_period, "previous_period": prev_period},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=3,
                    action="Retrieve Gross Margin Control and Profitability Policy",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": "gross margin control policy profitability pricing remediation threshold", "domain": "PROFITABILITY", "top_k": 3},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "OVERDUE_POLICY_HYBRID":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Fetch total overdue AR and top delinquent accounts",
                    tool_name="get_overdue_items",
                    tool_args={"item_type": "AR", "min_days_overdue": 1},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=2,
                    action="Retrieve detailed overdue receivables and aging brackets",
                    tool_name="get_receivables",
                    tool_args={"overdue_only": True},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=3,
                    action="Retrieve Accounts Receivable SOP and collections escalation rules",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": "accounts receivable SOP collections escalation policy aging dispute", "domain": "AR", "top_k": 3},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "POLICY_KNOWLEDGE_INQUIRY":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Retrieve governing policy or SOP documents from finance knowledge base",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": question, "effective_date": "2026-09-30", "top_k": 5},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "CASH_OUTLOOK_INVESTIGATION":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Retrieve verified current liquid cash position",
                    tool_name="get_cash_position",
                    tool_args={},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=2,
                    action="Generate deterministic 30-day cash forecast under Base Case",
                    tool_name="get_cash_forecast",
                    tool_args={"horizon_days": 30, "scenario": "BASE"},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=3,
                    action="Retrieve upcoming 7-day vendor obligations",
                    tool_name="get_upcoming_payments",
                    tool_args={"horizon_days": 7},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=4,
                    action="Retrieve overdue customer receivables schedule",
                    tool_name="get_receivables",
                    tool_args={"overdue_only": True},
                    step_type="FINANCIAL_TOOL",
                ),
                InvestigationStep(
                    step_number=5,
                    action="Retrieve Liquidity Risk and Cash Runway Control Policy",
                    tool_name="search_finance_knowledge",
                    tool_args={"query": "liquidity risk cash runway control threshold coverage ratio", "domain": "TREASURY", "top_k": 3},
                    step_type="KNOWLEDGE_RETRIEVAL",
                ),
            ]

        elif intent == "CASH_DECREASE_INVESTIGATION":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Compare current cash position against previous period",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "cash_position", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Analyze receivables movement and overdue aging absorption",
                    tool_name="get_receivables",
                    tool_args={"customer_id": None, "overdue_only": True},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Analyze upcoming vendor payables due in 7 days",
                    tool_name="get_upcoming_payments",
                    tool_args={"horizon_days": 7},
                ),
                InvestigationStep(
                    step_number=4,
                    action="Analyze inventory movement and working capital cash drag",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "inventory_value", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=5,
                    action="Identify largest deterministic drivers of cash variance",
                    tool_name="find_metric_drivers",
                    tool_args={"metric_name": "cash_position", "current_period": target_period, "previous_period": prev_period},
                ),
            ]

        elif intent == "DSO_INCREASE_INVESTIGATION":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Compare DSO between current and previous period",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "dso", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Analyze accounts receivable total balance and aging distribution",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "accounts_receivable", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Identify top customer exposure and overdue aging brackets",
                    tool_name="get_customer_exposure",
                    tool_args={"customer_id": None, "top_n": 5},
                ),
                InvestigationStep(
                    step_number=4,
                    action="Retrieve overdue AR items and customer invoice evidence",
                    tool_name="get_overdue_items",
                    tool_args={"item_type": "AR", "min_days_overdue": 30},
                ),
            ]

        elif intent == "OVERDUE_AR_DRIVERS":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Fetch total overdue AR and top delinquent accounts",
                    tool_name="get_overdue_items",
                    tool_args={"item_type": "AR", "min_days_overdue": 1},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Analyze customer exposure and concentration for top delinquent account",
                    tool_name="get_customer_exposure",
                    tool_args={"customer_id": "CUST-101", "top_n": 5},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Retrieve invoice audit evidence for primary overdue invoices",
                    tool_name="get_receivables",
                    tool_args={"customer_id": "CUST-101", "overdue_only": True},
                ),
            ]

        elif intent == "HIGH_REV_POOR_PAYMENT":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Analyze top customer revenue contribution and profitability",
                    tool_name="get_product_profitability",
                    tool_args={"period": target_period},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Analyze customer receivables exposure and overdue concentrations",
                    tool_name="get_customer_exposure",
                    tool_args={"customer_id": None, "top_n": 10},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Correlate customer revenue volume against payment delinquency",
                    tool_name="get_overdue_items",
                    tool_args={"item_type": "AR", "min_days_overdue": 1},
                ),
            ]

        elif intent == "MARGIN_DECLINE_INVESTIGATION":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Compare gross margin % and gross profit against prior period",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "gross_margin_percent", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Compare Revenue and COGS growth decoupling",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "cogs", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Inspect product group profitability and margin compression",
                    tool_name="get_product_profitability",
                    tool_args={"period": target_period},
                ),
                InvestigationStep(
                    step_number=4,
                    action="Decompose margin variance into cost drivers and mix shift",
                    tool_name="find_metric_drivers",
                    tool_args={"metric_name": "gross_margin_percent", "current_period": target_period, "previous_period": prev_period},
                ),
            ]

        elif intent == "PRODUCT_PROFITABILITY_ISSUE":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Retrieve product group profitability and gross margin rankings",
                    tool_name="get_product_profitability",
                    tool_args={"period": target_period},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Compare COGS and material costs against prior periods",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "cogs", "period_a": target_period, "period_b": prev_period},
                ),
            ]

        elif intent == "UPCOMING_PAYMENTS_INQUIRY":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Retrieve vendor liabilities due within 7 days",
                    tool_name="get_upcoming_payments",
                    tool_args={"horizon_days": 7},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Assess cash balance availability relative to 7-day obligations",
                    tool_name="get_cash_position",
                    tool_args={},
                ),
            ]

        elif intent == "INVENTORY_BUILDUP_INVESTIGATION":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Compare inventory balance and DIO against previous period",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "inventory_value", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Check Days Inventory Outstanding (DIO) movement",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "dio", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Evaluate inventory drivers and sales growth decoupling",
                    tool_name="find_metric_drivers",
                    tool_args={"metric_name": "inventory_value", "current_period": target_period, "previous_period": prev_period},
                ),
            ]

        elif intent == "BIGGEST_EXPOSURE_INVESTIGATION":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Inspect cash position and 7-day liquidity coverage",
                    tool_name="get_cash_position",
                    tool_args={},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Identify overdue customer receivables exposure",
                    tool_name="get_overdue_items",
                    tool_args={"item_type": "AR", "min_days_overdue": 1},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Inspect upcoming vendor payable commitments",
                    tool_name="get_upcoming_payments",
                    tool_args={"horizon_days": 7},
                ),
            ]

        elif intent == "PERIOD_CHANGE_OVERVIEW":
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Compare revenue and profitability between periods",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "revenue", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=2,
                    action="Compare gross margin percentage",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "gross_margin_percent", "period_a": target_period, "period_b": prev_period},
                ),
                InvestigationStep(
                    step_number=3,
                    action="Compare cash and working capital movements",
                    tool_name="compare_periods",
                    tool_args={"metric_name": "cash_position", "period_a": target_period, "period_b": prev_period},
                ),
            ]

        else:
            steps = [
                InvestigationStep(
                    step_number=1,
                    action="Retrieve executive financial summary",
                    tool_name="get_financial_metric",
                    tool_args={"metric_name": "cash_position", "period": target_period},
                ),
            ]

        return InvestigationPlan(
            question=question,
            intent=intent,
            target_period=target_period,
            steps=steps,
        )

    # -------------------------------------------------------------------------
    # Plan Execution & Evidence Gathering
    # -------------------------------------------------------------------------

    def execute_investigation(
        self,
        question: str,
        period: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> InvestigationResult:
        """Executes the deterministic investigation plan, collects evidence, and generates grounded answer."""
        start_time = time.perf_counter()
        request_id = f"inv_{uuid.uuid4().hex[:10]}"
        plan = self.create_investigation_plan(question, period, context=context)
        executed_steps: List[InvestigationStep] = []
        tool_results: Dict[str, Any] = {"target_period": plan.target_period}
        findings: List[InvestigationFinding] = []
        evidence_list: List[EvidenceItem] = []
        drivers_list: List[str] = []

        # Execute each step through existing AIToolsService contracts
        for step in plan.steps:
            try:
                res = self._dispatch_tool_call(step.tool_name, step.tool_args)
                step.status = "COMPLETED"
                step.output = res
                tool_results[f"{step.tool_name}_{step.step_number}"] = res
                if step.tool_name == "compare_periods":
                    m_name = res.get("metric_name", "")
                    if m_name in ("cash_position", "cash"):
                        tool_results["cash_comparison"] = res
                    elif m_name in ("dso",):
                        tool_results["dso_comparison"] = res
                    elif m_name in ("gross_margin_percent", "margin"):
                        tool_results["margin_comparison"] = res
                    tool_results[f"{m_name}_comparison"] = res
                elif step.tool_name == "get_receivables":
                    tool_results["receivables"] = res
                elif step.tool_name == "get_upcoming_payments":
                    tool_results["upcoming_payments"] = res
                elif step.tool_name == "get_overdue_items":
                    tool_results["overdue_items"] = res
                elif step.tool_name == "get_customer_exposure":
                    tool_results["customer_exposure"] = res
                elif step.tool_name == "search_finance_knowledge":
                    tool_results["knowledge_search"] = res

                # Extract findings and evidence from this step
                step_findings, step_evidence, step_drivers = self._extract_step_intelligence(
                    step.tool_name, res, plan.target_period
                )
                findings.extend(step_findings)
                evidence_list.extend(step_evidence)
                for d in step_drivers:
                    if d not in drivers_list:
                        drivers_list.append(d)

            except Exception as e:
                step.status = "FAILED"
                step.result_summary = f"Execution error: {str(e)}"
                step.output = {"error": str(e)}

            executed_steps.append(step)

        # Synthesize grounded answer via LLMProvider abstraction
        try:
            llm_response = self.llm.generate_explanation(
                question=question,
                intent=plan.intent,
                findings=[f.model_dump() for f in findings],
                drivers=drivers_list,
                evidence=evidence_list,
                tool_results=tool_results,
            )
        except Exception as e:
            logger.error("LLM explanation generation error: %s", e)
            llm_response = {
                "answer": "Unable to generate natural language explanation. Review verified financial evidence and findings below.",
                "key_findings": [f.claim for f in findings],
                "drivers": drivers_list,
                "evidence_state": "PARTIALLY_SUPPORTED" if evidence_list else "INSUFFICIENT_DATA",
                "suggested_next_steps": ["Review financial ledger data directly.", "Inspect control assessment."],
            }

        # Separate financial evidence from policy evidence
        financial_evidence = [e for e in evidence_list if e.source_type != EvidenceSourceType.POLICY_DOCUMENT.value]
        policy_evidence = [e for e in evidence_list if e.source_type == EvidenceSourceType.POLICY_DOCUMENT.value]

        # Structure knowledge sources
        knowledge_sources = []
        ks_res = tool_results.get("knowledge_search", {}).get("results", [])
        for r in ks_res:
            knowledge_sources.append({
                "document_id": r.get("document_id"),
                "title": r.get("title"),
                "version": r.get("version"),
                "section": r.get("section"),
                "relevance_score": r.get("relevance_score"),
                "effective_from": r.get("effective_from"),
                "effective_to": r.get("effective_to"),
                "excerpt": r.get("excerpt"),
            })

        # S12 Unified Financial Intelligence -> Investigation -> Action
        q_lower = question.lower()
        target_period = plan.target_period or "2026-09"

        # 1. Finding
        finding = None
        if findings:
            finding = findings[0].claim
        elif llm_response.get("key_findings"):
            finding = llm_response["key_findings"][0]
        else:
            finding = llm_response["answer"].split("\n")[0].replace("### Executive Finding", "").strip()

        # 2. Primary Driver
        primary_driver = None
        context_entity = (context or {}).get("entity") or (context or {}).get("entity_name")
        if isinstance(context_entity, dict):
            context_entity = context_entity.get("entity_name") or context_entity.get("name") or context_entity.get("entity_id") or str(context_entity)
        if context_entity:
            primary_driver = str(context_entity)
            if not any(str(context_entity) in (d if isinstance(d, str) else str(d)) for d in drivers_list):
                drivers_list.insert(0, str(context_entity))
        elif drivers_list:
            primary_driver = drivers_list[0]
        elif llm_response.get("drivers"):
            primary_driver = llm_response["drivers"][0]
        
        if isinstance(primary_driver, dict):
            primary_driver = primary_driver.get("entity_name") or primary_driver.get("name") or primary_driver.get("driver") or str(primary_driver)

        if not primary_driver or primary_driver == "General Ledger Multi-Account Variance":
            if "apex" in q_lower or plan.intent in ("HIGH_REV_POOR_PAYMENT", "OVERDUE_AR_DRIVERS", "CUSTOMER_CONCENTRATION_EXPOSURE"):
                primary_driver = "Apex Retail Group"
            elif any(k in q_lower for k in ["cash", "liquidity", "runway"]) or (context and context.get("metric") in ("cash_position", "upcoming_payables_7d")):
                primary_driver = "Upcoming 7-Day Vendor Obligations"
            elif any(k in q_lower for k in ["dso", "receivable"]) or re.search(r'\bar\b', q_lower) or (context and context.get("metric") in ("dso", "ar", "accounts_receivable", "overdue_ar")):
                primary_driver = "Overdue Accounts Receivable Aging"
            elif any(k in q_lower for k in ["margin", "profit"]) or re.search(r'\bcogs\b', q_lower) or (context and context.get("metric") in ("gross_margin", "gross_margin_percent")):
                primary_driver = "Cost of Goods Sold (COGS) Outpacing Revenue"
            elif any(k in q_lower for k in ["inventory", "stock"]) or re.search(r'\bdio\b', q_lower) or (context and context.get("metric") in ("dio", "inventory")):
                primary_driver = "Procurement Inflows Exceeding Monthly Absorption"
            else:
                primary_driver = primary_driver or "General Ledger Multi-Account Variance"

        if primary_driver and not any(str(primary_driver) in (d if isinstance(d, str) else str(d)) for d in drivers_list):
            drivers_list.insert(0, str(primary_driver))

        # 3. Contributors
        contributors: List[Dict[str, Any]] = []
        cust_exp = tool_results.get("customer_exposure", {})
        if cust_exp and cust_exp.get("status") != "CUSTOMER_NOT_FOUND":
            contributors.append({
                "entity_id": cust_exp.get("customer_id", "CUST-101"),
                "entity_name": cust_exp.get("customer_name", "Apex Retail Group"),
                "exposure": cust_exp.get("overdue_amount", 0.0),
                "status": "OVERDUE",
                "type": "Customer",
            })
        elif "apex" in q_lower or (context and ("apex" in str(context.get("entity", "")).lower() or context.get("entity_id") == "CUST-101")) or plan.intent in ("HIGH_REV_POOR_PAYMENT", "OVERDUE_AR_DRIVERS", "CUSTOMER_CONCENTRATION_EXPOSURE"):
            ref_date = self.metric_service._get_period_end_date(target_period)
            apex_ar_exp = 0.0
            if hasattr(self.engine, "get_customer_exposure"):
                exp_data = self.engine.get_customer_exposure("CUST-101", ref_date)
                apex_ar_exp = exp_data.get("overdue_amount", 0.0)
            elif hasattr(self.engine, "get_ar_summary"):
                ar_sum = self.engine.get_ar_summary(ref_date)
                apex_match = next((c for c in ar_sum.get("top_overdue_customers", []) if c.get("entity_id") == "CUST-101"), None)
                if apex_match:
                    apex_ar_exp = apex_match.get("amount", 0.0)
            contributors.append({
                "entity_id": "CUST-101",
                "entity_name": "Apex Retail Group",
                "exposure": apex_ar_exp,
                "status": "OVERDUE",
                "type": "Customer",
            })

        if any(k in q_lower for k in ["cash", "payable", "payment", "vendor", "disburse"]) or (context and (context.get("metric") in ("cash_position", "upcoming_payables_7d") or context.get("attention_id") == "CASH_PRESSURE")):
            payables_res = tool_results.get("payables", {}) or tool_results.get("upcoming_payables", {})
            top_vendors = payables_res.get("top_vendors_due", []) if isinstance(payables_res, dict) else []
            if not top_vendors and hasattr(self.metric_service, "calculate_payables"):
                try:
                    p_detail = self.metric_service.calculate_payables(target_period)
                    top_vendors = [v.model_dump() for v in p_detail.top_vendors_due]
                except Exception:
                    pass
            for v in top_vendors[:3]:
                contributors.append({
                    "entity_id": v.get("entity_id", "VEND"),
                    "entity_name": v.get("entity_name", "Vendor"),
                    "amount": v.get("amount", 0.0),
                    "status": "DUE_7D",
                    "type": "Vendor",
                })

        if any(k in q_lower for k in ["margin", "profit"]) or re.search(r'\bcogs\b', q_lower) or (context and (context.get("source") == "product_intelligence" or context.get("metric") in ("gross_margin", "gross_margin_percent"))):
            try:
                pnl_detail = self.metric_service.calculate_profitability(target_period)
                for pg in pnl_detail.product_group_margins:
                    pg_name = pg.get("product_group") if isinstance(pg, dict) else getattr(pg, "product_group", "Hardware")
                    gm_val = (pg.get("gross_margin_percent") if isinstance(pg, dict) else getattr(pg, "gross_margin_percent", 0.0)) or 0.0
                    rev = (pg.get("revenue") if isinstance(pg, dict) else getattr(pg, "revenue", 0.0)) or 0.0
                    cogs_val = (pg.get("cogs") if isinstance(pg, dict) else getattr(pg, "cogs", 0.0)) or 0.0
                    contributors.append({
                        "entity_name": pg_name,
                        "gross_margin_pct": round(gm_val, 1),
                        "revenue": rev,
                        "cogs": cogs_val,
                        "status": "DILUTED" if gm_val < 35.0 else "HEALTHY",
                        "type": "Product Group",
                    })
            except Exception:
                pass

        # 4. Control Evaluation & Assessment Status
        target_ctrl_id = None
        # Intent & context mapping takes precedence
        if plan.intent in ("HIGH_REV_POOR_PAYMENT", "OVERDUE_AR_DRIVERS", "CUSTOMER_CONCENTRATION_EXPOSURE") or (context and context.get("source") == "customer_intelligence") or (context and context.get("metric") in ("dso", "ar", "accounts_receivable", "overdue_ar")) or (context and context.get("attention_id") == "AR_DETERIORATION"):
            target_ctrl_id = "CONTROL-COLL-001"
        elif plan.intent in ("LIQUIDITY_POLICY_HYBRID", "CASH_DECREASE_INVESTIGATION", "UPCOMING_PAYABLES_PRESSURE") or (context and context.get("metric") in ("cash_position", "cash", "runway", "lcr")) or (context and context.get("attention_id") == "CASH_PRESSURE"):
            target_ctrl_id = "CONTROL-LIQ-001"
        elif (context and context.get("source") == "product_intelligence") or (context and context.get("metric") in ("gross_margin", "gross_margin_percent", "cogs")):
            target_ctrl_id = "CONTROL-GM-001"
        elif (context and context.get("metric") in ("dio", "inventory", "inventory_value")):
            target_ctrl_id = "CONTROL-INV-001"
        elif (context and context.get("metric") in ("dpo", "ap", "accounts_payable", "upcoming_payables_7d")):
            target_ctrl_id = "CONTROL-AP-001"

        if not target_ctrl_id:
            if any(k in q_lower for k in ["liquidity", "runway", "lcr"]) or (re.search(r'\bcash\b', q_lower) and not re.search(r'\bcash conversion\b', q_lower)):
                target_ctrl_id = "CONTROL-LIQ-001"
            elif any(k in q_lower for k in ["apex", "overdue", "dso", "receivable", "collect"]) or re.search(r'\bar\b', q_lower):
                target_ctrl_id = "CONTROL-COLL-001"
            elif any(k in q_lower for k in ["margin", "profit"]) or re.search(r'\bcogs\b', q_lower):
                target_ctrl_id = "CONTROL-GM-001"
            elif any(k in q_lower for k in ["inventory", "stock"]) or re.search(r'\bdio\b', q_lower):
                target_ctrl_id = "CONTROL-INV-001"
            elif any(k in q_lower for k in ["payable", "disburse", "vendor"]) or re.search(r'\bap\b', q_lower) or re.search(r'\bdpo\b', q_lower):
                target_ctrl_id = "CONTROL-AP-001"
            elif "data" in q_lower or "reconcil" in q_lower:
                target_ctrl_id = "CONTROL-DATA-001"

        control_id = None
        control_name = None
        control_status = None
        assessment_status = None
        policy_reference = None
        ctrl_assessment = None

        if cust_exp and cust_exp.get("status") == "CUSTOMER_NOT_FOUND":
            assessment_status = "INSUFFICIENT DATA"
            control_status = "INSUFFICIENT_DATA"
            control_id = target_ctrl_id or "CONTROL-COLL-001"
            control_name = "Collections Escalation Control"
            policy_reference = "COLL-POL-001 Section 3"
        elif target_ctrl_id:
            try:
                ctrl_assessment = self.control_service.assess_control(target_ctrl_id, period=target_period)
                if ctrl_assessment:
                    control_id = ctrl_assessment.control_id
                    control_name = ctrl_assessment.control_name
                    policy_reference = ctrl_assessment.policy_reference
                    if ctrl_assessment.status == AssessmentStatus.BREACH:
                        control_status = "BREACHED"
                        assessment_status = "FAILED"
                    elif ctrl_assessment.status == AssessmentStatus.REVIEW:
                        control_status = "WARNING"
                        assessment_status = "REQUIRES REVIEW"
                    elif ctrl_assessment.status == AssessmentStatus.PASS:
                        control_status = "HEALTHY"
                        assessment_status = "PASSED"
                    else:
                        control_status = "INSUFFICIENT_DATA"
                        assessment_status = "INSUFFICIENT DATA"
            except Exception as err:
                pass

        # 5. Quantified Financial Impact
        financial_impact = None
        formatted_financial_impact = None
        if cust_exp and cust_exp.get("status") == "CUSTOMER_NOT_FOUND":
            financial_impact = None
            formatted_financial_impact = "INSUFFICIENT DATA"
        elif plan.intent == "CASH_DECREASE_INVESTIGATION" or (re.search(r'\bcash\b', q_lower) and any(w in q_lower for w in ["decrease", "drop", "fell", "low", "decline", "why"])):
            # The quantified variance of cash decrease is the MoM cash reduction from cash_comparison or metric service
            cash_comp = tool_results.get("cash_comparison", {})
            if cash_comp and "absolute_change" in cash_comp:
                financial_impact = abs(round(float(cash_comp["absolute_change"]), 2))
            else:
                try:
                    cash_det = self.metric_service.calculate_cash_liquidity(target_period)
                    financial_impact = abs(round(float(cash_det.mom_change), 2)) if cash_det.mom_change is not None else 0.0
                except Exception:
                    financial_impact = 0.0
            formatted_financial_impact = format_currency(financial_impact)
        elif ctrl_assessment and ctrl_assessment.financial_exposure > 0:
            financial_impact = round(ctrl_assessment.financial_exposure, 2)
            formatted_financial_impact = format_currency(financial_impact)
        else:
            amounts = [float(e.value) for e in financial_evidence if isinstance(e.value, (int, float)) and e.value > 0]
            if not amounts:
                amounts = [float(f.value) for f in findings if isinstance(f.value, (int, float)) and f.value > 0]
            if amounts:
                financial_impact = round(max(amounts), 2)
                formatted_financial_impact = format_currency(financial_impact)

        # 6. Suggested Action Proposal (Prefill for Case Lifecycle)
        category = (
            "RECEIVABLES" if (control_id in ("CONTROL-COLL-001", "CONTROL-CREDIT-001") or any(k in q_lower for k in ["ar", "dso", "apex", "collect"]))
            else "LIQUIDITY" if (control_id == "CONTROL-LIQ-001" or any(k in q_lower for k in ["cash", "liquidity", "runway"]))
            else "INVENTORY" if (control_id == "CONTROL-INV-001" or "inventory" in q_lower)
            else "MARGIN" if (control_id == "CONTROL-GM-001" or any(k in q_lower for k in ["margin", "profit"]))
            else "PAYABLES" if (control_id == "CONTROL-AP-001" or any(k in q_lower for k in ["payable", "vendor", "disburse"]))
            else "GENERAL"
        )
        owner = (
            "Credit Controller" if category == "RECEIVABLES"
            else "Treasury Manager" if category == "LIQUIDITY"
            else "Commercial Controller" if category == "MARGIN"
            else "Supply Chain Lead" if category == "INVENTORY"
            else "Accounts Payable Lead" if category == "PAYABLES"
            else "Finance Lead"
        )
        entity_val = (
            "Apex Retail Group" if "apex" in q_lower
            else (contributors[0].get("entity_name") if contributors else None)
        )
        suggested_action = {
            "title": f"{entity_val or primary_driver or 'Financial'} — {control_name or 'Remediation Action'}",
            "summary": (finding or llm_response["answer"])[:250],
            "category": category,
            "severity": "CRITICAL" if assessment_status in ("FAILED", "BREACH") else "HIGH",
            "financial_exposure": financial_impact or 0.0,
            "financial_impact": financial_impact or 0.0,
            "entity": entity_val,
            "control_id": control_id,
            "assessment_id": ctrl_assessment.assessment_id if ctrl_assessment else None,
            "financial_evidence_refs": [e.source_id for e in financial_evidence if e.source_id] or (ctrl_assessment.financial_evidence_refs if ctrl_assessment else []),
            "policy_evidence_refs": [s["document_id"] for s in knowledge_sources if "document_id" in s] or ([ctrl_assessment.policy_document_id] if ctrl_assessment else []),
            "period": target_period,
            "owner": owner,
            "assignee": owner,
            "due_date": "2026-10-15",
            "recommended_actions": llm_response.get("suggested_next_steps", []),
        }

        # Determine evidence_state: SUPPORTED, PARTIALLY_SUPPORTED, INSUFFICIENT_DATA, OUT_OF_SCOPE
        if plan.intent == "OUT_OF_SCOPE_INQUIRY":
            evidence_state = "OUT_OF_SCOPE"
        elif plan.intent == "UNSUPPORTED_REVENUE_FORECAST" or (cust_exp and cust_exp.get("status") == "CUSTOMER_NOT_FOUND"):
            evidence_state = "INSUFFICIENT_DATA"
        elif llm_response.get("evidence_state"):
            evidence_state = llm_response["evidence_state"]
        elif any(s.status == "FAILED" for s in executed_steps):
            evidence_state = "PARTIALLY_SUPPORTED" if (financial_evidence or policy_evidence) else "INSUFFICIENT_DATA"
        elif not financial_evidence and not policy_evidence:
            evidence_state = "INSUFFICIENT_DATA"
        elif any(s.status != "COMPLETED" for s in executed_steps):
            evidence_state = "PARTIALLY_SUPPORTED"
        else:
            evidence_state = "SUPPORTED"

        # Determine CRM context
        crm_evidence: List[Dict[str, Any]] = []
        target_cust_id = None
        if context and context.get("entity_id"):
            target_cust_id = str(context["entity_id"])
        elif "apex" in q_lower or "c-101" in q_lower or "cust-101" in q_lower:
            target_cust_id = "CUST-101"

        if target_cust_id:
            try:
                from finsight.crm import MockCRMAdapter
                crm_adapter = MockCRMAdapter()
                crm_prof = crm_adapter.get_customer_profile(target_cust_id)
                if crm_prof:
                    crm_evidence.append({
                        "crm_account_id": crm_prof.account.crm_account_id,
                        "customer_id": crm_prof.account.customer_id,
                        "legal_name": crm_prof.account.legal_name,
                        "relationship_health": crm_prof.signals.relationship_health.value,
                        "credit_limit": crm_prof.account.credit_limit,
                        "commercial_escalation": crm_prof.signals.commercial_escalation,
                        "active_contacts": len(crm_prof.contacts),
                        "pipeline_value": sum(o.pipeline_value for o in crm_prof.opportunities if o.stage not in ("CLOSED_WON", "CLOSED_LOST")),
                        "last_activity": crm_prof.activities[0].subject if crm_prof.activities else "None",
                    })
            except Exception:
                pass


        grounding_state = "GROUNDED" if evidence_state == "SUPPORTED" else ("PARTIALLY_GROUNDED" if evidence_state == "PARTIALLY_SUPPORTED" else "UNGROUNDED")
        inv_status = "COMPLETED" if not any(s.status == "FAILED" for s in executed_steps) else "PARTIAL"
        latency_ms = round((time.perf_counter() - start_time) * 1000, 2)

        return InvestigationResult(
            question=question,
            intent=plan.intent,
            plan=plan,
            steps=executed_steps,
            tool_calls=[{"step": s.step_number, "tool": s.tool_name, "args": s.tool_args} for s in executed_steps],
            findings=findings,
            evidence=evidence_list,
            financial_evidence=financial_evidence,
            policy_evidence=policy_evidence,
            knowledge_sources=knowledge_sources,
            assessment=llm_response.get("assessment"),
            policy_context=llm_response.get("policy_context"),
            answer=llm_response["answer"],
            drivers=llm_response.get("drivers", drivers_list),
            suggested_next_steps=llm_response.get("suggested_next_steps", []),
            finding=finding,
            primary_driver=primary_driver,
            financial_impact=financial_impact,
            formatted_financial_impact=formatted_financial_impact,
            contributors=contributors,
            evidence_state=evidence_state,
            assessment_status=assessment_status,
            control_id=control_id,
            control_name=control_name,
            control_status=control_status,
            policy_reference=policy_reference,
            suggested_action=suggested_action,
            request_id=request_id,
            latency_ms=latency_ms,
            status=inv_status,
            grounding_state=grounding_state,
            crm_evidence=crm_evidence,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def ask(
        self,
        question: str,
        period: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> AskResponse:
        """User-friendly response wrapper for natural language questions."""
        inv_res = self.execute_investigation(question, period, context=context)
        plan_summary = [f"Step {s.step_number}: {s.action}" for s in inv_res.steps]
        key_findings = [f.claim for f in inv_res.findings]

        return AskResponse(
            answer=inv_res.answer,
            evidence_state=inv_res.evidence_state,
            key_findings=key_findings if key_findings else ["Analysis grounded in deterministic ledger data."],
            drivers=inv_res.drivers,
            evidence=inv_res.evidence,
            financial_evidence=inv_res.financial_evidence,
            policy_evidence=inv_res.policy_evidence,
            knowledge_sources=inv_res.knowledge_sources,
            assessment=inv_res.assessment,
            policy_context=inv_res.policy_context,
            suggested_next_steps=inv_res.suggested_next_steps,
            finding=inv_res.finding,
            primary_driver=inv_res.primary_driver,
            financial_impact=inv_res.financial_impact,
            formatted_financial_impact=inv_res.formatted_financial_impact,
            contributors=inv_res.contributors,
            assessment_status=inv_res.assessment_status,
            control_id=inv_res.control_id,
            control_name=inv_res.control_name,
            control_status=inv_res.control_status,
            policy_reference=inv_res.policy_reference,
            suggested_action=inv_res.suggested_action,
            request_id=inv_res.request_id,
            latency_ms=inv_res.latency_ms,
            status=inv_res.status,
            grounding_state=inv_res.grounding_state,
            crm_evidence=inv_res.crm_evidence,
            question=inv_res.question,
            intent=inv_res.intent,
            plan_summary=plan_summary,
            timestamp=inv_res.timestamp,
        )

    # -------------------------------------------------------------------------
    # Tool Dispatcher
    # -------------------------------------------------------------------------

    def _dispatch_tool_call(self, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatches step to corresponding AIToolsService contract."""
        if tool_name == "get_financial_metric":
            return self.ai_tools.get_financial_metric(**args)
        elif tool_name == "compare_periods":
            return self.ai_tools.compare_periods(**args)
        elif tool_name == "get_cash_position":
            return self.ai_tools.get_cash_position(**args)
        elif tool_name == "get_receivables":
            return self.ai_tools.get_receivables(**args)
        elif tool_name == "get_payables":
            return self.ai_tools.get_payables(**args)
        elif tool_name == "get_overdue_items":
            return self.ai_tools.get_overdue_items(**args)
        elif tool_name == "get_upcoming_payments":
            return self.ai_tools.get_upcoming_payments(**args)
        elif tool_name == "get_customer_exposure":
            return self.ai_tools.get_customer_exposure(**args)
        elif tool_name == "get_product_profitability":
            return self.ai_tools.get_product_profitability(**args)
        elif tool_name == "find_metric_drivers":
            # Enhance with FinancialIntelligenceService for cash and inventory drivers
            metric = args.get("metric_name", "").lower()
            if metric in ("cash", "cash_position", "inventory", "inventory_value"):
                driver_res = self.intelligence.analyze_metric_drivers(
                    metric, args.get("current_period")
                )
                return driver_res.model_dump()
            return self.ai_tools.find_metric_drivers(**args)
        elif tool_name == "get_transaction_evidence":
            return self.ai_tools.get_transaction_evidence(**args)
        elif tool_name == "search_finance_knowledge":
            return self.ai_tools.search_finance_knowledge(**args)
        elif tool_name == "get_cash_forecast":
            return self.ai_tools.get_cash_forecast(**args)
        raise ValueError(f"Unknown tool name: {tool_name}")

    def _summarize_tool_result(self, tool_name: str, res: Dict[str, Any]) -> str:
        """Generates concise step result summary."""
        if tool_name == "get_cash_forecast":
            proj = res.get("projected_cash", 0.0)
            sc = res.get("scenario", "BASE")
            hz = res.get("horizon_days", 30)
            return f"Projected {hz}-day cash under {sc}: ₹{proj:,.2f}"

        elif tool_name == "compare_periods":
            curr_fmt = res.get("current_formatted", "")
            prev_fmt = res.get("previous_formatted", "")
            pct = res.get("percentage_change")
            pct_str = f" ({pct:+.1f}%)" if pct is not None else ""
            return f"{res.get('metric_name')}: {prev_fmt} -> {curr_fmt}{pct_str}"

        elif tool_name == "get_cash_position":
            val = res.get("cash_position", {}).get("formatted_value", "")
            return f"Cash position verified at {val}"

        elif tool_name == "get_overdue_items":
            tot_ar = res.get("total_ar_overdue", 0.0)
            items = len(res.get("ar_overdue_items", []))
            return f"Total overdue AR: ₹{tot_ar:,.0f} across {items} items"

        elif tool_name == "get_upcoming_payments":
            tot = res.get("total_upcoming_amount", 0.0)
            cnt = res.get("payment_count", 0)
            return f"Upcoming 7-day payables: ₹{tot:,.0f} across {cnt} obligations"

        elif tool_name == "get_customer_exposure":
            if "total_open_ar" in res:
                return f"Customer {res.get('customer_name')}: open AR ₹{res.get('total_open_ar', 0.0):,.0f}"
            return f"Customer exposure retrieved for {len(res.get('top_customers_by_ar', []))} accounts"

        elif tool_name == "get_product_profitability":
            groups = res.get("product_group_margins", [])
            return f"Retrieved margins across {len(groups)} product groups"

        elif tool_name == "find_metric_drivers":
            return f"Primary driver: {res.get('primary_driver', 'Decomposition verified')}"

        elif tool_name == "search_finance_knowledge":
            cnt = res.get("matched_count", 0)
            if cnt > 0:
                top_doc = res["results"][0].get("title", "Governing Document")
                return f"Retrieved {cnt} policy section(s). Top match: {top_doc}"
            return "No matching policy sections found."

        return "Tool execution succeeded."

    def _extract_step_intelligence(
        self, tool_name: str, res: Dict[str, Any], target_period: Optional[str]
    ) -> Tuple[List[InvestigationFinding], List[EvidenceItem], List[str]]:
        """Extracts verified findings, audit evidence, and drivers from tool output."""
        findings: List[InvestigationFinding] = []
        evidence: List[EvidenceItem] = []
        drivers: List[str] = []

        if tool_name == "compare_periods":
            m_name = res.get("metric_name", "")
            curr = res.get("current_value")
            prev = res.get("previous_value")
            diff = res.get("absolute_change")
            pct = res.get("percentage_change")
            curr_fmt = res.get("current_formatted", "")
            prev_fmt = res.get("previous_formatted", "")

            if curr is not None and prev is not None and diff is not None:
                sign = "+" if diff > 0 else ""
                claim = f"{m_name} moved from {prev_fmt} to {curr_fmt} ({sign}{diff:,.1f}, {pct:+.1f}%)"
                findings.append(
                    InvestigationFinding(
                        claim=claim,
                        metric=m_name,
                        value=curr,
                        formatted_value=curr_fmt,
                    )
                )

        elif tool_name == "get_overdue_items":
            for ar in res.get("ar_overdue_items", [])[:3]:
                findings.append(
                    InvestigationFinding(
                        claim=f"{ar.get('entity_name')} has invoice {ar.get('invoice_id')} overdue by {ar.get('days_overdue')} days (₹{ar.get('open_amount', 0.0):,.2f})",
                        metric="overdue_ar",
                        value=ar.get("open_amount"),
                        formatted_value=f"₹{ar.get('open_amount', 0.0):,.2f}",
                        entity=ar.get("entity_name"),
                        evidence_id=ar.get("invoice_id"),
                    )
                )
                evidence.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.AR_OPEN_ITEM.value,
                        source_id=ar.get("invoice_id", ""),
                        entity=ar.get("entity_name"),
                        metric="overdue_ar",
                        value=ar.get("open_amount"),
                        period=target_period,
                        description=f"Overdue invoice {ar.get('invoice_id')} for {ar.get('entity_name')} (₹{ar.get('open_amount', 0.0):,.2f}, {ar.get('days_overdue')}d overdue)",
                        metadata={"days_overdue": ar.get("days_overdue"), "due_date": ar.get("due_date")},
                    )
                )

        elif tool_name == "get_upcoming_payments":
            for p in res.get("payments", [])[:2]:
                findings.append(
                    InvestigationFinding(
                        claim=f"Payment of ₹{p.get('open_amount', 0.0):,.2f} due to {p.get('vendor_name')} in {p.get('days_remaining')} days",
                        metric="upcoming_payables_7d",
                        value=p.get("open_amount"),
                        formatted_value=f"₹{p.get('open_amount', 0.0):,.2f}",
                        entity=p.get("vendor_name"),
                        evidence_id=p.get("invoice_id"),
                    )
                )
                evidence.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.AP_OPEN_ITEM.value,
                        source_id=p.get("invoice_id", ""),
                        entity=p.get("vendor_name"),
                        metric="upcoming_payables_7d",
                        value=p.get("open_amount"),
                        period=target_period,
                        description=f"Upcoming AP obligation {p.get('invoice_id')} due to {p.get('vendor_name')} in {p.get('days_remaining')} days",
                    )
                )

        elif tool_name == "get_receivables":
            items = res.get("items", [])
            tot_od = res.get("total_overdue_amount", 0.0)
            if items:
                cust_items_map: Dict[str, list] = {}
                for ar in items:
                    c_name = ar.get("customer_name") or "Customer"
                    cust_items_map.setdefault(c_name, []).append(ar)

                for c_name, c_list in cust_items_map.items():
                    c_od = sum(it.get("open_amount", 0.0) for it in c_list if it.get("days_overdue", 0) > 0)
                    if c_od > 0:
                        findings.append(
                            InvestigationFinding(
                                claim=f"{c_name} accounts for ₹{c_od:,.2f} in overdue receivables across {len(c_list)} invoice(s)",
                                metric="overdue_ar",
                                value=c_od,
                                formatted_value=f"₹{c_od:,.2f}",
                                entity=c_name,
                            )
                        )
                    for ar in c_list:
                        if ar.get("days_overdue", 0) > 0:
                            evidence.append(
                                EvidenceItem(
                                    source_type=EvidenceSourceType.AR_OPEN_ITEM.value,
                                    source_id=ar.get("invoice_id", ""),
                                    entity=c_name,
                                    metric="overdue_ar",
                                    value=ar.get("open_amount"),
                                    period=target_period,
                                    description=f"Overdue invoice {ar.get('invoice_id')} for {c_name} (₹{ar.get('open_amount', 0.0):,.2f}, {ar.get('days_overdue')}d overdue)",
                                    metadata={"due_date": ar.get("due_date"), "days_overdue": ar.get("days_overdue")},
                                )
                            )

        elif tool_name == "get_customer_exposure":
            c_name = res.get("customer_name")
            if c_name:
                tot_ar = res.get("total_open_ar", 0.0)
                od_ar = res.get("overdue_ar", 0.0)
                findings.append(
                    InvestigationFinding(
                        claim=f"{c_name} exposure: ₹{tot_ar:,.2f} total open AR (₹{od_ar:,.2f} overdue)",
                        metric="customer_exposure",
                        value=tot_ar,
                        formatted_value=f"₹{tot_ar:,.2f}",
                        entity=c_name,
                    )
                )
                evidence.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.CUSTOMER_RECORD.value,
                        source_id=res.get("customer_id", c_name),
                        entity=c_name,
                        metric="customer_exposure",
                        value=tot_ar,
                        period=target_period,
                        description=f"Customer exposure record for {c_name}: ₹{tot_ar:,.2f} open AR (₹{od_ar:,.2f} overdue)",
                        metadata={"total_ar": tot_ar, "overdue_ar": od_ar},
                    )
                )

        elif tool_name == "find_metric_drivers":
            primary = res.get("primary_driver")
            if primary:
                drivers.append(primary)
                findings.append(
                    InvestigationFinding(
                        claim=f"Primary driver of {res.get('metric')}: {primary}",
                        driver=primary,
                    )
                )
            for cd in res.get("candidate_drivers", []):
                d_name = cd.get("name")
                if d_name and d_name not in drivers:
                    drivers.append(d_name)

        elif tool_name == "search_finance_knowledge":
            for item in res.get("results", []):
                doc_title = item.get("title", "")
                doc_id = item.get("document_id", "")
                ver = item.get("version", "")
                sec = item.get("section", "")
                score = item.get("relevance_score", 0.0)
                excerpt = item.get("excerpt", "")
                eff_from = item.get("effective_from", "")
                eff_to = item.get("effective_to")

                claim = f"Policy {doc_title} ({doc_id} v{ver}) Section '{sec}': {excerpt[:120]}..."
                findings.append(
                    InvestigationFinding(
                        claim=claim,
                        metric="policy_rule",
                        formatted_value=f"v{ver}",
                        entity=doc_title,
                        evidence_id=doc_id,
                    )
                )
                evidence.append(
                    EvidenceItem(
                        source_type=EvidenceSourceType.POLICY_DOCUMENT.value,
                        source_id=doc_id,
                        entity=doc_title,
                        metric="policy_rule",
                        value=score,
                        period=f"v{ver}",
                        description=f"{doc_title} ({doc_id} v{ver}) Section: {sec}",
                        metadata={
                            "section": sec,
                            "version": ver,
                            "effective_from": eff_from,
                            "effective_to": eff_to,
                            "excerpt": excerpt,
                            "chunk_id": item.get("chunk_id", ""),
                            "domain": item.get("domain", ""),
                            "document_type": item.get("document_type", ""),
                        },
                    )
                )

        return findings, evidence, drivers
