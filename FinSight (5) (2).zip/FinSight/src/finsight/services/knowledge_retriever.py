"""Governed Knowledge Retrieval Engine for FinSight.

Implements BaseKnowledgeRetriever and LocalKnowledgeRetriever for deterministic,
zero-external-dependency local policy and SOP retrieval.
"""

from abc import ABC, abstractmethod
from collections import Counter
from datetime import datetime, timezone
import math
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from finsight.knowledge.corpus import get_default_knowledge_documents
from finsight.models.knowledge import (
    DocumentChunk,
    DocumentType,
    KnowledgeDocument,
    KnowledgeSearchResult,
    KnowledgeSummary,
)


class BaseKnowledgeRetriever(ABC):
    """Abstract contract for knowledge and policy retrieval backends."""

    @abstractmethod
    def index_documents(self, documents: List[KnowledgeDocument]) -> None:
        """Indexes or refreshes knowledge documents in the retrieval store."""
        pass

    @abstractmethod
    def search(
        self,
        query: str,
        domain: Optional[str] = None,
        document_type: Optional[str] = None,
        effective_date: Optional[str] = None,
        top_k: int = 5,
    ) -> List[KnowledgeSearchResult]:
        """Searches indexed policy chunks respecting effective dates and filters."""
        pass

    @abstractmethod
    def get_document(self, document_id: str) -> Optional[KnowledgeDocument]:
        """Retrieves a single knowledge document by ID."""
        pass

    @abstractmethod
    def list_documents(self, status: Optional[str] = None) -> List[KnowledgeDocument]:
        """Lists all registered knowledge documents."""
        pass

    @abstractmethod
    def get_governance_summary(self) -> KnowledgeSummary:
        """Returns governance and health metrics for the knowledge repository."""
        pass


STOP_WORDS: Set[str] = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
    "any", "are", "aren't", "as", "at", "be", "because", "been", "before", "being",
    "below", "between", "both", "but", "by", "can", "cannot", "could", "did", "do",
    "does", "doing", "down", "during", "each", "few", "for", "from", "further",
    "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him",
    "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself",
    "me", "more", "most", "my", "myself", "no", "nor", "not", "of", "off", "on",
    "once", "only", "or", "other", "ought", "our", "ours", "ourselves", "out",
    "over", "own", "same", "she", "should", "so", "some", "such", "than", "that",
    "the", "their", "theirs", "them", "themselves", "then", "there", "these",
    "they", "this", "those", "through", "to", "too", "under", "until", "up", "very",
    "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom",
    "why", "with", "would", "you", "your", "yours", "yourself", "yourselves",
}

GENERIC_TERMS: Set[str] = {
    "policy", "policies", "sop", "sops", "control", "controls", "governance",
    "rule", "rules", "procedure", "procedures", "guideline", "guidelines",
    "document", "documents", "standard", "standards", "internal", "corporate",
}


class LocalKnowledgeRetriever(BaseKnowledgeRetriever):
    """Deterministic, lightweight local retriever combining BM25/TF-IDF token matching,

    section boosting, and version/effective-date filtering with zero external DB dependencies.
    """

    def __init__(self, initial_documents: Optional[List[KnowledgeDocument]] = None):
        self._documents: Dict[str, KnowledgeDocument] = {}
        self._chunks: List[DocumentChunk] = []
        self._chunk_by_id: Dict[str, DocumentChunk] = {}
        self._last_indexed_at: str = datetime.now(timezone.utc).isoformat()

        # Inverted index structures for fast deterministic search
        self._chunk_tokens: Dict[str, Counter] = {}
        self._doc_freq: Counter = Counter()
        self._total_chunks: int = 0
        self._avg_chunk_length: float = 0.0

        # Load initial corpus
        docs = initial_documents if initial_documents is not None else get_default_knowledge_documents()
        self.index_documents(docs)

    @staticmethod
    def _normalize_domain(domain: Optional[str]) -> Optional[str]:
        if not domain:
            return None
        d = domain.strip().upper()
        mapping = {
            "RECEIVABLES": "AR",
            "RECEIVABLE": "AR",
            "AR": "AR",
            "PAYABLES": "AP",
            "PAYABLE": "AP",
            "AP": "AP",
            "CASH": "TREASURY",
            "LIQUIDITY": "TREASURY",
            "TREASURY": "TREASURY",
            "INVENTORY": "WORKING_CAPITAL",
            "WORKING_CAPITAL": "WORKING_CAPITAL",
            "MARGIN": "PROFITABILITY",
            "PROFITABILITY": "PROFITABILITY",
            "GOVERNANCE": "GOVERNANCE",
        }
        return mapping.get(d, d)

    def index_documents(self, documents: List[KnowledgeDocument]) -> None:
        """Ingests and deterministically chunks documents, building local BM25 index."""
        self._documents = {doc.document_id: doc for doc in documents}
        self._chunks = []
        self._chunk_by_id = {}
        self._chunk_tokens = {}
        self._doc_freq = Counter()

        total_words = 0

        for doc in documents:
            chunks = self._chunk_document(doc)
            for chunk in chunks:
                self._chunks.append(chunk)
                self._chunk_by_id[chunk.chunk_id] = chunk

                # Tokenize section + text + title with extra weight on section heading
                tokens = self._tokenize(chunk.text)
                title_tokens = self._tokenize(chunk.document_title)
                section_tokens = self._tokenize(chunk.section)

                # Weight title and section headings higher
                counter = Counter(tokens)
                for t in title_tokens:
                    counter[t] += 4
                for s in section_tokens:
                    counter[s] += 3

                self._chunk_tokens[chunk.chunk_id] = counter
                total_words += len(tokens)

                # Track document frequency for unique tokens
                unique_tokens = set(counter.keys())
                for tok in unique_tokens:
                    self._doc_freq[tok] += 1

        self._total_chunks = len(self._chunks)
        self._avg_chunk_length = (total_words / self._total_chunks) if self._total_chunks > 0 else 1.0
        self._last_indexed_at = datetime.now(timezone.utc).isoformat()

    def _chunk_document(self, doc: KnowledgeDocument) -> List[DocumentChunk]:
        """Splits markdown document into semantic sections based on headers."""
        raw_text = doc.text.strip()
        chunks: List[DocumentChunk] = []

        # Split on ## markdown section headers
        section_pattern = re.compile(r"(?=^##\s+)", re.MULTILINE)
        parts = section_pattern.split(raw_text)

        chunk_idx = 1
        for part in parts:
            part = part.strip()
            if not part:
                continue

            # Determine section title
            lines = part.split("\n")
            first_line = lines[0].strip()
            if first_line.startswith("## "):
                section_title = first_line.replace("## ", "").strip()
                body = "\n".join(lines[1:]).strip()
            elif first_line.startswith("# "):
                section_title = first_line.replace("# ", "").strip()
                body = "\n".join(lines[1:]).strip()
            else:
                section_title = f"Overview - Section {chunk_idx}"
                body = part

            chunk_id = f"{doc.document_id}-v{doc.version}-chunk{chunk_idx:02d}"
            chunk = DocumentChunk(
                chunk_id=chunk_id,
                document_id=doc.document_id,
                document_title=doc.title,
                version=doc.version,
                section=section_title,
                effective_from=doc.effective_from,
                effective_to=doc.effective_to,
                status=doc.status,
                domain=doc.domain,
                document_type=doc.document_type.value if isinstance(doc.document_type, DocumentType) else str(doc.document_type),
                text=body if body else first_line,
                metadata={
                    **doc.metadata,
                    "section": section_title,
                },
            )
            chunks.append(chunk)
            chunk_idx += 1

        if not chunks:
            # Fallback single chunk
            chunks.append(
                DocumentChunk(
                    chunk_id=f"{doc.document_id}-v{doc.version}-chunk01",
                    document_id=doc.document_id,
                    document_title=doc.title,
                    version=doc.version,
                    section="Full Document",
                    effective_from=doc.effective_from,
                    effective_to=doc.effective_to,
                    status=doc.status,
                    domain=doc.domain,
                    document_type=str(doc.document_type),
                    text=raw_text,
                    metadata=doc.metadata,
                )
            )

        return chunks

    def _tokenize(self, text: str) -> List[str]:
        """Normalizes and extracts words and alphanumeric tokens."""
        text_clean = re.sub(r"[^\w\s-]", " ", text.lower())
        tokens = [w.strip() for w in text_clean.split() if len(w.strip()) > 1]
        return tokens

    def search(
        self,
        query: str,
        domain: Optional[str] = None,
        document_type: Optional[str] = None,
        effective_date: Optional[str] = None,
        top_k: int = 5,
    ) -> List[KnowledgeSearchResult]:
        """Searches indexed policy chunks respecting effective dates, versions, and domain filters."""
        target_date = effective_date or "2026-09-30"
        q_tokens = self._tokenize(query)
        if not q_tokens:
            return []

        # Identify substantive non-generic keywords
        meaningful_tokens = [t for t in q_tokens if t not in STOP_WORDS]
        substantive_tokens = [t for t in meaningful_tokens if t not in GENERIC_TERMS]

        # Find documents that are active and effective on target_date
        effective_docs: Dict[str, KnowledgeDocument] = {}
        for doc in self._documents.values():
            if not doc.is_effective_on(target_date):
                continue
            if domain and self._normalize_domain(doc.domain) != self._normalize_domain(domain):
                continue
            if document_type:
                dt_str = doc.document_type.value if isinstance(doc.document_type, DocumentType) else str(doc.document_type)
                if dt_str.upper() != document_type.upper():
                    continue

            # Version resolution: if multiple versions effective, pick latest version
            base_id = doc.document_id.split("-v")[0]
            existing = effective_docs.get(base_id)
            if existing is None or doc.version > existing.version:
                effective_docs[base_id] = doc

        valid_doc_ids = {d.document_id for d in effective_docs.values()}

        # Filter candidate chunks belonging to valid effective documents
        candidate_chunks = [c for c in self._chunks if c.document_id in valid_doc_ids]
        if not candidate_chunks:
            return []

        # Score candidate chunks using BM25 scoring
        k1 = 1.5
        b = 0.75
        scores: List[Tuple[float, DocumentChunk]] = []

        q_lower = query.lower().strip()
        search_terms = meaningful_tokens if meaningful_tokens else q_tokens

        for chunk in candidate_chunks:
            c_tokens = self._chunk_tokens.get(chunk.chunk_id, Counter())
            # If query has distinctive substantive tokens, candidate chunk must match at least one
            if substantive_tokens and not any(c_tokens.get(st, 0) > 0 for st in substantive_tokens):
                continue

            chunk_len = sum(c_tokens.values())

            score = 0.0
            for term in search_terms:
                tf = c_tokens.get(term, 0)
                if tf == 0:
                    continue

                # Document frequency
                df = self._doc_freq.get(term, 1)
                # Smoothed BM25 IDF
                idf = math.log(1.0 + (self._total_chunks - df + 0.5) / (df + 0.5))

                # BM25 Term Weight
                term_score = idf * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * (chunk_len / self._avg_chunk_length)))
                score += term_score

            # Boost for phrase match in title or section
            if q_lower in chunk.section.lower():
                score += 5.0
            if q_lower in chunk.document_title.lower():
                score += 4.0

            if score > 0.05:
                scores.append((score, chunk))

        scores.sort(key=lambda x: x[0], reverse=True)

        # Normalize relevance scores relative to max score
        results: List[KnowledgeSearchResult] = []
        if scores:
            max_score = scores[0][0]
            for raw_score, chunk in scores[:top_k]:
                rel_score = round(min(1.0, raw_score / max_score if max_score > 0 else 0.0), 3)
                results.append(
                    KnowledgeSearchResult(
                        chunk_id=chunk.chunk_id,
                        document_id=chunk.document_id,
                        title=chunk.document_title,
                        version=chunk.version,
                        section=chunk.section,
                        relevance_score=rel_score,
                        effective_from=chunk.effective_from,
                        effective_to=chunk.effective_to,
                        excerpt=chunk.text[:500] + ("..." if len(chunk.text) > 500 else ""),
                        metadata=chunk.metadata,
                        domain=chunk.domain,
                        document_type=chunk.document_type,
                    )
                )

        return results

    def get_document(self, document_id: str) -> Optional[KnowledgeDocument]:
        """Returns complete document matching document_id."""
        return self._documents.get(document_id)

    def list_documents(self, status: Optional[str] = None) -> List[KnowledgeDocument]:
        """Lists registered documents, optionally filtered by status."""
        docs = list(self._documents.values())
        if status:
            docs = [d for d in docs if d.status.upper() == status.upper()]
        return docs

    def get_governance_summary(self) -> KnowledgeSummary:
        """Returns knowledge base inventory, version counts, and indexing health."""
        active = sum(1 for d in self._documents.values() if d.status == "ACTIVE")
        expired = sum(1 for d in self._documents.values() if d.status == "EXPIRED")
        superseded = sum(1 for d in self._documents.values() if d.status == "SUPERSEDED")

        return KnowledgeSummary(
            total_documents=len(self._documents),
            active_documents=active,
            expired_documents=expired,
            superseded_documents=superseded,
            indexed_chunks=len(self._chunks),
            last_indexed_at=self._last_indexed_at,
            retrieval_status="READY",
        )
