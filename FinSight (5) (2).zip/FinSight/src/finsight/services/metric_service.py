"""Metric Calculation & Comparison Service for FinSight.

Calculates foundational financial metrics strictly from canonical data with explicit handling
of edge cases (zero denominators, missing data), comparative analytics, and audit evidence.
"""

from calendar import monthrange
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from finsight.models.canonical import FinancialConcept
from finsight.models.metrics import (
    AgingBucket,
    CashMetricDetail,
    CFORatioGroup,
    CFORatiosResponse,
    ConcentrationItem,
    DuPontAnalysis,
    FinancialSummary,
    InventoryMetricDetail,
    MetricComparison,
    MetricHistoryPoint,
    MetricHistoryResponse,
    MetricResult,
    MetricStatus,
    MetricUnit,
    PayablesMetricDetail,
    ProfitabilityMetricDetail,
    ReceivablesMetricDetail,
    TrendDirection,
    UpcomingBucket,
    WorkingCapitalDetail,
)
from finsight.knowledge.metric_catalog import get_governed_metric_definition
from finsight.services.financial_engine import FinancialEngine
from finsight.config import format_currency, settings


GOVERNED_RATIO_THRESHOLDS: Dict[str, Dict[str, Any]] = {
    "current_ratio": {
        "healthy_min": 1.5,
        "attention_min": 1.0,
        "policy_basis": "Corporate liquidity policy mandates minimum 1.50x current ratio for operational resilience.",
    },
    "quick_ratio": {
        "healthy_min": 1.0,
        "attention_min": 0.8,
        "policy_basis": "Acid-test threshold requiring 1.00x quick assets to cover short-term liabilities without inventory liquidation.",
    },
    "debt_to_equity": {
        "healthy_max": 1.0,
        "attention_max": 2.0,
        "policy_basis": "Prudent leverage threshold capping debt at 1.00x total equity.",
    },
    "ar_turnover": {
        "healthy_min": 0.5,
        "policy_basis": "Monthly AR velocity threshold.",
    },
    "ap_turnover": {
        "healthy_max": 0.6,
        "policy_basis": "Disbursement velocity threshold balancing vendor goodwill with working capital preservation.",
    },
    "ebitda": {
        "healthy_min": 0.0,
        "policy_basis": "Positive operating earnings before D&A (EBIT/Operating Income).",
    },
    "roe": {
        "healthy_min": 0.0,
        "policy_basis": "Positive operating return on equity capital.",
    },
}


class MetricService:
    """Computes deterministic financial metrics with period-over-period comparisons."""

    def __init__(self, engine: FinancialEngine, source_name: str = "canonical_ledger"):
        self.engine = engine
        self.source_name = source_name

    def _get_days_in_period(self, period_str: str) -> int:
        """Returns number of days in period 'YYYY-MM'."""
        try:
            year, month = map(int, period_str.split("-"))
            _, days = monthrange(year, month)
            return days
        except Exception:
            return 30

    def _get_period_end_date(self, period_str: str) -> date:
        """Returns date object representing the last calendar day of period 'YYYY-MM'."""
        year, month = map(int, period_str.split("-"))
        _, days = monthrange(year, month)
        return date(year, month, days)

    def _get_previous_period(self, period_str: str) -> Optional[str]:
        """Returns immediate prior month 'YYYY-MM'."""
        try:
            year, month = map(int, period_str.split("-"))
            if month == 1:
                return f"{year - 1}-12"
            return f"{year}-{month - 1:02d}"
        except Exception:
            return None

    def _compute_comparison(
        self,
        current_val: Optional[float],
        previous_val: Optional[float],
        previous_period: str,
        higher_is_better: bool = True,
    ) -> Optional[MetricComparison]:
        """Builds standardized period-over-period comparison."""
        if current_val is None or previous_val is None:
            return None

        abs_diff = round(current_val - previous_val, 4)
        pct_diff = round(((current_val - previous_val) / abs(previous_val) * 100.0), 2) if abs(previous_val) > 1e-6 else None

        if abs(abs_diff) < 1e-4:
            trend = TrendDirection.FLAT
            is_fav = True
        elif abs_diff > 0:
            trend = TrendDirection.INCREASING
            is_fav = higher_is_better
        else:
            trend = TrendDirection.DECREASING
            is_fav = not higher_is_better

        return MetricComparison(
            previous_period=previous_period,
            previous_value=round(previous_val, 2),
            absolute_change=round(abs_diff, 2),
            percentage_change=pct_diff,
            trend=trend,
            is_favorable=is_fav,
        )

    # -------------------------------------------------------------------------
    # CASH METRIC
    # -------------------------------------------------------------------------

    def calculate_cash_position(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates total Cash Position at period end or reference date."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)

        cash_bal, breakdown = self.engine.get_cash_position(target_date)

        comparison = None
        if compare_with_previous:
            prev_p = self._get_previous_period(target_period)
            if prev_p and prev_p in self.engine.available_periods:
                prev_date = self._get_period_end_date(prev_p)
                prev_cash, _ = self.engine.get_cash_position(prev_date)
                comparison = self._compute_comparison(cash_bal, prev_cash, prev_p, higher_is_better=True)

        return MetricResult(
            metric_name="cash_position",
            display_name="Cash Position",
            value=cash_bal,
            formatted_value=format_currency(cash_bal),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            comparison_period=comparison.previous_period if comparison else None,
            status=MetricStatus.CALCULATED,
            inputs={"as_of_date": target_date.isoformat(), "gl_accounts": [b["gl_account"] for b in breakdown]},
            definition="Sum of all GL accounts mapped to CASH (Operating Checking, Payroll, Reserve accounts).",
            source=self.source_name,
            comparison=comparison,
            dimensions={"bank_accounts": breakdown},
        )

    # -------------------------------------------------------------------------
    # WORKING CAPITAL METRICS
    # -------------------------------------------------------------------------

    def calculate_working_capital(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> WorkingCapitalDetail:
        """Calculates Current Assets, Current Liabilities, and Net Working Capital."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)

        wc_comps = self.engine.get_working_capital_components(target_date)

        prev_comps = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_comps = self.engine.get_working_capital_components(prev_date)

        # Current Assets Metric
        ca_comp = self._compute_comparison(
            wc_comps["total_current_assets"],
            prev_comps["total_current_assets"] if prev_comps else None,
            prev_p or "",
            higher_is_better=True,
        )
        ca_metric = MetricResult(
            metric_name="current_assets",
            display_name="Total Current Assets",
            value=wc_comps["total_current_assets"],
            formatted_value=format_currency(wc_comps['total_current_assets']),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"cash": wc_comps["cash"], "ar": wc_comps["accounts_receivable"], "inventory": wc_comps["inventory"]},
            definition="Total assets convertible to cash within 12 months (Cash + AR + Inventory + Other CA).",
            source=self.source_name,
            comparison=ca_comp,
        )

        # Current Liabilities Metric
        cl_comp = self._compute_comparison(
            wc_comps["total_current_liabilities"],
            prev_comps["total_current_liabilities"] if prev_comps else None,
            prev_p or "",
            higher_is_better=False,
        )
        cl_metric = MetricResult(
            metric_name="current_liabilities",
            display_name="Total Current Liabilities",
            value=wc_comps["total_current_liabilities"],
            formatted_value=format_currency(wc_comps['total_current_liabilities']),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"ap": wc_comps["accounts_payable"], "short_debt": wc_comps["short_term_debt"]},
            definition="Obligations due within 12 months (AP + Short-term Debt + Accrued Liabilities).",
            source=self.source_name,
            comparison=cl_comp,
        )

        # Net Working Capital
        nwc_comp = self._compute_comparison(
            wc_comps["net_working_capital"],
            prev_comps["net_working_capital"] if prev_comps else None,
            prev_p or "",
            higher_is_better=True,
        )
        nwc_metric = MetricResult(
            metric_name="net_working_capital",
            display_name="Net Working Capital",
            value=wc_comps["net_working_capital"],
            formatted_value=format_currency(wc_comps['net_working_capital']),

            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"current_assets": wc_comps["total_current_assets"], "current_liabilities": wc_comps["total_current_liabilities"]},
            definition="Current Assets minus Current Liabilities.",
            source=self.source_name,
            comparison=nwc_comp,
        )

        return WorkingCapitalDetail(
            current_assets=ca_metric,
            current_liabilities=cl_metric,
            net_working_capital=nwc_metric,
            components=wc_comps,
        )

    # -------------------------------------------------------------------------
    # RECEIVABLES METRICS
    # -------------------------------------------------------------------------

    def calculate_receivables(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> ReceivablesMetricDetail:
        """Calculates AR, Overdue AR, Overdue AR %, and DSO."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        days_in_period = self._get_days_in_period(target_period)

        ar_summary = self.engine.get_ar_summary(target_date)
        pnl = self.engine.get_pnl_for_period(target_period)
        revenue = pnl["revenue"]

        # Comparative period data
        prev_summary = None
        prev_pnl = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_summary = self.engine.get_ar_summary(prev_date)
            prev_pnl = self.engine.get_pnl_for_period(prev_p)

        # 1. Accounts Receivable Metric
        ar_comp = self._compute_comparison(
            ar_summary["total_open_ar"],
            prev_summary["total_open_ar"] if prev_summary else None,
            prev_p or "",
            higher_is_better=False,
        )
        ar_metric = MetricResult(
            metric_name="accounts_receivable",
            display_name="Accounts Receivable (AR)",
            value=ar_summary["total_open_ar"],
            formatted_value=format_currency(ar_summary['total_open_ar']),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"as_of_date": target_date.isoformat()},
            definition="Total outstanding customer invoices in subledger as of reference date.",
            source=self.source_name,
            comparison=ar_comp,
        )

        # 2. Overdue AR Metric
        overdue_comp = self._compute_comparison(
            ar_summary["total_overdue_ar"],
            prev_summary["total_overdue_ar"] if prev_summary else None,
            prev_p or "",
            higher_is_better=False,
        )
        overdue_metric = MetricResult(
            metric_name="overdue_ar",
            display_name="Overdue Accounts Receivable",
            value=ar_summary["total_overdue_ar"],
            formatted_value=format_currency(ar_summary['total_overdue_ar']),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"total_overdue": ar_summary["total_overdue_ar"]},
            definition="Sum of open AR invoices whose payment due date is past the reference date.",
            source=self.source_name,
            comparison=overdue_comp,
        )

        # 3. Overdue AR %
        overdue_pct_val = ar_summary["overdue_percentage"]
        od_pct_status = MetricStatus.CALCULATED if ar_summary["total_open_ar"] > 0 else MetricStatus.NOT_APPLICABLE
        od_pct_comp = self._compute_comparison(
            overdue_pct_val,
            prev_summary["overdue_percentage"] if prev_summary else None,
            prev_p or "",
            higher_is_better=False,
        )
        overdue_pct_metric = MetricResult(
            metric_name="overdue_ar_percent",
            display_name="Overdue AR Percentage",
            value=overdue_pct_val if od_pct_status == MetricStatus.CALCULATED else None,
            formatted_value=f"{overdue_pct_val:.1f}%" if od_pct_status == MetricStatus.CALCULATED else "N/A",
            unit=MetricUnit.PERCENTAGE,
            currency=self.engine.company.currency,
            period=target_period,
            status=od_pct_status,
            inputs={"overdue_ar": ar_summary["total_overdue_ar"], "total_ar": ar_summary["total_open_ar"]},
            definition="(Overdue AR / Total AR) * 100",
            source=self.source_name,
            comparison=od_pct_comp,
        )

        # 4. DSO Calculation
        if revenue <= 0:
            dso_metric = MetricResult(
                metric_name="dso",
                display_name="Days Sales Outstanding (DSO)",
                value=None,
                formatted_value="INSUFFICIENT_DATA",
                unit=MetricUnit.DAYS,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if revenue == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Revenue for period is zero or negative; cannot calculate DSO.",
                inputs={"ending_ar": ar_summary["total_open_ar"], "credit_sales": revenue, "period_days": days_in_period},
                definition="(Ending AR / Period Credit Sales) * Days in Period",
                source=self.source_name,
            )
        else:
            dso_val = round((ar_summary["total_open_ar"] / revenue) * days_in_period, 1)
            prev_dso_val = None
            if prev_summary and prev_pnl and prev_pnl["revenue"] > 0:
                prev_dso_val = round((prev_summary["total_open_ar"] / prev_pnl["revenue"]) * self._get_days_in_period(prev_p or ""), 1)

            dso_comp = self._compute_comparison(dso_val, prev_dso_val, prev_p or "", higher_is_better=False)
            dso_metric = MetricResult(
                metric_name="dso",
                display_name="Days Sales Outstanding (DSO)",
                value=dso_val,
                formatted_value=f"{dso_val:.1f} days",
                unit=MetricUnit.DAYS,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.CALCULATED,
                inputs={"ending_ar": ar_summary["total_open_ar"], "credit_sales": revenue, "period_days": days_in_period},
                definition="(Ending AR / Period Credit Sales) * Days in Period",
                source=self.source_name,
                comparison=dso_comp,
            )

        aging_buckets = [AgingBucket(**b) for b in ar_summary["aging_buckets"]]
        top_od_custs = [ConcentrationItem(**c) for c in ar_summary["top_overdue_customers"]]
        top_all_custs = [ConcentrationItem(**c) for c in ar_summary["customer_concentration"]]
        overdue_invoices = self.engine.get_overdue_invoices(target_date)

        return ReceivablesMetricDetail(
            accounts_receivable=ar_metric,
            overdue_ar=overdue_metric,
            overdue_ar_percent=overdue_pct_metric,
            dso=dso_metric,
            aging_schedule=aging_buckets,
            top_overdue_customers=top_od_custs,
            customer_concentration=top_all_custs,
            overdue_invoices=overdue_invoices,
        )

    # -------------------------------------------------------------------------
    # PAYABLES METRICS
    # -------------------------------------------------------------------------

    def calculate_payables(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> PayablesMetricDetail:
        """Calculates AP, Upcoming Payables (7d), Overdue Payables, and DPO."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        days_in_period = self._get_days_in_period(target_period)

        ap_summary = self.engine.get_ap_summary(target_date)
        pnl = self.engine.get_pnl_for_period(target_period)
        cogs = pnl["cogs"]

        prev_summary = None
        prev_pnl = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_summary = self.engine.get_ap_summary(prev_date)
            prev_pnl = self.engine.get_pnl_for_period(prev_p)

        # 1. Accounts Payable
        ap_comp = self._compute_comparison(
            ap_summary["total_open_ap"],
            prev_summary["total_open_ap"] if prev_summary else None,
            prev_p or "",
            higher_is_better=False,
        )
        ap_metric = MetricResult(
            metric_name="accounts_payable",
            display_name="Accounts Payable (AP)",
            value=ap_summary["total_open_ap"],
            formatted_value=format_currency(ap_summary['total_open_ap']),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"as_of_date": target_date.isoformat()},
            definition="Total outstanding supplier liability in subledger.",
            source=self.source_name,
            comparison=ap_comp,
        )

        # 2. Upcoming Payables 7 Days
        up_comp = self._compute_comparison(
            ap_summary["upcoming_payables_7d"],
            prev_summary["upcoming_payables_7d"] if prev_summary else None,
            prev_p or "",
            higher_is_better=False,
        )
        up_metric = MetricResult(
            metric_name="upcoming_payables_7d",
            display_name="Upcoming Payables (7 Days)",
            value=ap_summary["upcoming_payables_7d"],
            formatted_value=format_currency(ap_summary['upcoming_payables_7d']),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"upcoming_schedule": ap_summary["upcoming_schedule"]},
            definition="Payables due today or within the next 7 calendar days.",
            source=self.source_name,
            comparison=up_comp,
        )

        # 3. Overdue Payables
        od_ap_comp = self._compute_comparison(
            ap_summary["total_overdue_ap"],
            prev_summary["total_overdue_ap"] if prev_summary else None,
            prev_p or "",
            higher_is_better=False,
        )
        od_ap_metric = MetricResult(
            metric_name="overdue_payables",
            display_name="Overdue Payables",
            value=ap_summary["total_overdue_ap"],
            formatted_value=format_currency(ap_summary['total_overdue_ap']),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"overdue_amount": ap_summary["total_overdue_ap"]},
            definition="Open supplier invoices past payment terms.",
            source=self.source_name,
            comparison=od_ap_comp,
        )

        # 4. DPO
        if cogs <= 0:
            dpo_metric = MetricResult(
                metric_name="dpo",
                display_name="Days Payables Outstanding (DPO — COGS Proxy Method)",
                value=None,
                formatted_value="INSUFFICIENT_DATA",
                unit=MetricUnit.DAYS,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if cogs == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="COGS for period is zero or negative; cannot calculate DPO.",
                inputs={"ending_ap": ap_summary["total_open_ap"], "cogs": cogs, "period_days": days_in_period},
                definition="(Ending AP / Period COGS) * Days in Period",
                source=self.source_name,
            )
        else:
            dpo_val = round((ap_summary["total_open_ap"] / cogs) * days_in_period, 1)
            prev_dpo_val = None
            if prev_summary and prev_pnl and prev_pnl["cogs"] > 0:
                prev_dpo_val = round((prev_summary["total_open_ap"] / prev_pnl["cogs"]) * self._get_days_in_period(prev_p or ""), 1)

            dpo_comp = self._compute_comparison(dpo_val, prev_dpo_val, prev_p or "", higher_is_better=True)
            dpo_metric = MetricResult(
                metric_name="dpo",
                display_name="Days Payables Outstanding (DPO — COGS Proxy Method)",
                value=dpo_val,
                formatted_value=f"{dpo_val:.1f} days",
                unit=MetricUnit.DAYS,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.CALCULATED,
                inputs={
                    "ending_ap": ap_summary["total_open_ap"],
                    "cogs": cogs,
                    "period_days": days_in_period,
                    "policy_interpretation": "Higher DPO preserves near-term liquidity, but extending beyond contractual vendor terms introduces credit and supply chain friction.",
                },
                definition="(Ending AP / Period COGS) * Days in Period",
                source=self.source_name,
                comparison=dpo_comp,
            )

        upcoming_schedule = [UpcomingBucket(**s) for s in ap_summary["upcoming_schedule"]]
        top_vendors = [ConcentrationItem(**v) for v in ap_summary["top_vendors_due"]]
        upcoming_invoices = self.engine.get_upcoming_invoices_7d(target_date)

        return PayablesMetricDetail(
            accounts_payable=ap_metric,
            upcoming_payables_7d=up_metric,
            overdue_payables=od_ap_metric,
            dpo=dpo_metric,
            upcoming_schedule=upcoming_schedule,
            top_vendors_due=top_vendors,
            upcoming_invoices=upcoming_invoices,
        )

    # -------------------------------------------------------------------------
    # INVENTORY METRICS
    # -------------------------------------------------------------------------

    def calculate_inventory(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> InventoryMetricDetail:
        """Calculates Inventory Value, DIO, and growth comparison against sales."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        days_in_period = self._get_days_in_period(target_period)

        inv_val = self.engine.calculate_balance_as_of(FinancialConcept.INVENTORY, target_date)
        pnl = self.engine.get_pnl_for_period(target_period)
        cogs = pnl["cogs"]
        revenue = pnl["revenue"]

        prev_inv = None
        prev_pnl = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_inv = self.engine.calculate_balance_as_of(FinancialConcept.INVENTORY, prev_date)
            prev_pnl = self.engine.get_pnl_for_period(prev_p)

        # 1. Inventory Value
        inv_comp = self._compute_comparison(inv_val, prev_inv, prev_p or "", higher_is_better=False)
        inv_metric = MetricResult(
            metric_name="inventory_value",
            display_name="Inventory Balance",
            value=inv_val,
            formatted_value=format_currency(inv_val),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"as_of_date": target_date.isoformat()},
            definition="Total book value of raw materials and finished goods inventory on balance sheet.",
            source=self.source_name,
            comparison=inv_comp,
        )

        # 2. DIO Calculation
        if cogs <= 0:
            dio_metric = MetricResult(
                metric_name="dio",
                display_name="Days Inventory Outstanding (DIO)",
                value=None,
                formatted_value="INSUFFICIENT_DATA",
                unit=MetricUnit.DAYS,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if cogs == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="COGS for period is zero or negative; cannot calculate DIO.",
                inputs={"ending_inventory": inv_val, "cogs": cogs, "period_days": days_in_period},
                definition="(Ending Inventory / Period COGS) * Days in Period",
                source=self.source_name,
            )
        else:
            dio_val = round((inv_val / cogs) * days_in_period, 1)
            prev_dio = None
            if prev_inv is not None and prev_pnl and prev_pnl["cogs"] > 0:
                prev_dio = round((prev_inv / prev_pnl["cogs"]) * self._get_days_in_period(prev_p or ""), 1)

            dio_comp = self._compute_comparison(dio_val, prev_dio, prev_p or "", higher_is_better=False)
            dio_metric = MetricResult(
                metric_name="dio",
                display_name="Days Inventory Outstanding (DIO)",
                value=dio_val,
                formatted_value=f"{dio_val:.1f} days",
                unit=MetricUnit.DAYS,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.CALCULATED,
                inputs={"ending_inventory": inv_val, "cogs": cogs, "period_days": days_in_period},
                definition="(Ending Inventory / Period COGS) * Days in Period",
                source=self.source_name,
                comparison=dio_comp,
            )

        # 3. Inventory to Sales Ratio
        ratio_val = round(inv_val / revenue, 2) if revenue > 0 else None
        ratio_metric = MetricResult(
            metric_name="inventory_to_sales",
            display_name="Inventory to Monthly Sales Ratio",
            value=ratio_val,
            formatted_value=f"{ratio_val:.2f}x" if ratio_val is not None else "N/A",
            unit=MetricUnit.RATIO,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED if ratio_val is not None else MetricStatus.ZERO_DENOMINATOR,
            inputs={"inventory": inv_val, "monthly_revenue": revenue},
            definition="Ending Inventory / Monthly Revenue",
            source=self.source_name,
        )

        # Growth rates
        inv_growth = round(((inv_val - prev_inv) / prev_inv * 100.0), 2) if (prev_inv and prev_inv > 0) else None
        sales_growth = round(((revenue - prev_pnl["revenue"]) / prev_pnl["revenue"] * 100.0), 2) if (prev_pnl and prev_pnl["revenue"] > 0) else None

        return InventoryMetricDetail(
            inventory_value=inv_metric,
            dio=dio_metric,
            inventory_to_sales_ratio=ratio_metric,
            inventory_growth_rate=inv_growth,
            sales_growth_rate=sales_growth,
        )

    # -------------------------------------------------------------------------
    # CASH CONVERSION CYCLE (CCC)
    # -------------------------------------------------------------------------

    def calculate_ccc(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Cash Conversion Cycle (CCC = DSO + DIO - DPO)."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)

        ar = self.calculate_receivables(target_period, target_date, compare_with_previous=False)
        inv = self.calculate_inventory(target_period, target_date, compare_with_previous=False)
        ap = self.calculate_payables(target_period, target_date, compare_with_previous=False)

        dso_val = ar.dso.value
        dio_val = inv.dio.value
        dpo_val = ap.dpo.value

        if dso_val is None or dio_val is None or dpo_val is None:
            return MetricResult(
                metric_name="ccc",
                display_name="Cash Conversion Cycle (CCC)",
                value=None,
                formatted_value="INSUFFICIENT_DATA",
                unit=MetricUnit.DAYS,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.INSUFFICIENT_DATA,
                status_message="Requires valid DSO, DIO, and DPO calculations.",
                definition="DSO + DIO - DPO",
                source=self.source_name,
            )

        ccc_val = round(dso_val + dio_val - dpo_val, 1)

        prev_ccc_val = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_ar = self.calculate_receivables(prev_p, prev_date, compare_with_previous=False)
            prev_inv = self.calculate_inventory(prev_p, prev_date, compare_with_previous=False)
            prev_ap = self.calculate_payables(prev_p, prev_date, compare_with_previous=False)
            if prev_ar.dso.value is not None and prev_inv.dio.value is not None and prev_ap.dpo.value is not None:
                prev_ccc_val = round(prev_ar.dso.value + prev_inv.dio.value - prev_ap.dpo.value, 1)

        comp = self._compute_comparison(ccc_val, prev_ccc_val, prev_p or "", higher_is_better=False)

        return MetricResult(
            metric_name="ccc",
            display_name="Cash Conversion Cycle (CCC)",
            value=ccc_val,
            formatted_value=f"{ccc_val:.1f} days",
            unit=MetricUnit.DAYS,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"dso": dso_val, "dio": dio_val, "dpo": dpo_val},
            definition="DSO + DIO - DPO (Days taken to convert investments in inventory and other resources into cash inflows).",
            source=self.source_name,
            comparison=comp,
        )

    # -------------------------------------------------------------------------
    # PROFITABILITY METRICS
    # -------------------------------------------------------------------------

    def calculate_profitability(
        self,
        period: Optional[str] = None,
        compare_with_previous: bool = True,
    ) -> ProfitabilityMetricDetail:
        """Calculates Revenue, COGS, Gross Profit, and Gross Margin %."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        pnl = self.engine.get_pnl_for_period(target_period)
        revenue = pnl["revenue"]
        cogs = pnl["cogs"]
        gp = pnl["gross_profit"]

        prev_pnl = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_pnl = self.engine.get_pnl_for_period(prev_p)

        # 1. Revenue
        rev_comp = self._compute_comparison(revenue, prev_pnl["revenue"] if prev_pnl else None, prev_p or "", higher_is_better=True)
        rev_metric = MetricResult(
            metric_name="revenue",
            display_name="Total Revenue",
            value=revenue,
            formatted_value=format_currency(revenue),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"period": target_period},
            definition="Total credit postings to GL revenue accounts in period.",
            source=self.source_name,
            comparison=rev_comp,
        )

        # 2. COGS
        cogs_comp = self._compute_comparison(cogs, prev_pnl["cogs"] if prev_pnl else None, prev_p or "", higher_is_better=False)
        cogs_metric = MetricResult(
            metric_name="cogs",
            display_name="Cost of Goods Sold (COGS)",
            value=cogs,
            formatted_value=format_currency(cogs),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"period": target_period},
            definition="Direct product and labor costs incurred in generating period revenue.",
            source=self.source_name,
            comparison=cogs_comp,
        )

        # 3. Gross Profit
        gp_comp = self._compute_comparison(gp, prev_pnl["gross_profit"] if prev_pnl else None, prev_p or "", higher_is_better=True)
        gp_metric = MetricResult(
            metric_name="gross_profit",
            display_name="Gross Profit",
            value=gp,
            formatted_value=format_currency(gp),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"revenue": revenue, "cogs": cogs},
            definition="Revenue minus Cost of Goods Sold.",
            source=self.source_name,
            comparison=gp_comp,
        )

        # 4. Gross Margin %
        if revenue <= 0:
            gm_metric = MetricResult(
                metric_name="gross_margin_percent",
                display_name="Gross Margin Percentage",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if revenue == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.PERCENTAGE,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if revenue == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Revenue for period is zero or negative; cannot calculate Gross Margin %.",
                inputs={"gross_profit": gp, "revenue": revenue},
                definition="(Gross Profit / Revenue) * 100",
                source=self.source_name,
            )
        else:
            gm_pct = round((gp / revenue) * 100.0, 2)
            prev_gm_pct = None
            if prev_pnl and prev_pnl["revenue"] > 0:
                prev_gm_pct = round((prev_pnl["gross_profit"] / prev_pnl["revenue"]) * 100.0, 2)

            gm_comp = self._compute_comparison(gm_pct, prev_gm_pct, prev_p or "", higher_is_better=True)
            gm_metric = MetricResult(
                metric_name="gross_margin_percent",
                display_name="Gross Margin Percentage",
                value=gm_pct,
                formatted_value=f"{gm_pct:.2f}%",
                unit=MetricUnit.PERCENTAGE,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.CALCULATED,
                inputs={"gross_profit": gp, "revenue": revenue},
                definition="(Gross Profit / Revenue) * 100",
                source=self.source_name,
                comparison=gm_comp,
            )

        breakdowns = self.engine.get_profitability_breakdowns(target_period)
        top_custs = [ConcentrationItem(**c) for c in breakdowns["top_customers_by_revenue"]]

        return ProfitabilityMetricDetail(
            revenue=rev_metric,
            cogs=cogs_metric,
            gross_profit=gp_metric,
            gross_margin_percent=gm_metric,
            top_customers_by_revenue=top_custs,
            product_group_margins=breakdowns["product_group_margins"],
        )

    # -------------------------------------------------------------------------
    # SPRINT 11: CFO RATIOS ENGINE
    # -------------------------------------------------------------------------

    def calculate_current_ratio(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Current Ratio = Total Current Assets / Total Current Liabilities."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        wc_comps = self.engine.get_working_capital_components(target_date)
        ca = wc_comps["total_current_assets"]
        cl = wc_comps["total_current_liabilities"]

        if cl <= 0:
            return MetricResult(
                metric_name="current_ratio",
                display_name="Current Ratio",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if cl == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.RATIO,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if cl == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Current Liabilities is zero or negative; division by zero is strictly prohibited.",
                inputs={"current_assets": ca, "current_liabilities": cl},
                definition="Total Current Assets / Total Current Liabilities",
                formula_human="Total current assets divided by total current liabilities",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        cr_val = round(ca / cl, 2)
        prev_cr_val = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_comps = self.engine.get_working_capital_components(prev_date)
            if prev_comps["total_current_liabilities"] > 0:
                prev_cr_val = round(prev_comps["total_current_assets"] / prev_comps["total_current_liabilities"], 2)

        comp = self._compute_comparison(cr_val, prev_cr_val, prev_p or "", higher_is_better=True)
        health = "HEALTHY" if cr_val >= 1.5 else ("ATTENTION" if cr_val >= 1.0 else "CRITICAL")

        return MetricResult(
            metric_name="current_ratio",
            display_name="Current Ratio",
            value=cr_val,
            formatted_value=f"{cr_val:.2f}x",
            unit=MetricUnit.RATIO,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"current_assets": ca, "current_liabilities": cl},
            definition="Total Current Assets / Total Current Liabilities",
            formula_human="Total current assets divided by total current liabilities",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_quick_ratio(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Quick Ratio = (Cash + Trade AR + Other Receivables) / Total Current Liabilities."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        wc_comps = self.engine.get_working_capital_components(target_date)
        cash = wc_comps["cash"]
        trade_ar = wc_comps["trade_receivables"]
        other_ar = wc_comps["other_receivables"]
        quick_assets = round(cash + trade_ar + other_ar, 2)
        cl = wc_comps["total_current_liabilities"]

        if cl <= 0:
            return MetricResult(
                metric_name="quick_ratio",
                display_name="Quick Ratio (Acid Test)",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if cl == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.RATIO,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if cl == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Current Liabilities is zero or negative; division by zero is strictly prohibited.",
                inputs={"quick_assets": quick_assets, "inventory": wc_comps["inventory"], "current_liabilities": cl},
                definition="(Cash + Trade AR + Other Receivables) / Total Current Liabilities",
                formula_human="Liquid cash and trade receivables divided by total current liabilities",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        qr_val = round(quick_assets / cl, 2)
        prev_qr_val = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_comps = self.engine.get_working_capital_components(prev_date)
            if prev_comps["total_current_liabilities"] > 0:
                prev_qa = round(prev_comps["cash"] + prev_comps["trade_receivables"] + prev_comps["other_receivables"], 2)
                prev_qr_val = round(prev_qa / prev_comps["total_current_liabilities"], 2)

        comp = self._compute_comparison(qr_val, prev_qr_val, prev_p or "", higher_is_better=True)
        health = "HEALTHY" if qr_val >= 1.0 else ("ATTENTION" if qr_val >= 0.8 else "CRITICAL")

        return MetricResult(
            metric_name="quick_ratio",
            display_name="Quick Ratio (Acid Test)",
            value=qr_val,
            formatted_value=f"{qr_val:.2f}x",
            unit=MetricUnit.RATIO,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={
                "cash": cash,
                "trade_receivables": trade_ar,
                "other_receivables": other_ar,
                "inventory": wc_comps["inventory"],
                "quick_assets": quick_assets,
                "current_liabilities": cl,
            },
            definition="(Cash + Trade AR + Other Receivables) / Total Current Liabilities",
            formula_human="Liquid cash and trade receivables divided by total current liabilities",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_ar_turnover(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates AR Turnover = Period Credit Sales / Trade Accounts Receivable."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        pnl = self.engine.get_pnl_for_period(target_period)
        revenue = pnl["revenue"]
        ar_summary = self.engine.get_ar_summary(target_date)
        trade_ar = ar_summary["total_open_ar"]

        if trade_ar <= 0:
            return MetricResult(
                metric_name="ar_turnover",
                display_name="Accounts Receivable Turnover",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if trade_ar == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.RATIO,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if trade_ar == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Trade Accounts Receivable is zero or negative; cannot calculate AR turnover.",
                inputs={"credit_sales": revenue, "revenue": revenue, "trade_ar": trade_ar},
                definition="Credit Sales / Trade Accounts Receivable",
                formula_human="Total period sales divided by ending trade accounts receivable",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        art_val = round(revenue / trade_ar, 2)
        prev_art_val = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_pnl = self.engine.get_pnl_for_period(prev_p)
            prev_ar = self.engine.get_ar_summary(prev_date)["total_open_ar"]
            if prev_ar > 0:
                prev_art_val = round(prev_pnl["revenue"] / prev_ar, 2)

        comp = self._compute_comparison(art_val, prev_art_val, prev_p or "", higher_is_better=True)
        health = "HEALTHY" if art_val >= 0.5 else "ATTENTION"

        return MetricResult(
            metric_name="ar_turnover",
            display_name="Accounts Receivable Turnover",
            value=art_val,
            formatted_value=f"{art_val:.2f}x",
            unit=MetricUnit.RATIO,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"credit_sales": revenue, "revenue": revenue, "trade_ar": trade_ar},
            definition="Credit Sales / Trade Accounts Receivable",
            formula_human="Total period sales divided by ending trade accounts receivable",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_ap_turnover(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates AP Turnover = Period COGS / Trade Accounts Payable."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        pnl = self.engine.get_pnl_for_period(target_period)
        cogs = pnl["cogs"]
        ap_summary = self.engine.get_ap_summary(target_date)
        trade_ap = ap_summary["total_open_ap"]

        if trade_ap <= 0:
            return MetricResult(
                metric_name="ap_turnover",
                display_name="Accounts Payable Turnover",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if trade_ap == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.RATIO,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if trade_ap == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Trade Accounts Payable is zero or negative; cannot calculate AP turnover.",
                inputs={"cogs": cogs, "trade_ap": trade_ap},
                definition="Cost of Goods Sold / Trade Accounts Payable",
                formula_human="Cost of Goods Sold divided by ending trade accounts payable",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        apt_val = round(cogs / trade_ap, 2)
        prev_apt_val = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_pnl = self.engine.get_pnl_for_period(prev_p)
            prev_ap = self.engine.get_ap_summary(prev_date)["total_open_ap"]
            if prev_ap > 0:
                prev_apt_val = round(prev_pnl["cogs"] / prev_ap, 2)

        comp = self._compute_comparison(apt_val, prev_apt_val, prev_p or "", higher_is_better=False)
        health = "HEALTHY" if apt_val <= 0.6 else "ATTENTION"

        return MetricResult(
            metric_name="ap_turnover",
            display_name="Accounts Payable Turnover",
            value=apt_val,
            formatted_value=f"{apt_val:.2f}x",
            unit=MetricUnit.RATIO,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"cogs": cogs, "trade_ap": trade_ap},
            definition="Cost of Goods Sold / Trade Accounts Payable",
            formula_human="Cost of Goods Sold divided by ending trade accounts payable",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_ebitda(
        self,
        period: Optional[str] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Operating Income / EBIT = Gross Profit - Operating Expenses (SG&A).
        
        Per FinSight accounting governance (Option B): Since Depreciation and Amortization (D&A)
        are not separately ledgered in the chart of accounts, this metric represents Operating Income / EBIT.
        """
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        pnl = self.engine.get_pnl_for_period(target_period)
        gp = pnl["gross_profit"]
        opex = pnl.get("opex", 0.0)
        ebitda_val = round(gp - opex, 2)

        prev_ebitda = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_pnl = self.engine.get_pnl_for_period(prev_p)
            prev_ebitda = round(prev_pnl["gross_profit"] - prev_pnl.get("opex", 0.0), 2)

        comp = self._compute_comparison(ebitda_val, prev_ebitda, prev_p or "", higher_is_better=True)
        health = "HEALTHY" if ebitda_val > 0 else "CRITICAL"

        return MetricResult(
            metric_name="ebitda",
            display_name="Operating Income (EBIT)",
            value=ebitda_val,
            formatted_value=format_currency(ebitda_val),
            unit=MetricUnit.CURRENCY,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"gross_profit": gp, "opex": opex, "revenue": pnl["revenue"], "cogs": pnl["cogs"], "da_tracked_separately": False},
            definition="Gross Profit - Operating Expenses (SG&A) [EBIT / Operating Income; D&A not separately ledgered]",
            formula_human="Operating profit before tax and non-operating items (D&A not separately ledgered)",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_roe(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Operating Return on Equity (Operating ROE) = (Net Operating Income / Total Equity) * 100."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        pnl = self.engine.get_pnl_for_period(target_period)
        operating_income = pnl["gross_profit"] - pnl.get("opex", 0.0)
        equity = self.engine.calculate_balance_as_of(FinancialConcept.EQUITY, target_date)

        if equity <= 0:
            return MetricResult(
                metric_name="roe",
                display_name="Operating Return on Equity (ROE)",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if equity == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.PERCENTAGE,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if equity == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Total Equity is zero or negative; division by zero is strictly prohibited.",
                inputs={"operating_income": operating_income, "equity": equity},
                definition="(Net Operating Income / Total Equity) * 100 [Governed Operating ROE]",
                formula_human="Net operating income divided by total shareholders' equity multiplied by 100 (Governed Operating ROE)",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        roe_val = round((operating_income / equity) * 100.0, 2)
        prev_roe = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_pnl = self.engine.get_pnl_for_period(prev_p)
            prev_oi = prev_pnl["gross_profit"] - prev_pnl.get("opex", 0.0)
            prev_eq = self.engine.calculate_balance_as_of(FinancialConcept.EQUITY, prev_date)
            if prev_eq > 0:
                prev_roe = round((prev_oi / prev_eq) * 100.0, 2)

        comp = self._compute_comparison(roe_val, prev_roe, prev_p or "", higher_is_better=True)
        health = "HEALTHY" if roe_val > 0 else "ATTENTION"

        return MetricResult(
            metric_name="roe",
            display_name="Operating Return on Equity (ROE)",
            value=roe_val,
            formatted_value=f"{roe_val:.2f}%",
            unit=MetricUnit.PERCENTAGE,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"operating_income": operating_income, "equity": equity},
            definition="(Net Operating Income / Total Equity) * 100 [Governed Operating ROE]",
            formula_human="Net operating income divided by total shareholders' equity multiplied by 100 (Governed Operating ROE)",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_debt_to_equity(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Debt-to-Equity Ratio = (Short-Term Debt + Long-Term Debt) / Total Equity."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)
        short_debt = self.engine.calculate_balance_as_of(FinancialConcept.SHORT_TERM_DEBT, target_date)
        long_debt = self.engine.calculate_balance_as_of(FinancialConcept.LONG_TERM_LIABILITY, target_date)
        total_debt = round(short_debt + long_debt, 2)
        equity = self.engine.calculate_balance_as_of(FinancialConcept.EQUITY, target_date)

        if equity <= 0:
            return MetricResult(
                metric_name="debt_to_equity",
                display_name="Debt to Equity Ratio",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if equity == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.RATIO,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if equity == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Total Equity is zero or negative; division by zero is strictly prohibited.",
                inputs={"short_term_debt": short_debt, "long_term_debt": long_debt, "total_debt": total_debt, "equity": equity, "total_equity": equity},
                definition="(Short-Term Debt + Long-Term Debt) / Total Equity",
                formula_human="Sum of short-term and long-term liabilities divided by total equity",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        de_val = round(total_debt / equity, 2)
        prev_de = None
        prev_p = self._get_previous_period(target_period)
        if compare_with_previous and prev_p and prev_p in self.engine.available_periods:
            prev_date = self._get_period_end_date(prev_p)
            prev_sd = self.engine.calculate_balance_as_of(FinancialConcept.SHORT_TERM_DEBT, prev_date)
            prev_ld = self.engine.calculate_balance_as_of(FinancialConcept.LONG_TERM_LIABILITY, prev_date)
            prev_td = round(prev_sd + prev_ld, 2)
            prev_eq = self.engine.calculate_balance_as_of(FinancialConcept.EQUITY, prev_date)
            if prev_eq > 0:
                prev_de = round(prev_td / prev_eq, 2)

        comp = self._compute_comparison(de_val, prev_de, prev_p or "", higher_is_better=False)
        health = "HEALTHY" if de_val <= 1.0 else ("ATTENTION" if de_val <= 2.0 else "CRITICAL")

        return MetricResult(
            metric_name="debt_to_equity",
            display_name="Debt to Equity Ratio",
            value=de_val,
            formatted_value=f"{de_val:.2f}x",
            unit=MetricUnit.RATIO,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"short_term_debt": short_debt, "long_term_debt": long_debt, "total_debt": total_debt, "equity": equity, "total_equity": equity},
            definition="(Short-Term Debt + Long-Term Debt) / Total Equity",
            formula_human="Sum of short-term and long-term liabilities divided by total equity",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_interest_coverage(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Interest Coverage Ratio = EBIT / Interest Expense."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        pnl = self.engine.get_pnl_for_period(target_period)
        ebit = round(pnl["gross_profit"] - pnl.get("opex", 0.0), 2)

        # Interest Expense check: Rule 6 & 16: Missing/unmapped denominator must NOT silently become zero.
        return MetricResult(
            metric_name="interest_coverage",
            display_name="Interest Coverage Ratio",
            value=None,
            formatted_value="INSUFFICIENT_DATA",
            unit=MetricUnit.RATIO,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.INSUFFICIENT_DATA,
            status_message="Interest Expense data is unavailable in the active ledger; cannot calculate Interest Coverage.",
            inputs={"ebit": ebit, "interest_expense": None},
            definition="Operating Profit (EBIT) / Interest Expense",
            formula_human="Operating earnings before interest and tax divided by period interest expense",
            source=self.source_name,
            reconciliation_status="INSUFFICIENT_DATA",
            health_status="INSUFFICIENT_DATA",
        )

    def calculate_revenue_growth(
        self,
        period: Optional[str] = None,
        compare_with_previous: bool = True,
    ) -> MetricResult:
        """Calculates Revenue Growth Rate = ((Current Revenue - Prior Revenue) / Prior Revenue) * 100."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        pnl = self.engine.get_pnl_for_period(target_period)
        curr_rev = pnl["revenue"]

        prev_p = self._get_previous_period(target_period)
        if not prev_p or prev_p not in self.engine.available_periods:
            return MetricResult(
                metric_name="revenue_growth",
                display_name="Revenue Growth Rate",
                value=None,
                formatted_value="INSUFFICIENT_DATA",
                unit=MetricUnit.PERCENTAGE,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.INSUFFICIENT_DATA,
                status_message="Prior comparative fiscal period data is not available.",
                inputs={"current_revenue": curr_rev, "previous_revenue": None},
                definition="((Current Revenue - Prior Revenue) / Prior Revenue) * 100",
                formula_human="Current monthly revenue minus prior monthly revenue divided by prior revenue multiplied by 100",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        prev_pnl = self.engine.get_pnl_for_period(prev_p)
        prev_rev = prev_pnl["revenue"]
        if prev_rev <= 0:
            return MetricResult(
                metric_name="revenue_growth",
                display_name="Revenue Growth Rate",
                value=None,
                formatted_value="ZERO_DENOMINATOR" if prev_rev == 0 else "INSUFFICIENT_DATA",
                unit=MetricUnit.PERCENTAGE,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.ZERO_DENOMINATOR if prev_rev == 0 else MetricStatus.INSUFFICIENT_DATA,
                status_message="Prior revenue is zero or negative; cannot calculate growth rate.",
                inputs={"current_revenue": curr_rev, "previous_revenue": prev_rev},
                definition="((Current Revenue - Prior Revenue) / Prior Revenue) * 100",
                formula_human="Current monthly revenue minus prior monthly revenue divided by prior revenue multiplied by 100",
                source=self.source_name,
                reconciliation_status="INSUFFICIENT_DATA",
                health_status="INSUFFICIENT_DATA",
            )

        growth_val = round(((curr_rev - prev_rev) / prev_rev) * 100.0, 2)
        comp = self._compute_comparison(curr_rev, prev_rev, prev_p, higher_is_better=True)
        health = "HEALTHY" if growth_val >= 0 else "ATTENTION"

        return MetricResult(
            metric_name="revenue_growth",
            display_name="Revenue Growth Rate",
            value=growth_val,
            formatted_value=f"{'+' if growth_val > 0 else ''}{growth_val:.2f}%",
            unit=MetricUnit.PERCENTAGE,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.CALCULATED,
            inputs={"current_revenue": curr_rev, "previous_revenue": prev_rev},
            definition="((Current Revenue - Prior Revenue) / Prior Revenue) * 100",
            formula_human="Current monthly revenue minus prior monthly revenue divided by prior revenue multiplied by 100",
            source=self.source_name,
            comparison=comp,
            reconciliation_status="RECONCILED",
            health_status=health,
        )

    def calculate_budget_variance(
        self,
        period: Optional[str] = None,
    ) -> MetricResult:
        """Calculates Budget Variance = ((Actual Revenue - Budget Target) / Budget Target) * 100."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        pnl = self.engine.get_pnl_for_period(target_period)
        curr_rev = pnl["revenue"]

        return MetricResult(
            metric_name="budget_variance",
            display_name="Budget Variance",
            value=None,
            formatted_value="INSUFFICIENT_DATA",
            unit=MetricUnit.PERCENTAGE,
            currency=self.engine.company.currency,
            period=target_period,
            status=MetricStatus.INSUFFICIENT_DATA,
            status_message="Board-approved budget plan data is not configured in the active ledger.",
            inputs={"actual_revenue": curr_rev, "budget_target": None},
            definition="((Actual Revenue - Budget Target) / Budget Target) * 100",
            formula_human="Actual realized revenue minus budget target divided by budget target multiplied by 100",
            source=self.source_name,
            reconciliation_status="INSUFFICIENT_DATA",
            health_status="INSUFFICIENT_DATA",
        )

    def get_cfo_ratios(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
    ) -> CFORatiosResponse:
        """Returns the complete governed CFO Ratio Cockpit categorized into 5 business groups."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)

        # 1. LIQUIDITY
        cr = self.calculate_current_ratio(target_period, target_date)
        qr = self.calculate_quick_ratio(target_period, target_date)
        wc = self.calculate_working_capital(target_period, target_date)

        liquidity_group = CFORatioGroup(
            category="LIQUIDITY",
            title="Liquidity & Short-Term Solvency",
            description="Measures ability to meet short-term liabilities with current cash and assets.",
            ratios=[cr, qr, wc.net_working_capital],
        )

        # 2. WORKING CAPITAL VELOCITY
        rec = self.calculate_receivables(target_period, target_date)
        pay = self.calculate_payables(target_period, target_date)
        inv = self.calculate_inventory(target_period, target_date)
        ccc = self.calculate_ccc(target_period, target_date)
        art = self.calculate_ar_turnover(target_period, target_date)
        apt = self.calculate_ap_turnover(target_period, target_date)

        wc_group = CFORatioGroup(
            category="WORKING_CAPITAL",
            title="Working Capital Velocity",
            description="Operating cash cycle efficiency and collection / inventory turnover velocity.",
            ratios=[rec.dso, inv.dio, pay.dpo, ccc, art, apt],
        )

        # 3. PROFITABILITY
        prof = self.calculate_profitability(target_period)
        ebitda = self.calculate_ebitda(target_period)
        roe = self.calculate_roe(target_period, target_date)

        prof_group = CFORatioGroup(
            category="PROFITABILITY",
            title="Operating Profitability & Margins",
            description="Gross and operating margin efficiency from core manufacturing and services.",
            ratios=[prof.gross_margin_percent, ebitda, roe],
        )

        # 4. LEVERAGE
        de = self.calculate_debt_to_equity(target_period, target_date)
        ic = self.calculate_interest_coverage(target_period, target_date)

        leverage_group = CFORatioGroup(
            category="LEVERAGE",
            title="Capital Structure & Leverage",
            description="Solvency and long-term obligation coverage ratios.",
            ratios=[de, ic],
        )

        # 5. GROWTH & PERFORMANCE
        rg = self.calculate_revenue_growth(target_period)
        bv = self.calculate_budget_variance(target_period)

        growth_group = CFORatioGroup(
            category="GROWTH",
            title="Growth & Budget Variance",
            description="Period expansion and performance variance against planned budget targets.",
            ratios=[rg, bv],
        )

        return CFORatiosResponse(
            company_code=self.engine.company.company_code,
            company_name=self.engine.company.company_name,
            period=target_period,
            comparison_period=self._get_previous_period(target_period),
            currency=self.engine.company.currency,
            groups=[liquidity_group, wc_group, prof_group, leverage_group, growth_group],
        )

    def calculate_dupont_analysis(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
    ) -> DuPontAnalysis:
        """Calculates three-tier DuPont decomposition tying Operating Margin, Asset Turnover, and Equity Multiplier to Governed Operating ROE."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)

        pnl = self.engine.get_pnl_for_period(target_period)
        revenue = pnl["revenue"]
        operating_income = pnl["gross_profit"] - pnl.get("opex", 0.0)

        wc_comps = self.engine.get_working_capital_components(target_date)
        ca = wc_comps["total_current_assets"]
        nca = self.engine.calculate_balance_as_of(FinancialConcept.NON_CURRENT_ASSET, target_date)
        total_assets = ca + nca
        equity = self.engine.calculate_balance_as_of(FinancialConcept.EQUITY, target_date)

        operating_margin_pct = round((operating_income / revenue) * 100.0, 4) if revenue > 0 else 0.0
        asset_turnover = round(revenue / total_assets, 4) if total_assets > 0 else 0.0
        equity_multiplier = round(total_assets / equity, 4) if equity > 0 else 0.0

        governed_operating_roe = round((operating_income / equity) * 100.0, 2) if equity > 0 else 0.0
        dupont_raw = (operating_income / revenue) * (revenue / total_assets) * (total_assets / equity) * 100.0 if (revenue > 0 and total_assets > 0 and equity > 0) else 0.0
        dupont_operating_roe = round(dupont_raw, 2)

        variance = round(abs(dupont_operating_roe - governed_operating_roe), 4)
        is_tied = variance <= 0.01

        explanation = (
            f"DuPont 3-Tier Decomposition for period {target_period}: "
            f"Operating Margin ({operating_margin_pct:.2f}%) × Asset Turnover ({asset_turnover:.4f}x) × "
            f"Equity Multiplier ({equity_multiplier:.4f}x) = {dupont_operating_roe:.2f}%, "
            f"which {'mathematically ties' if is_tied else 'has variance against'} governed Operating ROE ({governed_operating_roe:.2f}%)."
        )

        return DuPontAnalysis(
            period=target_period,
            operating_income=round(operating_income, 2),
            revenue=round(revenue, 2),
            total_assets=round(total_assets, 2),
            total_equity=round(equity, 2),
            operating_margin_pct=round(operating_margin_pct, 2),
            asset_turnover=round(asset_turnover, 4),
            equity_multiplier=round(equity_multiplier, 4),
            dupont_operating_roe=dupont_operating_roe,
            governed_operating_roe=governed_operating_roe,
            variance=variance,
            is_tied=is_tied,
            explanation=explanation,
        )

    # -------------------------------------------------------------------------
    # SPRINT 11: HISTORICAL FINANCIAL INTELLIGENCE
    # -------------------------------------------------------------------------

    def get_metric_history(
        self,
        metric_name: str,
        periods: Optional[List[str]] = None,
    ) -> MetricHistoryResponse:
        """Retrieves multi-period historical trajectory, deltas, and trend interpretation."""
        target_periods = periods or self.engine.available_periods
        if not target_periods:
            target_periods = ["2026-09"]

        history_points: List[MetricHistoryPoint] = []
        valid_values: List[float] = []

        last_val: Optional[float] = None
        for p in target_periods:
            res = self.get_metric_by_name(metric_name, p)
            val = res.value

            abs_change = None
            pct_change = None
            trend = TrendDirection.FLAT

            if val is not None and last_val is not None:
                abs_change = round(val - last_val, 2)
                pct_change = round(((val - last_val) / abs(last_val) * 100.0), 2) if abs(last_val) > 1e-6 else None
                if abs(abs_change) < 1e-4:
                    trend = TrendDirection.FLAT
                elif abs_change > 0:
                    trend = TrendDirection.INCREASING
                else:
                    trend = TrendDirection.DECREASING

            history_points.append(
                MetricHistoryPoint(
                    period=p,
                    value=val,
                    formatted_value=res.formatted_value,
                    status=res.status,
                    absolute_change=abs_change,
                    percentage_change=pct_change,
                    trend=trend,
                )
            )

            if val is not None:
                valid_values.append(val)
                last_val = val

        sample_res = self.get_metric_by_name(metric_name, target_periods[-1])
        defn = get_governed_metric_definition(metric_name)

        overall_change = None
        overall_pct = None
        overall_trend = "STABLE"
        interpretation = f"{sample_res.display_name} has insufficient historical data to evaluate trend."

        if len(valid_values) >= 2:
            first_val = valid_values[0]
            final_val = valid_values[-1]
            overall_change = round(final_val - first_val, 2)
            overall_pct = round(((final_val - first_val) / abs(first_val) * 100.0), 2) if abs(first_val) > 1e-6 else None

            # Determine if higher is favorable
            sign_conv = defn.sign_convention if defn else "POSITIVE_FAVORABLE"
            higher_is_favorable = sign_conv in ("POSITIVE_FAVORABLE", "HIGHER_FAVORABLE", "HIGHER_FAVORABLE_FOR_CASH")

            pct_str = f" ({overall_pct:+.1f}%)" if overall_pct is not None else ""

            if abs(overall_change) < 1e-4:
                overall_trend = "STABLE"
                interpretation = f"{sample_res.display_name} remained stable across {len(valid_values)} periods."
            elif overall_change > 0:
                overall_trend = "INCREASING"
                if higher_is_favorable:
                    interpretation = f"{sample_res.display_name} improved by {overall_change:+.2f}{pct_str} over {len(valid_values)} periods."
                else:
                    interpretation = f"{sample_res.display_name} increased by {overall_change:+.2f}{pct_str} over {len(valid_values)} periods, indicating operational friction."
            else:
                overall_trend = "DECREASING"
                if not higher_is_favorable:
                    interpretation = f"{sample_res.display_name} improved by {abs(overall_change):.2f}{pct_str} over {len(valid_values)} periods."
                else:
                    interpretation = f"{sample_res.display_name} declined by {abs(overall_change):.2f}{pct_str} over {len(valid_values)} periods."

        return MetricHistoryResponse(
            metric_name=metric_name,
            display_name=sample_res.display_name,
            unit=sample_res.unit,
            currency=self.engine.company.currency,
            history=history_points,
            overall_change=overall_change,
            overall_pct_change=overall_pct,
            overall_trend=overall_trend,
            interpretation=interpretation,
        )


    # -------------------------------------------------------------------------
    # EXECUTIVE FINANCIAL SUMMARY
    # -------------------------------------------------------------------------

    def get_financial_summary(
        self,
        period: Optional[str] = None,
        as_of_date: Optional[date] = None,
    ) -> FinancialSummary:
        """Aggregates all foundational metrics into an executive summary."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = as_of_date or self._get_period_end_date(target_period)

        cash = self.calculate_cash_position(target_period, target_date)
        wc = self.calculate_working_capital(target_period, target_date)
        ar = self.calculate_receivables(target_period, target_date)
        ap = self.calculate_payables(target_period, target_date)
        inv = self.calculate_inventory(target_period, target_date)
        prof = self.calculate_profitability(target_period)

        # Automated narrative preview for finance teams based on deterministic signals
        findings = []
        if ar.overdue_ar_percent.value and ar.overdue_ar_percent.value > 30.0:
            findings.append(f"Elevated Overdue AR: {ar.overdue_ar_percent.formatted_value} of receivables are past due terms.")
        if ap.upcoming_payables_7d.value and cash.value and ap.upcoming_payables_7d.value > cash.value:
            findings.append(f"Imminent Cash Squeeze: Upcoming 7-day payables ({ap.upcoming_payables_7d.formatted_value}) exceed total cash ({cash.formatted_value}).")
        if prof.gross_margin_percent.comparison and prof.gross_margin_percent.comparison.trend == TrendDirection.DECREASING:
            findings.append(f"Gross Margin Compression: Declined by {abs(prof.gross_margin_percent.comparison.absolute_change or 0.0):.1f} percentage points vs prior period.")
        if inv.inventory_growth_rate and inv.sales_growth_rate and inv.inventory_growth_rate > (inv.sales_growth_rate + 20.0):
            findings.append(f"Inventory Decoupling: Inventory grew {inv.inventory_growth_rate}% vs sales growth of {inv.sales_growth_rate}%.")

        return FinancialSummary(
            company_code=self.engine.company.company_code,
            company_name=self.engine.company.company_name,
            period=target_period,
            comparison_period=self._get_previous_period(target_period),
            reference_date=target_date.isoformat(),
            currency=self.engine.company.currency,
            cash_position=cash,
            net_working_capital=wc.net_working_capital,
            current_ratio=self.calculate_current_ratio(target_period, target_date),
            dso=ar.dso,
            dpo=ap.dpo,
            dio=inv.dio,
            ccc=self.calculate_ccc(target_period, target_date),
            gross_margin_percent=prof.gross_margin_percent,
            revenue=prof.revenue,
            accounts_receivable=ar.accounts_receivable,
            overdue_ar=ar.overdue_ar,
            overdue_ar_percent=ar.overdue_ar_percent,
            accounts_payable=ap.accounts_payable,
            upcoming_payables_7d=ap.upcoming_payables_7d,
            inventory_value=inv.inventory_value,
            key_findings_preview=findings,
        )

    # -------------------------------------------------------------------------
    # ARBITRARY METRIC ACCESSOR
    # -------------------------------------------------------------------------

    def get_metric_by_name(self, metric_name: str, period: Optional[str] = None) -> MetricResult:
        """Normalized metric retrieval by slug."""
        target_period = period or (self.engine.available_periods[-1] if self.engine.available_periods else "2026-09")
        target_date = self._get_period_end_date(target_period)
        m = metric_name.lower().strip()

        if m in ("cash", "cash_position"):
            return self.calculate_cash_position(target_period, target_date)
        elif m in ("nwc", "net_working_capital"):
            return self.calculate_working_capital(target_period, target_date).net_working_capital
        elif m in ("current_assets", "ca"):
            return self.calculate_working_capital(target_period, target_date).current_assets
        elif m in ("current_liabilities", "cl"):
            return self.calculate_working_capital(target_period, target_date).current_liabilities
        elif m in ("ar", "accounts_receivable"):
            return self.calculate_receivables(target_period, target_date).accounts_receivable
        elif m in ("other_receivables", "other_ar"):
            wc_comp = self.engine.get_working_capital_components(target_date)
            val = wc_comp["other_receivables"]
            return MetricResult(
                metric_name="other_receivables",
                display_name="Other Receivables",
                value=val,
                formatted_value=format_currency(val),
                unit=MetricUnit.CURRENCY,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.CALCULATED,
                definition="Non-trade and timing receivables reconciled from GL AR to Trade Subledger",
                source=self.source_name,
            )
        elif m in ("overdue_ar",):
            return self.calculate_receivables(target_period, target_date).overdue_ar
        elif m in ("overdue_ar_percent", "overdue_ar_pct"):
            return self.calculate_receivables(target_period, target_date).overdue_ar_percent
        elif m in ("dso", "days_sales_outstanding"):
            return self.calculate_receivables(target_period, target_date).dso
        elif m in ("ap", "accounts_payable"):
            return self.calculate_payables(target_period, target_date).accounts_payable
        elif m in ("other_payables", "other_ap"):
            wc_comp = self.engine.get_working_capital_components(target_date)
            val = wc_comp["other_payables"]
            return MetricResult(
                metric_name="other_payables",
                display_name="Other Payables",
                value=val,
                formatted_value=format_currency(val),
                unit=MetricUnit.CURRENCY,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.CALCULATED,
                definition="Non-trade and opening payables reconciled from GL AP to Trade Subledger",
                source=self.source_name,
            )
        elif m in ("upcoming_payables", "upcoming_payables_7d"):
            return self.calculate_payables(target_period, target_date).upcoming_payables_7d
        elif m in ("overdue_payables", "overdue_ap"):
            return self.calculate_payables(target_period, target_date).overdue_payables
        elif m in ("dpo", "days_payable_outstanding"):
            return self.calculate_payables(target_period, target_date).dpo
        elif m in ("inventory", "inventory_value"):
            return self.calculate_inventory(target_period, target_date).inventory_value
        elif m in ("dio", "days_inventory_outstanding"):
            return self.calculate_inventory(target_period, target_date).dio
        elif m in ("ccc", "cash_conversion_cycle"):
            return self.calculate_ccc(target_period, target_date)
        elif m in ("revenue", "sales"):
            return self.calculate_profitability(target_period).revenue
        elif m in ("cogs", "cost_of_goods_sold"):
            return self.calculate_profitability(target_period).cogs
        elif m in ("gross_profit", "gp"):
            return self.calculate_profitability(target_period).gross_profit
        elif m in ("gross_margin", "gross_margin_percent", "gm"):
            return self.calculate_profitability(target_period).gross_margin_percent
        elif m in ("current_ratio", "cr"):
            return self.calculate_current_ratio(target_period, target_date)
        elif m in ("quick_ratio", "qr"):
            return self.calculate_quick_ratio(target_period, target_date)
        elif m in ("ar_turnover", "art"):
            return self.calculate_ar_turnover(target_period, target_date)
        elif m in ("ap_turnover", "apt"):
            return self.calculate_ap_turnover(target_period, target_date)
        elif m in ("ebitda", "operating_income"):
            return self.calculate_ebitda(target_period)
        elif m in ("roe", "return_on_equity"):
            return self.calculate_roe(target_period, target_date)
        elif m in ("debt_to_equity", "de", "debt_equity"):
            return self.calculate_debt_to_equity(target_period, target_date)
        elif m in ("interest_coverage", "ic"):
            return self.calculate_interest_coverage(target_period, target_date)
        elif m in ("revenue_growth", "rg"):
            return self.calculate_revenue_growth(target_period)
        elif m in ("budget_variance", "bv"):
            return self.calculate_budget_variance(target_period)
        else:
            return MetricResult(
                metric_name=metric_name,
                display_name=f"Unknown Metric ({metric_name})",
                value=None,
                formatted_value="NOT_FOUND",
                unit=MetricUnit.COUNT,
                currency=self.engine.company.currency,
                period=target_period,
                status=MetricStatus.NOT_APPLICABLE,
                status_message=f"Metric '{metric_name}' is not recognized in the canonical financial suite.",
                definition="N/A",
                source=self.source_name,
            )
