"""Refresh Pipeline for FinSight.

Executes the LOAD -> VALIDATE -> NORMALIZE -> CALCULATE -> READY lifecycle.
Maintains the active in-memory state of the canonical financial engine and metrics.
"""

from calendar import monthrange
from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sqlite3
import time
from typing import Any, Dict, List, Optional
import uuid
from pydantic import BaseModel, Field

from finsight.adapters.base import BaseFinancialAdapter
from finsight.adapters.mock_adapter import MockFinancialAdapter
from finsight.config import settings
from finsight.models.quality import DataQualityReport, DataQualityStatus
from finsight.models.snapshot import FinancialSnapshot
from finsight.services.data_quality_service import DataQualityService
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


class RefreshResponse(BaseModel):
    """Execution status returned after running the refresh pipeline."""
    success: bool = Field(description="Whether the pipeline completed successfully to READY state")
    source: str = Field(description="Identifier of data source adapter")
    records_processed: int = Field(default=0, description="Total count of canonical records ingested")
    validation_status: DataQualityStatus = Field(description="Data quality audit outcome")
    calculation_status: str = Field(description="READY or FAILED")
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    duration_ms: float = Field(default=0.0, description="Pipeline elapsed time in milliseconds")
    warnings_count: int = Field(default=0)
    blockers_count: int = Field(default=0)
    errors: List[str] = Field(default_factory=list)
    summary_preview: Optional[Dict[str, Any]] = None


class RefreshService:
    """Orchestrates ingestion, validation, normalization, and engine caching with SQLite persistence."""

    def __init__(self, adapter: Optional[BaseFinancialAdapter] = None, db_path: Optional[str] = None):
        self._adapter: BaseFinancialAdapter = adapter or MockFinancialAdapter()
        self._data_quality_service = DataQualityService()
        self._engine: Optional[FinancialEngine] = None
        self._metric_service: Optional[MetricService] = None
        self._last_report: Optional[DataQualityReport] = None
        self._last_refresh_time: Optional[str] = None
        self._active_snapshot: Optional[FinancialSnapshot] = None

        if db_path is None:
            snap_env = os.getenv("FINSIGHT_SNAPSHOTS_DB")
            if snap_env:
                self.db_path = snap_env
            else:
                data_dir = Path(__file__).resolve().parent.parent.parent.parent / "data"
                data_dir.mkdir(parents=True, exist_ok=True)
                self.db_path = str(data_dir / "finsight_snapshots.db")
        else:
            self.db_path = db_path

        self._init_db()
        self._load_persisted_state()

    @contextmanager
    def _db_conn(self):
        conn = sqlite3.connect(self.db_path, timeout=10.0)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _load_persisted_state(self) -> None:
        """Restores latest active snapshot from SQLite if present."""
        try:
            with self._db_conn() as conn:
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute("SELECT data_json FROM snapshots WHERE is_active = 1 ORDER BY generated_at DESC LIMIT 1")
                row = cur.fetchone()
                if row:
                    self._active_snapshot = FinancialSnapshot.model_validate_json(row["data_json"])
        except Exception:
            pass

    def _init_db(self) -> None:
        """Initializes SQLite persistence tables for financial snapshots and refresh history."""
        data_dir = Path(self.db_path).parent
        data_dir.mkdir(parents=True, exist_ok=True)
        with self._db_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS snapshots (
                    snapshot_id TEXT PRIMARY KEY,
                    period TEXT NOT NULL,
                    period_start TEXT NOT NULL,
                    period_end TEXT NOT NULL,
                    reference_date TEXT NOT NULL,
                    source TEXT NOT NULL,
                    dataset_version TEXT NOT NULL,
                    generated_at TEXT NOT NULL,
                    calculation_status TEXT NOT NULL,
                    data_quality_status TEXT NOT NULL,
                    is_active INTEGER NOT NULL,
                    data_json TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS refresh_runs (
                    run_id TEXT PRIMARY KEY,
                    snapshot_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    source TEXT NOT NULL,
                    records_processed INTEGER NOT NULL,
                    validation_status TEXT NOT NULL,
                    calculation_status TEXT NOT NULL,
                    duration_ms REAL NOT NULL,
                    warnings_count INTEGER NOT NULL,
                    blockers_count INTEGER NOT NULL,
                    success INTEGER NOT NULL,
                    errors_json TEXT
                )
            """)
            conn.commit()

    def _persist_snapshot(self, snapshot: FinancialSnapshot) -> None:
        """Stores or updates the financial snapshot in SQLite."""
        with self._db_conn() as conn:
            conn.execute(
                "UPDATE snapshots SET is_active = 0 WHERE period = ?",
                (snapshot.period,),
            )
            conn.execute(
                """
                INSERT INTO snapshots (
                    snapshot_id, period, period_start, period_end, reference_date,
                    source, dataset_version, generated_at, calculation_status,
                    data_quality_status, is_active, data_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(snapshot_id) DO UPDATE SET
                    period = excluded.period,
                    period_start = excluded.period_start,
                    period_end = excluded.period_end,
                    reference_date = excluded.reference_date,
                    source = excluded.source,
                    dataset_version = excluded.dataset_version,
                    generated_at = excluded.generated_at,
                    calculation_status = excluded.calculation_status,
                    data_quality_status = excluded.data_quality_status,
                    is_active = excluded.is_active,
                    data_json = excluded.data_json
                """,
                (
                    snapshot.snapshot_id,
                    snapshot.period,
                    snapshot.period_start,
                    snapshot.period_end,
                    snapshot.reference_date,
                    snapshot.source,
                    snapshot.dataset_version,
                    snapshot.generated_at,
                    snapshot.calculation_status,
                    snapshot.data_quality_status,
                    1 if snapshot.is_active else 0,
                    snapshot.model_dump_json(),
                ),
            )
            conn.commit()

    def _persist_refresh_run(
        self,
        snapshot_id: str,
        total_records: int,
        report_status: DataQualityStatus,
        calc_status: str,
        duration_ms: float,
        warnings_count: int,
        blockers_count: int,
        success: bool,
        errors: List[str],
        timestamp: str,
    ) -> None:
        run_id = f"RUN-{uuid.uuid4().hex[:8]}"
        with self._db_conn() as conn:
            conn.execute(
                """
                INSERT INTO refresh_runs (
                    run_id, snapshot_id, timestamp, source, records_processed,
                    validation_status, calculation_status, duration_ms,
                    warnings_count, blockers_count, success, errors_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    snapshot_id,
                    timestamp,
                    self._adapter.adapter_name if self._adapter else "unknown",
                    total_records,
                    report_status.value,
                    calc_status,
                    duration_ms,
                    warnings_count,
                    blockers_count,
                    1 if success else 0,
                    json.dumps(errors),
                ),
            )
            conn.commit()

    @property
    def adapter(self) -> BaseFinancialAdapter:
        return self._adapter

    @adapter.setter
    def adapter(self, new_adapter: BaseFinancialAdapter) -> None:
        self._adapter = new_adapter

    @property
    def engine(self) -> FinancialEngine:
        if self._engine is None:
            res = self.execute_refresh()
            if self._engine is None:
                err_msg = "; ".join(res.errors) if res.errors else "Unknown initialization error"
                raise RuntimeError(f"FinancialEngine initialization failed: {err_msg}")
        return self._engine

    @property
    def metric_service(self) -> MetricService:
        if self._metric_service is None:
            res = self.execute_refresh()
            if self._metric_service is None:
                err_msg = "; ".join(res.errors) if res.errors else "Unknown initialization error"
                raise RuntimeError(f"MetricService initialization failed: {err_msg}")
        return self._metric_service

    @property
    def data_quality_report(self) -> DataQualityReport:
        if self._last_report is None:
            self.execute_refresh()
        return self._last_report  # type: ignore

    @property
    def active_snapshot(self) -> FinancialSnapshot:
        if self._active_snapshot is None:
            res = self.execute_refresh()
            if self._active_snapshot is None:
                err_msg = "; ".join(res.errors) if res.errors else "Active snapshot not generated"
                raise RuntimeError(f"FinancialSnapshot generation failed: {err_msg}")
        return self._active_snapshot

    def execute_refresh(self) -> RefreshResponse:
        """Executes the full LOAD -> VALIDATE -> NORMALIZE -> CALCULATE -> READY pipeline."""
        start_time = time.perf_counter()
        errors: List[str] = []

        try:
            # 1. LOAD
            company = self._adapter.get_company()
            customers = self._adapter.get_customers()
            vendors = self._adapter.get_vendors()
            products = self._adapter.get_products()
            account_mappings = self._adapter.get_account_mappings()
            journal_entries = self._adapter.get_journal_entries()
            ar_items = self._adapter.get_ar_items()
            ap_items = self._adapter.get_ap_items()

            total_records = (
                (1 if company else 0)
                + len(customers)
                + len(vendors)
                + len(products)
                + len(account_mappings)
                + len(journal_entries)
                + len(ar_items)
                + len(ap_items)
            )

            # 2. VALIDATE
            refresh_timestamp = datetime.now(timezone.utc).isoformat()
            dq_service = DataQualityService(last_refresh_timestamp=refresh_timestamp)
            report = dq_service.evaluate(
                company=company,
                customers=customers,
                vendors=vendors,
                products=products,
                account_mappings=account_mappings,
                journal_entries=journal_entries,
                ar_items=ar_items,
                ap_items=ap_items,
                source_name=self._adapter.adapter_name,
            )
            self._last_report = report

            if report.status == DataQualityStatus.BLOCKED:
                errors = [b.message for b in report.calculation_blockers]
                duration_ms = round((time.perf_counter() - start_time) * 1000, 2)
                return RefreshResponse(
                    success=False,
                    source=self._adapter.adapter_name,
                    records_processed=total_records,
                    validation_status=report.status,
                    calculation_status="FAILED",
                    duration_ms=duration_ms,
                    warnings_count=len(report.warnings),
                    blockers_count=len(report.calculation_blockers),
                    errors=errors,
                )

            # 3. NORMALIZE & 4. CALCULATE
            engine = FinancialEngine(
                company=company,
                customers=customers,
                vendors=vendors,
                products=products,
                account_mappings=account_mappings,
                journal_entries=journal_entries,
                ar_items=ar_items,
                ap_items=ap_items,
            )
            metric_service = MetricService(engine=engine, source_name=self._adapter.adapter_name)

            # Verification calculation run (smoke test summary)
            summary = metric_service.get_financial_summary()

            # 5. READY
            active_period = engine.available_periods[-1] if engine.available_periods else "2026-09"
            period_compact = active_period.replace("-", "")

            # Sequential unique snapshot numbering
            with self._db_conn() as conn:
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM snapshots WHERE period = ?", (active_period,))
                snap_count = (cur.fetchone()[0] or 0) + 1

            snapshot_id = f"SNAP-{period_compact}-{snap_count:03d}-{uuid.uuid4().hex[:6].upper()}"

            # Calculate actual month-end date for active_period
            year, month = map(int, active_period.split("-"))
            last_day = monthrange(year, month)[1]
            period_end = f"{active_period}-{last_day:02d}"

            self._active_snapshot = FinancialSnapshot(
                snapshot_id=snapshot_id,
                period=active_period,
                period_start=f"{active_period}-01",
                period_end=period_end,
                reference_date=period_end,
                source=self._adapter.adapter_name,
                dataset_version="v1.0-seed42",
                generated_at=refresh_timestamp,
                calculation_status="READY",
                data_quality_status=report.status.value,
                is_active=True,
            )
            self._persist_snapshot(self._active_snapshot)

            self._engine = engine
            self._metric_service = metric_service
            self._last_refresh_time = refresh_timestamp

            duration_ms = round((time.perf_counter() - start_time) * 1000, 2)
            self._persist_refresh_run(
                snapshot_id=self._active_snapshot.snapshot_id,
                total_records=total_records,
                report_status=report.status,
                calc_status="READY",
                duration_ms=duration_ms,
                warnings_count=len(report.warnings),
                blockers_count=len(report.calculation_blockers),
                success=True,
                errors=errors,
                timestamp=refresh_timestamp,
            )
            return RefreshResponse(
                success=True,
                source=self._adapter.adapter_name,
                records_processed=total_records,
                validation_status=report.status,
                calculation_status="READY",
                timestamp=refresh_timestamp,
                duration_ms=duration_ms,
                warnings_count=len(report.warnings),
                blockers_count=len(report.calculation_blockers),
                errors=errors,
                summary_preview={
                    "period": summary.period,
                    "cash": summary.cash_position.formatted_value,
                    "revenue": summary.revenue.formatted_value,
                    "gross_margin": summary.gross_margin_percent.formatted_value,
                    "dso": summary.dso.formatted_value,
                    "open_ar": summary.accounts_receivable.formatted_value,
                    "overdue_ar": summary.overdue_ar.formatted_value,
                },
            )

        except Exception as exc:
            duration_ms = round((time.perf_counter() - start_time) * 1000, 2)
            err_msg = str(exc)
            try:
                self._persist_refresh_run(
                    snapshot_id="N/A",
                    total_records=total_records if "total_records" in locals() else 0,
                    report_status=DataQualityStatus.BLOCKED,
                    calc_status="FAILED",
                    duration_ms=duration_ms,
                    warnings_count=0,
                    blockers_count=1,
                    success=False,
                    errors=[err_msg],
                    timestamp=datetime.now(timezone.utc).isoformat(),
                )
            except Exception:
                pass
            return RefreshResponse(
                success=False,
                source=self._adapter.adapter_name if self._adapter else "unknown",
                records_processed=0,
                validation_status=DataQualityStatus.BLOCKED,
                calculation_status="FAILED",
                duration_ms=duration_ms,
                errors=[err_msg],
            )

    def list_snapshots(self, period: Optional[str] = None) -> List[FinancialSnapshot]:
        """Lists historical persisted snapshots from SQLite."""
        with self._db_conn() as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if period:
                cur.execute("SELECT data_json FROM snapshots WHERE period = ? ORDER BY generated_at DESC", (period,))
            else:
                cur.execute("SELECT data_json FROM snapshots ORDER BY generated_at DESC")
            rows = cur.fetchall()
            return [FinancialSnapshot.model_validate_json(r["data_json"]) for r in rows]

    def get_snapshot_by_id(self, snapshot_id: str) -> Optional[FinancialSnapshot]:
        """Fetches a specific snapshot by ID from SQLite."""
        with self._db_conn() as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT data_json FROM snapshots WHERE snapshot_id = ?", (snapshot_id,))
            row = cur.fetchone()
            return FinancialSnapshot.model_validate_json(row["data_json"]) if row else None

    def get_snapshot_for_period(self, period: str) -> FinancialSnapshot:
        """Retrieves active snapshot if matching, or fetches/creates snapshot for specific historical period."""
        if self._active_snapshot and self._active_snapshot.period == period:
            return self._active_snapshot

        # Check SQLite for existing snapshot for this period
        with self._db_conn() as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT data_json FROM snapshots WHERE period = ? ORDER BY generated_at DESC LIMIT 1", (period,))
            row = cur.fetchone()
            if row:
                return FinancialSnapshot.model_validate_json(row["data_json"])

        # If not yet persisted, construct period-specific snapshot from engine
        period_compact = period.replace("-", "")
        year, month = map(int, period.split("-"))
        last_day = monthrange(year, month)[1]
        period_end = f"{period}-{last_day:02d}"
        snapshot_id = f"SNAP-{period_compact}-001"

        snap = FinancialSnapshot(
            snapshot_id=snapshot_id,
            period=period,
            period_start=f"{period}-01",
            period_end=period_end,
            reference_date=period_end,
            source=self._adapter.adapter_name if self._adapter else "Synthetic ERP Benchmark",
            dataset_version="v1.0-seed42",
            generated_at=datetime.now(timezone.utc).isoformat(),
            calculation_status="READY",
            data_quality_status=DataQualityStatus.PASSED.value,
            is_active=False,
        )
        self._persist_snapshot(snap)
        return snap

    def list_refresh_runs(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Lists historical refresh runs from SQLite."""
        with self._db_conn() as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT * FROM refresh_runs ORDER BY timestamp DESC LIMIT ?", (limit,))
            rows = cur.fetchall()
            return [dict(r) for r in rows]
