/**
 * FinSight Main Application Orchestrator
 */

import { api } from './services/api.js';
import { auth } from './services/auth.js';
import { renderSidebar } from './components/sidebar.js';
import { renderHeader } from './components/header.js';
import { initEvidenceDrawer } from './components/evidenceDrawer.js';
import { initTrustDrawer } from './components/trustDrawer.js';
import { initInvestigateDrawer } from './components/investigateDrawer.js';
import { initNotificationBar } from './components/notificationBar.js';

import { renderLogin } from './pages/login.js';
import { renderOverview } from './pages/overview.js';
import { renderFinancials } from './pages/financials.js';
import { renderPerformance } from './pages/performance.js';
import { renderInvestigate } from './pages/investigate.js';
import { renderActions } from './pages/actions.js';
import { renderDataStatus } from './pages/dataStatus.js';
import { renderSettings } from './pages/settings.js';

// Global 5-Second Undo Toast Notification (UC15 Pattern)
window.showUndoToast = (message, onUndo) => {
  document.querySelectorAll('.undo-toast').forEach(t => t.remove());
  const toast = document.createElement('div');
  toast.className = 'undo-toast';
  let seconds = 5;
  toast.innerHTML = `
    <span>${message}</span>
    <button class="undo-toast-btn" id="toastUndoBtn">Undo (${seconds}s)</button>
    <button class="undo-toast-close" id="toastCloseBtn">✕</button>
  `;
  document.body.appendChild(toast);

  const undoBtn = toast.querySelector('#toastUndoBtn');
  const closeBtn = toast.querySelector('#toastCloseBtn');
  const interval = setInterval(() => {
    seconds--;
    if (seconds <= 0) {
      clearInterval(interval);
      toast.remove();
    } else {
      if (undoBtn) undoBtn.textContent = `Undo (${seconds}s)`;
    }
  }, 1000);

  undoBtn?.addEventListener('click', () => {
    clearInterval(interval);
    toast.remove();
    if (onUndo) onUndo();
  });

  closeBtn?.addEventListener('click', () => {
    clearInterval(interval);
    toast.remove();
  });
};

class FinSightApp {
  constructor() {
    this.state = {
      activeTab: 'overview',
      currentPeriod: '2026-09',
      periods: api.periods,
      cases: [],
      investigateQuestion: null,
      trustState: { trust_state: 'UNKNOWN' },
    };

    this.loginContainer = document.getElementById('login-container');
    this.appContainer = document.getElementById('app-container');
    this.sidebarContainer = document.getElementById('app-sidebar');
    this.headerContainer = document.getElementById('app-header');
    this.notificationContainer = document.getElementById('notification-bar');
    this.viewContainer = document.getElementById('view-container');
    this.evidenceDialog = document.getElementById('evidence-drawer');
    this.trustDialog = document.getElementById('trust-drawer');
    this.investigateDialog = document.getElementById('investigate-drawer');

    this.evidenceDrawer = null;
    this.trustDrawer = null;
    this.investigateDrawer = null;
    this.notificationBar = null;
    this.casesViewHandle = null;
  }

  async init() {
    if (auth.isAuthenticated()) {
      try {
        const me = await api.getMe();
        if (me) {
          auth.setSession(auth.getToken(), me);
          await this.initAuthenticated();
          return;
        }
      } catch (err) {
        console.warn('Session verification fallback to login:', err);
        auth.clearSession();
      }
    }
    this.showLogin();
  }

  showLogin() {
    if (this.appContainer) this.appContainer.style.display = 'none';
    if (this.loginContainer) {
      this.loginContainer.style.display = 'block';
      renderLogin(this.loginContainer, api, async () => {
        this.loginContainer.style.display = 'none';
        if (this.appContainer) this.appContainer.style.display = 'flex';
        await this.initAuthenticated();
      });
    }
  }

  handleSignOut() {
    api.logout().catch(() => {});
    auth.clearSession();
    this.showLogin();
  }

  async initAuthenticated() {
    if (this.appContainer) this.appContainer.style.display = 'flex';
    if (this.loginContainer) this.loginContainer.style.display = 'none';

    // Initialize evidence drawer component
    if (!this.evidenceDrawer && this.evidenceDialog) {
      this.evidenceDrawer = initEvidenceDrawer(this.evidenceDialog, (caseData) => {
        this.navigateTo('actions', { createPrefill: caseData });
      });
    }

    // Initialize trust drawer component
    if (!this.trustDrawer && this.trustDialog) {
      this.trustDrawer = initTrustDrawer(this.trustDialog, api, () => this.runEngineWithPhasedHud());
      window.openTrustDrawer = (period) => this.trustDrawer?.open(period || this.state.currentPeriod);
    }

    // Initialize in-context investigation drawer component
    if (!this.investigateDrawer && this.investigateDialog) {
      this.investigateDrawer = initInvestigateDrawer(
        this.investigateDialog,
        api,
        (tab, params) => this.navigateTo(tab, params),
        (caseData) => this.navigateTo('actions', { createPrefill: caseData })
      );
    }

    // Initialize notification bar component
    if (!this.notificationBar && this.notificationContainer) {
      this.notificationBar = initNotificationBar(
        this.notificationContainer,
        (question) => this.navigateTo('investigate', { question }),
        () => this.navigateTo('actions')
      );
    }

    // Initial load of cases for sidebar badge and trust state
    try {
      const [cases, trust] = await Promise.all([
        api.getCases().catch(() => []),
        api.getTrustSummary(this.state.currentPeriod).catch(() => ({ trust_state: 'UNKNOWN' })),
      ]);
      this.state.cases = cases || [];
      this.state.trustState = trust || { trust_state: 'UNKNOWN' };
    } catch (e) {
      console.warn('Initial data fetch warning:', e);
    }

    // Restore sidebar drawer collapsed state
    if (localStorage.getItem('finsight_sidebar_collapsed') === 'true') {
      this.appContainer?.classList.add('sidebar-collapsed');
    }

    this.renderShell();
    this.renderCurrentView();

    // Evaluate executive alerts for the notification bar
    this.updateNotifications();
  }

  async updateNotifications() {
    if (!this.notificationBar) return;
    try {
      const attention = await api.getAttentionSummary();
      if (attention && attention.items) {
        this.notificationBar.evaluateAttention(attention.items);
        this.notificationBar.setActiveTab(this.state.activeTab);
      }
    } catch (e) {
      console.warn('Notification bar alert fetch warning:', e);
    }
  }

  renderShell() {
    const titles = {
      overview: 'Executive Dashboard & Overview',
      financials: 'Financial Statements & Ledgers',
      performance: 'Financial Performance & Analysis',
      investigate: 'Executive AI Investigator',
      actions: 'Remediation Actions & Governance',
      commandCenter: 'Executive Dashboard & Overview',
      money: 'Financial Statements & Ledgers',
      cases: 'Remediation Actions & Governance',
      dataStatus: 'Financial Data Integrity',
      settings: 'System Configuration & Administration',
    };

    renderSidebar(
      this.sidebarContainer,
      this.state,
      (tab) => this.navigateTo(tab),
      (period) => this.handlePeriodChange(period),
      () => this.handleSignOut()
    );

    renderHeader(
      this.headerContainer,
      titles[this.state.activeTab] || 'FinSight',
      this.state.currentPeriod,
      () => this.runEngineWithPhasedHud(),
      () => this.promptIngestModal(),
      (tab, params) => this.navigateTo(tab, params),
      () => this.trustDrawer?.open(this.state.currentPeriod),
      () => this.handleSignOut(),
      this.state.trustState
    );
  }

  // --- Phased Engine Execution HUD ---
  async runEngineWithPhasedHud() {
    let modalOverlay = document.getElementById('engineModalOverlay');
    if (!modalOverlay) {
      modalOverlay = document.createElement('div');
      modalOverlay.id = 'engineModalOverlay';
      document.body.appendChild(modalOverlay);
    }

    modalOverlay.innerHTML = `
      <div style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.72); backdrop-filter:blur(4px); display:flex; align-items:center; justify-content:center; z-index:999999;">
        <div style="background:#FFFFFF; border-radius:14px; max-width:480px; width:92%; padding:28px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.4); text-align:center;">
          <div style="width:48px; height:48px; border-radius:50%; background:linear-gradient(135deg, #2563EB, #1D4ED8); display:flex; align-items:center; justify-content:center; margin:0 auto 16px; color:#fff; box-shadow:0 10px 18px -3px rgba(37,99,235,0.35);">
            <div class="loading-spinner-ring" style="width:22px; height:22px; border-width:2.5px; border-color:#fff; border-top-color:transparent;"></div>
          </div>

          <h3 style="font-size:17px; font-weight:800; color:#0F172A; margin:0 0 6px 0;">
            Updating Financial Ledgers
          </h3>
          <p id="engineProgressSubtitle" style="font-size:13px; color:#64748B; margin:0;">
            Reconciling subledgers and recalculating metrics...
          </p>
        </div>
      </div>
    `;

    try {
      await api.refreshData();
      const [cases, trust] = await Promise.all([
        api.getCases().catch(() => []),
        api.getTrustSummary(this.state.currentPeriod).catch(() => ({ trust_state: 'UNKNOWN' })),
      ]);
      this.state.cases = cases || [];
      this.state.trustState = trust || { trust_state: 'UNKNOWN' };

      modalOverlay.innerHTML = '';
      this.renderShell();
      this.renderCurrentView();
      this.updateNotifications();
      this.showToast('✓ Financial ledgers successfully updated and verified.');
    } catch (err) {
      modalOverlay.innerHTML = '';
      this.showToast('Engine run failed: ' + (err.message || err));
    }
  }

  // --- Ingest Feeds Source Modal ---
  promptIngestModal() {
    let modalOverlay = document.getElementById('engineModalOverlay');
    if (!modalOverlay) {
      modalOverlay = document.createElement('div');
      modalOverlay.id = 'engineModalOverlay';
      document.body.appendChild(modalOverlay);
    }

    modalOverlay.innerHTML = `
      <div style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.65); backdrop-filter:blur(3px); display:flex; align-items:center; justify-content:center; z-index:999999;">
        <div style="background:#FFFFFF; border-radius:12px; max-width:520px; width:92%; padding:26px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.3);">
          <div style="display:flex; align-items:center; gap:10px; color:#2563EB; margin-bottom:12px;">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <h3 style="font-size:17px; font-weight:800; margin:0; color:#0F172A;">Ingest Financial Subledger Feeds</h3>
          </div>

          <p style="font-size:13px; color:#475569; line-height:1.5; margin-bottom:16px;">
            Select ingestion pipeline to stream journal records into FinSight's canonical financial model:
          </p>

          <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:18px;">
            <label style="display:flex; align-items:flex-start; gap:10px; padding:12px; border:1px solid #BFDBFE; border-radius:8px; background:#EFF6FF; cursor:pointer;">
              <input type="radio" name="ingestSourceRadio" value="demo" checked style="margin-top:3px;">
              <div>
                <strong style="font-size:13px; color:#1E40AF;">Standard Enterprise Benchmark (Acme Industrial)</strong>
                <div style="font-size:11.5px; color:#475569; margin-top:2px;">Complete 12-month dual-ledger transactions, AR/AP aging subledgers, and working capital variances.</div>
              </div>
            </label>

            <label style="display:flex; align-items:flex-start; gap:10px; padding:12px; border:1px solid #E2E8F0; border-radius:8px; background:#FFFFFF; cursor:pointer;">
              <input type="radio" name="ingestSourceRadio" value="sap" style="margin-top:3px;">
              <div>
                <strong style="font-size:13px; color:#0F172A;">Synthetic ERP Benchmark (SAP S/4HANA Shape, Company Code: 1000)</strong>
                <div style="font-size:11.5px; color:#475569; margin-top:2px;">SAP-shaped synthetic ledger connector (BKPF/BSEG journal ledger &amp; BSID open items).</div>
              </div>
            </label>
          </div>

          <div id="ingestTimerBox" style="display:none; margin-bottom:16px; padding:12px 14px; background:#EFF6FF; border:1px solid #BFDBFE; border-radius:8px; text-align:center;">
            <div style="font-size:13px; font-weight:700; color:#1E40AF; display:flex; align-items:center; justify-content:center; gap:8px;">
              <div class="loading-spinner-ring" style="width:16px; height:16px; border-width:2px;"></div>
              <span>Connecting to ERP Subledger Feed &amp; Reconciling...</span>
            </div>
          </div>

          <div style="display:flex; justify-content:flex-end; gap:10px;">
            <button id="btnCancelIngest" class="btn btn-secondary btn-sm">Cancel</button>
            <button id="btnExecuteIngest" class="btn btn-primary btn-sm" style="font-weight:700;">
              <span id="btnIngestLabel">Ingest Subledger Feeds</span>
            </button>
          </div>
        </div>
      </div>
    `;

    const cancelBtn = document.getElementById('btnCancelIngest');
    const execBtn = document.getElementById('btnExecuteIngest');
    const timerBox = document.getElementById('ingestTimerBox');
    const labelEl = document.getElementById('btnIngestLabel');

    cancelBtn?.addEventListener('click', () => { modalOverlay.innerHTML = ''; });

    execBtn?.addEventListener('click', async () => {
      execBtn.disabled = true;
      if (cancelBtn) cancelBtn.style.display = 'none';
      if (timerBox) timerBox.style.display = 'block';
      if (labelEl) labelEl.textContent = 'Ingesting & Reconciling...';

      try {
        await api.refreshData();
        const [cases, trust] = await Promise.all([
          api.getCases().catch(() => []),
          api.getTrustSummary(this.state.currentPeriod).catch(() => ({ trust_state: 'UNKNOWN' })),
        ]);
        this.state.cases = cases || [];
        this.state.trustState = trust || { trust_state: 'UNKNOWN' };

        modalOverlay.innerHTML = '';
        this.renderShell();
        this.renderCurrentView();
        this.updateNotifications();
        this.showToast('✓ Subledger feeds successfully ingested and reconciled.');
      } catch (err) {
        modalOverlay.innerHTML = '';
        this.showToast('Ingestion failed: ' + (err.message || err));
      }
    });
  }

  showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'undo-toast';
    toast.innerHTML = `
      <span>${message}</span>
      <button class="undo-toast-close" onclick="this.parentElement.remove()">✕</button>
    `;
    document.body.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 4000);
  }

  navigateTo(tab, params = {}) {
    let target = tab;
    // Backward compatibility aliases
    if (target === 'commandCenter') target = 'overview';
    if (target === 'money') target = 'financials';
    if (target === 'cases') target = 'actions';

    this.state.activeTab = target;
    this.renderShell();
    if (this.notificationBar) {
      this.notificationBar.setActiveTab(target);
    }

    if (target === 'overview') {
      renderOverview(
        this.viewContainer,
        api,
        (targetTab, targetParams) => this.navigateTo(targetTab, targetParams),
        (evidenceData) => this.evidenceDrawer?.open(evidenceData),
        (period) => this.trustDrawer?.open(period)
      );
    } else if (target === 'financials') {
      renderFinancials(
        this.viewContainer,
        api,
        params.tab || 'statements',
        (targetTab, targetParams) => this.navigateTo(targetTab, targetParams),
        (evidenceData) => this.evidenceDrawer?.open(evidenceData),
        (period) => this.trustDrawer?.open(period)
      );
    } else if (target === 'performance') {
      renderPerformance(
        this.viewContainer,
        api,
        params.tab || 'overview',
        (targetTab, targetParams) => this.navigateTo(targetTab, targetParams),
        (evidenceData) => this.evidenceDrawer?.open(evidenceData),
        (investigateData) => this.investigateDrawer?.open(investigateData)
      );
    } else if (target === 'investigate') {
      renderInvestigate(
        this.viewContainer,
        api,
        params.question || this.state.investigateQuestion,
        (targetTab, targetParams) => this.navigateTo(targetTab, targetParams),
        (evidenceData) => this.evidenceDrawer?.open(evidenceData),
        (caseData) => this.navigateTo('actions', { createPrefill: caseData }),
        params.context || null
      );
    } else if (target === 'actions') {
      renderActions(
        this.viewContainer,
        api,
        (evidenceData) => this.evidenceDrawer?.open(evidenceData)
      ).then(handle => {
        this.casesViewHandle = handle;
        if (params.createPrefill && handle && handle.openWithPrefill) {
          handle.openWithPrefill(params.createPrefill);
        }
      });
    } else if (target === 'dataStatus') {
      renderDataStatus(
        this.viewContainer,
        api,
        () => this.runEngineWithPhasedHud()
      );
    } else if (target === 'settings') {
      renderSettings(this.viewContainer, api);
    }
  }

  renderCurrentView() {
    this.navigateTo(this.state.activeTab);
  }

  async handlePeriodChange(period) {
    this.state.currentPeriod = period;
    api.setPeriod(period);
    try {
      this.state.trustState = await api.getTrustSummary(period).catch(() => ({ trust_state: 'UNKNOWN' }));
    } catch (e) {
      console.warn('Trust status update error:', e);
    }
    this.renderShell();
    this.renderCurrentView();
    this.updateNotifications();
  }

  async handleRefresh() {
    await this.runEngineWithPhasedHud();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const app = new FinSightApp();
  app.init();
});
