/**
 * Financial Attention Card Component
 */

import { formatCurrency } from '../utils/format.js';

export function renderAttentionCard(item, onInvestigate, onInspectEvidence) {
  const card = document.createElement('div');
  const sevLower = (item.severity || 'medium').toLowerCase();
  card.className = `attention-card ${sevLower}`;

  const impactFmt = item.financial_impact 
    ? formatCurrency(item.financial_impact, 0)
    : '—';

  const driversList = (item.drivers || []).slice(0, 3);

  card.innerHTML = `
    <div class="attention-header">
      <div class="attention-title-area">
        <span class="badge badge-${sevLower}">${item.severity}</span>
        <span class="attention-title">${item.title}</span>
      </div>
      <div class="attention-impact num">${impactFmt}</div>
    </div>

    <div class="attention-summary">${item.summary}</div>

    <div class="attention-drivers">
      ${driversList.map(d => `<span class="driver-pill">${d}</span>`).join('')}
    </div>

    <div class="attention-actions">
      ${(item.evidence && item.evidence.length > 0) ? `
        <button class="btn btn-outline btn-sm btn-evidence" title="Inspect transactional evidence">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          <span>Follow the Money (${item.evidence.length})</span>
        </button>
      ` : ''}
      <button class="btn btn-primary btn-sm btn-investigate" title="Inspect detailed root cause">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <span>Analyze Root Cause →</span>
      </button>
    </div>
  `;

  card.querySelector('.btn-investigate')?.addEventListener('click', () => {
    if (onInvestigate) onInvestigate(item);
  });

  card.querySelector('.btn-evidence')?.addEventListener('click', () => {
    if (onInspectEvidence) onInspectEvidence(item);
  });

  return card;
}
