/**
 * Clean Enterprise Cash Trend SVG Chart
 * Renders an accessible, responsive 12-month Cash Runway Curve with exact data callouts.
 */

export function renderCashTrendChart(dataPoints, width = 600, height = 180) {
  // dataPoints: Array of { period: '2025-10', value: 750000 }
  if (!dataPoints || dataPoints.length === 0) {
    return `<div style="padding: 20px; color: var(--color-text-muted); text-align: center;">No trend data available.</div>`;
  }

  const padding = { top: 20, right: 30, bottom: 30, left: 60 };
  const innerW = width - padding.left - padding.right;
  const innerH = height - padding.top - padding.bottom;

  const values = dataPoints.map(d => d.value);
  const minVal = Math.min(...values) * 0.85;
  const maxVal = Math.max(...values) * 1.05;

  const getX = (index) => padding.left + (index / (dataPoints.length - 1)) * innerW;
  const getY = (val) => padding.top + innerH - ((val - minVal) / (maxVal - minVal)) * innerH;

  const points = dataPoints.map((d, i) => `${getX(i)},${getY(d.value)}`).join(' ');
  const areaPoints = `${getX(0)},${padding.top + innerH} ` + points + ` ${getX(dataPoints.length - 1)},${padding.top + innerH}`;

  // Generate Y-axis grid ticks (3 ticks)
  const ticks = [minVal, (minVal + maxVal) / 2, maxVal];
  const gridLines = ticks.map(t => {
    const y = getY(t);
    const label = `₹${(t / 1000).toFixed(0)}k`;
    return `
      <line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3,3" />
      <text x="${padding.left - 8}" y="${y + 4}" font-size="10" fill="#94a3b8" text-anchor="end" font-family="var(--font-mono)">${label}</text>
    `;
  }).join('');

  // Generate X-axis labels
  const xLabels = dataPoints.map((d, i) => {
    // Show alternate labels to prevent crowding
    if (i % 2 !== 0 && i !== dataPoints.length - 1) return '';
    const x = getX(i);
    const shortLabel = d.period.slice(5); // '10', '12', '02'...
    return `<text x="${x}" y="${height - 8}" font-size="10.5" fill="#64748b" text-anchor="middle" font-family="var(--font-mono)">${shortLabel}</text>`;
  }).join('');

  // Interactive dots & active marker for the latest period
  const latestIndex = dataPoints.length - 1;
  const latestPt = dataPoints[latestIndex];
  const latestX = getX(latestIndex);
  const latestY = getY(latestPt.value);

  return `
    <svg viewBox="0 0 ${width} ${height}" class="cash-trend-svg" style="width: 100%; height: auto; overflow: visible;">
      <!-- Grid Lines -->
      ${gridLines}

      <!-- Shaded Area -->
      <polygon points="${areaPoints}" fill="rgba(37, 99, 235, 0.08)" />

      <!-- Curve Line -->
      <polyline points="${points}" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />

      <!-- X-axis Labels -->
      ${xLabels}

      <!-- Latest Value Marker -->
      <circle cx="${latestX}" cy="${latestY}" r="5" fill="#ef4444" stroke="#ffffff" stroke-width="2" />
      <text x="${latestX}" y="${latestY - 10}" font-size="11" font-weight="700" fill="#dc2626" text-anchor="end" font-family="var(--font-mono)">
        ₹${(latestPt.value / 1000).toFixed(0)}k (Cash Squeeze)
      </text>
    </svg>
  `;
}
