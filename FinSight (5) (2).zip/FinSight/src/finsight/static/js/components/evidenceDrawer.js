/**
 * Evidence Slide-Over Drawer Component
 * Uses native HTML5 <dialog> with modern accessible dismiss and deep "Follow the Money" audit trail.
 */

import { pushDrawerHistory, popDrawerHistory } from '../utils/drawerHistory.js';

export function initEvidenceDrawer(dialogEl, onCreateCase) {
  let currentEvidence = [];
  let currentContext = null;

  dialogEl.addEventListener('close', () => {
    popDrawerHistory('evidence-drawer');
  });

  // Light dismiss on backdrop click
  dialogEl.addEventListener('click', (e) => {
    const rect = dialogEl.getBoundingClientRect();
    const isInDialog = (
      rect.top <= e.clientY &&
      e.clientY <= rect.top + rect.height &&
      rect.left <= e.clientX &&
      e.clientX <= rect.left + rect.width
    );
    if (!isInDialog) {
      dialogEl.close();
    }
  });

  dialogEl.querySelector('.drawer-close')?.addEventListener('click', () => {
    dialogEl.close();
  });

  dialogEl.querySelector('#drawer-create-case-btn')?.addEventListener('click', () => {
    dialogEl.close();
    if (onCreateCase && currentContext) {
      onCreateCase(currentContext);
    }
  });

  return {
    open({ title, entity, evidenceList, context }) {
      currentEvidence = evidenceList || [];
      currentContext = context || { title, entity, evidence: currentEvidence };

      const titleEl = dialogEl.querySelector('.drawer-title');
      const bodyEl = dialogEl.querySelector('.drawer-body');

      if (titleEl) {
        titleEl.textContent = title || 'Audit Evidence & Subledger Records';
      }

      if (bodyEl) {
        if (!currentEvidence || currentEvidence.length === 0) {
          bodyEl.innerHTML = `
            <div style="padding: 30px; text-align: center; color: var(--color-text-muted);">
              No transaction-level evidence records attached.
            </div>
          `;
        } else {
          const financialItems = currentEvidence.filter(e => e.source_type !== 'POLICY_DOCUMENT');
          const totalVal = financialItems.reduce((sum, e) => sum + (e.value || 0), 0);

          bodyEl.innerHTML = `
            <!-- Follow the Money Visual Trail -->
            <div class="money-chain">
              <span class="chain-node">Finding</span>
              <span class="chain-arrow">→</span>
              <span class="chain-node">Driver Analysis</span>
              <span class="chain-arrow">→</span>
              <span class="chain-node" style="font-weight: 700; color: var(--color-blue-primary);">${entity || 'Entity Subledger'}</span>
              <span class="chain-arrow">→</span>
              <span class="chain-node">${currentEvidence.length} Record(s)</span>
            </div>

            ${currentContext && currentContext.crm ? `
              <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: var(--radius-sm); padding: 12px; margin-bottom: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                  <span style="font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase;">CRM Counterparty Context</span>
                  <span class="badge ${currentContext.crm.account?.health === 'CRITICAL' || currentContext.crm.account?.health === 'AT_RISK' ? 'badge-critical' : 'badge-resolved'}">
                    ${currentContext.crm.account?.health || 'HEALTHY'}
                  </span>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px; margin-bottom: 8px;">
                  <div><span style="color: #64748b;">Tier:</span> <strong>${currentContext.crm.account?.tier || 'Enterprise'}</strong></div>
                  <div><span style="color: #64748b;">Credit Limit:</span> <strong>₹${(currentContext.crm.signals?.credit_limit || 0).toLocaleString('en-IN')}</strong></div>
                  <div><span style="color: #64748b;">Credit Hold:</span> <strong style="color: ${currentContext.crm.signals?.credit_hold_recommended ? '#dc2626' : '#16a34a'};">${currentContext.crm.signals?.credit_hold_recommended ? 'RECOMMENDED' : 'NO'}</strong></div>
                  <div><span style="color: #64748b;">Account Exec:</span> <strong>${currentContext.crm.account?.account_executive || 'Assigned Lead'}</strong></div>
                </div>
                ${currentContext.crm.contacts && currentContext.crm.contacts.length > 0 ? `
                  <div style="border-top: 1px solid #e2e8f0; padding-top: 6px; font-size: 11.5px; color: #334155;">
                    <span style="color: #64748b;">Key Contact:</span> ${currentContext.crm.contacts[0].name} (${currentContext.crm.contacts[0].title}) &bull; <span class="mono">${currentContext.crm.contacts[0].email}</span>
                  </div>
                ` : ''}
              </div>
            ` : ''}

            <!-- Summary header -->
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; background-color: var(--color-surface-subtle); border-radius: var(--radius-sm); border: 1px solid var(--color-border);">
              <span style="font-size: 12px; color: var(--color-text-muted); font-weight: 600;">VERIFIED FINANCIAL SUBLEDGER SUM</span>
              <span class="num" style="font-size: 15px; font-weight: 700; color: var(--color-text-primary);">
                ₹${totalVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <!-- Evidence Cards List -->
            <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 4px;">
              ${currentEvidence.map((ev, idx) => `
                <div style="border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 14px; background-color: #ffffff;">
                  <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
                    <div>
                      ${ev.source_type === 'POLICY_DOCUMENT' ? `
                        <span class="badge" style="background:#ede9fe; color:#6b21a8; font-family: var(--font-mono); font-size: 10.5px; font-weight:700;">POLICY_DOCUMENT</span>
                        <strong style="margin-left: 6px; font-family: var(--font-mono); font-size: 13px;">${ev.source_id}</strong>
                      ` : `
                        <span class="badge badge-medium" style="font-family: var(--font-mono); font-size: 10.5px;">${ev.source_type}</span>
                        <strong style="margin-left: 6px; font-family: var(--font-mono); font-size: 13px;">${ev.source_id}</strong>
                      `}
                    </div>
                    ${ev.source_type === 'POLICY_DOCUMENT' ? `
                      <span class="badge badge-resolved" style="font-size:11px;">
                        Relevance: ${Math.round((ev.value || 1.0) * 100)}%
                      </span>
                    ` : `
                      <span class="num" style="font-weight: 700; font-size: 14px; color: var(--color-text-primary);">
                        ₹${(ev.value || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    `}
                  </div>

                  <div style="font-size: 12.5px; color: var(--color-text-secondary); margin-bottom: 10px; line-height: 1.4;">
                    ${ev.description}
                  </div>

                  ${ev.metadata && Object.keys(ev.metadata).length > 0 ? `
                    <div style="background-color: var(--color-surface-subtle); border-radius: 4px; padding: 8px 10px; font-size: 11.5px; border: 1px solid var(--color-border);">
                      <div class="kv-grid">
                        ${Object.entries(ev.metadata).map(([k, v]) => `
                          <span class="kv-key">${k.replace(/_/g, ' ')}:</span>
                          <span class="kv-val mono">${v}</span>
                        `).join('')}
                      </div>
                    </div>
                  ` : ''}
                </div>
              `).join('')}
            </div>
          `;
        }
      }

      if (!dialogEl.open) {
        pushDrawerHistory('evidence-drawer', () => dialogEl.close());
        dialogEl.showModal();
      }
    },
    close() {
      dialogEl.close();
    }
  };
}
