/**
 * Executive Top Header Component
 *
 * Professional Structure:
 * - Left: Sidebar Toggle, Title, Current Period Chip
 * - Right: Financial Data Trust & Reconciliation status chip, Recalculate Engine button, Ingest Feeds button
 */

export function renderHeader(
  container,
  title,
  currentPeriod,
  onRecalculateEngine,
  onIngestFeeds,
  onNavigate,
  onOpenTrustDrawer,
  onSignOut,
  trustState = null
) {
  const isReconciled = !trustState || trustState.overall_trust_status === 'RECONCILED' || trustState.status === 'RECONCILED' || trustState.trust_state === 'RECONCILED';
  const trustStatusText = isReconciled ? '100% Dual-Ledger Reconciled' : 'Reconciliation Discrepancy';

  container.innerHTML = `
    <!-- Header Left: Title & Fiscal Period -->
    <div class="header-left" style="display: flex; align-items: center; gap: 14px;">
      <!-- Sidebar Drawer Toggle Button -->
      <button id="header-sidebar-toggle-btn" class="sidebar-toggle-btn" title="Toggle Sidebar Navigation" aria-label="Toggle Sidebar Navigation">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
          <line x1="9" y1="3" x2="9" y2="21"/>
        </svg>
      </button>

      <h1 class="page-title" style="margin: 0; font-size: 16px; font-weight: 700; color: var(--color-text-primary); letter-spacing: -0.2px;">
        ${title}
      </h1>

      <div class="data-tag" style="display: inline-flex; align-items: center; gap: 6px; font-size: 11px; color: var(--color-text-muted); background: var(--color-surface-subtle); border: 1px solid var(--color-border); padding: 3px 8px; border-radius: var(--radius-sm); font-family: var(--font-mono);">
        <span class="status-dot" style="width: 6px; height: 6px; border-radius: 50%; background-color: #16a34a;"></span>
        <span>Period: ${currentPeriod}</span>
      </div>
    </div>

    <!-- Header Right: Trust Chip, Actions & Quick Utilities -->
    <div class="header-right" style="display: flex; align-items: center; gap: 10px;">
      <!-- Trust & Dual-Ledger Reconciliation Interactive Chip -->
      <button id="hdr-trust-btn" class="hdr-toolbar-btn" title="Inspect dual-ledger multi-layer reconciliation status" style="background: ${isReconciled ? '#f0fdf4' : '#fef2f2'}; border-color: ${isReconciled ? '#bbf7d0' : '#fecaca'}; color: ${isReconciled ? '#15803d' : '#dc2626'}; font-weight: 600; padding: 4px 10px; font-size: 11.5px; border-radius: var(--radius-sm); display: inline-flex; align-items: center; gap: 6px; cursor: pointer;">
        <span style="font-size: 12px;">🛡️</span>
        <span>${trustStatusText}</span>
      </button>

      <!-- Recalculate Engine Button (Phased HUD) -->
      <button id="hdr-recalc-btn" class="hdr-toolbar-btn btn-recalc" title="Recalculate ledger figures &amp; canonical metrics" style="display: inline-flex; align-items: center; gap: 6px; padding: 5px 12px; font-size: 11.5px; font-weight: 700; border-radius: var(--radius-sm); cursor: pointer;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        <span>⚡ Recalculate</span>
      </button>

      <!-- Ingest Feeds Button -->
      <button id="hdr-ingest-btn" class="hdr-toolbar-btn" title="Ingest raw transaction data from benchmark or ERP" style="display: inline-flex; align-items: center; gap: 6px; padding: 5px 11px; font-size: 11.5px; font-weight: 600; border-radius: var(--radius-sm); cursor: pointer;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        <span>Ingest</span>
      </button>
    </div>
  `;

  // Attach sidebar toggle listener
  const toggleBtn = container.querySelector('#header-sidebar-toggle-btn') || container.querySelector('#sidebar-toggle-btn');
  toggleBtn?.addEventListener('click', () => {
    const appContainer = document.getElementById('app-container');
    if (appContainer) {
      appContainer.classList.toggle('sidebar-collapsed');
      const isCollapsed = appContainer.classList.contains('sidebar-collapsed');
      localStorage.setItem('finsight_sidebar_collapsed', isCollapsed ? 'true' : 'false');
    }
  });

  // Attach interactive trust drawer trigger
  container.querySelector('#hdr-trust-btn')?.addEventListener('click', () => {
    if (onOpenTrustDrawer) onOpenTrustDrawer();
  });

  // Attach ingest feeds modal trigger
  container.querySelector('#hdr-ingest-btn')?.addEventListener('click', () => {
    if (onIngestFeeds) onIngestFeeds();
  });

  // Attach recalculate engine trigger
  container.querySelector('#hdr-recalc-btn')?.addEventListener('click', () => {
    if (onRecalculateEngine) onRecalculateEngine();
  });
}
