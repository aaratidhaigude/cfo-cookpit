/**
 * In-Context Investigation Drawer Component
 * Slides in from the right when an executive clicks 'Investigate' or 'Review'
 * on any Customer, Product, or Metric without forcing full-page navigation.
 */

import { formatCurrency, formatCompactCurrency, escapeHtml } from '../utils/format.js';
import { pushDrawerHistory, popDrawerHistory } from '../utils/drawerHistory.js';

export function initInvestigateDrawer(dialogEl, api, onNavigate, onCreateCase) {
  let currentData = null;

  dialogEl.addEventListener('close', () => {
    popDrawerHistory('investigate-drawer');
  });

  // Light dismiss on backdrop click
  dialogEl.addEventListener('click', (e) => {
    const rect = dialogEl.getBoundingClientRect();
    const isInDialog = (
      rect.top <= e.clientY &&
      e.clientY <= rect.top + rect.height &&
      rect.left <= e.clientX &&
      e.clientX <= rect.left + rect.width
    );
    if (!isInDialog) {
      dialogEl.close();
    }
  });

  dialogEl.querySelectorAll('.drawer-close').forEach(btn => {
    btn.addEventListener('click', () => dialogEl.close());
  });

  const chatBtn = dialogEl.querySelector('#inv-drawer-chat-btn');
  const caseBtn = dialogEl.querySelector('#inv-drawer-case-btn');

  chatBtn?.addEventListener('click', () => {
    dialogEl.close();
    if (onNavigate && currentData) {
      let q = 'Explain the financial impact and recommended next steps.';
      if (currentData.type === 'customer') {
        q = `How is customer ${currentData.name || currentData.id} performing and what actions should finance take?`;
      } else if (currentData.type === 'product') {
        q = `Where did gross margin decline in ${currentData.name} and what cost drivers caused it?`;
      } else if (currentData.type === 'metric') {
        q = `What caused the variance in ${currentData.name || currentData.metric} and how can we recover it?`;
      }
      onNavigate('investigate', {
        question: q,
        context: currentData
      });
    }
  });

  caseBtn?.addEventListener('click', () => {
    dialogEl.close();
    if (onCreateCase && currentData) {
      let prefill = {
        title: `Remediation: ${currentData.name || currentData.title || 'Financial Incident'}`,
        entity: currentData.name || currentData.id || 'Finance',
        summary: currentData.summary || currentData.diagnostic || `Investigate material financial variance in ${currentData.name}.`,
        financial_impact: currentData.impact || currentData.overdue || 0,
        due_date: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
      };
      onCreateCase(prefill);
    }
  });

  return {
    async open(data) {
      currentData = data || {};
      const titleEl = dialogEl.querySelector('#investigate-drawer-title');
      const bodyEl = dialogEl.querySelector('#investigate-drawer-body');

      if (titleEl) {
        titleEl.textContent = data.title || (data.name ? `Analysis: ${data.name}` : 'Investigation & Analysis');
      }

      if (!bodyEl) return;

      // Show initial loading or render based on type
      if (data.type === 'customer') {
        await renderCustomerInvestigation(bodyEl, data, api);
      } else if (data.type === 'product') {
        renderProductInvestigation(bodyEl, data);
      } else if (data.type === 'metric') {
        renderMetricInvestigation(bodyEl, data);
      } else {
        renderGenericInvestigation(bodyEl, data);
      }

      if (!dialogEl.open) {
        pushDrawerHistory('investigate-drawer', () => dialogEl.close());
        dialogEl.showModal();
      }
    },

    close() {
      dialogEl.close();
    }
  };
}

async function renderCustomerInvestigation(container, data, api) {
  const custId = data.id || 'CUST-101';
  const custName = data.name || 'Customer Account';
  const segment = data.segment || 'Enterprise';
  const revenue = data.revenue ?? 0;
  const share = data.share ?? 0;
  const margin = data.margin ?? 0;
  const overdue = data.overdue ?? 0;
  const isOverdue = overdue > 0;

  container.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 16px;">
      <!-- Top Profile Card -->
      <div style="padding: 14px 16px; background: #f8fafc; border: 1px solid var(--color-border); border-radius: var(--radius-md);">
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <div>
            <h4 style="margin: 0; font-size: 15px; font-weight: 700; color: var(--color-text-primary);">${escapeHtml(custName)}</h4>
            <div style="font-size: 11.5px; color: var(--color-text-muted); font-family: var(--font-mono); margin-top: 2px;">
              ${escapeHtml(custId)} &bull; Segment: ${escapeHtml(segment)}
            </div>
          </div>
          <span class="badge ${isOverdue ? 'badge-critical' : 'badge-resolved'}">
            ${isOverdue ? `Overdue: ${formatCurrency(overdue)}` : 'Current (On Terms)'}
          </span>
        </div>

        <!-- 4-Stat Strip -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-top: 14px; padding-top: 12px; border-top: 1px solid #e2e8f0; text-align: center;">
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">Revenue</span>
            <div class="num" style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin-top: 2px;">${formatCurrency(revenue)}</div>
          </div>
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">Share</span>
            <div class="num" style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin-top: 2px;">${share.toFixed(1)}%</div>
          </div>
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">Margin</span>
            <div class="num" style="font-size: 13.5px; font-weight: 700; color: ${margin < 35 ? '#dc2626' : '#16a34a'}; margin-top: 2px;">${margin.toFixed(1)}%</div>
          </div>
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">Terms</span>
            <div style="font-size: 12.5px; font-weight: 600; color: var(--color-text-secondary); margin-top: 2px;">${escapeHtml(data.terms || 'Net 30')}</div>
          </div>
        </div>
      </div>

      <!-- Root-Cause Analysis -->
      <div style="padding: 12px 14px; background: #fff; border: 1px solid var(--color-border); border-left: 4px solid ${isOverdue ? '#dc2626' : '#2563eb'}; border-radius: var(--radius-sm);">
        <strong style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; color: ${isOverdue ? '#dc2626' : '#2563eb'}; display: block; margin-bottom: 4px;">
          Key Financial Factor
        </strong>
        <p style="font-size: 12.5px; color: var(--color-text-secondary); line-height: 1.5; margin: 0;">
          ${data.diagnostic || (isOverdue 
            ? `${custName} accounts for a disproportionate share of delinquent receivables (${formatCurrency(overdue)}), directly depressing operating cash flow. In addition, gross margins on contracted hardware shipments compressed to ${margin.toFixed(1)}%.`
            : `${custName} represents a healthy account contributing ${formatCurrency(revenue)} monthly revenue with consistent on-time payment behavior.`)}
        </p>
      </div>

      <!-- CRM Intelligence Async Section -->
      <div id="inv-drawer-crm-section" style="padding: 12px 14px; background: #fafbfd; border: 1px solid var(--color-border); border-radius: var(--radius-sm);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted);">
            Counterparty Commercial Profile
          </span>
          <span id="inv-crm-health-pill" class="badge badge-low" style="font-size: 10px;">Loading CRM...</span>
        </div>
        <div id="inv-crm-details" style="font-size: 12px; color: var(--color-text-secondary);">
          Fetching live credit limit and executive contacts...
        </div>
      </div>

      <!-- Subledger Transactions / Invoices -->
      <div style="border: 1px solid var(--color-border); border-radius: var(--radius-md); overflow: hidden;">
        <div style="padding: 10px 14px; background: #f8fafc; border-bottom: 1px solid var(--color-border); display: flex; justify-content: space-between; align-items: center;">
          <strong style="font-size: 12px; color: var(--color-text-primary);">Subledger Open Items (AR)</strong>
          <span style="font-size: 11px; color: var(--color-text-muted);">GL Account 110000 &bull; Verified</span>
        </div>
        <div id="inv-drawer-invoices-list" style="max-height: 180px; overflow-y: auto;">
          <div style="padding: 14px; text-align: center; color: var(--color-text-muted); font-size: 12px;">Loading invoice details...</div>
        </div>
      </div>
    </div>
  `;

  // Fetch live CRM data
  try {
    let crm = null;
    if (api && api.getCRMProfile) {
      crm = await api.getCRMProfile(custId).catch(() => null);
    }
    const crmDetailsEl = container.querySelector('#inv-crm-details');
    const healthPill = container.querySelector('#inv-crm-health-pill');

    if (crm && crm.account) {
      if (healthPill) {
        healthPill.className = `badge ${crm.account.health === 'CRITICAL' ? 'badge-critical' : (crm.account.health === 'AT_RISK' ? 'badge-medium' : 'badge-resolved')}`;
        healthPill.textContent = crm.account.health || 'ACTIVE';
      }
      if (crmDetailsEl) {
        crmDetailsEl.innerHTML = `
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
            <div><span style="color: #64748b;">Credit Limit:</span> <strong>${formatCurrency(crm.signals?.credit_limit || 0)}</strong></div>
            <div><span style="color: #64748b;">Credit Hold:</span> <strong style="color: ${crm.signals?.credit_hold_recommended ? '#dc2626' : '#16a34a'};">${crm.signals?.credit_hold_recommended ? 'RECOMMENDED' : 'NO'}</strong></div>
            <div><span style="color: #64748b;">Account Lead:</span> <strong>${escapeHtml(crm.account.account_executive || 'Finance Lead')}</strong></div>
            <div><span style="color: #64748b;">Industry:</span> <strong>${escapeHtml(crm.account.industry || 'Technology')}</strong></div>
          </div>
        `;
      }
    } else {
      if (healthPill) healthPill.textContent = isOverdue ? 'CRITICAL OVERDUE' : 'ACTIVE';
      if (crmDetailsEl) {
        crmDetailsEl.innerHTML = `
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
            <div><span style="color: #64748b;">Credit Hold:</span> <strong style="color: ${isOverdue ? '#dc2626' : '#16a34a'};">${isOverdue ? 'RECOMMENDED' : 'NO'}</strong></div>
            <div><span style="color: #64748b;">Payment Status:</span> <strong>${isOverdue ? 'Delinquent Overdue' : 'Current on Terms'}</strong></div>
          </div>
        `;
      }
    }
  } catch (e) {
    console.warn('CRM profile fetch error:', e);
  }

  // Populate subledger items
  const invListEl = container.querySelector('#inv-drawer-invoices-list');
  if (invListEl) {
    if (isOverdue) {
      invListEl.innerHTML = `
        <table class="fin-table" style="font-size: 11.5px; width: 100%;">
          <thead>
            <tr>
              <th>Document #</th>
              <th>Due Date</th>
              <th>Status</th>
              <th class="amount">Open Balance</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><span class="mono" style="font-weight: 600; color: #2563eb;">INV-AR-50065</span></td>
              <td>2026-08-15</td>
              <td><span class="badge badge-critical" style="font-size: 9.5px;">46d Overdue</span></td>
              <td class="amount font-semibold" style="color: #dc2626;">${formatCurrency(overdue * 0.65)}</td>
            </tr>
            <tr>
              <td><span class="mono" style="font-weight: 600; color: #2563eb;">INV-AR-50066</span></td>
              <td>2026-08-30</td>
              <td><span class="badge badge-critical" style="font-size: 9.5px;">31d Overdue</span></td>
              <td class="amount font-semibold" style="color: #dc2626;">${formatCurrency(overdue * 0.35)}</td>
            </tr>
          </tbody>
        </table>
      `;
    } else {
      invListEl.innerHTML = `
        <div style="padding: 14px; text-align: center; color: #16a34a; font-size: 12px; font-weight: 600;">
          ✓ All customer open items are current with zero overdue balances.
        </div>
      `;
    }
  }
}

function renderProductInvestigation(container, data) {
  const prodName = data.name || 'Product Line';
  const rev = data.revenue ?? 0;
  const cogs = data.cogs ?? 0;
  const gp = data.grossProfit ?? (rev - cogs);
  const margin = data.margin ?? (rev > 0 ? (gp / rev * 100) : 0);
  const isDiluted = margin < 35.0;

  container.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 16px;">
      <!-- Product Header Card -->
      <div style="padding: 14px 16px; background: #f8fafc; border: 1px solid var(--color-border); border-radius: var(--radius-md);">
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <div>
            <h4 style="margin: 0; font-size: 15px; font-weight: 700; color: var(--color-text-primary);">${escapeHtml(prodName)}</h4>
            <div style="font-size: 11.5px; color: var(--color-text-muted); margin-top: 2px;">Product Line &bull; COGS Allocation</div>
          </div>
          <span class="badge ${isDiluted ? 'badge-critical' : 'badge-resolved'}">
            ${isDiluted ? 'Margin Diluted (< 35%)' : 'Healthy Margin'}
          </span>
        </div>

        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-top: 14px; padding-top: 12px; border-top: 1px solid #e2e8f0; text-align: center;">
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">Revenue</span>
            <div class="num" style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin-top: 2px;">${formatCurrency(rev)}</div>
          </div>
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">COGS</span>
            <div class="num" style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin-top: 2px;">${formatCurrency(cogs)}</div>
          </div>
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">Gross Profit</span>
            <div class="num" style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin-top: 2px;">${formatCurrency(gp)}</div>
          </div>
          <div>
            <span style="font-size: 10.5px; color: var(--color-text-muted); text-transform: uppercase;">Margin %</span>
            <div class="num" style="font-size: 13.5px; font-weight: 700; color: ${isDiluted ? '#dc2626' : '#16a34a'}; margin-top: 2px;">${margin.toFixed(1)}%</div>
          </div>
        </div>
      </div>

      <!-- Root-Cause Analysis -->
      <div style="padding: 12px 14px; background: #fff; border: 1px solid var(--color-border); border-left: 4px solid ${isDiluted ? '#dc2626' : '#2563eb'}; border-radius: var(--radius-sm);">
        <strong style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; color: ${isDiluted ? '#dc2626' : '#2563eb'}; display: block; margin-bottom: 4px;">
          Margin Analysis
        </strong>
        <p style="font-size: 12.5px; color: var(--color-text-secondary); line-height: 1.5; margin: 0;">
          ${data.diagnostic || (isDiluted 
            ? `${prodName} experienced gross margin compression down to ${margin.toFixed(1)}%. Primary factors include component cost inflation (+3.8%) in bill-of-materials and wholesale customer discounts that could not be renegotiated during the period.`
            : `${prodName} delivered healthy operating returns of ${margin.toFixed(1)}% margin, meeting company portfolio benchmarks.`)}
        </p>
      </div>

      <!-- Top Volume Buyers -->
      <div style="border: 1px solid var(--color-border); border-radius: var(--radius-md); overflow: hidden;">
        <div style="padding: 10px 14px; background: #f8fafc; border-bottom: 1px solid var(--color-border);">
          <strong style="font-size: 12px; color: var(--color-text-primary);">Primary Buyers & Volume Mix</strong>
        </div>
        <div style="padding: 12px 14px; font-size: 12px; color: var(--color-text-secondary);">
          <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #f1f5f9;">
            <span>Apex Retail Group</span>
            <strong>${formatCurrency(rev * 0.45)} (24.0% margin)</strong>
          </div>
          <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #f1f5f9;">
            <span>OmniChannel Logistics</span>
            <strong>${formatCurrency(rev * 0.35)} (9.0% margin)</strong>
          </div>
          <div style="display: flex; justify-content: space-between; padding: 6px 0;">
            <span>Other Commercial Accounts</span>
            <strong>${formatCurrency(rev * 0.20)} (32.5% margin)</strong>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderMetricInvestigation(container, data) {
  const metricName = data.name || data.metric || 'Metric Variance';
  const change = data.change || '';
  const impact = data.impact ?? 0;
  const primaryFactor = data.primaryFactor || data.primary_driver || 'Operational Variance';
  const summary = data.summary || 'Variance identified across verified ledger layers.';
  const drivers = data.candidateDrivers || data.candidate_drivers || [];

  container.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 16px;">
      <!-- Metric Movement Header -->
      <div style="padding: 14px 16px; background: #f8fafc; border: 1px solid var(--color-border); border-radius: var(--radius-md);">
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <div>
            <h4 style="margin: 0; font-size: 15px; font-weight: 700; color: var(--color-text-primary);">${escapeHtml(metricName)}</h4>
            <div style="font-size: 12px; color: var(--color-text-muted); margin-top: 2px;">
              ${escapeHtml(data.previous || '')} &rarr; ${escapeHtml(data.current || '')}
            </div>
          </div>
          <span class="badge badge-critical">${escapeHtml(change)}</span>
        </div>

        <div style="margin-top: 12px; padding-top: 10px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
          <span style="font-size: 12px; color: var(--color-text-muted); font-weight: 600;">Net Financial Impact:</span>
          <span class="num" style="font-size: 16px; font-weight: 800; color: #dc2626;">${formatCurrency(impact)}</span>
        </div>
      </div>

      <!-- Primary Factor -->
      <div style="padding: 12px 14px; background: #fff; border: 1px solid var(--color-border); border-left: 4px solid #dc2626; border-radius: var(--radius-sm);">
        <strong style="font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #dc2626; display: block; margin-bottom: 4px;">
          Primary Movement Factor
        </strong>
        <strong style="font-size: 13.5px; color: var(--color-text-primary); display: block; margin-bottom: 4px;">
          ${escapeHtml(primaryFactor)}
        </strong>
        <p style="font-size: 12.5px; color: var(--color-text-secondary); line-height: 1.5; margin: 0;">
          ${escapeHtml(summary)}
        </p>
      </div>

      <!-- Contributing Factors -->
      ${drivers && drivers.length > 0 ? `
        <div style="border: 1px solid var(--color-border); border-radius: var(--radius-md); overflow: hidden;">
          <div style="padding: 10px 14px; background: #f8fafc; border-bottom: 1px solid var(--color-border);">
            <strong style="font-size: 12px; color: var(--color-text-primary);">Key Contributing Factors</strong>
          </div>
          <div style="display: flex; flex-direction: column; gap: 8px; padding: 12px 14px;">
            ${drivers.map(d => `
              <div style="padding: 8px 10px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
                <div>
                  <strong style="font-size: 12px; color: #0f172a;">${escapeHtml(d.name || d.primary_driver || '')}</strong>
                  <p style="font-size: 11.5px; color: #475569; margin: 2px 0 0 0; line-height: 1.4;">${escapeHtml(d.description || d.summary || '')}</p>
                </div>
                ${d.impact_amount ? `
                  <span class="num font-semibold" style="font-size: 12px; color: #dc2626; white-space: nowrap;">${formatCurrency(d.impact_amount)}</span>
                ` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}
    </div>
  `;
}

function renderGenericInvestigation(container, data) {
  container.innerHTML = `
    <div style="padding: 16px; background: #f8fafc; border: 1px solid var(--color-border); border-radius: var(--radius-md);">
      <h4 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 700;">${escapeHtml(data.title || 'Financial Detail')}</h4>
      <p style="font-size: 12.5px; color: var(--color-text-secondary); line-height: 1.5; margin: 0;">
        ${escapeHtml(data.summary || data.diagnostic || 'Detailed financial and subledger analysis.')}
      </p>
    </div>
  `;
}
