/**
 * Executive Metric KPI Card Component
 */

export function renderMetricCard({
  label,
  value,
  formattedValue,
  deltaText = null,
  deltaType = 'neutral', // 'pos', 'neg', 'neutral'
  badgeText = null,
  badgeType = null,      // 'critical', 'high', 'medium', 'low', 'resolved'
  subtext = null,
  onClick = null,
}) {
  const card = document.createElement('div');
  card.className = 'metric-card';
  if (onClick) {
    card.style.cursor = 'pointer';
    card.addEventListener('click', onClick);
  }

  let badgeHtml = '';
  if (badgeText) {
    badgeHtml = `<span class="badge ${badgeType ? `badge-${badgeType}` : ''}">${badgeText}</span>`;
  }

  let deltaHtml = '';
  if (deltaText) {
    const deltaClass = deltaType === 'pos' ? 'delta-pos' : deltaType === 'neg' ? 'delta-neg' : 'delta-neutral';
    deltaHtml = `<span class="metric-delta ${deltaClass}">${deltaText}</span>`;
  }

  card.innerHTML = `
    <div class="metric-card-header">
      <span class="metric-label">${label}</span>
      ${badgeHtml}
    </div>
    <div class="metric-value num">${formattedValue || value}</div>
    <div class="metric-comparison">
      ${deltaHtml}
      ${subtext ? `<span class="metric-subtext">${subtext}</span>` : ''}
    </div>
  `;

  return card;
}
