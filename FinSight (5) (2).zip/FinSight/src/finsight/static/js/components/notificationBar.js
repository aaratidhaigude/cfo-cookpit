/**
 * Executive Notification Bar Component
 * Displays urgent financial risks and liquidity alerts at the top of the workspace.
 */

export function initNotificationBar(container, onInvestigate, onViewCases) {
  let isDismissed = false;
  let currentAlert = null;
  let activeTab = 'overview';

  function render() {
    if (!currentAlert || isDismissed || activeTab !== 'overview') {
      container.style.display = 'none';
      container.innerHTML = '';
      return;
    }

    container.style.display = 'block';
    container.innerHTML = `
      <div class="notification-banner">
        <div class="notification-left">
          <span class="notification-tag">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            ${currentAlert.tag || 'URGENT ATTENTION'}
          </span>
          <div class="notification-message">
            <strong>${currentAlert.headline}:</strong> ${currentAlert.details}
          </div>
        </div>
        <div class="notification-actions">
          ${currentAlert.investigateQuestion ? `
            <button class="notification-btn notification-btn-primary" id="btn-notif-investigate">
              ${currentAlert.actionLabel || 'Investigate Cause →'}
            </button>
          ` : ''}
          ${onViewCases ? `
            <button class="notification-btn" id="btn-notif-cases">
              Action Plans
            </button>
          ` : ''}
          <button class="notification-close" id="btn-notif-dismiss" title="Dismiss alert">
            ✕
          </button>
        </div>
      </div>
    `;

    container.querySelector('#btn-notif-investigate')?.addEventListener('click', () => {
      if (onInvestigate && currentAlert.investigateQuestion) {
        onInvestigate(currentAlert.investigateQuestion);
      }
    });

    container.querySelector('#btn-notif-cases')?.addEventListener('click', () => {
      if (onViewCases) onViewCases();
    });

    container.querySelector('#btn-notif-dismiss')?.addEventListener('click', () => {
      isDismissed = true;
      render();
    });
  }

  return {
    setAlert(alert) {
      currentAlert = alert;
      isDismissed = false;
      render();
    },
    evaluateAttention(attentionItems) {
      if (!attentionItems || attentionItems.length === 0) {
        currentAlert = null;
        render();
        return;
      }

      // Find highest priority item
      const criticalItem = attentionItems.find(it => it.severity === 'CRITICAL') || attentionItems[0];
      if (criticalItem) {
        this.setAlert({
          tag: `${criticalItem.severity} PRIORITY`,
          headline: criticalItem.title,
          details: criticalItem.summary,
          investigateQuestion: criticalItem.type === 'CASH_PRESSURE'
            ? 'Why did cash decrease?'
            : (criticalItem.type === 'AR_DETERIORATION' ? 'Which customers are driving overdue AR?' : null),
          actionLabel: 'Analyze Root Cause →',
        });
      }
    },
    dismiss() {
      isDismissed = true;
      render();
    },
    reopen() {
      isDismissed = false;
      render();
    },
    setActiveTab(tab) {
      activeTab = tab;
      render();
    }
  };
}
