/**
 * Sidebar Navigation Component (Sprint 11)
 * Enforces strictly 5 primary executive navigation destinations:
 * 1. Overview
 * 2. Financials
 * 3. Performance
 * 4. Investigate
 * 5. Actions
 */

import { renderUserProfileMenu } from './userProfileMenu.js';

const MONTH_NAMES = {
  '01': 'January',
  '02': 'February',
  '03': 'March',
  '04': 'April',
  '05': 'May',
  '06': 'June',
  '07': 'July',
  '08': 'August',
  '09': 'September',
  '10': 'October',
  '11': 'November',
  '12': 'December',
};

function formatPeriodLabel(p) {
  if (typeof p !== 'string') return String(p);
  const parts = p.split('-');
  if (parts.length === 2) {
    const year = parts[0];
    const month = parts[1];
    if (MONTH_NAMES[month]) {
      return `${MONTH_NAMES[month]} ${year}`;
    }
    if (month.startsWith('Q')) {
      return `Q${month.slice(1)} ${year}`;
    }
  }
  return p;
}

function renderPeriodOptions(periods, currentPeriod) {
  if (!Array.isArray(periods) || periods.length === 0) {
    return `<option value="${currentPeriod}" selected>${formatPeriodLabel(currentPeriod)}</option>`;
  }

  // Group by fiscal year if available periods justify it (> 3 periods across multiple years)
  const yearsMap = {};
  for (const p of periods) {
    const year = typeof p === 'string' && p.includes('-') ? p.split('-')[0] : 'Other';
    if (!yearsMap[year]) yearsMap[year] = [];
    yearsMap[year].push(p);
  }

  const distinctYears = Object.keys(yearsMap);
  const shouldGroup = periods.length > 3 && distinctYears.length >= 2;

  if (shouldGroup) {
    // Reverse chronological order for fiscal years (e.g. 2026, 2025)
    distinctYears.sort((a, b) => b.localeCompare(a));

    return distinctYears.map(year => {
      // Reverse chronological order within each fiscal year (e.g. Sep 2026, Aug 2026, ...)
      const yearPeriods = [...yearsMap[year]].sort((a, b) => b.localeCompare(a));
      return `
        <optgroup label="${year}">
          ${yearPeriods.map(p => `
            <option value="${p}" ${p === currentPeriod ? 'selected' : ''}>${formatPeriodLabel(p)}${p === '2026-09' ? ' (Active / Live)' : ''}</option>
          `).join('')}
        </optgroup>
      `;
    }).join('');
  }

  return periods.map(p => `
    <option value="${p}" ${p === currentPeriod ? 'selected' : ''}>${formatPeriodLabel(p)}${p === '2026-09' ? ' (Active / Live)' : ''}</option>
  `).join('');
}

export function renderSidebar(container, state, onNavigate, onPeriodChange, onSignOut) {
  const openCasesCount = state.cases ? state.cases.filter(c => c.status === 'OPEN').length : 0;

  // Map legacy tab names to 5 primary destinations for active state highlight
  let activeTab = state.activeTab;
  if (activeTab === 'commandCenter') activeTab = 'overview';
  if (activeTab === 'money') activeTab = 'financials';
  if (activeTab === 'cases') activeTab = 'actions';

  container.innerHTML = `
    <div class="sidebar-brand">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div class="brand-icon">FS</div>
        <div class="brand-info">
          <span class="brand-name">FinSight</span>
          <span class="brand-tagline">Financial Analytics &amp; Control</span>
        </div>
      </div>
      <button id="sidebar-toggle-btn" class="sidebar-toggle-btn" title="Toggle Sidebar Navigation" aria-label="Toggle Sidebar Navigation">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
          <line x1="9" y1="3" x2="9" y2="21"/>
        </svg>
      </button>
    </div>

    <div class="sidebar-period">
      <label for="period-switcher">Fiscal Period</label>
      <select id="period-switcher" class="period-select">
        ${renderPeriodOptions(state.periods, state.currentPeriod)}
      </select>
    </div>

    <nav class="sidebar-nav">
      <!-- 1. Overview -->
      <a class="nav-item ${activeTab === 'overview' ? 'active' : ''}" data-target="overview" id="nav-overview">
        <span class="nav-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>
        </span>
        <span>Overview</span>
      </a>

      <!-- 2. Financials -->
      <a class="nav-item ${activeTab === 'financials' ? 'active' : ''}" data-target="financials" id="nav-financials">
        <span class="nav-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M15 9.5a2.5 2.5 0 0 0-5 0c0 4 5 2 5 6a2.5 2.5 0 0 1-5 0"/></svg>
        </span>
        <span>Financials</span>
      </a>

      <!-- 3. Performance -->
      <a class="nav-item ${activeTab === 'performance' ? 'active' : ''}" data-target="performance" id="nav-performance">
        <span class="nav-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
        </span>
        <span>Performance</span>
      </a>

      <!-- 4. Investigate -->
      <a class="nav-item ${activeTab === 'investigate' ? 'active' : ''}" data-target="investigate" id="nav-investigate">
        <span class="nav-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        </span>
        <span>Investigate</span>
      </a>

      <!-- 5. Actions -->
      <a class="nav-item ${activeTab === 'actions' ? 'active' : ''}" data-target="actions" id="nav-actions">
        <span class="nav-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
        </span>
        <span>Actions</span>
        ${openCasesCount > 0 ? `<span class="nav-badge">${openCasesCount}</span>` : ''}
      </a>
    </nav>

    <!-- Sidebar Bottom User Profile Slot -->
    <div class="sidebar-user-footer">
      <div id="sidebar-user-profile-slot"></div>
    </div>
  `;

  // Attach event listeners
  container.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const target = item.getAttribute('data-target');
      if (target && onNavigate) onNavigate(target);
    });
  });

  const periodSelect = container.querySelector('#period-switcher');
  if (periodSelect) {
    periodSelect.addEventListener('change', (e) => {
      if (onPeriodChange) onPeriodChange(e.target.value);
    });
  }

  const profileSlot = container.querySelector('#sidebar-user-profile-slot');
  if (profileSlot) {
    renderUserProfileMenu(profileSlot, onNavigate, onSignOut);
  }

  const toggleBtn = container.querySelector('#sidebar-toggle-btn') || container.querySelector('.sidebar-toggle-btn') || container.querySelector('#sidebar-close-btn');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const appContainer = document.getElementById('app-container');
      if (appContainer) {
        appContainer.classList.toggle('sidebar-collapsed');
        const isCollapsed = appContainer.classList.contains('sidebar-collapsed');
        localStorage.setItem('finsight_sidebar_collapsed', isCollapsed ? 'true' : 'false');
      }
    });
  }
}
