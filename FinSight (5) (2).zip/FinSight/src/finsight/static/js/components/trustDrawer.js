/**
 * Financial Data Trust & Reconciliation Slide-Over Drawer Component
 * Visualizes the enterprise financial data trust pipeline:
 * SOURCE -> NORMALIZE -> MAP -> DEFINE -> CALCULATE -> RECONCILE -> PUBLISH -> TRACE
 */

import { pushDrawerHistory, popDrawerHistory } from '../utils/drawerHistory.js';

export function initTrustDrawer(dialogEl, api, onRecalculateEngine) {
  if (!dialogEl) return null;

  dialogEl.addEventListener('close', () => {
    popDrawerHistory('trust-drawer');
  });

  // Light dismiss on backdrop click
  dialogEl.addEventListener('click', (e) => {
    const rect = dialogEl.getBoundingClientRect();
    const isInDialog = (
      rect.top <= e.clientY &&
      e.clientY <= rect.top + rect.height &&
      rect.left <= e.clientX &&
      e.clientX <= rect.left + rect.width
    );
    if (!isInDialog) {
      dialogEl.close();
    }
  });

  dialogEl.querySelectorAll('.drawer-close').forEach(btn => {
    btn.addEventListener('click', () => dialogEl.close());
  });

  const recalcBtn = dialogEl.querySelector('#trust-drawer-recalc-btn');
  if (recalcBtn) {
    recalcBtn.addEventListener('click', () => {
      dialogEl.close();
      if (onRecalculateEngine) onRecalculateEngine();
    });
  }

  const renderTrustContent = async (period) => {
    const bodyEl = dialogEl.querySelector('#trust-drawer-body');
    if (!bodyEl) return;

    bodyEl.innerHTML = `
      <div style="padding: 40px; text-align: center; color: var(--color-text-muted);">
        <div class="spinner" style="margin: 0 auto 12px;"></div>
        <p style="font-size: 13px;">Auditing General Ledger mappings &amp; reconciliation ties...</p>
      </div>
    `;

    try {
      const [summary, ties, mappingsData] = await Promise.all([
        api.getTrustSummary(period),
        api.getTrustReconciliation(period),
        api.getTrustMappings(),
      ]);

      const isReconciled = summary.overall_trust_status === 'RECONCILED';
      const badgeBg = isReconciled ? '#ecfdf5' : '#fffbeb';
      const badgeColor = isReconciled ? '#059669' : '#d97706';
      const badgeBorder = isReconciled ? '#a7f3d0' : '#fde68a';

      bodyEl.innerHTML = `
        <!-- Trust Status Hero Banner -->
        <div style="background: ${badgeBg}; border: 1px solid ${badgeBorder}; border-radius: 8px; padding: 14px 18px; margin-bottom: 6px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: ${badgeColor};"></span>
              <strong style="color: ${badgeColor}; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">
                ${summary.trust_badge_label || 'Financial Data Reconciled'}
              </strong>
            </div>
            <span style="font-size: 11px; color: var(--color-text-muted); font-family: var(--font-mono);">
              Period: ${summary.period}
            </span>
          </div>
          <p style="font-size: 12.5px; color: var(--color-text-primary); margin: 0; line-height: 1.4;">
            Every published figure is mathematically tied across 4 auditing layers: Source Subledger, Mapped GL Chart of Accounts, Governed Metric Formula, and Executive Reporting.
          </p>
        </div>

        <!-- System Governance & Mapping Stats Card -->
        <div style="background: #ffffff; border: 1px solid var(--color-border); border-radius: 8px; padding: 16px;">
          <h4 style="font-size: 13px; font-weight: 700; color: var(--color-text-primary); margin: 0 0 12px; display: flex; align-items: center; gap: 6px;">
            <span>🏛️</span> Enterprise Source &amp; Mapping Governance
          </h4>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 12.5px;">
            <div>
              <span style="color: var(--color-text-muted); display: block; font-size: 11px; margin-bottom: 2px;">SOURCE SYSTEM ADAPTER</span>
              <strong style="color: var(--color-text-primary);">${summary.source_system}</strong>
            </div>
            <div>
              <span style="color: var(--color-text-muted); display: block; font-size: 11px; margin-bottom: 2px;">POSTED RECORDS AUDITED</span>
              <strong style="color: var(--color-text-primary);">${summary.records_processed} Transactions</strong>
            </div>
            <div>
              <span style="color: var(--color-text-muted); display: block; font-size: 11px; margin-bottom: 2px;">CHART OF ACCOUNTS COVERAGE</span>
              <strong style="color: #059669;">${summary.mapping_coverage_pct}% (${summary.mapped_accounts_count}/${summary.total_accounts} Mapped)</strong>
            </div>
            <div>
              <span style="color: var(--color-text-muted); display: block; font-size: 11px; margin-bottom: 2px;">UNMAPPED / AMBIGUOUS</span>
              <strong style="color: ${summary.unmapped_accounts_count > 0 ? '#dc2626' : '#64748b'};">
                ${summary.unmapped_accounts_count} Accounts
              </strong>
            </div>
          </div>
        </div>

        <!-- 4-Layer Multi-Layer Reconciliation Ties -->
        <div style="background: #ffffff; border: 1px solid var(--color-border); border-radius: 8px; padding: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <h4 style="font-size: 13px; font-weight: 700; color: var(--color-text-primary); margin: 0; display: flex; align-items: center; gap: 6px;">
              <span>⚖️</span> Subledger-to-GL Multi-Layer Reconciliation Ties
            </h4>
            <span class="badge badge-resolved" style="font-size: 11px;">
              ${summary.reconciled_checks_count} / ${summary.total_reconciliation_checks} Reconciled
            </span>
          </div>

          <div style="display: flex; flex-direction: column; gap: 10px;">
            ${(ties || []).map(tie => `
              <div style="border: 1px solid var(--color-border); border-radius: 6px; padding: 12px; background: var(--color-surface-subtle);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                  <div style="display: flex; align-items: center; gap: 8px;">
                    <span style="font-weight: 700; font-size: 13px; text-transform: capitalize; color: var(--color-text-primary);">
                      ${tie.metric_or_concept.replace(/_/g, ' ')}
                    </span>
                    <span style="font-family: var(--font-mono); font-size: 10.5px; color: var(--color-text-muted);">
                      [${tie.tie_id}]
                    </span>
                  </div>
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <span class="badge ${tie.status === 'RECONCILED' ? 'badge-resolved' : 'badge-critical'}" style="font-size: 11px;">
                      ${tie.status === 'RECONCILED' ? '✓ RECONCILED' : '⚠ FAILED'}
                    </span>
                    <button class="btn btn-secondary btn-sm trace-lineage-btn" data-metric="${tie.metric_or_concept}" style="padding: 2px 8px; font-size: 11px;" title="View end-to-end mathematical lineage">
                      Trace Lineage →
                    </button>
                  </div>
                </div>

                <!-- 4 Layer Drilldown -->
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 8px; font-size: 11px; background: #ffffff; padding: 8px 10px; border-radius: 4px; border: 1px solid var(--color-border);">
                  <div>
                    <span style="color: var(--color-text-muted); display: block;">1. Subledger</span>
                    <strong class="num">₹${tie.source_value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                  </div>
                  <div>
                    <span style="color: var(--color-text-muted); display: block;">2. Mapped GL</span>
                    <strong class="num">₹${tie.mapped_value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                  </div>
                  <div>
                    <span style="color: var(--color-text-muted); display: block;">3. Published</span>
                    <strong class="num">₹${tie.published_value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                  </div>
                  <div>
                    <span style="color: var(--color-text-muted); display: block;">Variance</span>
                    <strong class="num" style="color: ${tie.variance <= tie.tolerance ? '#059669' : '#dc2626'};">
                      ₹${tie.variance.toFixed(2)}
                    </strong>
                  </div>
                </div>

                <div style="font-size: 11.5px; color: var(--color-text-secondary); margin-top: 6px;">
                  ${tie.explanation}
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Lineage Drill-down Modal / In-drawer Box -->
        <div id="trust-drawer-lineage-container" style="display: none; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <h4 id="lineage-title" style="font-size: 13px; font-weight: 700; color: #166534; margin: 0;">
              Metric Provenance &amp; Lineage Chain
            </h4>
            <button id="close-lineage-btn" style="background: none; border: none; font-size: 14px; cursor: pointer; color: #166534;">✕</button>
          </div>
          <div id="lineage-content" style="font-size: 12px; color: #14532d;"></div>
        </div>

        <!-- Exceptions & Diagnostics Section -->
        <div style="background: #ffffff; border: 1px solid var(--color-border); border-radius: 8px; padding: 16px;">
          <h4 style="font-size: 13px; font-weight: 700; color: var(--color-text-primary); margin: 0 0 10px; display: flex; align-items: center; gap: 6px;">
            <span>🔍</span> Active Reconciliation Exceptions (${summary.active_exceptions_count})
          </h4>
          ${summary.active_exceptions_count === 0 ? `
            <div style="padding: 12px; background: #f8fafc; border-radius: 6px; border: 1px dashed var(--color-border); text-align: center; color: var(--color-text-muted); font-size: 12px;">
              ✓ Zero active discrepancies detected. All subledger balances agree with the general ledger within ₹0.01 tolerance.
            </div>
          ` : `
            <div style="display: flex; flex-direction: column; gap: 8px;">
              ${summary.exceptions.map(exc => `
                <div style="padding: 10px; border-left: 3px solid #f59e0b; background: #fffbeb; border-radius: 4px; font-size: 12px;">
                  <strong style="color: #92400e;">[${exc.severity}] ${exc.what_differs}</strong>
                  <div style="color: #b45309; margin-top: 4px;">Root cause: ${exc.why_it_differs}</div>
                  <div style="color: #78350f; font-size: 11px; margin-top: 2px;">Downstream impacts: ${exc.downstream_impacts.join(', ')}</div>
                </div>
              `).join('')}
            </div>
          `}
        </div>

        <!-- Governed Chart of Accounts Dictionary -->
        <div style="background: #ffffff; border: 1px solid var(--color-border); border-radius: 8px; padding: 16px;">
          <h4 style="font-size: 13px; font-weight: 700; color: var(--color-text-primary); margin: 0 0 10px; display: flex; align-items: center; gap: 6px;">
            <span>📖</span> Chart of Accounts Mapping Dictionary (${(mappingsData.mappings || []).length} Accounts)
          </h4>
          <div style="max-height: 220px; overflow-y: auto; border: 1px solid var(--color-border); border-radius: 6px;">
            <table style="width: 100%; border-collapse: collapse; font-size: 11.5px;">
              <thead>
                <tr style="background: var(--color-surface-subtle); border-bottom: 1px solid var(--color-border); text-align: left;">
                  <th style="padding: 6px 10px;">GL Account</th>
                  <th style="padding: 6px 10px;">Concept</th>
                  <th style="padding: 6px 10px;">Statement Category</th>
                  <th style="padding: 6px 10px;">Status</th>
                </tr>
              </thead>
              <tbody>
                ${(mappingsData.mappings || []).map(m => `
                  <tr style="border-bottom: 1px solid var(--color-border);">
                    <td style="padding: 6px 10px; font-family: var(--font-mono); font-weight: 600;">${m.gl_account}</td>
                    <td style="padding: 6px 10px; color: var(--color-text-primary);">${m.canonical_concept || 'UNMAPPED'}</td>
                    <td style="padding: 6px 10px; color: var(--color-text-muted);">${m.category || 'N/A'}</td>
                    <td style="padding: 6px 10px;">
                      <span class="badge ${m.mapping_status === 'MAPPED' ? 'badge-resolved' : 'badge-critical'}" style="font-size: 10px;">
                        ${m.mapping_status}
                      </span>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;

      // Wire Trace Lineage buttons
      bodyEl.querySelectorAll('.trace-lineage-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          const metric = e.currentTarget.dataset.metric;
          await showMetricLineage(metric, period);
        });
      });

    } catch (err) {
      console.error('Error rendering trust drawer:', err);
      bodyEl.innerHTML = `
        <div style="padding: 24px; color: #dc2626; text-align: center;">
          Failed to load trust summary: ${err.message}
        </div>
      `;
    }
  };

  const showMetricLineage = async (metricName, period) => {
    const lineageContainer = dialogEl.querySelector('#trust-drawer-lineage-container');
    const lineageTitle = dialogEl.querySelector('#lineage-title');
    const lineageContent = dialogEl.querySelector('#lineage-content');
    const closeLineageBtn = dialogEl.querySelector('#close-lineage-btn');

    if (!lineageContainer || !lineageContent) return;

    lineageContainer.style.display = 'block';
    lineageContent.innerHTML = '<div style="padding: 10px;">Loading provenance chain...</div>';

    try {
      const lineage = await api.getMetricLineage(metricName, period);
      lineageTitle.textContent = `Proven Lineage: ${lineage.display_name}`;
      lineageContent.innerHTML = `
        <div style="margin-bottom: 10px;">
          <strong>Governed Formula:</strong> <code style="background: rgba(0,0,0,0.06); padding: 2px 6px; border-radius: 4px;">${lineage.formula}</code>
        </div>
        <div style="margin-bottom: 10px;">
          <strong>Denominator Rules:</strong> ${lineage.denominator_rules}
        </div>

        <div style="background: #ffffff; border: 1px solid #bbf7d0; border-radius: 6px; padding: 10px; margin-bottom: 10px;">
          <div style="font-weight: 700; margin-bottom: 6px; color: #166534;">Mathematical Input Traces:</div>
          <div style="display: flex; flex-direction: column; gap: 6px;">
            ${(lineage.inputs || []).map(inp => `
              <div style="display: flex; justify-content: space-between; border-bottom: 1px dashed #e2e8f0; padding-bottom: 4px;">
                <span>${inp.concept} (GL ${inp.gl_accounts.join(', ')})</span>
                <strong class="num">₹${inp.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
              </div>
            `).join('')}
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11.5px;">
          <span>Source Subledger References: <strong>${lineage.source_evidence_ids.join(', ') || 'Direct GL'}</strong></span>
          <span class="badge badge-resolved">Publication Status: ${lineage.published_metric.publication_status}</span>
        </div>
      `;

      closeLineageBtn?.addEventListener('click', () => {
        lineageContainer.style.display = 'none';
      });

      lineageContainer.scrollIntoView({ behavior: 'smooth' });
    } catch (e) {
      lineageContent.innerHTML = `<div style="color: #dc2626;">Lineage unavailable for '${metricName}': ${e.message}</div>`;
    }
  };

  return {
    open(period) {
      if (!dialogEl.open) {
        pushDrawerHistory('trust-drawer', () => dialogEl.close());
        dialogEl.showModal();
      }
      renderTrustContent(period);
    },
    close() {
      dialogEl.close();
    }
  };
}
