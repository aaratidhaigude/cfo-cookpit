/**
 * User Profile & Role Dropdown Menu Component (Sprint 11)
 * Displays current user name, role badge, settings shortcut, and sign out.
 */

import { auth } from '../services/auth.js';

export function renderUserProfileMenu(container, onNavigate, onSignOut) {
  const user = auth.getUser() || {
    full_name: 'Samarth',
    role: 'ADMIN',
    display_title: 'Samarth / Finance Admin',
    email: 'samarth@finsight.internal',
  };

  const userRole = user.role === 'ADMIN' ? 'Finance Admin' : (user.role ? user.role.replace('_', ' ') : 'Finance Team');

  container.innerHTML = `
    <div class="user-profile-menu-container">
      <button id="user-menu-btn" class="user-menu-trigger" aria-haspopup="true" aria-expanded="false" title="Account settings &amp; sign out">
        <div class="user-avatar-circle">
          ${user.full_name ? user.full_name.charAt(0).toUpperCase() : 'S'}
        </div>
        <div class="user-menu-label">
          <span class="user-display-name">${user.full_name || 'Samarth'}</span>
          <span class="user-display-role">${userRole}</span>
        </div>
        <svg class="dropdown-chevron" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 15 12 9 18 15"/></svg>
      </button>

      <div id="user-menu-dropdown" class="user-dropdown-card" style="display: none;">
        <div class="dropdown-user-header">
          <strong>${user.full_name}</strong>
          <span class="dropdown-user-email">${user.email}</span>
          <div class="dropdown-role-tag">
            <span class="badge ${user.role === 'ADMIN' ? 'badge-critical' : (user.role === 'FINANCE_MANAGER' ? 'badge-high' : 'badge-resolved')}">
              ${user.role.replace('_', ' ')}
            </span>
          </div>
        </div>

        <div class="dropdown-menu-list">
          <button class="dropdown-item" id="menu-view-settings">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
            <span>Settings</span>
          </button>
          <div class="dropdown-divider"></div>
          <button class="dropdown-item dropdown-item-danger" id="menu-sign-out">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            <span>Sign out</span>
          </button>
        </div>
      </div>
    </div>
  `;

  const btn = container.querySelector('#user-menu-btn');
  const dropdownCard = container.querySelector('#user-menu-dropdown');

  const toggleDropdown = (e) => {
    e.stopPropagation();
    const isVisible = dropdownCard.style.display !== 'none';
    dropdownCard.style.display = isVisible ? 'none' : 'block';
    btn.setAttribute('aria-expanded', !isVisible);
  };

  btn?.addEventListener('click', toggleDropdown);

  document.addEventListener('click', (e) => {
    if (!container.contains(e.target)) {
      dropdownCard.style.display = 'none';
      btn?.setAttribute('aria-expanded', 'false');
    }
  });

  container.querySelector('#menu-view-settings')?.addEventListener('click', () => {
    dropdownCard.style.display = 'none';
    if (onNavigate) onNavigate('settings');
  });

  container.querySelector('#menu-sign-out')?.addEventListener('click', () => {
    dropdownCard.style.display = 'none';
    if (onSignOut) onSignOut();
  });
}
