/**
 * Actions Page View (Sprint 11 - Executive Governance & Remediation)
 * Primary executive term: "Actions"
 *
 * Comprehensive Action Management:
 * - Real-time Exposure & Status KPIs (All / Open / In Review / Resolved)
 * - Search by Title / Counterparty / ID with Category & Severity Filter Dropdowns
 * - Executive Table with Action ID, Issue & Counterparty, Category, Severity, Exposure (₹), Due Date, Status, Quick Actions
 * - Comprehensive In-Context Detail View (No browser prompts):
 *     1. Executive Metrics Grid (Exposure, Counterparty, Owner, Due Date)
 *     2. Issue Narrative & Governing Policy Reference
 *     3. Evidence & Subledger Links with Audit Drawer trigger
 *     4. Interactive Remediation Plan with "+ Add Remediation Step" form
 *     5. Analyst Notes & Investigation Updates with "+ Add Progress Note" form
 *     6. Governed Resolution & Sign-Off workflow with RBAC checks
 *     7. Immutable Append-Only Audit Trail
 * - Create Action Modal with explicit Category, Severity, Due Date, and Linked Policy / Evidence
 * - Integration Contract: { openWithPrefill: (prefillData) => showCreateActionModal(prefillData) }
 */

import { exportToCsv } from '../utils/exportCsv.js';
import { formatCurrency, escapeHtml } from '../utils/format.js';
import { auth } from '../services/auth.js';

function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'undo-toast';
  toast.innerHTML = `
    <span>${escapeHtml(message)}</span>
    <button class="undo-toast-close" onclick="this.parentElement.remove()">✕</button>
  `;
  document.body.appendChild(toast);
  setTimeout(() => { toast.remove(); }, 4000);
}

function getSeverityBadge(severity) {
  const sev = (severity || 'HIGH').toUpperCase();
  if (sev === 'CRITICAL') return '<span class="badge badge-critical">Critical</span>';
  if (sev === 'HIGH') return '<span class="badge badge-high">High</span>';
  if (sev === 'MEDIUM') return '<span class="badge badge-medium">Medium</span>';
  return '<span class="badge badge-low">Low</span>';
}

function getStatusBadge(status) {
  const st = (status || 'OPEN').toUpperCase();
  if (st === 'RESOLVED' || st === 'CLOSED') {
    return '<span class="badge badge-resolved">Resolved</span>';
  }
  if (st === 'IN_REVIEW' || st === 'PENDING_REVIEW') {
    return '<span class="badge badge-high">In Review</span>';
  }
  if (st === 'IN_PROGRESS' || st === 'INVESTIGATING') {
    return '<span class="badge badge-medium">In Progress</span>';
  }
  return '<span class="badge badge-critical">Open</span>';
}

function getCategoryBadge(category) {
  const cat = (category || 'GENERAL').toUpperCase();
  const colors = {
    RECEIVABLES: { bg: '#eff6ff', text: '#1d4ed8', border: '#bfdbfe' },
    LIQUIDITY: { bg: '#fef3c7', text: '#b45309', border: '#fde68a' },
    CASH: { bg: '#fef3c7', text: '#b45309', border: '#fde68a' },
    MARGIN: { bg: '#fdf2f8', text: '#be185d', border: '#fbcfe8' },
    INVENTORY: { bg: '#f5f3ff', text: '#6d28d9', border: '#ddd6fe' },
    PAYABLES: { bg: '#ecfdf5', text: '#047857', border: '#a7f3d0' },
    GOVERNANCE: { bg: '#f1f5f9', text: '#334155', border: '#cbd5e1' },
    GENERAL: { bg: '#f8fafc', text: '#475569', border: '#e2e8f0' },
  };
  const style = colors[cat] || colors.GENERAL;
  return `<span style="font-size: 10.5px; font-weight: 700; padding: 2px 7px; border-radius: 4px; background: ${style.bg}; color: ${style.text}; border: 1px solid ${style.border}; letter-spacing: 0.3px; text-transform: uppercase;">${escapeHtml(cat)}</span>`;
}

export async function renderActions(container, api, onOpenEvidence) {
  container.innerHTML = `
    <div style="display: flex; justify-content: center; align-items: center; padding: 60px;">
      <div style="color: var(--color-text-muted); font-size: 14px;">Loading executive financial actions...</div>
    </div>
  `;

  let currentActions = [];
  let activeTab = 'ALL'; // 'ALL' | 'OPEN' | 'IN_REVIEW' | 'RESOLVED'
  let searchQuery = '';
  let categoryFilter = 'ALL';
  let severityFilter = 'ALL';

  try {
    currentActions = await api.getCases();

    function render() {
      const openActions = currentActions.filter(c => c.status === 'OPEN' || c.status === 'IN_PROGRESS' || c.status === 'INVESTIGATING');
      const inReviewActions = currentActions.filter(c => c.status === 'IN_REVIEW' || c.status === 'PENDING_REVIEW' || c.status === 'ACTION_REQUIRED');
      const resolvedActions = currentActions.filter(c => c.status === 'RESOLVED' || c.status === 'CLOSED');

      // Filter displayed list according to activeTab, search query, category, and severity
      let displayedActions = currentActions;
      if (activeTab === 'OPEN') {
        displayedActions = openActions;
      } else if (activeTab === 'IN_REVIEW') {
        displayedActions = inReviewActions;
      } else if (activeTab === 'RESOLVED') {
        displayedActions = resolvedActions;
      }

      if (categoryFilter !== 'ALL') {
        displayedActions = displayedActions.filter(c => (c.category || '').toUpperCase() === categoryFilter);
      }

      if (severityFilter !== 'ALL') {
        displayedActions = displayedActions.filter(c => (c.severity || '').toUpperCase() === severityFilter);
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        displayedActions = displayedActions.filter(c =>
          (c.id || '').toLowerCase().includes(q) ||
          (c.title || '').toLowerCase().includes(q) ||
          (c.entity || '').toLowerCase().includes(q) ||
          (c.owner || '').toLowerCase().includes(q) ||
          (c.summary || '').toLowerCase().includes(q)
        );
      }

      const totalExposure = currentActions.reduce((s, c) => s + (c.financial_exposure || c.financial_impact || 0), 0);
      const openExposure = openActions.reduce((s, c) => s + (c.financial_exposure || c.financial_impact || 0), 0);

      container.innerHTML = `
        <!-- Top Metrics Row -->
        <div class="kpi-grid" style="grid-template-columns: repeat(4, 1fr); margin-bottom: 16px;">
          <div class="metric-card kpi-card-clickable ${activeTab === 'ALL' ? 'active-filter' : ''}" data-tab="ALL" style="cursor: pointer;">
            <span class="metric-label">Total Monitored Exposure</span>
            <div class="metric-value num">₹${totalExposure.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</div>
            <div class="metric-comparison"><span class="metric-subtext">Across ${currentActions.length} registered actions</span></div>
          </div>
          <div class="metric-card kpi-card-clickable ${activeTab === 'OPEN' ? 'active-filter' : ''}" data-tab="OPEN" style="cursor: pointer;">
            <span class="metric-label">Open Actions</span>
            <div class="metric-value num" style="color: #dc2626;">${openActions.length}</div>
            <div class="metric-comparison"><span class="badge badge-critical">₹${openExposure.toLocaleString('en-IN', { maximumFractionDigits: 0 })} at Risk</span></div>
          </div>
          <div class="metric-card kpi-card-clickable ${activeTab === 'IN_REVIEW' ? 'active-filter' : ''}" data-tab="IN_REVIEW" style="cursor: pointer;">
            <span class="metric-label">In Review</span>
            <div class="metric-value num" style="color: #d97706;">${inReviewActions.length}</div>
            <div class="metric-comparison"><span class="badge badge-high">Active Follow-up</span></div>
          </div>
          <div class="metric-card kpi-card-clickable ${activeTab === 'RESOLVED' ? 'active-filter' : ''}" data-tab="RESOLVED" style="cursor: pointer;">
            <span class="metric-label">Resolved</span>
            <div class="metric-value num" style="color: #16a34a;">${resolvedActions.length}</div>
            <div class="metric-comparison"><span class="badge badge-resolved">Completed</span></div>
          </div>
        </div>

        <!-- Main Actions Panel with Integrated Header, Tabs & Compact Toolbar -->
        <div class="panel" style="background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 18px 20px; box-shadow: var(--shadow-sm);">
          
          <!-- Top Row: Title, Quick Info & Action Buttons -->
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
            <div>
              <h3 class="panel-title" style="margin: 0; font-size: 15px; font-weight: 700; color: var(--color-text-primary);">
                Remediation Actions &amp; Governance
                <span style="font-size: 12px; font-weight: 500; color: var(--color-text-muted); margin-left: 6px;">(${displayedActions.length} of ${currentActions.length})</span>
              </h3>
              <p style="font-size: 12px; color: var(--color-text-muted); margin: 2px 0 0 0;">
                Track, remediate, and audit financial risk exposures with dual-ledger verification.
              </p>
            </div>
            <div style="display: flex; align-items: center; gap: 8px;">
              <button id="btn-export-actions-csv" class="btn btn-outline btn-sm" title="Export current list to CSV" style="padding: 5px 10px; font-size: 11.5px;">
                Export CSV
              </button>
              <button id="btn-new-action-modal" class="btn btn-primary btn-sm" style="font-weight: 600; padding: 5px 12px; font-size: 11.5px;">
                + Create Action
              </button>
            </div>
          </div>

          <!-- Second Row: Clean Tabs on Left + Compact Search & Filter Controls on Right -->
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--color-border); padding-bottom: 10px; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
            <!-- Standard Tabs (Clean Underline Style) -->
            <div class="tabs-nav" style="border-bottom: none; margin-bottom: 0; display: flex; gap: 4px;">
              <button class="tab-btn ${activeTab === 'ALL' ? 'active' : ''}" data-tab="ALL" style="font-size: 12.5px; padding: 6px 12px; cursor: pointer;">
                All <span style="font-size: 11px; opacity: 0.85;">(${currentActions.length})</span>
              </button>
              <button class="tab-btn ${activeTab === 'OPEN' ? 'active' : ''}" data-tab="OPEN" style="font-size: 12.5px; padding: 6px 12px; cursor: pointer;">
                Open <span style="font-size: 11px; opacity: 0.85;">(${openActions.length})</span>
              </button>
              <button class="tab-btn ${activeTab === 'IN_REVIEW' ? 'active' : ''}" data-tab="IN_REVIEW" style="font-size: 12.5px; padding: 6px 12px; cursor: pointer;">
                In Review <span style="font-size: 11px; opacity: 0.85;">(${inReviewActions.length})</span>
              </button>
              <button class="tab-btn ${activeTab === 'RESOLVED' ? 'active' : ''}" data-tab="RESOLVED" style="font-size: 12.5px; padding: 6px 12px; cursor: pointer;">
                Resolved <span style="font-size: 11px; opacity: 0.85;">(${resolvedActions.length})</span>
              </button>
            </div>

            <!-- Compact Inline Search & Dropdowns -->
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              <!-- Compact Search Input -->
              <div style="position: relative; width: 200px;">
                <input type="text" id="action-search-input" class="form-input" placeholder="Search title, entity, ID..." value="${escapeHtml(searchQuery)}" style="padding: 4px 8px; font-size: 11.5px; height: 28px; width: 100%; border-radius: var(--radius-sm);" />
              </div>

              <!-- Compact Category Dropdown -->
              <select id="action-category-filter" class="form-input" style="padding: 3px 8px; font-size: 11.5px; height: 28px; cursor: pointer; border-radius: var(--radius-sm); width: auto;">
                <option value="ALL" ${categoryFilter === 'ALL' ? 'selected' : ''}>All Categories</option>
                <option value="RECEIVABLES" ${categoryFilter === 'RECEIVABLES' ? 'selected' : ''}>Receivables</option>
                <option value="LIQUIDITY" ${categoryFilter === 'LIQUIDITY' ? 'selected' : ''}>Liquidity</option>
                <option value="MARGIN" ${categoryFilter === 'MARGIN' ? 'selected' : ''}>Margin</option>
                <option value="INVENTORY" ${categoryFilter === 'INVENTORY' ? 'selected' : ''}>Inventory</option>
                <option value="PAYABLES" ${categoryFilter === 'PAYABLES' ? 'selected' : ''}>Payables</option>
                <option value="GOVERNANCE" ${categoryFilter === 'GOVERNANCE' ? 'selected' : ''}>Governance</option>
              </select>

              <!-- Compact Severity Dropdown -->
              <select id="action-severity-filter" class="form-input" style="padding: 3px 8px; font-size: 11.5px; height: 28px; cursor: pointer; border-radius: var(--radius-sm); width: auto;">
                <option value="ALL" ${severityFilter === 'ALL' ? 'selected' : ''}>All Severities</option>
                <option value="CRITICAL" ${severityFilter === 'CRITICAL' ? 'selected' : ''}>Critical</option>
                <option value="HIGH" ${severityFilter === 'HIGH' ? 'selected' : ''}>High</option>
                <option value="MEDIUM" ${severityFilter === 'MEDIUM' ? 'selected' : ''}>Medium</option>
                <option value="LOW" ${severityFilter === 'LOW' ? 'selected' : ''}>Low</option>
              </select>

              ${searchQuery || categoryFilter !== 'ALL' || severityFilter !== 'ALL' ? `
                <button id="btn-reset-filters" class="btn btn-outline btn-sm" title="Clear search and filters" style="padding: 3px 7px; height: 28px; font-size: 11px;">
                  ✕ Clear
                </button>
              ` : ''}
            </div>
          </div>

          <div style="margin-top: 8px; overflow-x: auto;">
            ${displayedActions.length > 0 ? `
              <table class="fin-table" style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                  <tr style="border-bottom: 1px solid var(--color-border); background-color: var(--color-surface-subtle);">
                    <th style="width: 13%; padding: 10px 12px; font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600; letter-spacing: 0.4px;">Action ID</th>
                    <th style="width: 31%; padding: 10px 12px; font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600; letter-spacing: 0.4px;">Issue &amp; Counterparty</th>
                    <th style="width: 11%; padding: 10px 12px; font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600; letter-spacing: 0.4px;">Category</th>
                    <th style="width: 9%; padding: 10px 12px; font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600; letter-spacing: 0.4px;">Severity</th>
                    <th style="width: 13%; padding: 10px 12px; font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600; letter-spacing: 0.4px; text-align: right;">Exposure (₹)</th>
                    <th style="width: 11%; padding: 10px 12px; font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600; letter-spacing: 0.4px;">Due Date</th>
                    <th style="width: 12%; padding: 10px 12px; font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600; letter-spacing: 0.4px; text-align: right;">Status</th>
                  </tr>
                </thead>
                <tbody>
                  ${displayedActions.map(action => {
                    const exposure = action.financial_exposure || action.financial_impact || 0;
                    return `
                      <tr class="action-row" data-id="${action.id}" style="cursor: pointer; border-bottom: 1px solid #f1f5f9; transition: background-color 0.15s ease;">
                        <td style="padding: 12px 12px; vertical-align: middle;">
                          <code class="mono" style="font-weight: 700; color: #2563eb; background: #eff6ff; padding: 3px 8px; border-radius: 4px; border: 1px solid #bfdbfe; font-size: 12px;">
                            ${escapeHtml(action.id)}
                          </code>
                        </td>
                        <td style="padding: 12px 12px; vertical-align: middle;">
                          <div style="font-weight: 700; color: var(--color-text-primary); font-size: 13px; margin-bottom: 2px;">
                            ${escapeHtml(action.title)}
                          </div>
                          <div style="font-size: 11.5px; color: var(--color-text-muted); display: flex; align-items: center; gap: 6px;">
                            <span>🏢 ${escapeHtml(action.entity || 'Company-Wide')}</span>
                            <span>&bull;</span>
                            <span>👤 ${escapeHtml(action.owner || action.assignee || 'Finance Lead')}</span>
                          </div>
                        </td>
                        <td style="padding: 12px 12px; vertical-align: middle;">
                          ${getCategoryBadge(action.category)}
                        </td>
                        <td style="padding: 12px 12px; vertical-align: middle;">
                          ${getSeverityBadge(action.severity)}
                        </td>
                        <td class="mono" style="padding: 12px 12px; vertical-align: middle; text-align: right; font-weight: 700; font-size: 13px; color: ${exposure > 0 ? '#b91c1c' : '#334155'};">
                          ₹${exposure.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                        </td>
                        <td class="mono" style="padding: 12px 12px; vertical-align: middle; font-size: 12px; color: var(--color-text-secondary);">
                          ${escapeHtml(action.due_date || '—')}
                        </td>
                        <td style="padding: 12px 12px; vertical-align: middle; text-align: right;">
                          ${getStatusBadge(action.status)}
                        </td>
                      </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
            ` : `
              <div style="padding: 42px; text-align: center; color: var(--color-text-muted); font-size: 13px;">
                <div style="font-size: 24px; margin-bottom: 8px;">📋</div>
                <strong>No matching actions found.</strong>
                <p style="margin: 4px 0 0 0; font-size: 12px;">Try adjusting your filter settings or search term.</p>
              </div>
            `}
          </div>
        </div>
      `;

      // Event handlers: Tab and KPI filter buttons
      container.querySelectorAll('.tab-btn, .kpi-card-clickable').forEach(btn => {
        btn.addEventListener('click', () => {
          activeTab = btn.getAttribute('data-tab');
          render();
        });
      });

      // Search input handler
      const searchInput = container.querySelector('#action-search-input');
      if (searchInput) {
        searchInput.addEventListener('input', (e) => {
          searchQuery = e.target.value;
          render();
          const reInput = container.querySelector('#action-search-input');
          if (reInput) {
            reInput.focus();
            reInput.setSelectionRange(reInput.value.length, reInput.value.length);
          }
        });
      }

      // Category filter handler
      container.querySelector('#action-category-filter')?.addEventListener('change', (e) => {
        categoryFilter = e.target.value;
        render();
      });

      // Severity filter handler
      container.querySelector('#action-severity-filter')?.addEventListener('change', (e) => {
        severityFilter = e.target.value;
        render();
      });

      // Reset filters handler
      container.querySelector('#btn-reset-filters')?.addEventListener('click', () => {
        searchQuery = '';
        categoryFilter = 'ALL';
        severityFilter = 'ALL';
        activeTab = 'ALL';
        render();
      });

      // Row click handler -> open detailed modal
      container.querySelectorAll('.action-row').forEach(el => {
        el.addEventListener('click', () => {
          const actionId = el.getAttribute('data-id');
          if (actionId) {
            const action = currentActions.find(a => a.id === actionId);
            if (action) showActionDetailModal(action);
          }
        });
      });

      // Create new action modal trigger
      container.querySelector('#btn-new-action-modal')?.addEventListener('click', () => {
        showCreateActionModal();
      });

      // Export CSV handler
      container.querySelector('#btn-export-actions-csv')?.addEventListener('click', () => {
        exportToCsv('finsight_actions.csv', displayedActions.map(a => ({
          ID: a.id,
          Title: a.title,
          Status: a.status,
          Severity: a.severity,
          Category: a.category,
          Exposure: a.financial_exposure || a.financial_impact || 0,
          Entity: a.entity,
          Owner: a.owner,
          DueDate: a.due_date,
          Summary: a.summary,
        })));
      });
    }

    // Modal: Detailed Action View displaying Exposure, Counterparty, Owner, Narrative, Remediation, Notes, Resolution & Audit Trail
    function showActionDetailModal(action) {
      let modalOverlay = document.getElementById('actionDetailModalOverlay');
      if (!modalOverlay) {
        modalOverlay = document.createElement('div');
        modalOverlay.id = 'actionDetailModalOverlay';
        document.body.appendChild(modalOverlay);
      }

      const exposureFormatted = (action.financial_exposure || action.financial_impact || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 });
      const remediationPlan = action.remediation_plan || [];
      const notesList = action.notes || [];
      const auditTrail = action.audit_notes || [];
      const isClosed = action.status === 'RESOLVED' || action.status === 'CLOSED';

      modalOverlay.innerHTML = `
        <div style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.68); backdrop-filter:blur(3px); display:flex; align-items:center; justify-content:center; z-index:999999;">
          <div style="background:#FFFFFF; border-radius:12px; max-width:880px; width:94%; max-height:92vh; display:flex; flex-direction:column; box-shadow:0 25px 50px -12px rgba(0,0,0,0.35);">
            <!-- Modal Header -->
            <div style="padding:16px 24px; border-bottom:1px solid #E2E8F0; display:flex; justify-content:space-between; align-items:center;">
              <div style="display:flex; align-items:center; gap:10px;">
                <code class="mono" style="font-weight:800; color:#2563EB; background:#EFF6FF; border:1px solid #BFDBFE; padding:3px 10px; border-radius:4px; font-size:13px;">
                  ${escapeHtml(action.id)}
                </code>
                ${getStatusBadge(action.status)}
                ${getSeverityBadge(action.severity)}
                ${getCategoryBadge(action.category)}
              </div>
              <button id="closeActionDetailBtn" style="background:none; border:none; font-size:20px; cursor:pointer; color:#64748B; padding:4px;" title="Close dialog">✕</button>
            </div>

            <!-- Modal Title & Status Progression Banner -->
            <div style="padding:14px 24px 0 24px; display:flex; justify-content:space-between; align-items:flex-start; gap:16px;">
              <div>
                <h3 style="margin:0 0 4px 0; font-size:17px; font-weight:800; color:#0F172A;">${escapeHtml(action.title)}</h3>
                <span style="font-size:12px; color:#64748B;">Fiscal Period: <strong class="mono">${escapeHtml(action.period || '2026-09')}</strong> &bull; Snapshot: <strong class="mono">${escapeHtml(action.snapshot_id || 'SNAP-202609-001')}</strong></span>
              </div>

              <!-- Quick Status Progression (if not closed) -->
              ${!isClosed ? `
                <div style="display:flex; align-items:center; gap:8px;">
                  ${action.status === 'OPEN' ? `
                    <button id="btn-advance-to-review" class="btn btn-outline btn-sm" style="font-size:11.5px; border-color:#F59E0B; color:#B45309; background:#FFFBEB;">
                      ▶ Mark In Review
                    </button>
                  ` : ''}
                  ${action.status === 'IN_REVIEW' ? `
                    <button id="btn-revert-to-open" class="btn btn-outline btn-sm" style="font-size:11.5px; border-color:#DC2626; color:#DC2626; background:#FEF2F2;">
                      ↺ Return to Open
                    </button>
                  ` : ''}
                </div>
              ` : ''}
            </div>

            <!-- Modal Body (Scrollable) -->
            <div style="padding:20px 24px; overflow-y:auto; flex:1; font-size:13px; color:#334155; display:flex; flex-direction:column; gap:16px;">
              <!-- 1. KEY EXECUTIVE METRICS: Exposure, Counterparty, Owner, Due Date -->
              <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:12px;">
                <div style="background:#FFF1F2; border:1px solid #FECDD3; border-radius:8px; padding:12px;">
                  <span style="font-size:11px; color:#9F1239; font-weight:700; text-transform:uppercase;">Financial Exposure</span>
                  <div style="font-size:18px; font-weight:800; color:#E11D48; margin-top:2px;" class="mono">₹${exposureFormatted}</div>
                </div>
                <div style="background:#F0F9FF; border:1px solid #BAE6FD; border-radius:8px; padding:12px;">
                  <span style="font-size:11px; color:#0369A1; font-weight:700; text-transform:uppercase;">Counterparty / Entity</span>
                  <div style="font-size:13px; font-weight:700; color:#0C4A6E; margin-top:4px;">${escapeHtml(action.entity || 'Company-Wide')}</div>
                </div>
                <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:8px; padding:12px;">
                  <span style="font-size:11px; color:#64748B; font-weight:700; text-transform:uppercase;">Owner / Assignee</span>
                  <div style="font-size:13px; font-weight:700; color:#0F172A; margin-top:4px;">${escapeHtml(action.owner || action.assignee || 'Finance Lead')}</div>
                </div>
                <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:8px; padding:12px;">
                  <span style="font-size:11px; color:#64748B; font-weight:700; text-transform:uppercase;">Target Due Date</span>
                  <div class="mono" style="font-size:13px; font-weight:700; color:#0F172A; margin-top:4px;">${escapeHtml(action.due_date || '—')}</div>
                </div>
              </div>

              <!-- 2. ISSUE SUMMARY WITH GOVERNING POLICY TAG -->
              <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:8px; padding:14px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                  <span style="font-size:11px; font-weight:800; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">
                    Issue Narrative &amp; Finding
                  </span>
                  ${action.control_id ? `
                    <span style="font-size:11px; background:#F5F3FF; color:#6B21A8; border:1px solid #DDD6FE; padding:2px 8px; border-radius:4px; font-weight:600;">
                      Governing Policy: ${escapeHtml(action.control_id)}
                    </span>
                  ` : ''}
                </div>
                <p style="margin:0; line-height:1.55; color:#1E293B; font-size:13px;">${escapeHtml(action.summary)}</p>
              </div>

              <!-- 3. EVIDENCE & SUBLEDGER REFERENCES -->
              <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:8px; padding:14px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                  <span style="font-size:11px; font-weight:800; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">
                    Evidence &amp; Subledger References
                  </span>
                  <button id="btn-modal-open-evidence" class="btn btn-outline btn-sm" style="font-size:11px; padding:2px 8px; background:#fff;">
                    Open Audit Drawer &rarr;
                  </button>
                </div>
                <div style="display:flex; flex-wrap:wrap; gap:6px;">
                  ${((action.financial_evidence_refs && action.financial_evidence_refs.length > 0) ? action.financial_evidence_refs : ['INV-AR-50065', 'INV-AR-50073', 'INV-AR-50081']).map(ref => `
                    <span style="font-family:var(--font-mono); font-size:11.5px; background:#FFFFFF; border:1px solid #CBD5E1; padding:3px 9px; border-radius:4px; color:#1E293B; font-weight:600;">
                      ${escapeHtml(ref)}
                    </span>
                  `).join('')}
                </div>
              </div>

              <!-- 4. ACTIVITY & REMEDIATION PLAN (WITH IN-MODAL ADD FORM) -->
              <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-radius:8px; padding:14px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                  <span style="font-size:11px; font-weight:800; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">
                    Remediation Plan (${remediationPlan.length} step${remediationPlan.length === 1 ? '' : 's'})
                  </span>
                  ${!isClosed ? `
                    <button id="btn-toggle-add-step" class="btn btn-outline btn-sm" style="font-size:11px; padding:2px 8px;">
                      + Add Step
                    </button>
                  ` : ''}
                </div>

                <!-- Step input form (initially hidden) -->
                ${!isClosed ? `
                  <form id="add-step-form" style="display:none; background:#F8FAFC; border:1px solid #E2E8F0; border-radius:6px; padding:12px; margin-bottom:12px;">
                    <div style="font-weight:700; font-size:12px; color:#1E293B; margin-bottom:8px;">New Remediation Action Item</div>
                    <div style="margin-bottom:8px;">
                      <input type="text" id="step-action-input" class="form-input" placeholder="Action description (e.g. Schedule CCO repayment review)" required style="width:100%; font-size:12px; padding:6px 8px;" />
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:8px;">
                      <input type="text" id="step-owner-input" class="form-input" placeholder="Owner (e.g. AR Specialist)" required value="${escapeHtml(action.owner || '')}" style="font-size:12px; padding:6px 8px;" />
                      <input type="date" id="step-due-input" class="form-input mono" required value="${new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]}" style="font-size:12px; padding:6px 8px;" />
                    </div>
                    <div style="display:flex; justify-content:flex-end; gap:8px;">
                      <button type="button" id="btn-cancel-add-step" class="btn btn-secondary btn-sm" style="font-size:11px;">Cancel</button>
                      <button type="submit" class="btn btn-primary btn-sm" style="font-size:11px;">Save Step</button>
                    </div>
                  </form>
                ` : ''}

                <div style="display:flex; flex-direction:column; gap:8px;">
                  ${remediationPlan.length > 0 ? remediationPlan.map(item => `
                    <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:6px; padding:10px 12px; display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                      <div style="flex:1;">
                        <div style="font-weight:700; color:#1E293B; font-size:12.5px;">${escapeHtml(item.action)}</div>
                        <div style="font-size:11px; color:#64748B; margin-top:2px;">
                          Owner: <strong>${escapeHtml(item.owner || 'Unassigned')}</strong> &bull; Target Due: <span class="mono">${escapeHtml(item.due_date || '—')}</span>
                          ${item.comment ? ` &bull; <em>"${escapeHtml(item.comment)}"</em>` : ''}
                        </div>
                      </div>
                      <span class="badge ${item.status === 'COMPLETED' ? 'badge-resolved' : 'badge-high'}" style="font-size:10px;">
                        ${escapeHtml(item.status)}
                      </span>
                    </div>
                  `).join('') : `
                    <p style="margin:0; font-size:12px; color:#64748B;">No active remediation items assigned yet.</p>
                  `}
                </div>
              </div>

              <!-- 5. ANALYST NOTES & PROGRESS UPDATES (WITH IN-MODAL ADD NOTE) -->
              <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-radius:8px; padding:14px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                  <span style="font-size:11px; font-weight:800; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">
                    Analyst Notes &amp; Updates (${notesList.length})
                  </span>
                  ${!isClosed ? `
                    <button id="btn-toggle-add-note" class="btn btn-outline btn-sm" style="font-size:11px; padding:2px 8px;">
                      + Add Note
                    </button>
                  ` : ''}
                </div>

                <!-- Add Note Form (initially hidden) -->
                ${!isClosed ? `
                  <form id="add-note-form" style="display:none; background:#F8FAFC; border:1px solid #E2E8F0; border-radius:6px; padding:12px; margin-bottom:12px;">
                    <div style="margin-bottom:8px;">
                      <textarea id="note-text-input" class="form-input" rows="2" placeholder="Record investigation note or operational update..." required style="width:100%; font-size:12px; padding:6px 8px;"></textarea>
                    </div>
                    <div style="display:flex; justify-content:flex-end; gap:8px;">
                      <button type="button" id="btn-cancel-add-note" class="btn btn-secondary btn-sm" style="font-size:11px;">Cancel</button>
                      <button type="submit" class="btn btn-primary btn-sm" style="font-size:11px;">Post Note</button>
                    </div>
                  </form>
                ` : ''}

                <div style="display:flex; flex-direction:column; gap:6px;">
                  ${notesList.length > 0 ? notesList.map(n => `
                    <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:6px; padding:8px 12px; font-size:12px;">
                      <div style="display:flex; justify-content:space-between; margin-bottom:3px; font-size:11px; color:#64748B;">
                        <strong>${escapeHtml(n.author || 'Analyst')}</strong>
                        <span class="mono">${escapeHtml(n.created_at ? n.created_at.slice(0, 16).replace('T', ' ') : '—')}</span>
                      </div>
                      <div style="color:#1E293B;">${escapeHtml(n.text)}</div>
                    </div>
                  `).join('') : `
                    <div style="font-size:12px; color:#64748B;">No notes logged.</div>
                  `}
                </div>
              </div>

              <!-- 6. RESOLUTION & SIGN-OFF (NO BROWSER PROMPT) -->
              ${isClosed ? `
                <div style="background:#F0FDF4; border:1px solid #BBF7D0; border-radius:8px; padding:14px;">
                  <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
                    <span style="font-size:11px; font-weight:800; color:#15803D; text-transform:uppercase; letter-spacing:0.5px;">
                      Verified Resolution &amp; Executive Sign-Off
                    </span>
                    <span class="badge badge-resolved" style="font-size:10px;">CLOSED</span>
                  </div>
                  <div style="font-size:13px; color:#166534; font-weight:600; margin-bottom:6px;">
                    ${escapeHtml(action.resolution_summary || 'Action successfully resolved and reconciled.')}
                  </div>
                  <div style="font-size:11.5px; color:#15803D; display:flex; flex-wrap:wrap; gap:12px;">
                    <span>Verified Proof: <code class="mono" style="background:#DCFCE7; padding:2px 6px; border-radius:3px;">${escapeHtml(action.resolution_evidence || 'N/A')}</code></span>
                    <span>Sign-off Reviewer: <strong>${escapeHtml(action.reviewer || 'Finance Admin')}</strong></span>
                  </div>
                </div>
              ` : `
                <div style="background:#FAFAF9; border:1px solid #E7E5E4; border-radius:8px; padding:14px;">
                  <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div>
                      <strong style="color:#1C1917; font-size:13px;">Resolve &amp; Close Action</strong>
                      <div style="font-size:11.5px; color:#78716C; margin-top:2px;">
                        Requires documented resolution summary, verified proof (e.g. bank wire ref, credit note), and authorized sign-off.
                      </div>
                    </div>
                    ${auth.isFinanceManager() ? `
                      <button id="btn-toggle-resolve-card" class="btn btn-primary btn-sm" style="background:#059669; border-color:#059669; font-weight:600;">
                        Resolve Action
                      </button>
                    ` : `
                      <span style="font-size:11.5px; color:#94A3B8; font-style:italic;">Manager / Admin authorization required</span>
                    `}
                  </div>

                  <!-- In-place Resolution Form (Replaces prompt) -->
                  <form id="resolve-action-form" style="display:none; margin-top:12px; padding-top:12px; border-top:1px solid #E7E5E4;">
                    <div style="margin-bottom:10px;">
                      <label style="display:block; font-size:11.5px; font-weight:700; color:#334155; margin-bottom:4px;">
                        Resolution Summary <span style="color:#DC2626;">*</span>
                      </label>
                      <textarea id="resolve-summary-input" class="form-input" rows="2" placeholder="Detail how the exposure was neutralized or resolved..." required style="width:100%; font-size:12px; padding:6px 8px;"></textarea>
                    </div>
                    <div style="margin-bottom:10px;">
                      <label style="display:block; font-size:11.5px; font-weight:700; color:#334155; margin-bottom:4px;">
                        Verified Evidence / Reference ID <span style="color:#DC2626;">*</span>
                      </label>
                      <input type="text" id="resolve-evidence-input" class="form-input" placeholder="e.g. Wire Ref #88921 / Journal Entry JE-9921 / Credit Note CN-401" required style="width:100%; font-size:12px; padding:6px 8px;" />
                    </div>
                    <div style="display:flex; justify-content:flex-end; gap:8px;">
                      <button type="button" id="btn-cancel-resolve" class="btn btn-secondary btn-sm" style="font-size:11px;">Cancel</button>
                      <button type="submit" class="btn btn-primary btn-sm" style="background:#059669; border-color:#059669; font-size:11px;">
                        Confirm &amp; Formally Close Action
                      </button>
                    </div>
                  </form>
                </div>
              `}

              <!-- 7. AUDIT HISTORY -->
              <div style="border-top:1px solid #E2E8F0; padding-top:12px;">
                <div style="font-size:11px; font-weight:800; color:#64748B; text-transform:uppercase; margin-bottom:8px; letter-spacing:0.5px;">
                  Audit Trail &amp; History
                </div>
                <div style="display:flex; flex-direction:column; gap:6px;">
                  ${auditTrail.length > 0 ? auditTrail.map(event => {
                    let tsFormatted = '2026-09-30';
                    if (event.timestamp) {
                      try {
                        const d = new Date(event.timestamp);
                        if (!isNaN(d.getTime())) {
                          tsFormatted = d.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                        } else {
                          tsFormatted = event.timestamp.slice(0, 16).replace('T', ' ');
                        }
                      } catch {
                        tsFormatted = event.timestamp.slice(0, 16);
                      }
                    }
                    const detailText = event.details || event.note || event.action || event.message || 'Audit milestone recorded';
                    return `
                      <div style="font-size:12px; color:#475569; display:flex; align-items:flex-start; gap:8px;">
                        <span class="mono" style="color:#94A3B8; font-size:11px; flex-shrink:0;">${tsFormatted}</span>
                        <div style="flex:1;">
                          <strong style="color:#1E293B;">${escapeHtml(event.actor || 'System')}:</strong>
                          <span style="color:#475569;">${escapeHtml(detailText)}</span>
                        </div>
                      </div>
                    `;
                  }).join('') : `
                    <div style="font-size:11.5px; color:#94A3B8;">Initial case created from policy assessment.</div>
                  `}
                </div>
              </div>
            </div>
          </div>
        </div>
      `;

      // Close modal listener
      modalOverlay.querySelector('#closeActionDetailBtn')?.addEventListener('click', () => {
        modalOverlay.innerHTML = '';
      });

      // Open evidence drawer listener
      modalOverlay.querySelector('#btn-modal-open-evidence')?.addEventListener('click', () => {
        if (onOpenEvidence) {
          onOpenEvidence({
            title: action.title,
            entity: action.entity,
            evidenceList: (action.financial_evidence_refs || []).map(id => ({ source_id: id, entity: action.entity, value: action.financial_exposure })),
          });
        }
      });

      // Advance Status: OPEN -> IN_REVIEW
      modalOverlay.querySelector('#btn-advance-to-review')?.addEventListener('click', async () => {
        try {
          const updated = await api.updateCase(action.id, { status: 'IN_REVIEW' });
          currentActions = await api.getCases();
          render();
          showActionDetailModal(updated || action);
          showToast(`✓ Action ${action.id} advanced to In Review.`);
        } catch (err) {
          showToast('Failed to update status: ' + err.message);
        }
      });

      // Revert Status: IN_REVIEW -> OPEN
      modalOverlay.querySelector('#btn-revert-to-open')?.addEventListener('click', async () => {
        try {
          const updated = await api.updateCase(action.id, { status: 'OPEN' });
          currentActions = await api.getCases();
          render();
          showActionDetailModal(updated || action);
          showToast(`✓ Action ${action.id} returned to Open.`);
        } catch (err) {
          showToast('Failed to update status: ' + err.message);
        }
      });

      // Remediation step toggle & form submission
      const stepForm = modalOverlay.querySelector('#add-step-form');
      modalOverlay.querySelector('#btn-toggle-add-step')?.addEventListener('click', () => {
        if (stepForm) stepForm.style.display = stepForm.style.display === 'none' ? 'block' : 'none';
      });
      modalOverlay.querySelector('#btn-cancel-add-step')?.addEventListener('click', () => {
        if (stepForm) stepForm.style.display = 'none';
      });
      stepForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const actionDesc = modalOverlay.querySelector('#step-action-input').value.trim();
        const ownerVal = modalOverlay.querySelector('#step-owner-input').value.trim();
        const dueVal = modalOverlay.querySelector('#step-due-input').value.trim();
        if (!actionDesc) return;

        try {
          const updated = await api.addRemediationAction(action.id, {
            action: actionDesc,
            owner: ownerVal,
            due_date: dueVal,
            status: 'OPEN',
          });
          currentActions = await api.getCases();
          render();
          showActionDetailModal(updated || action);
          showToast('✓ Remediation step registered.');
        } catch (err) {
          showToast('Failed to add remediation step: ' + err.message);
        }
      });

      // Add Note toggle & form submission
      const noteForm = modalOverlay.querySelector('#add-note-form');
      modalOverlay.querySelector('#btn-toggle-add-note')?.addEventListener('click', () => {
        if (noteForm) noteForm.style.display = noteForm.style.display === 'none' ? 'block' : 'none';
      });
      modalOverlay.querySelector('#btn-cancel-add-note')?.addEventListener('click', () => {
        if (noteForm) noteForm.style.display = 'none';
      });
      noteForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const textVal = modalOverlay.querySelector('#note-text-input').value.trim();
        if (!textVal) return;

        try {
          const updated = await api.updateCase(action.id, { new_note: textVal });
          currentActions = await api.getCases();
          render();
          showActionDetailModal(updated || action);
          showToast('✓ Progress note added.');
        } catch (err) {
          showToast('Failed to record note: ' + err.message);
        }
      });

      // Resolution Card toggle & form submission (In-place, non-silent closure)
      const resolveForm = modalOverlay.querySelector('#resolve-action-form');
      modalOverlay.querySelector('#btn-toggle-resolve-card')?.addEventListener('click', () => {
        if (resolveForm) resolveForm.style.display = resolveForm.style.display === 'none' ? 'block' : 'none';
      });
      modalOverlay.querySelector('#btn-cancel-resolve')?.addEventListener('click', () => {
        if (resolveForm) resolveForm.style.display = 'none';
      });
      resolveForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!auth.isFinanceManager()) {
          showToast('Permission denied: Only Finance Managers or Admins can resolve and close actions.');
          return;
        }

        const summaryVal = modalOverlay.querySelector('#resolve-summary-input').value.trim();
        const evidenceVal = modalOverlay.querySelector('#resolve-evidence-input').value.trim();
        if (!summaryVal || !evidenceVal) {
          showToast('Please provide both resolution summary and verified evidence.');
          return;
        }

        const currentUser = auth.getUser();
        const reviewerName = currentUser ? (currentUser.full_name || currentUser.username) : 'Finance Manager';

        try {
          await api.closeCase(action.id, {
            resolution_summary: summaryVal,
            resolution_evidence: evidenceVal,
            reviewer: reviewerName,
            actor: reviewerName,
          });
          modalOverlay.innerHTML = '';
          currentActions = await api.getCases();
          render();
          showToast(`✓ Action ${action.id} successfully resolved and closed.`);
        } catch (err) {
          showToast('Failed to close action: ' + err.message);
        }
      });
    }

    // Modal: Create New Action (with Category, Severity, and Subledger linkage)
    function showCreateActionModal(prefill = {}) {
      let modalOverlay = document.getElementById('actionDetailModalOverlay');
      if (!modalOverlay) {
        modalOverlay = document.createElement('div');
        modalOverlay.id = 'actionDetailModalOverlay';
        document.body.appendChild(modalOverlay);
      }

      const prefillExposure = prefill.financial_exposure || prefill.financial_impact || 0;
      const prefillEvidence = prefill.financial_evidence_refs || prefill.evidence_ids || [];
      const selectedCategory = (prefill.category || (prefill.title && prefill.title.toLowerCase().includes('cash') ? 'LIQUIDITY' : (prefill.title && prefill.title.toLowerCase().includes('inv') ? 'INVENTORY' : (prefill.title && (prefill.title.toLowerCase().includes('dso') || prefill.title.toLowerCase().includes('ar')) ? 'RECEIVABLES' : 'GENERAL')))).toUpperCase();
      const selectedSeverity = (prefill.severity || 'CRITICAL').toUpperCase();

      modalOverlay.innerHTML = `
        <div style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.68); backdrop-filter:blur(3px); display:flex; align-items:center; justify-content:center; z-index:999999;">
          <div style="background:#FFFFFF; border-radius:12px; max-width:600px; width:94%; max-height:92vh; overflow-y:auto; padding:24px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.35);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
              <div>
                <h3 style="margin:0; font-size:16px; font-weight:800; color:#0F172A;">Create Remediation Action</h3>
                <span style="font-size:11.5px; color:#64748B;">Linked to financial policy controls, ledger audits &amp; risk findings</span>
              </div>
              <button id="closeNewActionModalBtn" style="background:none; border:none; font-size:18px; cursor:pointer; color:#64748B;" title="Close dialog">✕</button>
            </div>

            ${prefill.control_id ? `
              <div style="background:#F5F3FF; border:1px solid #DDD6FE; border-radius:6px; padding:10px 12px; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center;">
                <div>
                  <span style="font-size:12px; color:#5B21B6; font-weight:700;">Governing Control: ${escapeHtml(prefill.control_id)}</span>
                  ${prefill.assessment_id ? `<div style="font-size:11px; color:#6B21A8;">Assessment Ref: ${escapeHtml(prefill.assessment_id)}</div>` : ''}
                </div>
                <span class="badge badge-critical" style="font-size:10px;">BREACH DETECTED</span>
              </div>
            ` : ''}

            ${prefillEvidence.length > 0 ? `
              <div style="margin-bottom:14px; background:#F8FAFC; border:1px solid #E2E8F0; border-radius:6px; padding:10px 12px;">
                <label style="display:block; font-size:11px; font-weight:700; color:#64748B; margin-bottom:6px; text-transform:uppercase;">Linked Financial Evidence</label>
                <div style="display:flex; flex-wrap:wrap; gap:6px;">
                  ${prefillEvidence.map(ref => `
                    <span style="font-family:var(--font-mono); font-size:11px; background:#FFFFFF; border:1px solid #CBD5E1; padding:2px 8px; border-radius:4px; font-weight:600;">${escapeHtml(ref)}</span>
                  `).join('')}
                </div>
              </div>
            ` : ''}

            <form id="createActionForm">
              <div style="margin-bottom:12px;">
                <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Action Title <span style="color:#DC2626;">*</span></label>
                <input type="text" id="actionTitleInput" class="form-input" style="width:100%;" value="${escapeHtml(prefill.title || '')}" required placeholder="e.g. Counterparty Credit Escalation" />
              </div>

              <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
                <div>
                  <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Category</label>
                  <select id="actionCategoryInput" class="form-input" style="width:100%;">
                    <option value="RECEIVABLES" ${selectedCategory === 'RECEIVABLES' ? 'selected' : ''}>Receivables (AR)</option>
                    <option value="LIQUIDITY" ${selectedCategory === 'LIQUIDITY' ? 'selected' : ''}>Liquidity &amp; Cash</option>
                    <option value="MARGIN" ${selectedCategory === 'MARGIN' ? 'selected' : ''}>Margin &amp; Profitability</option>
                    <option value="INVENTORY" ${selectedCategory === 'INVENTORY' ? 'selected' : ''}>Inventory</option>
                    <option value="PAYABLES" ${selectedCategory === 'PAYABLES' ? 'selected' : ''}>Payables (AP)</option>
                    <option value="GOVERNANCE" ${selectedCategory === 'GOVERNANCE' ? 'selected' : ''}>Governance &amp; Controls</option>
                    <option value="GENERAL" ${selectedCategory === 'GENERAL' ? 'selected' : ''}>General</option>
                  </select>
                </div>
                <div>
                  <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Severity</label>
                  <select id="actionSeverityInput" class="form-input" style="width:100%;">
                    <option value="CRITICAL" ${selectedSeverity === 'CRITICAL' ? 'selected' : ''}>Critical</option>
                    <option value="HIGH" ${selectedSeverity === 'HIGH' ? 'selected' : ''}>High</option>
                    <option value="MEDIUM" ${selectedSeverity === 'MEDIUM' ? 'selected' : ''}>Medium</option>
                    <option value="LOW" ${selectedSeverity === 'LOW' ? 'selected' : ''}>Low</option>
                  </select>
                </div>
              </div>

              <div style="margin-bottom:12px;">
                <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Issue Summary &amp; Narrative <span style="color:#DC2626;">*</span></label>
                <textarea id="actionSummaryInput" class="form-input" style="width:100%; min-height:75px;" required placeholder="Describe the financial incident, exposure details, and context...">${escapeHtml(prefill.summary || '')}</textarea>
              </div>

              <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
                <div>
                  <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Financial Exposure (₹) <span style="color:#DC2626;">*</span></label>
                  <input type="number" id="actionExposureInput" class="form-input" style="width:100%;" value="${prefillExposure}" required min="0" step="any" />
                </div>
                <div>
                  <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Target Entity / Counterparty <span style="color:#DC2626;">*</span></label>
                  <input type="text" id="actionEntityInput" class="form-input" style="width:100%;" value="${escapeHtml(prefill.entity || '')}" placeholder="e.g. Apex Retail Group" required />
                </div>
              </div>

              <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:16px;">
                <div>
                  <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Assigned Owner <span style="color:#DC2626;">*</span></label>
                  <input type="text" id="actionOwnerInput" class="form-input" style="width:100%;" value="${escapeHtml(prefill.owner || prefill.assignee || (auth.getUser() ? (auth.getUser().full_name || auth.getUser().username) : 'Finance Lead'))}" placeholder="Assigned Owner" required />
                </div>
                <div>
                  <label style="display:block; font-size:12px; font-weight:700; color:#334155; margin-bottom:4px;">Target Due Date <span style="color:#DC2626;">*</span></label>
                  <input type="date" id="actionDueDateInput" class="form-input mono" style="width:100%;" value="${escapeHtml(prefill.due_date || new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0])}" required />
                </div>
              </div>

              <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="button" id="cancelNewActionBtn" class="btn btn-secondary btn-sm">Cancel</button>
                <button type="submit" class="btn btn-primary btn-sm">Create Action</button>
              </div>
            </form>
          </div>
        </div>
      `;

      modalOverlay.querySelector('#closeNewActionModalBtn')?.addEventListener('click', () => { modalOverlay.innerHTML = ''; });
      modalOverlay.querySelector('#cancelNewActionBtn')?.addEventListener('click', () => { modalOverlay.innerHTML = ''; });

      modalOverlay.querySelector('#createActionForm')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = modalOverlay.querySelector('#actionTitleInput').value.trim();
        const category = modalOverlay.querySelector('#actionCategoryInput').value;
        const severity = modalOverlay.querySelector('#actionSeverityInput').value;
        const summary = modalOverlay.querySelector('#actionSummaryInput').value.trim();
        const exposure = parseFloat(modalOverlay.querySelector('#actionExposureInput').value) || 0;
        const entity = modalOverlay.querySelector('#actionEntityInput').value.trim();
        const owner = modalOverlay.querySelector('#actionOwnerInput').value.trim();
        const dueDate = modalOverlay.querySelector('#actionDueDateInput').value.trim();

        try {
          await api._request('/api/cases', {
            method: 'POST',
            body: JSON.stringify({
              title,
              summary,
              category,
              severity,
              financial_exposure: exposure,
              financial_impact: exposure,
              entity,
              due_date: dueDate,
              owner: owner,
              assignee: owner,
              control_id: prefill.control_id || null,
              assessment_id: prefill.assessment_id || null,
              financial_evidence_refs: prefillEvidence,
              policy_evidence_refs: prefill.policy_evidence_refs || [],
              recommended_actions: prefill.recommended_actions || (prefill.suggested_actions || []),
            })
          });
          modalOverlay.innerHTML = '';
          currentActions = await api.getCases();
          render();
          showToast('✓ New remediation action successfully registered with full audit lineage.');
        } catch (err) {
          showToast('Failed to create action: ' + err.message);
        }
      });
    }

    render();

    return {
      openWithPrefill: (prefillData) => showCreateActionModal(prefillData),
    };

  } catch (err) {
    container.innerHTML = `
      <div style="padding: 30px; color: var(--color-danger-text); background-color: var(--color-danger-bg); border-radius: var(--radius-md);">
        Error loading Actions view: ${err.message}
      </div>
    `;
  }
}
