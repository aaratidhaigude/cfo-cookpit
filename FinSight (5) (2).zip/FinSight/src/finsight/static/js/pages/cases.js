import { exportToCsv } from '../utils/exportCsv.js';

export async function renderCases(container, api, onOpenEvidence) {
  container.innerHTML = `
    <div style="display: flex; justify-content: center; align-items: center; padding: 60px;">
      <div style="color: var(--color-text-muted); font-size: 14px;">Loading financial cases...</div>
    </div>
  `;

  let currentCases = [];
  let statusFilter = '';
  let severityFilter = '';

  try {
    currentCases = await api.getCases();

    function render() {
      const filtered = currentCases.filter(c => {
        if (statusFilter && c.status !== statusFilter) return false;
        if (severityFilter && c.severity !== severityFilter) return false;
        return true;
      });

      const totalImpact = currentCases.reduce((s, c) => s + (c.financial_impact || 0), 0);
      const openCount = currentCases.filter(c => c.status === 'OPEN').length;
      const reviewCount = currentCases.filter(c => c.status === 'IN_REVIEW').length;
      const resolvedCount = currentCases.filter(c => c.status === 'RESOLVED').length;

      container.innerHTML = `
        <!-- Top Stats Row (Interactive Click-to-Filter) -->
        <div class="kpi-grid" style="margin-bottom: 20px;">
          <div class="metric-card kpi-card-clickable ${statusFilter === '' ? 'active-filter' : ''}" data-status="" title="Click to show all cases">
            <span class="metric-label">Total Remediated Exposure</span>
            <div class="metric-value num">₹${totalImpact.toLocaleString()}</div>
            <div class="metric-comparison"><span class="metric-subtext">Across ${currentCases.length} registered cases</span></div>
          </div>
          <div class="metric-card kpi-card-clickable ${statusFilter === 'OPEN' ? 'active-filter' : ''}" data-status="OPEN" title="Click to filter Open cases">
            <span class="metric-label">Open Cases</span>
            <div class="metric-value num" style="color: #dc2626;">${openCount}</div>
            <div class="metric-comparison"><span class="badge badge-critical">Requires Action</span></div>
          </div>
          <div class="metric-card kpi-card-clickable ${statusFilter === 'IN_REVIEW' ? 'active-filter' : ''}" data-status="IN_REVIEW" title="Click to filter In-Review cases">
            <span class="metric-label">Under Active Review</span>
            <div class="metric-value num" style="color: #d97706;">${reviewCount}</div>
            <div class="metric-comparison"><span class="badge badge-high">In Progress</span></div>
          </div>
          <div class="metric-card kpi-card-clickable ${statusFilter === 'RESOLVED' ? 'active-filter' : ''}" data-status="RESOLVED" title="Click to filter Resolved cases">
            <span class="metric-label">Resolved</span>
            <div class="metric-value num" style="color: #16a34a;">${resolvedCount}</div>
            <div class="metric-comparison"><span class="badge badge-resolved">Completed</span></div>
          </div>
        </div>

        <!-- Cases Table Panel -->
        <div class="panel">
          <div class="panel-header">
            <div style="display: flex; align-items: center; gap: 12px;">
              <h3 class="panel-title">Financial Remediation Cases</h3>
              <!-- Filters -->
              <select id="case-status-filter" class="period-select" style="width: auto; padding: 4px 8px; font-size: 12px; background: #ffffff; color: var(--color-text-primary); border-color: var(--color-border);">
                <option value="">All Statuses</option>
                <option value="OPEN" ${statusFilter === 'OPEN' ? 'selected' : ''}>Open</option>
                <option value="IN_REVIEW" ${statusFilter === 'IN_REVIEW' ? 'selected' : ''}>In Review</option>
                <option value="RESOLVED" ${statusFilter === 'RESOLVED' ? 'selected' : ''}>Resolved</option>
                <option value="CLOSED" ${statusFilter === 'CLOSED' ? 'selected' : ''}>Closed</option>
              </select>

              <select id="case-severity-filter" class="period-select" style="width: auto; padding: 4px 8px; font-size: 12px; background: #ffffff; color: var(--color-text-primary); border-color: var(--color-border);">
                <option value="">All Severities</option>
                <option value="CRITICAL" ${severityFilter === 'CRITICAL' ? 'selected' : ''}>Critical</option>
                <option value="HIGH" ${severityFilter === 'HIGH' ? 'selected' : ''}>High</option>
                <option value="MEDIUM" ${severityFilter === 'MEDIUM' ? 'selected' : ''}>Medium</option>
                <option value="LOW" ${severityFilter === 'LOW' ? 'selected' : ''}>Low</option>
              </select>
            </div>

            <div style="display: flex; align-items: center; gap: 8px;">
              <button id="btn-export-cases-csv" class="btn btn-outline btn-sm" style="display: flex; align-items: center; gap: 6px;">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                <span>Export CSV</span>
              </button>
              <button id="btn-create-new-case" class="btn btn-primary btn-sm">
                <span>+ Open New Case</span>
              </button>
            </div>
          </div>

          <!-- Table -->
          <div class="table-container">
            <table class="fin-table">
              <thead>
                <tr>
                  <th>Case ID</th>
                  <th>Title & Finding</th>
                  <th>Category</th>
                  <th>Severity</th>
                  <th>Status</th>
                  <th class="amount">Financial Exposure</th>
                  <th>Assignee</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                ${filtered.map(c => `
                  <tr>
                    <td><code class="mono" style="font-weight: 700;">${c.id}</code></td>
                    <td>
                      <strong>${c.title}</strong>
                      <div style="font-size: 11.5px; color: var(--color-text-muted); max-width: 420px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        ${c.summary}
                      </div>
                    </td>
                    <td><span class="badge badge-low">${c.category}</span></td>
                    <td><span class="badge badge-${c.severity.toLowerCase()}">${c.severity}</span></td>
                    <td><span class="badge badge-${c.status === 'RESOLVED' ? 'resolved' : c.status === 'OPEN' ? 'critical' : 'high'}">${c.status}</span></td>
                    <td class="amount">₹${(c.financial_impact || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    <td>${c.assignee}</td>
                    <td>
                      <button class="btn btn-outline btn-sm btn-view-case" data-id="${c.id}">
                        Manage Case →
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Case Details Modal -->
        <div id="case-modal-container"></div>
      `;

      // Event handlers for filters
      container.querySelector('#case-status-filter')?.addEventListener('change', (e) => {
        statusFilter = e.target.value;
        render();
      });

      container.querySelector('#case-severity-filter')?.addEventListener('change', (e) => {
        severityFilter = e.target.value;
        render();
      });

      // UC15 Feature 3: Click-to-Filter on KPI Cards
      container.querySelectorAll('.kpi-card-clickable').forEach(card => {
        card.addEventListener('click', () => {
          const targetStatus = card.getAttribute('data-status');
          statusFilter = (statusFilter === targetStatus) ? '' : targetStatus;
          render();
        });
      });

      // UC15 Feature 7: Export Cases to CSV
      container.querySelector('#btn-export-cases-csv')?.addEventListener('click', () => {
        const headers = [
          { label: 'Case ID', key: 'id' },
          { label: 'Title', key: 'title' },
          { label: 'Category', key: 'category' },
          { label: 'Severity', key: 'severity' },
          { label: 'Status', key: 'status' },
          { label: 'Financial Impact (INR)', key: 'financial_impact' },
          { label: 'Assignee', key: 'assignee' },
          { label: 'Summary', key: 'summary' }
        ];
        exportToCsv('finsight_action_items.csv', headers, filtered);
      });

      // View case button handlers
      container.querySelectorAll('.btn-view-case').forEach(btn => {
        btn.addEventListener('click', async () => {
          const caseId = btn.getAttribute('data-id');
          try {
            const fullCase = await api.getCase(caseId);
            openCaseModal(fullCase);
          } catch (e) {
            const fallback = currentCases.find(item => item.id === caseId);
            if (fallback) openCaseModal(fallback);
          }
        });
      });

      container.querySelector('#btn-create-new-case')?.addEventListener('click', () => {
        openCreateCaseModal();
      });
    }

    async function openCaseModal(c) {
      const modalCont = container.querySelector('#case-modal-container');
      const exposure = c.financial_exposure ?? c.financial_impact ?? 0;
      const remediationPlan = c.remediation_plan || [];
      const auditTrail = c.audit_notes || [];
      const finEvidence = c.financial_evidence || [];
      const polEvidence = c.policy_evidence || [];

      modalCont.innerHTML = `
        <dialog id="case-detail-dialog" class="drawer" style="width: min(780px, 96vw); max-width: 820px;">
          <!-- Section 1: Exposure Header -->
          <div class="drawer-header" style="border-bottom: 1px solid var(--color-border); padding: 14px 20px;">
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
              <code class="mono" style="font-weight: 700; font-size: 14px; background: var(--color-surface-subtle); padding: 2px 6px; border-radius: var(--radius-sm); border: 1px solid var(--color-border);">${c.id}</code>
              <span class="badge badge-${(c.severity || 'HIGH').toLowerCase()}">${c.severity || 'HIGH'}</span>
              <span class="badge ${c.status === 'CLOSED' ? 'badge-resolved' : c.status === 'RESOLVED' ? 'badge-resolved' : c.status === 'OPEN' ? 'badge-critical' : 'badge-high'}" id="current-status-badge">${c.status}</span>
              <strong style="font-size: 15px; color: var(--color-text-primary); margin-left: 4px;">${c.title}</strong>
            </div>
            <button class="drawer-close" id="btn-close-case-modal">✕</button>
          </div>

          <div class="drawer-body" style="padding: 18px 20px; display: flex; flex-direction: column; gap: 18px;">
            <!-- Exposure & Metadata Header Bar -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; padding: 12px 16px; background-color: var(--color-surface-subtle); border-radius: var(--radius-sm); border: 1px solid var(--color-border);">
              <div>
                <span style="font-size: 11px; color: var(--color-text-muted); text-transform: uppercase;">Financial Exposure</span>
                <div class="num" style="font-size: 16px; font-weight: 700; color: #dc2626;">
                  ₹${exposure.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
              <div>
                <span style="font-size: 11px; color: var(--color-text-muted); text-transform: uppercase;">Assignee / Owner</span>
                <div style="font-size: 13px; font-weight: 600; color: var(--color-text-primary); margin-top: 2px;">
                  ${c.assigned_owner || c.assignee || 'Finance Operations'}
                </div>
              </div>
              <div>
                <span style="font-size: 11px; color: var(--color-text-muted); text-transform: uppercase;">Target Due Date</span>
                <div class="mono" style="font-size: 12px; font-weight: 600; color: var(--color-text-primary); margin-top: 2px;">
                  ${c.due_date || '2026-10-15'}
                </div>
              </div>
              <div>
                <span style="font-size: 11px; color: var(--color-text-muted); text-transform: uppercase;">Case Lifecycle Status</span>
                <div style="margin-top: 2px;">
                  <select id="modal-status-select" class="period-select" style="background: #ffffff; color: var(--color-text-primary); border-color: var(--color-border); padding: 2px 6px; font-size: 11.5px;">
                    <option value="DETECTED" ${c.status === 'DETECTED' ? 'selected' : ''}>DETECTED</option>
                    <option value="INVESTIGATING" ${c.status === 'INVESTIGATING' ? 'selected' : ''}>INVESTIGATING</option>
                    <option value="OPEN" ${c.status === 'OPEN' ? 'selected' : ''}>OPEN</option>
                    <option value="IN_PROGRESS" ${c.status === 'IN_PROGRESS' || c.status === 'IN_REVIEW' ? 'selected' : ''}>IN_PROGRESS</option>
                    <option value="PENDING_REVIEW" ${c.status === 'PENDING_REVIEW' ? 'selected' : ''}>PENDING_REVIEW</option>
                    <option value="RESOLVED" ${c.status === 'RESOLVED' ? 'selected' : ''}>RESOLVED</option>
                    <option value="CLOSED" ${c.status === 'CLOSED' ? 'selected' : ''}>CLOSED</option>
                  </select>
                </div>
              </div>
            </div>

            <!-- Section 2: Why This Case Exists -->
            <div class="panel" style="padding: 14px 16px;">
              <h4 style="font-size: 12px; text-transform: uppercase; color: var(--color-text-muted); margin-bottom: 6px; font-weight: 700; letter-spacing: 0.5px;">
                Why This Case Exists
              </h4>
              <p style="font-size: 13px; color: var(--color-text-primary); line-height: 1.5; margin: 0;">
                ${c.why_this_case_exists || c.summary}
              </p>
            </div>

            <!-- Section 3: Control Assessment -->
            <div class="panel" style="padding: 14px 16px;">
              <h4 style="font-size: 12px; text-transform: uppercase; color: var(--color-text-muted); margin-bottom: 8px; font-weight: 700; letter-spacing: 0.5px;">
                Governing Internal Control Assessment
              </h4>
              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; font-size: 12px;">
                <div>
                  <span style="color: var(--color-text-muted);">Control ID:</span>
                  <div><code class="mono" style="font-weight: 700;">${c.control_id || 'CONTROL-COLL-001'}</code></div>
                </div>
                <div>
                  <span style="color: var(--color-text-muted);">Governing Policy:</span>
                  <div><code class="mono" style="font-weight: 700;">${c.policy_reference || 'COLL-POL-001'}</code></div>
                </div>
                <div>
                  <span style="color: var(--color-text-muted);">Threshold vs Observed:</span>
                  <div style="font-weight: 600; color: #dc2626;">
                    ${c.control_assessment?.observed_value !== undefined ? `${c.control_assessment.observed_value} (Limit: ${c.control_assessment.threshold_value})` : 'Breached Escalation Floor'}
                  </div>
                </div>
                <div>
                  <span style="color: var(--color-text-muted);">Assessment Result:</span>
                  <div><span class="badge badge-critical">BREACH CONFIRMED</span></div>
                </div>
              </div>
            </div>

            <!-- Section 4: Financial Evidence -->
            <div class="panel" style="padding: 14px 16px;">
              <h4 style="font-size: 12px; text-transform: uppercase; color: var(--color-text-muted); margin-bottom: 8px; font-weight: 700; letter-spacing: 0.5px;">
                Supporting Financial Evidence (${finEvidence.length} items)
              </h4>
              ${finEvidence.length > 0 ? `
                <div style="display: flex; flex-direction: column; gap: 6px;">
                  ${finEvidence.map(ev => `
                    <div style="padding: 8px 10px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 12px;">
                      <div style="display: flex; justify-content: space-between; font-weight: 600;">
                        <span>${ev.claim || ev.statement || 'Verified Ledger Finding'}</span>
                        <span class="num" style="color: #dc2626;">${ev.formatted_value || (ev.value ? `₹${ev.value.toLocaleString()}` : '')}</span>
                      </div>
                      <div style="font-size: 11px; color: var(--color-text-muted); margin-top: 3px;">
                        Source: <code class="mono">${ev.source_system || 'Enterprise ERP'}</code> &middot; Entity: <strong>${ev.entity || 'General Ledger'}</strong>
                      </div>
                    </div>
                  `).join('')}
                </div>
              ` : `
                <div style="font-size: 12px; color: var(--color-text-muted);">
                  Financial balances verified from subledger: ₹${exposure.toLocaleString()} concentrated exposure.
                </div>
              `}
            </div>

            <!-- Section 5: Policy Evidence -->
            <div class="panel" style="padding: 14px 16px;">
              <h4 style="font-size: 12px; text-transform: uppercase; color: var(--color-text-muted); margin-bottom: 8px; font-weight: 700; letter-spacing: 0.5px;">
                Finance Policy Evidence (${polEvidence.length} items)
              </h4>
              ${polEvidence.length > 0 ? `
                <div style="display: flex; flex-direction: column; gap: 6px;">
                  ${polEvidence.map(pev => `
                    <div style="padding: 8px 10px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 12px;">
                      <div style="font-weight: 600; color: var(--color-text-primary); margin-bottom: 2px;">
                        ${pev.title || pev.claim || 'Policy Clause'}
                      </div>
                      <div style="font-size: 11.5px; color: var(--color-text-secondary); line-height: 1.4;">
                        ${pev.context_snippet || pev.statement || pev.claim}
                      </div>
                      <div style="font-size: 11px; color: var(--color-text-muted); margin-top: 4px;">
                        DocRef: <code class="mono">${pev.doc_id || c.policy_reference}</code> &middot; Section: <strong>${pev.section || 'Escalation & Holds'}</strong>
                      </div>
                    </div>
                  `).join('')}
                </div>
              ` : `
                <div style="font-size: 12px; color: var(--color-text-muted);">
                  Governed under Policy <code class="mono">${c.policy_reference || 'COLL-POL-001'}</code>: Mandatory immediate escalation for overdue accounts exceeding ₹500,000.
                </div>
              `}
            </div>

            <!-- Section 6: Remediation Plan & Action Items -->
            <div class="panel" style="padding: 14px 16px;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h4 style="font-size: 12px; text-transform: uppercase; color: var(--color-text-muted); margin: 0; font-weight: 700; letter-spacing: 0.5px;">
                  Remediation Action Items (${remediationPlan.length})
                </h4>
                <button class="btn btn-outline btn-sm" id="btn-toggle-add-action" style="padding: 2px 8px; font-size: 11px;">
                  + Add Action
                </button>
              </div>

              <!-- Add Action Inline Form (collapsible) -->
              <div id="add-action-form" style="display: none; margin-bottom: 12px; padding: 10px 12px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-sm);">
                <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 8px; align-items: center;">
                  <input type="text" id="new-action-desc" class="investigate-input" style="font-size: 12px; padding: 5px 8px;" placeholder="Remediation action description..." />
                  <input type="text" id="new-action-owner" class="investigate-input" style="font-size: 12px; padding: 5px 8px;" placeholder="Owner (e.g. Treasury Lead)" />
                  <input type="date" id="new-action-due" class="investigate-input" style="font-size: 12px; padding: 5px 8px;" value="2026-10-10" />
                  <button class="btn btn-primary btn-sm" id="btn-save-new-action" style="padding: 5px 10px; font-size: 11.5px;">Save</button>
                </div>
              </div>

              <div class="table-container">
                <table class="fin-table" style="font-size: 12px;">
                  <thead>
                    <tr>
                      <th>Action</th>
                      <th>Owner</th>
                      <th>Target Date</th>
                      <th>Status</th>
                      <th>Evidence / Output</th>
                    </tr>
                  </thead>
                  <tbody id="remediation-table-body">
                    ${remediationPlan.length > 0 ? remediationPlan.map(act => `
                      <tr>
                        <td><strong>${act.action}</strong></td>
                        <td>${act.owner}</td>
                        <td><code class="mono" style="font-size: 11px;">${act.due_date}</code></td>
                        <td>
                          <span class="badge ${act.status === 'COMPLETED' ? 'badge-resolved' : act.status === 'IN_PROGRESS' ? 'badge-high' : 'badge-medium'}">
                            ${act.status}
                          </span>
                        </td>
                        <td style="font-size: 11px; color: var(--color-text-secondary);">${act.evidence || act.completion_evidence || '—'}</td>
                      </tr>
                    `).join('') : `
                      <tr>
                        <td colspan="5" style="text-align: center; color: var(--color-text-muted);">No remediation actions logged yet.</td>
                      </tr>
                    `}
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Section 7: Activity Timeline & Immutable Audit Trail -->
            <div class="panel" style="padding: 14px 16px;">
              <h4 style="font-size: 12px; text-transform: uppercase; color: var(--color-text-muted); margin-bottom: 10px; font-weight: 700; letter-spacing: 0.5px;">
                Activity Timeline & Audit Trail (${auditTrail.length} Events)
              </h4>
              <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; max-height: 220px; overflow-y: auto;">
                ${auditTrail.length > 0 ? auditTrail.map(event => `
                  <div style="padding: 8px 10px; background-color: var(--color-surface-subtle); border-radius: var(--radius-sm); border: 1px solid var(--color-border); font-size: 11.5px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                      <div style="display: flex; align-items: center; gap: 6px;">
                        <span class="badge badge-low" style="font-size: 10px; padding: 1px 5px;">${event.event_type}</span>
                        <strong>${event.actor || 'System'}</strong>
                      </div>
                      <span class="mono" style="font-size: 10.5px; color: var(--color-text-muted);">
                        ${(event.timestamp || '').slice(0, 16).replace('T', ' ')}
                      </span>
                    </div>
                    <div style="color: var(--color-text-secondary);">${event.description}</div>
                  </div>
                `).join('') : `
                  <div style="font-size: 12px; color: var(--color-text-muted);">No events recorded in audit log.</div>
                `}
              </div>

              <!-- Quick-Pick Templates -->
              <div style="font-size: 11px; font-weight: 600; color: var(--color-text-muted); margin-bottom: 4px; text-transform: uppercase;">
                Quick-Pick Justification Templates:
              </div>
              <div class="template-chips-container" style="margin-bottom: 8px;">
                <span class="template-chip" data-text="Remediation action verified with bank receipt.">Bank receipt verified</span>
                <span class="template-chip" data-text="Payment restructuring agreement signed with customer.">Restructuring agreement signed</span>
                <span class="template-chip" data-text="ERP shipping hold applied per credit policy.">ERP hold applied</span>
                <span class="template-chip" data-text="Approved per CFO liquidity preservation plan.">Approved per CFO plan</span>
              </div>

              <!-- Add Audit Note -->
              <div style="display: flex; gap: 8px;">
                <input type="text" id="modal-new-note-input" class="investigate-input" style="font-size: 12px; padding: 6px 10px;" placeholder="Add immutable audit log update..." />
                <button id="modal-btn-add-note" class="btn btn-secondary btn-sm" style="font-size: 11.5px;">Post Note</button>
              </div>
            </div>

            <!-- Non-Silent Case Closure Section (shown when CLOSED selected) -->
            <div id="closure-form-container" style="display: ${c.status === 'CLOSED' ? 'block' : 'none'}; padding: 14px 16px; background: #fffbeb; border: 1px solid #fde68a; border-radius: var(--radius-sm);">
              <h4 style="font-size: 12.5px; font-weight: 700; color: #92400e; margin: 0 0 8px 0; text-transform: uppercase;">
                Formal Non-Silent Case Closure Documentation
              </h4>
              <p style="font-size: 11.5px; color: #78350f; margin-bottom: 10px;">
                FinSight policy strictly prohibits silent case closure. You must provide audited resolution summary, objective evidence reference, and reviewer sign-off.
              </p>
              <div style="display: flex; flex-direction: column; gap: 8px;">
                <div>
                  <label style="font-size: 11px; font-weight: 600; color: #92400e;">Resolution Summary *</label>
                  <textarea id="closure-summary-input" class="investigate-input" style="width: 100%; height: 50px; font-size: 12px; padding: 6px;" placeholder="Explain how the financial risk / control breach was resolved...">${c.resolution_summary || ''}</textarea>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                  <div>
                    <label style="font-size: 11px; font-weight: 600; color: #92400e;">Resolution Evidence Reference *</label>
                    <input type="text" id="closure-evidence-input" class="investigate-input" style="font-size: 12px; padding: 5px 8px;" placeholder="Doc ID, bank slip, or contract ref..." value="${c.resolution_evidence || ''}" />
                  </div>
                  <div>
                    <label style="font-size: 11px; font-weight: 600; color: #92400e;">Reviewer Sign-Off *</label>
                    <input type="text" id="closure-reviewer-input" class="investigate-input" style="font-size: 12px; padding: 5px 8px;" placeholder="Reviewer name / title..." value="${c.resolved_by || 'VP Commercial Finance'}" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="drawer-footer" style="padding: 12px 20px; border-top: 1px solid var(--color-border); display: flex; justify-content: space-between; align-items: center;">
            <button class="btn btn-secondary btn-sm" id="btn-modal-cancel">Close Drawer</button>
            <button class="btn btn-primary btn-sm" id="btn-modal-save">Save Case Updates</button>
          </div>
        </dialog>
      `;

      const dlg = modalCont.querySelector('#case-detail-dialog');
      dlg.showModal();

      const closeDlg = () => dlg.close();
      modalCont.querySelector('#btn-close-case-modal')?.addEventListener('click', closeDlg);
      modalCont.querySelector('#btn-modal-cancel')?.addEventListener('click', closeDlg);

      // Status selector toggles closure form
      const statusSelect = modalCont.querySelector('#modal-status-select');
      const closureContainer = modalCont.querySelector('#closure-form-container');
      statusSelect?.addEventListener('change', (e) => {
        if (e.target.value === 'CLOSED') {
          closureContainer.style.display = 'block';
        } else {
          if (c.status !== 'CLOSED') {
            closureContainer.style.display = 'none';
          }
        }
      });

      // Toggle Add Action Form
      const addActionForm = modalCont.querySelector('#add-action-form');
      modalCont.querySelector('#btn-toggle-add-action')?.addEventListener('click', () => {
        addActionForm.style.display = addActionForm.style.display === 'none' ? 'block' : 'none';
      });

      // Save New Remediation Action
      modalCont.querySelector('#btn-save-new-action')?.addEventListener('click', async () => {
        const actionDesc = modalCont.querySelector('#new-action-desc').value.trim();
        const actionOwner = modalCont.querySelector('#new-action-owner').value.trim() || 'Finance Lead';
        const actionDue = modalCont.querySelector('#new-action-due').value;

        if (!actionDesc) {
          alert('Action description is required.');
          return;
        }

        try {
          const updated = await api.addRemediationAction(c.id, {
            action: actionDesc,
            owner: actionOwner,
            due_date: actionDue,
            status: 'OPEN'
          });
          currentCases = await api.getCases();
          dlg.close();
          openCaseModal(updated);
        } catch (e) {
          alert('Error adding remediation action: ' + e.message);
        }
      });

      // Quick-pick chips
      modalCont.querySelectorAll('.template-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          const inp = modalCont.querySelector('#modal-new-note-input');
          if (inp) {
            inp.value = chip.getAttribute('data-text');
            inp.focus();
          }
        });
      });

      // Post Note
      modalCont.querySelector('#modal-btn-add-note')?.addEventListener('click', async () => {
        const inp = modalCont.querySelector('#modal-new-note-input');
        const txt = inp?.value.trim();
        if (txt) {
          try {
            const updated = await api.updateCase(c.id, { new_note: txt, note_author: 'Finance Controller' });
            currentCases = await api.getCases();
            dlg.close();
            openCaseModal(updated);
          } catch (e) {
            alert('Error adding audit note: ' + e.message);
          }
        }
      });

      // Save Case Updates / Enforce Non-Silent Closure
      modalCont.querySelector('#btn-modal-save')?.addEventListener('click', async () => {
        const targetStatus = statusSelect.value;
        const noteText = modalCont.querySelector('#modal-new-note-input')?.value.trim();

        if (targetStatus === 'CLOSED') {
          const resSummary = modalCont.querySelector('#closure-summary-input')?.value.trim();
          const resEvidence = modalCont.querySelector('#closure-evidence-input')?.value.trim();
          const reviewer = modalCont.querySelector('#closure-reviewer-input')?.value.trim();

          if (!resSummary || !resEvidence) {
            alert('Non-Silent Closure Enforced: Resolution summary and evidence reference are mandatory to close a case.');
            return;
          }

          try {
            await api.closeCase(c.id, {
              resolution_summary: resSummary,
              resolution_evidence: resEvidence,
              reviewer: reviewer || 'Finance Controller'
            });
            currentCases = await api.getCases();
            dlg.close();
            render();
            return;
          } catch (e) {
            alert('Error closing case: ' + e.message);
            return;
          }
        }

        // Standard status update
        try {
          const payload = { status: targetStatus };
          if (noteText) {
            payload.new_note = noteText;
            payload.note_author = 'Finance Controller';
          }
          await api.updateCase(c.id, payload);
          currentCases = await api.getCases();
          dlg.close();
          render();
        } catch (e) {
          alert('Error updating case: ' + e.message);
        }
      });
    }

    function openCreateCaseModal(prefill = null) {
      const modalCont = container.querySelector('#case-modal-container');
      modalCont.innerHTML = `
        <dialog id="new-case-dialog" class="drawer" style="width: min(540px, 95vw);">
          <div class="drawer-header">
            <strong style="font-size: 15px;">Open New Remediation Case</strong>
            <button class="drawer-close" id="btn-close-new-case">✕</button>
          </div>
          <div class="drawer-body">
            <div>
              <label style="display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px;">Title</label>
              <input type="text" id="new-case-title" class="investigate-input" style="width: 100%; font-size: 13px;" value="${prefill?.title || ''}" placeholder="e.g. Apex Retail Overdue AR Escalation" />
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div>
                <label style="display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px;">Severity</label>
                <select id="new-case-sev" class="period-select" style="width: 100%; background: #ffffff; color: var(--color-text-primary); border-color: var(--color-border);">
                  <option value="CRITICAL" ${prefill?.severity === 'CRITICAL' ? 'selected' : ''}>CRITICAL</option>
                  <option value="HIGH" ${(!prefill || prefill.severity === 'HIGH') ? 'selected' : ''}>HIGH</option>
                  <option value="MEDIUM" ${prefill?.severity === 'MEDIUM' ? 'selected' : ''}>MEDIUM</option>
                  <option value="LOW" ${prefill?.severity === 'LOW' ? 'selected' : ''}>LOW</option>
                </select>
              </div>
              <div>
                <label style="display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px;">Category</label>
                <select id="new-case-cat" class="period-select" style="width: 100%; background: #ffffff; color: var(--color-text-primary); border-color: var(--color-border);">
                  <option value="RECEIVABLES" ${prefill?.category === 'RECEIVABLES' ? 'selected' : ''}>RECEIVABLES</option>
                  <option value="LIQUIDITY" ${prefill?.category === 'LIQUIDITY' ? 'selected' : ''}>LIQUIDITY</option>
                  <option value="MARGIN" ${prefill?.category === 'MARGIN' ? 'selected' : ''}>MARGIN</option>
                  <option value="INVENTORY" ${prefill?.category === 'INVENTORY' ? 'selected' : ''}>INVENTORY</option>
                  <option value="PAYABLES" ${prefill?.category === 'PAYABLES' ? 'selected' : ''}>PAYABLES</option>
                  <option value="GENERAL">GENERAL</option>
                </select>
              </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div>
                <label style="display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px;">Financial Exposure (₹)</label>
                <input type="number" id="new-case-impact" class="investigate-input" style="width: 100%; font-size: 13px;" value="${prefill?.financial_impact || 0}" />
              </div>
              <div>
                <label style="display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px;">Assignee</label>
                <input type="text" id="new-case-assignee" class="investigate-input" style="width: 100%; font-size: 13px;" value="Credit Controller" />
              </div>
            </div>

            <div>
              <label style="display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px;">Executive Problem Statement</label>
              <textarea id="new-case-summary" class="investigate-input" style="width: 100%; height: 80px; font-size: 12.5px; resize: vertical;" placeholder="Explain the financial risk, entity, and subledger evidence...">${prefill?.summary || ''}</textarea>
            </div>
          </div>
          <div class="drawer-footer">
            <button class="btn btn-secondary btn-sm" id="btn-cancel-create">Cancel</button>
            <button class="btn btn-primary btn-sm" id="btn-submit-create">Create Case</button>
          </div>
        </dialog>
      `;

      const dlg = modalCont.querySelector('#new-case-dialog');
      dlg.showModal();

      const closeDlg = () => dlg.close();
      modalCont.querySelector('#btn-close-new-case')?.addEventListener('click', closeDlg);
      modalCont.querySelector('#btn-cancel-create')?.addEventListener('click', closeDlg);

      modalCont.querySelector('#btn-submit-create')?.addEventListener('click', async () => {
        const title = modalCont.querySelector('#new-case-title').value.trim();
        const severity = modalCont.querySelector('#new-case-sev').value;
        const category = modalCont.querySelector('#new-case-cat').value;
        const impact = parseFloat(modalCont.querySelector('#new-case-impact').value) || 0;
        const assignee = modalCont.querySelector('#new-case-assignee').value.trim() || 'Finance Lead';
        const summary = modalCont.querySelector('#new-case-summary').value.trim();

        if (!title || !summary) {
          alert('Title and Summary are required.');
          return;
        }

        try {
          await api.createCase({
            title,
            severity,
            category,
            financial_impact: impact,
            summary,
            assignee,
            linked_attention_id: prefill?.linked_attention_id,
            linked_question: prefill?.linked_question,
            recommended_actions: prefill?.recommended_actions || [],
            initial_note: 'Case initialized from executive investigation.'
          });
          currentCases = await api.getCases();
          dlg.close();
          render();
        } catch (e) {
          alert('Error creating case: ' + e.message);
        }
      });
    }

    render();

    return {
      openWithPrefill(data) {
        openCreateCaseModal(data);
      }
    };

  } catch (err) {
    container.innerHTML = `
      <div style="padding: 30px; color: var(--color-danger-text); background-color: var(--color-danger-bg); border-radius: var(--radius-md);">
        Error loading Cases: ${err.message}
      </div>
    `;
  }
}
