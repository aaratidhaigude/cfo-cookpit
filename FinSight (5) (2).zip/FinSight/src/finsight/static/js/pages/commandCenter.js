/**
 * Command Center Page View
 * High-density executive landing page for CFO and finance leadership.
 */

import { renderMetricCard } from '../components/metricCard.js';
import { renderAttentionCard } from '../components/attentionCard.js';
import { renderCashTrendChart } from '../components/cashTrendChart.js';
import { formatCompactCurrency } from '../utils/format.js';

export async function renderCommandCenter(container, api, onNavigate, onOpenEvidence) {
  container.innerHTML = `
    <div style="display: flex; justify-content: center; align-items: center; padding: 60px;">
      <div style="color: var(--color-text-muted); font-size: 14px;">Loading executive financial data...</div>
    </div>
  `;

  try {
    const [summary, attention, intelReport, cashData, snapshot, controlSummary] = await Promise.all([
      api.getSummary(),
      api.getAttentionSummary(),
      api.getIntelligenceReport(),
      api.getCash().catch(() => null),
      api.getSnapshot().catch(() => null),
      api.getControlSummary().catch(() => null),
    ]);

    container.innerHTML = '';

    // Data Provenance & Authoritative Snapshot Header Banner
    const provenanceBanner = document.createElement('div');
    provenanceBanner.style.cssText = 'margin-bottom: 12px; padding: 10px 16px; background-color: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-sm); display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: var(--color-text-secondary); flex-wrap: wrap; gap: 8px;';
    provenanceBanner.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <span class="badge badge-resolved" style="font-size: 11px;">Authoritative Snapshot</span>
        <strong>${summary.period}</strong> &middot; <span>${summary.company_name} (${summary.company_code})</span> &middot; <span>Currency: ${summary.currency}</span>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; font-size: 11.5px; color: var(--color-text-muted);">
        <span>Source: <strong>${snapshot?.source || 'Enterprise ERP'}</strong></span>
        <span>Snapshot: <code class="mono">${snapshot?.snapshot_id || 'SNAP-ACTIVE'}</code></span>
        <span class="badge ${snapshot?.data_quality_status === 'READY' ? 'badge-resolved' : 'badge-high'}">Quality: ${snapshot?.data_quality_status || 'READY'}</span>
      </div>
    `;
    container.appendChild(provenanceBanner);

    // Phase 6: Financial Controls Intelligence Health Widget
    if (controlSummary) {
      const controlsBanner = document.createElement('div');
      controlsBanner.style.cssText = 'margin-bottom: 18px; padding: 12px 16px; background: linear-gradient(135deg, rgba(239,68,68,0.06), rgba(245,158,11,0.06)); border: 1px solid rgba(239,68,68,0.25); border-radius: var(--radius-sm); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; font-size: 12.5px;';
      const exposureFormatted = controlSummary.total_financial_exposure 
        ? formatCompactCurrency(controlSummary.total_financial_exposure) 
        : '₹0';
      controlsBanner.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
          <div style="display: flex; align-items: center; gap: 6px; font-weight: 700; color: var(--color-text-primary);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            <span>Internal Financial Controls:</span>
          </div>
          <span class="badge badge-critical">${controlSummary.breached_controls} Breached</span>
          <span class="badge badge-high">${controlSummary.review_controls} Under Review</span>
          <span class="badge badge-resolved">${controlSummary.passed_controls} Passed</span>
          <span style="color: var(--color-text-muted); font-size: 11.5px;">(${controlSummary.total_controls} Active Evaluated)</span>
        </div>
        <div style="display: flex; align-items: center; gap: 14px;">
          <span>Exposure under Policy: <strong style="color: #dc2626;">${exposureFormatted}</strong></span>
          <button class="btn btn-outline btn-sm" id="btn-view-remediations" style="padding: 4px 10px; font-size: 11.5px; background: #ffffff;">
            <span>Review Remediations →</span>
          </button>
        </div>
      `;
      controlsBanner.querySelector('#btn-view-remediations')?.addEventListener('click', () => {
        onNavigate('actions');
      });
      container.appendChild(controlsBanner);
    }

    // 1. Top-Level Executive 6 KPI Cards
    const kpiSection = document.createElement('section');
    kpiSection.className = 'kpi-grid';

    // Cash Card
    const cashVal = summary.cash_position.value || 0;
    const cashComp = summary.cash_position.comparison;
    const cashCard = renderMetricCard({
      label: 'Cash & Equivalents',
      formattedValue: summary.cash_position.formatted_value,
      deltaText: cashComp ? `${cashComp.percentage_change > 0 ? '+' : ''}${cashComp.percentage_change}%` : null,
      deltaType: cashComp && cashComp.percentage_change < 0 ? 'neg' : 'pos',
      badgeText: cashVal < 1000000 ? 'Liquidity Pressure' : null,
      badgeType: 'critical',
      subtext: 'vs prior period',
      onClick: () => onNavigate('financials', { tab: 'cash' }),
    });

    // Net Working Capital
    const nwcComp = summary.net_working_capital.comparison;
    const nwcCard = renderMetricCard({
      label: 'Net Working Capital',
      formattedValue: summary.net_working_capital.formatted_value,
      deltaText: nwcComp ? `${nwcComp.percentage_change > 0 ? '+' : ''}${nwcComp.percentage_change}%` : null,
      deltaType: 'pos',
      badgeText: 'CA - CL Reconciled',
      badgeType: 'resolved',
      subtext: 'CA minus CL',
      onClick: () => onNavigate('financials'),
    });

    // DSO
    const dsoComp = summary.dso.comparison;
    const dsoCard = renderMetricCard({
      label: 'Days Sales Outstanding (DSO)',
      formattedValue: summary.dso.formatted_value,
      deltaText: dsoComp ? `+${dsoComp.absolute_change} days` : null,
      deltaType: 'neg',
      badgeText: 'Deteriorating',
      badgeType: 'high',
      subtext: 'Collection lag',
      onClick: () => onNavigate('financials', { tab: 'receivables' }),
    });

    // Cash Conversion Cycle (CCC = DSO + DIO - DPO)
    const cccVal = summary.ccc ? summary.ccc.formatted_value : 'N/A';
    const cccComp = summary.ccc?.comparison;
    const cccDeltaText = cccComp ? `${cccComp.absolute_change > 0 ? '+' : ''}${cccComp.absolute_change} days` : null;
    const cccCard = renderMetricCard({
      label: 'Cash Conversion Cycle (CCC)',
      formattedValue: cccVal,
      deltaText: cccDeltaText,
      deltaType: cccComp && cccComp.absolute_change > 0 ? 'neg' : 'pos',
      badgeText: 'Capital Trapped',
      badgeType: 'high',
      subtext: 'DSO + DIO - DPO',
      onClick: () => onNavigate('investigate', { question: 'Why did cash decrease?' }),
    });

    // Accounts Receivable
    const arComp = summary.accounts_receivable.comparison;
    const arCard = renderMetricCard({
      label: 'Accounts Receivable (AR)',
      formattedValue: summary.accounts_receivable.formatted_value,
      deltaText: arComp ? `+${arComp.percentage_change}%` : null,
      deltaType: 'neg',
      badgeText: `${summary.overdue_ar_percent.formatted_value} Overdue`,
      badgeType: 'critical',
      subtext: '100% in Apex Retail',
      onClick: () => onNavigate('financials', { tab: 'receivables' }),
    });

    // Gross Margin %
    const gmComp = summary.gross_margin_percent.comparison;
    const gmCard = renderMetricCard({
      label: 'Gross Margin %',
      formattedValue: summary.gross_margin_percent.formatted_value,
      deltaText: gmComp ? `${gmComp.absolute_change} pp` : null,
      deltaType: 'neg',
      badgeText: 'Margin Dilution',
      badgeType: 'medium',
      subtext: 'COGS outpacing sales',
      onClick: () => onNavigate('performance'),
    });

    kpiSection.appendChild(cashCard);
    kpiSection.appendChild(nwcCard);
    kpiSection.appendChild(dsoCard);
    kpiSection.appendChild(cccCard);
    kpiSection.appendChild(arCard);
    kpiSection.appendChild(gmCard);
    container.appendChild(kpiSection);

    // 2. Two-Column Row: 12-Month Cash Trajectory & Runway VS Material Movements & Anomalies
    const splitRow = document.createElement('div');
    splitRow.className = 'split-row';

    // Left Panel: Cash Curve
    const cashPanel = document.createElement('div');
    cashPanel.className = 'panel';

    // Dynamic cash trend points from backend or authoritative sequence
    const cashHistoricalPoints = (cashData && cashData.cash_trend && cashData.cash_trend.length > 0)
      ? cashData.cash_trend
      : [];

    const payables7dVal = summary.upcoming_payables_7d?.value || 0;
    const liquidityShortfall = cashVal - payables7dVal;

    cashPanel.innerHTML = `
      <div class="panel-header">
        <h3 class="panel-title">12-Month Liquid Cash Runway & Trajectory</h3>
        <span class="badge badge-critical">Burn Acceleration</span>
      </div>
      <div style="margin-bottom: 14px;">
        ${cashHistoricalPoints.length > 0 ? renderCashTrendChart(cashHistoricalPoints, 560, 160) : '<div class="text-muted text-center" style="padding: 40px 0;">Cash trend trajectory unavailable</div>'}
      </div>
      <div style="background-color: var(--color-danger-bg); border: 1px solid var(--color-danger-border); border-radius: var(--radius-sm); padding: 12px 14px; font-size: 12px; color: var(--color-danger-text);">
        <strong>Imminent 7-Day Cash Deficit:</strong> Liquid reserves of <strong>${summary.cash_position.formatted_value}</strong> face immediate payable obligations of <strong>${summary.upcoming_payables_7d.formatted_value}</strong> maturing within 7 calendar days (${liquidityShortfall < 0 ? 'shortfall: -₹' + Math.abs(Math.round(liquidityShortfall)).toLocaleString('en-IN') : 'surplus: +₹' + Math.round(liquidityShortfall).toLocaleString('en-IN')}).
      </div>
    `;

    // Right Panel: What Changed & Material Anomalies
    const changePanel = document.createElement('div');
    changePanel.className = 'panel';

    const anomalies = intelReport.anomalies || [];
    const movements = (intelReport.material_changes && intelReport.material_changes.length > 0)
      ? intelReport.material_changes.slice(0, 4)
      : (intelReport.period_changes || []).slice(0, 4);

    const movementsHtml = movements.length > 0 ? movements.map(ch => {
      const isNeg = ch.impact_direction === 'NEGATIVE' || (ch.percentage_change !== undefined && ch.percentage_change < 0);
      const arrow = ch.percentage_change > 0 ? '↑' : (ch.percentage_change < 0 ? '↓' : '→');
      const deltaStr = ch.percentage_change !== null && ch.percentage_change !== undefined
        ? `${arrow} ${ch.percentage_change > 0 ? '+' : ''}${ch.percentage_change.toFixed(1)}%`
        : (ch.absolute_change ? `${ch.absolute_change > 0 ? '+' : ''}${ch.absolute_change}` : '—');
      const valStr = typeof ch.current_value === 'number'
        ? (ch.current_value >= 1000 ? '₹' + ch.current_value.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2}) : ch.current_value.toFixed(1))
        : ch.current_value;
      return `
        <tr>
          <td><strong>${ch.metric_name ? ch.metric_name.replace(/_/g, ' ').toUpperCase() : 'METRIC'}</strong></td>
          <td class="${isNeg ? 'delta-neg' : 'delta-pos'}">${deltaStr}</td>
          <td class="amount">${valStr}</td>
          <td><span class="badge ${ch.severity === 'CRITICAL' ? 'badge-critical' : (ch.severity === 'HIGH' ? 'badge-high' : 'badge-medium')}">${ch.explanation ? ch.explanation.slice(0, 24) : 'Material Movement'}</span></td>
        </tr>
      `;
    }).join('') : `
      <tr>
        <td colspan="4" class="text-center" style="padding: 24px; color: var(--color-text-muted);">No material period-over-period movements recorded.</td>
      </tr>
    `;


    changePanel.innerHTML = `
      <div class="panel-header">
        <h3 class="panel-title">Material Movements & Anomaly Detection</h3>
        <span class="badge badge-medium">Period: ${summary.period}</span>
      </div>
      <div class="table-container">
        <table class="fin-table">
          <thead>
            <tr>
              <th>Metric</th>
              <th>Movement</th>
              <th>Magnitude</th>
              <th>Significance</th>
            </tr>
          </thead>
          <tbody>
            ${movementsHtml}
          </tbody>
        </table>
      </div>
      ${anomalies.length > 0 ? `
        <div style="margin-top: 14px; padding: 10px 12px; background-color: var(--color-warning-bg); border: 1px solid var(--color-warning-border); border-radius: var(--radius-sm); font-size: 12px; color: var(--color-warning-text);">
          <strong>Detected Statistical Anomaly:</strong> ${anomalies[0].reason} (${anomalies[0].deviation_pct}% deviation).
        </div>
      ` : ''}
    `;

    splitRow.appendChild(cashPanel);
    splitRow.appendChild(changePanel);
    container.appendChild(splitRow);

    // 3. Priority Financial Risk Score & Action Items Section (Below)
    const attnSection = document.createElement('section');
    attnSection.className = 'attention-section';
    const totalItems = attention.total_items ?? (attention.items ? attention.items.length : 0);
    const maxScore = attention.items && attention.items.length > 0 
      ? Math.max(...attention.items.map(it => it.priority_score || 0)) 
      : 88;
    
    attnSection.innerHTML = `
      <div class="section-header">
        <h2 class="section-title">
          <span>Priority Financial Risk Items</span>
          <span class="badge badge-critical">${totalItems} Action Items</span>
          <span class="badge badge-high">Risk Score: ${Math.round(maxScore)}/100</span>
          ${attention.total_financial_exposure ? `<span class="badge badge-medium">₹${(attention.total_financial_exposure / 1000).toLocaleString('en-IN', {maximumFractionDigits: 0})}k Total Exposure</span>` : ''}
        </h2>
        <button class="btn btn-secondary btn-sm" id="btn-view-all-cases">
          <span>View Action Plans</span>
        </button>
      </div>
      <div class="attention-grid" id="attn-cards-container"></div>
    `;

    const attnCardsContainer = attnSection.querySelector('#attn-cards-container');
    attention.items.forEach(item => {
      const card = renderAttentionCard(
        item,
        (attnItem) => {
          // Deep link to Investigate
          const questionMap = {
            'CASH_PRESSURE': 'Why did cash decrease?',
            'AR_DETERIORATION': 'Which customers are driving overdue AR?',
            'CUSTOMER_PAYMENT_DETERIORATION': 'Which customers have high revenue but poor payment behaviour?',
            'MARGIN_COMPRESSION': 'Where did gross margin decline?',
            'INVENTORY_BUILDUP': 'Why is inventory increasing?',
          };
          const q = questionMap[attnItem.type] || `Investigate ${attnItem.title}`;
          onNavigate('investigate', { question: q });
        },
        (attnItem) => {
          if (onOpenEvidence) {
            onOpenEvidence({
              title: `${attnItem.title} — Evidence Audit Trail`,
              entity: attnItem.entities && attnItem.entities[0] ? (attnItem.entities[0].entity_name || attnItem.entities[0].name) : 'Subledger',
              evidenceList: attnItem.evidence || [],
              context: {
                title: attnItem.title,
                severity: attnItem.severity,
                financial_impact: attnItem.financial_impact,
                summary: attnItem.summary,
                linked_attention_id: attnItem.id,
                recommended_actions: attnItem.drivers,
              }
            });
          }
        }
      );
      attnCardsContainer.appendChild(card);
    });

    attnSection.querySelector('#btn-view-all-cases')?.addEventListener('click', () => {
      onNavigate('actions');
    });

    container.appendChild(attnSection);

  } catch (err) {
    container.innerHTML = `
      <div style="padding: 40px; text-align: center; color: var(--color-danger-text); background-color: var(--color-danger-bg); border-radius: var(--radius-md); border: 1px solid var(--color-danger-border);">
        <h3 style="font-weight: 600; font-size: 16px;">Unable to load Executive Dashboard</h3>
        <p style="margin-top: 8px; font-size: 13px;">${err.message}</p>
        <button class="btn btn-secondary btn-sm" style="margin-top: 16px;" onclick="window.location.reload()">Retry</button>
      </div>
    `;
  }
}
