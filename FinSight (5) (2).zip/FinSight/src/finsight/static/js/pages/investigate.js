/**
 * Investigate Workspace Page View (AI Assistant)
 * Modeled on the UC15 Controlled AI Assistant pattern:
 * - Prominent suggested investigation cards matching controlled financial intents
 * - Free-text entry underneath for power users
 * - Full multi-turn investigation session thread with audit trail & evidence inspection
 */

import { formatCurrency } from '../utils/format.js';

export async function renderInvestigate(container, api, initialQuestion = null, onNavigate, onOpenEvidence, onCreateCase, initialContext = null) {
  let sessionId = 'sess_' + Date.now();
  let currentContext = initialContext;

  const suggestedQuestions = [
    {
      category: 'Cash & Liquidity Risk',
      question: 'Why did cash decrease?',
      desc: 'Decomposes cash variance into operating disbursements, collections, and working capital shifts',
      q: 'Why did cash decrease?',
    },
    {
      category: 'Working Capital (DSO)',
      question: 'Why is DSO increasing?',
      desc: 'Analyzes Days Sales Outstanding collection lags across customer billing cycles and receivables aging',
      q: 'Why is DSO increasing?',
    },
    {
      category: 'Customer Credit Delinquency',
      question: 'Which customers are driving overdue AR?',
      desc: 'Identifies delinquent customer accounts, concentration risk, and open overdue invoice aging',
      q: 'Which customers are driving overdue AR?',
    },
    {
      category: 'Policy & Escalation (Hybrid)',
      question: 'Why are delinquent accounts overdue and what should finance do according to policy?',
      desc: 'Evaluates customer overdue balances against Collections Policy (COLL-POL-001) thresholds & shipment hold rules',
      q: 'Why are delinquent accounts overdue and what should finance do according to policy?',
    },
    {
      category: 'Policy & Shipment Control',
      question: 'Can we release shipments to high-risk overdue accounts?',
      desc: 'Audits administrative shipment hold rules and credit limit enforcement under COLL-POL-001 Section 3',
      q: 'Can we release shipments to high-risk overdue accounts?',
    },
    {
      category: 'Treasury & Liquidity Policy',
      question: 'Are we compliant with liquidity risk control policy?',
      desc: 'Tests operational cash reserves against internal 7-day Liquidity Coverage Ratio (LIQ-CTRL-001) requirements',
      q: 'Are we compliant with our liquidity control policy given our upcoming payments?',
    },
    {
      category: 'Profitability & Margins',
      question: 'Where did gross margin decline?',
      desc: 'Decomposes product and customer profitability, cost of goods sold, and margin dilution',
      q: 'Where did gross margin decline?',
    },
    {
      category: 'Treasury Obligations',
      question: 'What payments are due in the next 7 days?',
      desc: 'Inspects upcoming vendor commitments, maturity schedule, and short-term disbursement obligations',
      q: 'What payments are due in the next 7 days?',
    },
    {
      category: 'Inventory & Operations',
      question: 'Why is inventory increasing?',
      desc: 'Analyzes inventory asset growth, procurement decoupling, and Days Inventory Outstanding (DIO)',
      q: 'Why is inventory increasing?',
    },
  ];

  container.innerHTML = `
    <!-- 1. Header Banner -->
    <div style="padding: 18px 24px; background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-md); margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
      <div style="display: flex; align-items: center; gap: 12px;">
        <div style="width: 38px; height: 38px; border-radius: 10px; background: linear-gradient(135deg, #2563eb, #1d4ed8); display: flex; align-items: center; justify-content: center; color: #ffffff; font-weight: 800; font-size: 16px; box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);">
          🔍
        </div>
        <div>
          <h2 style="font-size: 17px; font-weight: 700; color: var(--color-text-primary); margin: 0; letter-spacing: -0.01em;">
            Investigate — Financial Investigation Workspace
          </h2>
          <p style="font-size: 12.5px; color: var(--color-text-muted); margin-top: 2px;">
            Financial analysis grounded in verified general ledger &amp; subledger postings.
          </p>
          <div style="font-size: 11.5px; color: var(--color-text-muted); margin-top: 4px; display: flex; align-items: center; gap: 8px;">
            <span class="badge badge-resolved" style="font-size: 10px;">LEDGER VERIFIED</span>
            <span>Source: General Ledger &middot; Verified Calculations &middot; Auditable Lineage</span>
          </div>
        </div>
      </div>

      <div style="display: flex; gap: 10px; align-items: center;">
        <button id="aiNewSessionBtn" class="btn btn-secondary btn-sm" style="display: flex; align-items: center; gap: 6px; font-weight: 600;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
          <span>New Investigation</span>
        </button>
      </div>
    </div>

    <!-- 2. Primary UI: Suggested Question Cards -->
    <div style="margin-bottom: 20px;">
      <div style="font-size: 12.5px; font-weight: 700; color: var(--color-text-secondary); margin-bottom: 10px; display: flex; align-items: center; gap: 6px;">
        <span>💡</span> Suggested Financial Inquiries (Controlled Core Intents):
      </div>
      <div class="sample-intent-grid">
        ${suggestedQuestions.map(item => `
          <button class="sample-intent-card" data-q="${item.q}">
            <div class="card-category">${item.category}</div>
            <div class="card-question">"${item.question}"</div>
            <div class="card-desc">${item.desc}</div>
          </button>
        `).join('')}
      </div>
    </div>

    <!-- Active Investigation Context Banner (Preserves cross-page drilldown context) -->
    ${currentContext ? `
      <div id="activeContextBanner" style="padding: 10px 14px; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: var(--radius-sm); margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 13px;">📌</span>
          <span style="font-size: 12.5px; color: #1e40af; font-weight: 600;">
            Active Investigation Focus:
            <strong>${currentContext.entity || currentContext.name || currentContext.metric || 'Selected Record'}</strong>
            ${currentContext.period ? `&bull; Period: <span class="mono">${currentContext.period}</span>` : ''}
            ${currentContext.source ? `&bull; Origin: <span style="text-transform: capitalize;">${currentContext.source.replace(/_/g, ' ')}</span>` : ''}
          </span>
        </div>
        <button id="btnClearContextBtn" class="btn btn-ghost btn-sm" style="font-size: 11px; padding: 2px 8px; color: #1e40af; cursor: pointer;">Clear Focus ✕</button>
      </div>
    ` : ''}

    <!-- 3. Free-Text Search Area for Power Users -->
    <div class="card" style="background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 16px 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(15, 23, 42, 0.05);">
      <label style="display: block; font-size: 12px; font-weight: 700; color: var(--color-text-secondary); margin-bottom: 6px;">
        Custom Free-Text Query (Power Users):
      </label>
      <div style="display: flex; gap: 10px;">
        <input 
          type="text" 
          id="aiQueryInput" 
          class="investigate-input" 
          placeholder="Ask any financial question (e.g. 'Where is our biggest financial exposure?', 'Why did cash decrease?')..." 
          style="flex: 1;"
          value="${initialQuestion || ''}"
        />
        <button id="aiSubmitBtn" class="btn btn-primary" style="padding: 9px 20px; font-weight: 700; font-size: 13px; cursor: pointer;">
          Investigate &rarr;
        </button>
      </div>
    </div>

    <!-- 4. Multi-Turn Investigation Thread Container -->
    <div id="aiThreadContainer">
      <div id="aiEmptyPlaceholder" style="padding: 36px 20px; background: var(--color-surface-subtle); border: 1px dashed var(--color-border); border-radius: var(--radius-md); text-align: center; color: var(--color-text-muted); font-size: 13px;">
        Select any suggested question above or type a custom query to start financial AI investigation.
      </div>
    </div>
  `;

  const queryInput = container.querySelector('#aiQueryInput');
  const clearContextBtn = container.querySelector('#btnClearContextBtn');
  clearContextBtn?.addEventListener('click', () => {
    currentContext = null;
    container.querySelector('#activeContextBanner')?.remove();
  });
  const submitBtn = container.querySelector('#aiSubmitBtn');
  const newSessionBtn = container.querySelector('#aiNewSessionBtn');
  const threadContainer = container.querySelector('#aiThreadContainer');

  // Bind Suggested Cards
  container.querySelectorAll('.sample-intent-card').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.getAttribute('data-q');
      queryInput.value = q;
      currentContext = null;
      runInvestigation(q, null);
    });
  });

  // Bind Submit Button & Enter Key
  submitBtn.addEventListener('click', () => {
    const q = queryInput.value.trim();
    if (q) runInvestigation(q, currentContext);
  });

  queryInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const q = queryInput.value.trim();
      if (q) runInvestigation(q, currentContext);
    }
  });

  // Bind New Session
  newSessionBtn.addEventListener('click', () => {
    sessionId = 'sess_' + Date.now();
    currentContext = null;
    queryInput.value = '';
    threadContainer.innerHTML = `
      <div id="aiEmptyPlaceholder" style="padding: 36px 20px; background: var(--color-surface-subtle); border: 1px dashed var(--color-border); border-radius: var(--radius-md); text-align: center; color: var(--color-text-muted); font-size: 13px;">
        Session initialized (<strong>${sessionId}</strong>). Select a suggested question above or type a custom query.
      </div>
    `;
  });

  // If initialQuestion provided, execute immediately
  if (initialQuestion) {
    runInvestigation(initialQuestion, initialContext);
  }

  async function runInvestigation(query, context = currentContext) {
    if (!query || !query.trim()) return;

    submitBtn.disabled = true;

    // Remove empty placeholder
    const placeholder = threadContainer.querySelector('#aiEmptyPlaceholder');
    if (placeholder) {
      placeholder.remove();
    }

    const turnId = 'turn_' + Date.now();
    const turnDiv = document.createElement('div');
    turnDiv.id = turnId;
    turnDiv.style.marginBottom = '20px';

    // Loading State
    turnDiv.innerHTML = `
      <div style="padding: 18px 20px; background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-md); box-shadow: 0 1px 3px rgba(15, 23, 42, 0.05);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
          <span style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary);">"${query}"</span>
          <span style="font-size: 11.5px; color: var(--color-blue-primary); font-weight: 600;">Analyzing Layer A Facts...</span>
        </div>
        <div style="padding: 20px; text-align: center;">
          <div class="loading-spinner-ring"></div>
          <p style="font-size: 12px; color: var(--color-text-muted); margin-top: 8px;">
            Evaluating subledgers, working capital variances, and transaction records...
          </p>
        </div>
      </div>
    `;

    threadContainer.prepend(turnDiv);

    try {
      const result = await api.investigate(query, api.currentPeriod, context);
      renderTurnResult(turnDiv, query, result, onOpenEvidence, onCreateCase);
    } catch (err) {
      turnDiv.innerHTML = `
        <div style="padding: 16px 20px; background: var(--color-danger-bg); border: 1px solid var(--color-danger-border); border-radius: var(--radius-md); color: var(--color-danger-text); font-size: 13px;">
          <strong>Investigation query failed:</strong> ${err.message}
        </div>
      `;
    } finally {
      submitBtn.disabled = false;
    }
  }
}

  function renderTurnResult(turnDiv, query, result, onOpenEvidence, onCreateCase) {
    const steps = result.steps || [];
    const findings = result.findings || [];
    const drivers = result.drivers || [];
    const evidence = result.evidence || [];
    const nextSteps = result.suggested_next_steps || [];
    const contributors = result.contributors || [];
    const answerText = result.answer || result.explanation || 'Financial analysis completed based on ledger verification.';

    // Extract financial impact
    const financialEv = evidence.filter(e => e.source_type !== 'POLICY_DOCUMENT');
    let impactAmount = 0;
    if (result.financial_impact !== null && result.financial_impact !== undefined) {
      impactAmount = result.financial_impact;
    } else if (financialEv.length > 0 && typeof financialEv[0].value === 'number') {
      impactAmount = financialEv[0].value;
    } else if (findings.length > 0) {
      for (const f of findings) {
        if (f.raw_value && typeof f.raw_value === 'number') {
          impactAmount = Math.abs(f.raw_value);
          break;
        }
      }
    }

    const impactStr = result.formatted_financial_impact 
      ? result.formatted_financial_impact.replace(/\$/g, '₹') 
      : (impactAmount > 0 ? formatCurrency(impactAmount, 2) : '—');

    // Assessment status & badge color
    const assessmentStatus = result.assessment_status || (result.control_status ? (result.control_status === 'BREACHED' ? 'FAILED' : 'PASSED') : 'REQUIRES REVIEW');
    let assessBadgeClass = 'badge-high';
    if (assessmentStatus === 'PASSED' || assessmentStatus === 'PASS' || assessmentStatus === 'HEALTHY') {
      assessBadgeClass = 'badge-resolved';
    } else if (assessmentStatus === 'FAILED' || assessmentStatus === 'FAIL' || assessmentStatus === 'BREACH' || assessmentStatus === 'BREACHED') {
      assessBadgeClass = 'badge-critical';
    } else if (assessmentStatus === 'INSUFFICIENT DATA' || assessmentStatus === 'INSUFFICIENT_DATA') {
      assessBadgeClass = 'badge-low';
    }

    const primaryDriverText = result.primary_driver || (drivers.length > 0 ? drivers[0] : 'Multi-Factor Ledger Variance');

    turnDiv.innerHTML = `
      <div style="padding: 22px 26px; background: #ffffff; border: 1px solid #bfdbfe; border-radius: var(--radius-md); box-shadow: 0 4px 12px rgba(37, 99, 235, 0.08); margin-bottom: 20px;">
        <!-- Top Query Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; flex-wrap: wrap; gap: 8px; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 16px;">🔍</span>
            <strong style="font-size: 15px; color: var(--color-text-primary);">"${query}"</strong>
          </div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <span class="badge ${assessBadgeClass}" style="font-size: 11px; padding: 3px 8px; font-weight: 700;">
              ${assessmentStatus}
            </span>
            <span style="font-size: 11px; color: #059669; font-weight: 700; background: #ecfdf5; border: 1px solid #a7f3d0; padding: 3px 10px; border-radius: 12px;">
              ✓ Verified Ledger Fact
            </span>
          </div>
        </div>

        <!-- 1. FINDING -->
        <div class="investigation-block" style="margin-bottom: 16px;">
          <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">
            1. Finding
          </div>
          <div style="font-size: 13.5px; line-height: 1.65; color: var(--color-text-primary); background: #f8fafc; border: 1px solid var(--color-border); padding: 14px 18px; border-radius: var(--radius-sm);">
            ${result.finding ? `<div style="font-weight: 700; color: #0f172a; margin-bottom: 8px;">${result.finding}</div>` : ''}
            ${formatMarkdown(answerText)}
          </div>
          ${findings.length > 0 ? `
            <div style="margin-top: 8px; display: flex; flex-direction: column; gap: 4px;">
              ${findings.map(f => `
                <div style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: #334155; padding: 4px 8px; background: #f1f5f9; border-radius: 4px;">
                  <span style="color: #059669; font-weight: 700;">✓</span>
                  <span>${f.claim}</span>
                  ${f.formatted_value ? `<strong class="mono" style="margin-left: auto;">${f.formatted_value}</strong>` : ''}
                </div>
              `).join('')}
            </div>
          ` : ''}
        </div>

        <!-- 2. PRIMARY DRIVER -->
        <div class="investigation-block" style="margin-bottom: 16px;">
          <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">
            2. Primary Driver
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
            <span class="badge badge-critical" style="font-size: 12px; padding: 5px 12px; text-transform: none;">
              <strong>Primary Driver:</strong> ${primaryDriverText}
            </span>
            ${drivers.filter(d => d !== primaryDriverText).map(d => `
              <span class="badge badge-high" style="font-size: 12px; padding: 5px 12px; text-transform: none;">
                ${d}
              </span>
            `).join('')}
          </div>
        </div>

        <!-- 3. FINANCIAL IMPACT -->
        <div class="investigation-block" style="margin-bottom: 16px;">
          <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">
            3. Financial Impact
          </div>
          <div style="background: #fff1f2; border: 1px solid #fecdd3; border-radius: var(--radius-sm); padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div>
              <span style="font-size: 12px; color: #9f1239; font-weight: 600;">Total Quantified Variance Exposure:</span>
              <div style="font-size: 20px; font-weight: 800; color: #e11d48; margin-top: 2px;">
                ${impactStr}
              </div>
            </div>
            <span class="badge badge-critical">Material Variance</span>
          </div>
        </div>

        <!-- 4. SUPPORTING DATA & EVIDENCE -->
        <div class="investigation-block" style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px;">
              4. Supporting Data & Evidence ("Follow the Money")
            </div>
            ${financialEv.length > 0 ? `
              <button class="btn btn-outline btn-sm btn-inspect-evidence" style="font-size: 11px; padding: 2px 8px;">
                Inspect in Drawer &rarr;
              </button>
            ` : ''}
          </div>
          ${financialEv.length > 0 ? `
            <div style="display: flex; flex-wrap: wrap; gap: 8px;">
              ${financialEv.slice(0, 6).map(ev => `
                <div style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 10px; font-size: 11.5px; font-family: var(--font-mono); display: flex; gap: 6px;">
                  <strong style="color: #2563eb;">${ev.source_id}</strong>
                  <span>&bull;</span>
                  <span>${ev.entity || 'Ledger'}</span>
                  ${ev.value ? `<strong style="color: #0f172a;">(${typeof ev.value === 'number' ? formatCurrency(ev.value, 0) : String(ev.value).replace(/\$/g, '₹')})</strong>` : ''}
                </div>
              `).join('')}
            </div>
          ` : `
            <div style="font-size: 12px; color: var(--color-text-muted);">
              Linked to authoritative subledger transaction registers.
            </div>
          `}
        </div>

        <!-- 5. CONTRIBUTORS -->
        <div class="investigation-block" style="margin-bottom: 16px;">
          <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">
            5. Contributors (Segment Attribution)
          </div>
          ${contributors.length > 0 ? `
            <table class="data-table" style="width: 100%; border-collapse: collapse; font-size: 12px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px;">
              <thead>
                <tr style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                  <th style="padding: 6px 10px; text-align: left;">Entity / Dimension</th>
                  <th style="padding: 6px 10px; text-align: left;">Type</th>
                  <th style="padding: 6px 10px; text-align: right;">Amount</th>
                  <th style="padding: 6px 10px; text-align: right;">Share / Exposure</th>
                  <th style="padding: 6px 10px; text-align: left;">Detail</th>
                </tr>
              </thead>
              <tbody>
                ${contributors.map(c => `
                  <tr style="border-bottom: 1px solid #f1f5f9;">
                    <td style="padding: 6px 10px;">
                      <strong>${c.entity_name || c.name || 'Entity'}</strong>
                      ${c.entity_id ? `<span style="font-size: 11px; color: #64748b; margin-left: 4px;">(${c.entity_id})</span>` : ''}
                    </td>
                    <td style="padding: 6px 10px;">
                      <span class="badge badge-outline" style="font-size: 10px;">${c.type || 'Customer'}</span>
                    </td>
                    <td style="padding: 6px 10px; text-align: right; font-weight: 700;">
                      ${c.formatted_amount ? c.formatted_amount.replace(/\$/g, '₹') : (c.amount ? formatCurrency(c.amount) : '—')}
                    </td>
                    <td style="padding: 6px 10px; text-align: right; color: #dc2626; font-weight: 600;">
                      ${c.share ? c.share.toFixed(1) + '%' : (c.formatted_amount || '100%')}
                    </td>
                    <td style="padding: 6px 10px; font-size: 11.5px; color: #475569;">
                      ${c.notes || c.details || 'Identified material contributor'}
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          ` : `
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 14px; font-size: 12px; color: #475569;">
              Multi-account general ledger variance identified across primary working capital balance sheets.
            </div>
          `}
        </div>

        <!-- 6. POLICY / CONTROL CONTEXT -->
        <div class="investigation-block" style="margin-bottom: 16px;">
          <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">
            6. Policy / Control Context
          </div>
          ${result.control_id ? `
            <div style="background: #f5f3ff; border: 1px solid #ddd6fe; border-radius: 6px; padding: 10px 14px; margin-bottom: 8px;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                <div>
                  <span class="badge" style="background:#ede9fe; color:#6b21a8; font-size:10px; font-weight:700;">${result.control_id}</span>
                  <strong style="margin-left: 6px; font-size: 12.5px; color: #1e1b4b;">${result.control_name || 'Governed Financial Control'}</strong>
                </div>
                <span class="badge ${result.control_status === 'BREACHED' ? 'badge-critical' : 'badge-resolved'}" style="font-size: 10px;">
                  ${result.control_status || 'EVALUATED'}
                </span>
              </div>
              ${result.policy_reference ? `
                <div style="font-size: 11.5px; color: #5b21b6; margin-top: 2px;">
                  Policy Document: <strong>${result.policy_reference}</strong>
                </div>
              ` : ''}
            </div>
          ` : ''}
          ${result.knowledge_sources && result.knowledge_sources.length > 0 ? `
            <div style="display: flex; flex-direction: column; gap: 8px;">
              ${result.knowledge_sources.map(src => `
                <div style="background: #f5f3ff; border: 1px solid #ddd6fe; border-radius: 6px; padding: 10px 14px;">
                  <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                    <div>
                      <span class="badge" style="background:#ede9fe; color:#6b21a8; font-size:10px; font-weight:700;">${src.document_id}</span>
                      <strong style="margin-left: 6px; font-size: 12.5px; color: #1e1b4b;">${src.title}</strong>
                    </div>
                    <span style="font-size: 11px; color: #6b21a8;">Section: ${src.section}</span>
                  </div>
                  <div style="font-size: 12px; color: #475569; font-style: italic; line-height: 1.4;">
                    "${src.excerpt}"
                  </div>
                </div>
              `).join('')}
            </div>
          ` : (result.control_id ? '' : `
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 14px; font-size: 12px; color: #475569;">
              Evaluated against internal financial controls (LIQ-CTRL-001, COLL-POL-001, REV-REC-001).
            </div>
          `)}
        </div>

        <!-- 7. ASSESSMENT -->
        <div class="investigation-block" style="margin-bottom: 16px;">
          <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">
            7. Assessment
          </div>
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px 14px;">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
              <span class="badge ${assessBadgeClass}" style="font-size: 11px; padding: 3px 8px; font-weight: 700;">
                ${assessmentStatus}
              </span>
              <strong style="font-size: 12.5px; color: #1e293b;">
                ${assessmentStatus === 'FAILED' ? 'Control Condition Breached' : (assessmentStatus === 'REQUIRES REVIEW' ? 'Actionable Operating Variance' : 'Operating Within Normal Tolerances')}
              </strong>
            </div>
            <div style="font-size: 12.5px; color: #475569; line-height: 1.5;">
              ${result.assessment || 'Grounded policy evaluation against current financial metrics confirms condition requires executive review.'}
            </div>
          </div>
        </div>

        <!-- 8. RECOMMENDED FOLLOW-UP -->
        <div class="investigation-block" style="margin-bottom: 20px;">
          <div class="investigation-block-title" style="font-size: 11.5px; font-weight: 800; color: #1e40af; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">
            8. Recommended Follow-Up
          </div>
          ${nextSteps.length > 0 ? `
            <ul style="margin: 0; padding-left: 20px; font-size: 12.5px; color: var(--color-text-secondary); display: flex; flex-direction: column; gap: 5px;">
              ${nextSteps.map(step => `<li><strong>${step}</strong></li>`).join('')}
            </ul>
          ` : `
            <p style="font-size: 12.5px; color: var(--color-text-secondary); margin: 0;">
              Initiate formal remediation case and schedule counterparty credit/disbursement review.
            </p>
          `}
        </div>

        <!-- 9. CREATE ACTION -->
        <div style="padding-top: 14px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
          <div style="font-size: 11.5px; color: var(--color-text-muted);">
            Audit Steps: <strong>${steps.length} Ledger Queries</strong> &middot; <strong style="color: #059669;">Verified Execution</strong>
          </div>
          <button class="btn btn-primary btn-sm btn-create-action-from-inv" style="font-weight: 700; padding: 6px 16px;">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
            <span style="margin-left: 4px;">Create Action</span>
          </button>
        </div>
      </div>
    `;

    // Bind Create Action button
    turnDiv.querySelector('.btn-create-action-from-inv')?.addEventListener('click', () => {
      if (onCreateCase) {
        const entityName = currentContext?.entity || currentContext?.name || result.suggested_action?.entity || financialEv[0]?.entity || 'Finance';
        if (result.suggested_action) {
          onCreateCase({
            ...result.suggested_action,
            entity: result.suggested_action.entity || entityName,
          });
        } else {
          onCreateCase({
            title: `Action: ${query}`,
            entity: entityName,
            summary: `${answerText.slice(0, 220)}...`,
            category: query.toLowerCase().includes('cash') ? 'CASH' : (query.toLowerCase().includes('dso') || query.toLowerCase().includes('ar') ? 'RECEIVABLES' : 'GENERAL'),
            financial_impact: impactAmount || 0,
            suggested_actions: nextSteps,
            evidence_ids: financialEv.map(e => e.source_id),
          });
        }
      }
    });

    // Bind inspect evidence drawer button
    turnDiv.querySelector('.btn-inspect-evidence')?.addEventListener('click', () => {
      if (onOpenEvidence) {
        onOpenEvidence({
          title: `Evidence: ${query}`,
          entity: financialEv[0]?.entity || 'Subledger',
          evidenceList: financialEv,
          context: {
            title: query,
            findings: findings,
            drivers: drivers,
          }
        });
      }
    });
  }

function formatMarkdown(text) {
  if (!text) return '';
  let html = text
    .replace(/^### (.*$)/gim, '<h3 style="font-size:14px; font-weight:700; color:var(--color-text-primary); margin:10px 0 4px 0;">$1</h3>')
    .replace(/^#### (.*$)/gim, '<h4 style="font-size:12px; font-weight:700; color:var(--color-blue-primary); margin:8px 0 4px 0; text-transform:uppercase; letter-spacing:0.5px;">$1</h4>')
    .replace(/\*\*(.*?)\*\*/gim, '<strong style="color:var(--color-text-primary); font-weight:700;">$1</strong>')
    .replace(/\*(.*?)\*/gim, '<em>$1</em>')
    .replace(/`([^`]+)`/gim, '<code style="font-family:var(--font-mono); background:var(--color-surface-subtle); color:var(--color-text-primary); padding:2px 6px; border-radius:4px; font-size:12px; border:1px solid var(--color-border);">$1</code>')
    .replace(/^- (.*$)/gim, '<div style="margin:4px 0 4px 8px; display:flex; gap:6px;"><span>&bull;</span><span>$1</span></div>')
    .replace(/\n\n/gim, '<div style="height:8px;"></div>')
    .replace(/\n/gim, '<br>');
  return html;
}
