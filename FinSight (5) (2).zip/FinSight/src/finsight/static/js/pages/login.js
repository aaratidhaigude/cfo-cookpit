/**
 * FinSight Executive Login View (Sprint 11)
 * Split-screen layout:
 * - Left: FinSight brand & deterministic financial intelligence visual
 * - Right: Clean login card with prefilled dev/demo credentials
 */

import { auth } from '../services/auth.js';

export function renderLogin(container, api, onLoginSuccess) {
  container.innerHTML = `
    <div class="login-wrapper">
      <!-- Left: Minimalist Executive Brand Panel -->
      <div class="login-brand-panel">
        <div class="login-brand-content">
          <div class="login-logo-badge">
            <span class="login-logo-icon">FS</span>
            <div>
              <h1 class="login-brand-title">FinSight</h1>
              <span class="login-brand-tag">Financial Analytics &amp; Control</span>
            </div>
          </div>

          <p class="login-brand-tagline">
            Accurate financial analysis and real-time ledger reporting for finance leadership.
          </p>
        </div>
      </div>

      <!-- Right: Minimalist Executive Login Card -->
      <div class="login-form-panel">
        <div class="login-card">
          <div class="login-card-header">
            <h3>Executive Sign In</h3>
            <p>Enter your corporate credentials to access FinSight.</p>
          </div>

          <div id="login-error-alert" class="login-error" style="display: none;"></div>

          <form id="login-form" autocomplete="on">
            <div class="form-group">
              <label for="login-username">User ID / Username</label>
              <input
                type="text"
                id="login-username"
                name="username"
                class="form-input"
                placeholder="e.g. admin, manager, analyst"
                required
                autocomplete="username"
              />
            </div>

            <div class="form-group">
              <label for="login-password">Password</label>
              <input
                type="password"
                id="login-password"
                name="password"
                class="form-input"
                placeholder="••••••••"
                required
                autocomplete="current-password"
              />
            </div>

            <button type="submit" id="login-submit-btn" class="btn btn-primary login-btn">
              <span>Sign In</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
            </button>
          </form>

          <!-- Quick 1-Click Demo Credentials Helper (Gated by FINSIGHT_ENABLE_DEMO_CREDENTIALS) -->
          <div id="login-demo-box" class="login-demo-box" style="display: none;">
            <div class="login-demo-title">
              <span>Quick Demo Access</span>
              <span class="demo-badge">1-Click Sign In</span>
            </div>
            <p class="login-demo-subtext">Click any role to prefill credentials:</p>
            <div class="demo-chips-grid">
              <button type="button" class="demo-chip" data-user="admin" data-pwd="demo123">
                <span class="demo-role-pill role-admin">ADMIN</span>
                <strong>admin</strong>
                <span class="demo-pwd-hint">demo123</span>
              </button>
              <button type="button" class="demo-chip" data-user="manager" data-pwd="demo123">
                <span class="demo-role-pill role-mgr">MANAGER</span>
                <strong>manager</strong>
                <span class="demo-pwd-hint">demo123</span>
              </button>
              <button type="button" class="demo-chip" data-user="analyst" data-pwd="demo123">
                <span class="demo-role-pill role-anl">ANALYST</span>
                <strong>analyst</strong>
                <span class="demo-pwd-hint">demo123</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  const form = container.querySelector('#login-form');
  const userInput = container.querySelector('#login-username');
  const pwdInput = container.querySelector('#login-password');
  const submitBtn = container.querySelector('#login-submit-btn');
  const errorAlert = container.querySelector('#login-error-alert');
  const demoBox = container.querySelector('#login-demo-box');

  // Check public config to determine if demo credentials helper should be displayed
  fetch('/api/public/config')
    .then(res => res.ok ? res.json() : null)
    .then(cfg => {
      if (cfg && cfg.enable_demo_credentials) {
        if (demoBox) demoBox.style.display = 'block';
      }
    })
    .catch(() => {
      // Keep hidden on network error
    });

  // Interactive Demo chip auto-fill
  container.querySelectorAll('.demo-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      userInput.value = chip.getAttribute('data-user');
      pwdInput.value = chip.getAttribute('data-pwd');
      errorAlert.style.display = 'none';
      userInput.focus();
    });
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorAlert.style.display = 'none';
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<span>Signing In...</span>`;

    try {
      const username = userInput.value.trim();
      const password = pwdInput.value;
      const resp = await api.login(username, password);

      auth.setSession(resp.token, resp.user);
      if (onLoginSuccess) {
        onLoginSuccess(resp.user);
      }
    } catch (err) {
      errorAlert.textContent = err.message || 'Authentication failed. Please verify credentials.';
      errorAlert.style.display = 'block';
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = `
        <span>Sign In</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
      `;
    }
  });
}
