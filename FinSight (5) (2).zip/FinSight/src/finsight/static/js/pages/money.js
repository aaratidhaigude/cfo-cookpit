import { exportToCsv } from '../utils/exportCsv.js';
import { formatCurrency } from '../utils/format.js';

export async function renderMoney(container, api, initialTab = 'cash', onNavigate, onOpenEvidence) {
  let activeTab = initialTab;

  container.innerHTML = `
    <div style="display: flex; justify-content: center; align-items: center; padding: 60px;">
      <div style="color: var(--color-text-muted); font-size: 14px;">Loading financial subledger data...</div>
    </div>
  `;

  try {
    const [cashData, arData, apData] = await Promise.all([
      api.getCash(),
      api.getReceivables(),
      api.getPayables(),
    ]);

    function render() {
      container.innerHTML = `
        <div class="tabs-nav">
          <button class="tab-btn ${activeTab === 'cash' ? 'active' : ''}" data-tab="cash">
            Cash Position & Runway
          </button>
          <button class="tab-btn ${activeTab === 'receivables' ? 'active' : ''}" data-tab="receivables">
            Accounts Receivable & Aging (${arData.overdue_ar_percent.formatted_value} Overdue)
          </button>
          <button class="tab-btn ${activeTab === 'payables' ? 'active' : ''}" data-tab="payables">
            Payables & 7-Day Commitments (${apData.upcoming_payables_7d.formatted_value} Due)
          </button>
        </div>

        <div id="money-tab-content"></div>
      `;

      // Tab switcher handlers
      container.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          activeTab = btn.getAttribute('data-tab');
          render();
        });
      });

      const tabContainer = container.querySelector('#money-tab-content');

      if (activeTab === 'cash') {
        renderCashTab(tabContainer, cashData, arData, apData, api, onNavigate);
      } else if (activeTab === 'receivables') {
        renderReceivablesTab(tabContainer, arData, onNavigate, onOpenEvidence);
      } else if (activeTab === 'payables') {
        renderPayablesTab(tabContainer, apData, onNavigate, onOpenEvidence);
      }
    }

    render();

  } catch (err) {
    container.innerHTML = `
      <div style="padding: 30px; color: var(--color-danger-text); background-color: var(--color-danger-bg); border-radius: var(--radius-md);">
        Error loading Money view: ${err.message}
      </div>
    `;
  }
}

async function renderCashTab(container, cashData, arData, apData, api, onNavigate) {
  const cashVal = cashData.cash_position.value || 0;
  const accounts = (cashData.bank_accounts_breakdown && cashData.bank_accounts_breakdown.length > 0)
    ? cashData.bank_accounts_breakdown
    : ((cashData.cash_position.dimensions && cashData.cash_position.dimensions.bank_accounts) || []);

  const upcoming7d = apData.upcoming_payables_7d.value || 0;
  const coverageRatio = upcoming7d > 0 ? (cashVal / upcoming7d).toFixed(2) : '1.00';
  const cashShortfall = cashVal - upcoming7d;
  const isDeficit = cashShortfall < 0;

  // Forecast state
  let currentHorizon = 30;
  let currentScenario = 'BASE';
  let forecast = null;
  let comparison = null;

  try {
    [forecast, comparison] = await Promise.all([
      api.getCashForecast(currentHorizon, currentScenario),
      api.compareForecastScenarios(currentHorizon),
    ]);
  } catch (e) {
    console.error('Failed to load initial cash forecast:', e);
  }

  function renderView() {
    const lcr7d = forecast?.liquidity_indicators?.lcr_7d ?? coverageRatio;
    const isBreach = forecast?.liquidity_indicators?.policy_breach_detected ?? (lcr7d < 0.75);

    container.innerHTML = `
      <div class="split-row">
        <!-- Left: Accounts Breakdown -->
        <div class="panel">
          <div class="panel-header">
            <h3 class="panel-title">Liquid Cash Accounts Reconciliation</h3>
            <div style="display: flex; align-items: center; gap: 8px;">
              <button id="btn-export-cash-csv" class="btn btn-outline btn-sm" style="display: flex; align-items: center; gap: 4px; padding: 3px 8px; font-size: 11.5px;">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                <span>Export CSV</span>
              </button>
              <span class="badge badge-critical">Total: ${cashData.cash_position.formatted_value}</span>
            </div>
          </div>
          <table class="fin-table">
            <thead>
              <tr>
                <th>Account Name</th>
                <th>GL Account</th>
                <th class="amount">Balance</th>
                <th class="amount">Share</th>
              </tr>
            </thead>
            <tbody>
              ${accounts.map(acc => `
                <tr>
                  <td><strong>${acc.account_name || acc.name}</strong></td>
                  <td><code class="mono">${acc.gl_account || '10xx'}</code></td>
                  <td class="amount">₹${(acc.balance || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                  <td class="amount">${cashVal > 0 ? ((acc.balance / cashVal) * 100).toFixed(1) : 0}%</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div style="margin-top: 14px; font-size: 12px; color: var(--color-text-muted); display: flex; justify-content: space-between; align-items: center;">
            <span>ℹ️ All bank balances reconcile directly to canonical general ledger cash accounts (GL 101000 + 102000).</span>
            <button class="btn btn-secondary btn-sm" onclick="window.openTrustDrawer && window.openTrustDrawer()" style="padding: 2px 8px; font-size: 11px;">
              View Reconciliation Tie →
            </button>
          </div>
        </div>

        <!-- Right: Liquidity Stress Analysis -->
        <div class="panel">
          <div class="panel-header">
            <h3 class="panel-title">7-Day Imminent Liquidity Coverage</h3>
            <span class="badge ${isDeficit ? 'badge-critical' : 'badge-resolved'}">Coverage: ${coverageRatio}x (${isDeficit ? 'Deficit' : 'Surplus'})</span>
          </div>
          <div style="display: flex; flex-direction: column; gap: 12px;">
            <div style="padding: 12px; background-color: var(--color-surface-subtle); border-radius: var(--radius-sm); border: 1px solid var(--color-border); font-size: 12.5px;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                <span>Available Liquid Cash:</span>
                <strong class="num">${cashData.cash_position.formatted_value}</strong>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 6px; color: var(--color-danger-text);">
                <span>Vendor Obligations Due in 7 Days:</span>
                <strong class="num">-${apData.upcoming_payables_7d.formatted_value}</strong>
              </div>
              <div style="height: 1px; background-color: var(--color-border); margin: 6px 0;"></div>
              <div style="display: flex; justify-content: space-between; font-weight: 700; color: ${isDeficit ? '#dc2626' : '#16a34a'};">
                <span>${isDeficit ? 'Immediate Cash Shortfall:' : 'Immediate Net Buffer:'}</span>
                <strong class="num">${isDeficit ? '-' : '+'}${formatCurrency(Math.abs(cashShortfall))}</strong>
              </div>
            </div>

            <div style="font-size: 12.5px; color: var(--color-text-secondary); line-height: 1.5;">
              <strong>Root Cause Analysis:</strong> Over <strong>${arData.overdue_ar?.formatted_value || '₹1.044M'}</strong> of operating capital is trapped in overdue customer receivables with Apex Retail Group, while input procurement costs accelerated in August and September.
            </div>

            <button class="btn btn-primary" id="btn-investigate-cash" style="align-self: flex-start; margin-top: 6px;">
              <span>Launch AI Cash Investigation</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Phase 8: Cash Outlook & Scenario Intelligence Panel -->
      <div class="panel" style="margin-top: 24px;">
        <div class="panel-header" style="flex-wrap: wrap; gap: 12px;">
          <div>
            <h3 class="panel-title" style="display: flex; align-items: center; gap: 8px;">
              <span>Cash Flow Forecast &amp; Scenario Projections</span>
              <span class="badge badge-resolved" style="font-size: 11px;">Subledger-Grounded</span>
            </h3>
            <p style="font-size: 12px; color: var(--color-text-muted); margin-top: 2px;">
              30/60/90-day trajectory based on open AR/AP schedules, recurring OPEX, and governing liquidity controls.
            </p>
          </div>

          <!-- Controls: Horizon and Scenario -->
          <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
            <!-- Horizon Selector -->
            <div style="display: flex; align-items: center; background: var(--color-surface-subtle); border-radius: var(--radius-sm); border: 1px solid var(--color-border); padding: 2px;">
              <button class="btn btn-sm btn-horizon ${currentHorizon === 30 ? 'btn-primary' : 'btn-outline'}" data-horizon="30" style="padding: 3px 9px; font-size: 11.5px; border: none;">30 Days</button>
              <button class="btn btn-sm btn-horizon ${currentHorizon === 60 ? 'btn-primary' : 'btn-outline'}" data-horizon="60" style="padding: 3px 9px; font-size: 11.5px; border: none;">60 Days</button>
              <button class="btn btn-sm btn-horizon ${currentHorizon === 90 ? 'btn-primary' : 'btn-outline'}" data-horizon="90" style="padding: 3px 9px; font-size: 11.5px; border: none;">90 Days</button>
            </div>

            <!-- Scenario Selector -->
            <div style="display: flex; align-items: center; background: var(--color-surface-subtle); border-radius: var(--radius-sm); border: 1px solid var(--color-border); padding: 2px;">
              <button class="btn btn-sm btn-scenario ${currentScenario === 'BASE' ? 'btn-primary' : 'btn-outline'}" data-scenario="BASE" style="padding: 3px 9px; font-size: 11.5px; border: none;">Base</button>
              <button class="btn btn-sm btn-scenario ${currentScenario === 'CONSERVATIVE' ? 'btn-primary' : 'btn-outline'}" data-scenario="CONSERVATIVE" style="padding: 3px 9px; font-size: 11.5px; border: none;">Conservative</button>
              <button class="btn btn-sm btn-scenario ${currentScenario === 'IMPROVED_COLLECTIONS' ? 'btn-primary' : 'btn-outline'}" data-scenario="IMPROVED_COLLECTIONS" style="padding: 3px 9px; font-size: 11.5px; border: none;">Improved Collections</button>
            </div>
          </div>
        </div>

        ${isBreach ? `
          <div style="margin-bottom: 18px; padding: 12px 16px; background-color: var(--color-danger-bg, #fef2f2); border: 1px solid var(--color-danger-border, #fecaca); border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span class="badge badge-critical" style="font-weight: 700;">LIQ-CTRL-001 BREACH</span>
              <span style="font-size: 12.5px; color: var(--color-danger-text, #991b1b);">
                <strong>7-Day Liquidity Ratio (${lcr7d}x)</strong> is below the emergency threshold of <strong>0.75x</strong> (₹1,377,000 due vs ₹813,750 cash).
              </span>
            </div>
            <button class="btn btn-secondary btn-sm" id="btn-remediate-liq" style="font-size: 11.5px;">View Case CASE-2026-002 →</button>
          </div>
        ` : ''}

        <!-- KPI Forecast Summary Row -->
        <div class="kpi-grid" style="margin-bottom: 20px;">
          <div class="metric-card">
            <span class="metric-label">Starting Cash Balance</span>
            <div class="metric-value num">${formatCurrency(forecast?.starting_cash ?? 0, 2)}</div>
            <div class="metric-comparison"><span class="metric-subtext">As of September 30, 2026</span></div>
          </div>
          <div class="metric-card">
            <span class="metric-label">Expected Collections (${currentHorizon}d)</span>
            <div class="metric-value num" style="color: #16a34a;">+${formatCurrency(forecast?.expected_collections ?? 0, 2)}</div>
            <div class="metric-comparison"><span class="metric-subtext">Scenario: ${currentScenario}</span></div>
          </div>
          <div class="metric-card">
            <span class="metric-label">Expected Payables & OPEX</span>
            <div class="metric-value num" style="color: #dc2626;">-${formatCurrency(((forecast?.expected_payables || 0) + (forecast?.recurring_outflows || 0)), 2)}</div>
            <div class="metric-comparison"><span class="metric-subtext">AP: ${formatCurrency(forecast?.expected_payables ?? 0, 0)} | OPEX: ${formatCurrency(forecast?.recurring_outflows ?? 0, 0)}</span></div>
          </div>
          <div class="metric-card">
            <span class="metric-label">Projected Ending Cash (${currentHorizon}d)</span>
            <div class="metric-value num" style="color: ${(forecast?.projected_cash ?? 0) >= (forecast?.starting_cash ?? 0) ? '#16a34a' : '#d97706'};">
              ${formatCurrency(forecast?.projected_cash ?? 0, 2)}
            </div>
            <div class="metric-comparison">
              <span class="metric-subtext">Range: ${formatCurrency(forecast?.lower_bound ?? 0, 0)} – ${formatCurrency(forecast?.upper_bound ?? 0, 0)}</span>
            </div>
          </div>
        </div>

        <!-- Weekly Trajectory Table -->
        <div style="margin-bottom: 24px;">
          <h4 style="font-size: 13px; font-weight: 600; margin-bottom: 10px; color: var(--color-text-primary);">
            Weekly Cash Trajectory (${currentHorizon}-Day Horizon)
          </h4>
          <div class="table-container">
            <table class="fin-table">
              <thead>
                <tr>
                  <th>Week #</th>
                  <th>Date Window</th>
                  <th class="amount">Starting Cash</th>
                  <th class="amount">Collections</th>
                  <th class="amount">Vendor AP</th>
                  <th class="amount">Recurring OPEX</th>
                  <th class="amount">Net Flow</th>
                  <th class="amount">Ending Cash</th>
                  <th>LCR Ratio</th>
                </tr>
              </thead>
              <tbody>
                ${(forecast?.weekly_breakdown || []).map(w => {
                  const isWeek1Dip = w.week_number === 1;
                  return `
                    <tr style="${isWeek1Dip ? 'background-color: #fef2f2;' : ''}">
                      <td><strong>Week ${w.week_number}</strong> ${isWeek1Dip ? '<span class="badge badge-critical" style="font-size: 10px;">AP Squeeze</span>' : ''}</td>
                      <td><code class="mono" style="font-size: 11px;">${w.week_start_date} to ${w.week_end_date}</code></td>
                      <td class="amount num">₹${w.starting_cash.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      <td class="amount num delta-pos">+₹${w.collections.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      <td class="amount num delta-neg">-₹${w.disbursements.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      <td class="amount num delta-neg">-₹${w.recurring_outflows.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      <td class="amount num ${w.net_cash_flow >= 0 ? 'delta-pos' : 'delta-neg'}">
                        ${w.net_cash_flow >= 0 ? '+' : ''}₹${w.net_cash_flow.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td class="amount num" style="font-weight: 700; color: ${w.ending_cash < 500000 ? '#dc2626' : 'var(--color-text-primary)'};">
                        ₹${w.ending_cash.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td>
                        <span class="badge ${w.lcr_ratio < 0.75 ? 'badge-critical' : w.lcr_ratio < 1.0 ? 'badge-high' : 'badge-resolved'}">
                          ${w.lcr_ratio.toFixed(2)}x
                        </span>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Scenario Comparison Matrix -->
        <div>
          <h4 style="font-size: 13px; font-weight: 600; margin-bottom: 10px; color: var(--color-text-primary);">
            Multi-Scenario Sensitivity Comparison (${currentHorizon}-Day Horizon)
          </h4>
          <div class="table-container">
            <table class="fin-table">
              <thead>
                <tr>
                  <th>Scenario</th>
                  <th class="amount">Expected Collections</th>
                  <th class="amount">Expected Payables</th>
                  <th class="amount">Projected Ending Cash</th>
                  <th class="amount">Net Change vs Base</th>
                  <th>7-Day LCR</th>
                  <th>Liquidity Status</th>
                </tr>
              </thead>
              <tbody>
                ${(Array.isArray(comparison?.scenarios) ? comparison.scenarios : Object.values(comparison?.scenarios || {})).map(sc => {
                  const scenName = typeof sc.scenario === 'object' ? sc.scenario?.value : sc.scenario;
                  const isCurrent = scenName === currentScenario;
                  const baseCash = (comparison?.scenarios?.BASE || comparison?.scenarios?.base)?.projected_cash ?? sc.projected_cash;
                  const variance = Math.round((sc.projected_cash - baseCash) * 100) / 100;
                  return `
                    <tr style="${isCurrent ? 'background-color: var(--color-surface-subtle); font-weight: 600;' : ''}">
                      <td>
                        <strong>${scenName}</strong>
                        ${isCurrent ? '<span class="badge badge-medium" style="font-size: 10px; margin-left: 6px;">Active</span>' : ''}
                      </td>
                      <td class="amount num">+${formatCurrency(sc.expected_collections ?? 0, 2)}</td>
                      <td class="amount num">-${formatCurrency(sc.expected_payables ?? 0, 2)}</td>
                      <td class="amount num" style="font-weight: 700;">${formatCurrency(sc.projected_cash ?? 0, 2)}</td>
                      <td class="amount num ${variance >= 0 ? 'delta-pos' : 'delta-neg'}">
                        ${variance > 0 ? '+' : ''}${formatCurrency(variance, 2)}
                      </td>
                      <td>
                        <span class="badge ${sc.liquidity_indicators?.lcr_7d < 0.75 ? 'badge-critical' : 'badge-resolved'}">
                          ${(sc.liquidity_indicators?.lcr_7d ?? 0).toFixed(2)}x
                        </span>
                      </td>
                      <td>
                        <span class="badge ${sc.liquidity_indicators?.policy_breach_detected ? 'badge-critical' : 'badge-resolved'}">
                          ${sc.liquidity_indicators?.policy_breach_detected ? 'Breach (Week 1)' : 'Compliant'}
                        </span>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Assumptions & AI CTA -->
        <div style="margin-top: 18px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; padding: 12px 14px; background: var(--color-surface-subtle); border-radius: var(--radius-sm); border: 1px solid var(--color-border);">
          <div style="font-size: 11.5px; color: var(--color-text-secondary); max-width: 650px;">
            <strong>Underlying Assumptions:</strong> Base scenario applies 95% collection rate on current AR (₹1.843M) and ₹500k restructuring tranche from Apex; Conservative omits Apex overdue collection entirely (₹0 from Apex); Improved collections models 100% current AR plus accelerated Apex recovery (₹750k).
          </div>
          <button class="btn btn-primary btn-sm" id="btn-investigate-outlook" style="white-space: nowrap;">
            <span>Investigate Outlook with AI →</span>
          </button>
        </div>
      </div>
    `;

    // Event Listeners for Cash Tab
    container.querySelector('#btn-export-cash-csv')?.addEventListener('click', () => {
      exportToCsv('finsight_cash_accounts.csv', [
        { label: 'Account Name', key: 'name' },
        { label: 'Balance (₹)', key: 'balance' }
      ], accounts);
    });

    container.querySelector('#btn-investigate-cash')?.addEventListener('click', () => {
      onNavigate('investigate', { question: 'Why did cash decrease?' });
    });

    container.querySelector('#btn-investigate-outlook')?.addEventListener('click', () => {
      onNavigate('investigate', { question: 'What is our cash outlook and 30-day liquidity forecast under the base scenario?' });
    });

    container.querySelector('#btn-remediate-liq')?.addEventListener('click', () => {
      onNavigate('actions');
    });

    // Horizon buttons
    container.querySelectorAll('.btn-horizon').forEach(btn => {
      btn.addEventListener('click', async () => {
        const h = parseInt(btn.getAttribute('data-horizon'), 10);
        if (h !== currentHorizon) {
          currentHorizon = h;
          try {
            [forecast, comparison] = await Promise.all([
              api.getCashForecast(currentHorizon, currentScenario),
              api.compareForecastScenarios(currentHorizon),
            ]);
            renderView();
          } catch (e) {
            console.error('Failed to update forecast horizon:', e);
          }
        }
      });
    });

    // Scenario buttons
    container.querySelectorAll('.btn-scenario').forEach(btn => {
      btn.addEventListener('click', async () => {
        const sc = btn.getAttribute('data-scenario');
        if (sc !== currentScenario) {
          currentScenario = sc;
          try {
            forecast = await api.getCashForecast(currentHorizon, currentScenario);
            renderView();
          } catch (e) {
            console.error('Failed to update forecast scenario:', e);
          }
        }
      });
    });
  }

  renderView();
}

function renderReceivablesTab(container, arData, onNavigate, onOpenEvidence) {
  const aging = arData.aging_schedule || [];
  const topOverdue = arData.top_overdue_customers || [];
  const customers = (arData.customer_concentration && arData.customer_concentration.length > 0)
    ? arData.customer_concentration
    : topOverdue;

  container.innerHTML = `
    <!-- Top summary cards for AR -->
    <div class="kpi-grid" style="margin-bottom: 20px;">
      <div class="metric-card">
        <span class="metric-label">Total Open Receivables</span>
        <div class="metric-value num">${arData.accounts_receivable.formatted_value}</div>
        <div class="metric-comparison"><span class="metric-delta ${arData.accounts_receivable.comparison?.percentage_change > 0 ? 'delta-neg' : 'delta-pos'}">${arData.accounts_receivable.comparison ? `${arData.accounts_receivable.comparison.percentage_change > 0 ? '+' : ''}${arData.accounts_receivable.comparison.percentage_change}% vs prior` : 'Current period'}</span></div>
      </div>
      <div class="metric-card">
        <span class="metric-label">Total Overdue Receivables</span>
        <div class="metric-value num" style="color: #dc2626;">${arData.overdue_ar.formatted_value}</div>
        <div class="metric-comparison"><span class="badge badge-critical">100% in Apex Retail</span></div>
      </div>
      <div class="metric-card">
        <span class="metric-label">Overdue Percentage</span>
        <div class="metric-value num" style="color: #dc2626;">${arData.overdue_ar_percent.formatted_value}</div>
        <div class="metric-comparison"><span class="metric-subtext">Threshold: 25.0%</span></div>
      </div>
      <div class="metric-card">
        <span class="metric-label">Days Sales Outstanding (DSO)</span>
        <div class="metric-value num">${arData.dso.formatted_value}</div>
        <div class="metric-comparison"><span class="metric-delta delta-neg">${arData.dso.comparison ? `+${arData.dso.comparison.absolute_change} days lag` : 'Collection cycle'}</span></div>
      </div>
    </div>

    <div class="split-row">
      <!-- Aging Schedule -->
      <div class="panel">
        <div class="panel-header">
          <h3 class="panel-title">Receivables Aging Distribution</h3>
          <div style="display: flex; align-items: center; gap: 8px;">
            <button id="btn-export-ar-csv" class="btn btn-outline btn-sm" style="display: flex; align-items: center; gap: 4px; padding: 3px 8px; font-size: 11.5px;">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              <span>Export CSV</span>
            </button>
            <span class="badge badge-high">Overdue: ${arData.overdue_ar.formatted_value}</span>
          </div>
        </div>
        <table class="fin-table">
          <thead>
            <tr>
              <th>Aging Bucket</th>
              <th class="amount">Balance</th>
              <th class="amount">Share</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${aging.map(b => `
              <tr style="${b.bucket_name.includes('Overdue') || b.bucket_name.includes('Days') || b.bucket_name !== 'Current' ? 'background-color: #fffbeb;' : ''}">
                <td><strong>${b.bucket_name}</strong></td>
                <td class="amount">₹${(b.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                <td class="amount">${(b.percentage || b.share_of_total_percent || 0).toFixed(1)}%</td>
                <td>
                  ${b.bucket_name.includes('Current') ? '<span class="badge badge-resolved">Current</span>' : '<span class="badge badge-critical">Past Due</span>'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <!-- Delinquent Customer Concentration -->
      <div class="panel">
        <div class="panel-header">
          <h3 class="panel-title">Customer Balance & Delinquency Exposure</h3>
          <span class="badge badge-critical">Top Risk Concentration</span>
        </div>
        <table class="fin-table">
          <thead>
            <tr>
              <th>Customer</th>
              <th class="amount">Total Open AR</th>
              <th class="amount">Overdue AR</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${customers.map(c => {
              const od = c.additional_context?.overdue_amount || (topOverdue.find(o => o.entity_id === c.entity_id)?.amount || 0);
              const totalOpen = c.amount || c.additional_context?.total_open_ar || 0;
              return `
                <tr>
                  <td>
                    <strong>${c.entity_name}</strong>
                    <div style="font-size: 11px; color: var(--color-text-muted);">${c.entity_id} &bull; ${c.additional_context?.segment || 'Account'}</div>
                  </td>
                  <td class="amount">₹${totalOpen.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                  <td class="amount" style="color: ${od > 0 ? '#dc2626' : '#16a34a'}; font-weight: 700;">₹${od.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                  <td>
                    ${od > 0 ? `
                      <button class="btn btn-outline btn-sm" id="btn-inspect-apex">
                        <span>View Invoices (3)</span>
                      </button>
                    ` : '<span class="badge badge-resolved">Current</span>'}
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <div style="margin-top: 16px; padding: 12px; background-color: var(--color-danger-bg); border-radius: var(--radius-sm); border: 1px solid var(--color-danger-border); font-size: 12px; color: var(--color-danger-text);">
          <strong>Critical Finding:</strong> Apex Retail Group accounts for <strong>100% of all past-due receivables</strong> across the company (${arData.overdue_ar.formatted_value}). Invoice aging reaches 68 days past agreed credit terms.
        </div>
      </div>
    </div>
  `;

  // Attach button listener to view Apex invoices
  container.querySelector('#btn-inspect-apex')?.addEventListener('click', () => {
    if (onOpenEvidence) {
      const invs = arData.overdue_invoices && arData.overdue_invoices.length > 0
        ? arData.overdue_invoices.map(inv => ({
            source_type: 'AR_OPEN_ITEM',
            source_id: inv.invoice_id,
            entity: inv.customer_name,
            value: inv.amount,
            description: `${inv.customer_name} delinquent invoice; due ${inv.due_date} (${inv.days_overdue} days overdue).`,
            metadata: { due_date: inv.due_date, days_overdue: inv.days_overdue, payment_terms: inv.payment_terms }
          }))
        : [
            {
              source_type: 'AR_OPEN_ITEM',
              source_id: 'INV-AR-50065',
              entity: 'Apex Retail Group',
              value: 189000.00,
              description: 'Standard Components shipment; terms Net 30, due 2026-07-24 (68 days overdue).',
              metadata: { due_date: '2026-07-24', days_overdue: 68, original_amount: '₹189,000.00' }
            },
            {
              source_type: 'AR_OPEN_ITEM',
              source_id: 'INV-AR-50073',
              entity: 'Apex Retail Group',
              value: 425000.00,
              description: 'Enterprise Server batch 4; terms Net 30, due 2026-08-22 (39 days overdue).',
              metadata: { due_date: '2026-08-22', days_overdue: 39, original_amount: '₹425,000.00' }
            },
            {
              source_type: 'AR_OPEN_ITEM',
              source_id: 'INV-AR-50081',
              entity: 'Apex Retail Group',
              value: 430000.00,
              description: 'Hardware appliances; terms Net 30, due 2026-09-15 (15 days overdue).',
              metadata: { due_date: '2026-09-15', days_overdue: 15, original_amount: '₹430,000.00' }
            }
          ];

      onOpenEvidence({
        title: 'Apex Retail Group (CUST-101) — Overdue Invoices Audit',
        entity: 'Apex Retail Group',
        evidenceList: invs,
        context: {
          title: 'Apex Retail Group Delinquency Escalation',
          severity: 'CRITICAL',
          category: 'RECEIVABLES',
          financial_impact: arData.overdue_ar?.value ?? 0.0,
          summary: `Apex Retail Group owes ${arData.overdue_ar.formatted_value} across overdue invoices aged 15 to 68 days.`,
          linked_attention_id: 'ATTN-AR-202609-01',
          recommended_actions: [
            'Initiate direct executive billing review with Apex Accounts Payable Director.',
            'Place temporary shipment hold on new purchase orders.',
            'Establish structured weekly payment milestone agreement.'
          ]
        }
      });
    }
  });

  container.querySelector('#btn-export-ar-csv')?.addEventListener('click', () => {
    exportToCsv('finsight_ar_aging.csv', [
      { label: 'Aging Bucket', key: 'bucket_name' },
      { label: 'Balance (INR)', key: 'amount' },
      { label: 'Share (%)', key: 'percentage' }
    ], aging);
  });
}

function renderPayablesTab(container, apData, onNavigate, onOpenEvidence) {
  const upcomingInvoices = (apData.upcoming_invoices && apData.upcoming_invoices.length > 0)
    ? apData.upcoming_invoices
    : (apData.top_vendors_due || []).map(v => ({
        vendor_name: v.entity_name,
        vendor_id: v.entity_id,
        invoice_id: 'INV-AP-EXP',
        due_date: 'Next 7 Days',
        days_remaining: 5,
        amount: v.amount,
        payment_terms: v.additional_context?.payment_terms || 'Net 30'
      }));

  container.innerHTML = `
    <!-- Top summary cards for AP -->
    <div class="kpi-grid" style="margin-bottom: 20px;">
      <div class="metric-card">
        <span class="metric-label">Total Accounts Payable</span>
        <div class="metric-value num">${apData.accounts_payable.formatted_value}</div>
        <div class="metric-comparison"><span class="metric-subtext">Total supplier obligations</span></div>
      </div>
      <div class="metric-card">
        <span class="metric-label">Due Next 7 Days</span>
        <div class="metric-value num" style="color: #dc2626;">${apData.upcoming_payables_7d.formatted_value}</div>
        <div class="metric-comparison"><span class="badge badge-critical">Exceeds Liquid Cash</span></div>
      </div>
      <div class="metric-card">
        <span class="metric-label">Overdue Payables</span>
        <div class="metric-value num" style="color: #16a34a;">${apData.overdue_payables.formatted_value}</div>
        <div class="metric-comparison"><span class="badge badge-resolved">No Supplier Default</span></div>
      </div>
      <div class="metric-card">
        <span class="metric-label">Days Payable Outstanding (DPO)</span>
        <div class="metric-value num">${apData.dpo.formatted_value}</div>
        <div class="metric-comparison"><span class="metric-subtext">Operating payment terms</span></div>
      </div>
    </div>

    <!-- Imminent Payables Schedule -->
    <div class="panel">
      <div class="panel-header">
        <h3 class="panel-title">Imminent 7-Day Maturing Liabilities Schedule</h3>
        <div style="display: flex; align-items: center; gap: 8px;">
          <button id="btn-export-ap-csv" class="btn btn-outline btn-sm" style="display: flex; align-items: center; gap: 4px; padding: 3px 8px; font-size: 11.5px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Export CSV</span>
          </button>
          <span class="badge badge-critical">Total: ${apData.upcoming_payables_7d.formatted_value} Due</span>
        </div>
      </div>
      <table class="fin-table">
        <thead>
          <tr>
            <th>Vendor Name</th>
            <th>Invoice ID</th>
            <th>Due Date</th>
            <th>Days Remaining</th>
            <th class="amount">Open Amount</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          ${upcomingInvoices.map((inv, idx) => `
            <tr>
              <td>
                <strong>${inv.vendor_name}</strong>
                <div style="font-size: 11px; color: var(--color-text-muted);">${inv.vendor_id} &bull; Terms: ${inv.payment_terms || 'Net 30'}</div>
              </td>
              <td><code class="mono">${inv.invoice_id}</code></td>
              <td>${inv.due_date}</td>
              <td><span class="badge ${inv.days_remaining <= 1 ? 'badge-critical' : (inv.days_remaining <= 4 ? 'badge-high' : 'badge-medium')}">${inv.days_remaining === 0 ? 'Due Today' : `${inv.days_remaining} Days`}</span></td>
              <td class="amount">₹${(inv.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
              <td>
                <button class="btn btn-outline btn-sm btn-inspect-vendor-inv" data-idx="${idx}">Inspect</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  container.querySelectorAll('.btn-inspect-vendor-inv').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.getAttribute('data-idx'), 10);
      const inv = upcomingInvoices[idx];
      if (inv && onOpenEvidence) {
        onOpenEvidence({
          title: `${inv.vendor_name} — AP Obligation Evidence`,
          entity: inv.vendor_name,
          evidenceList: [
            {
              source_type: 'AP_OPEN_ITEM',
              source_id: inv.invoice_id,
              entity: inv.vendor_name,
              value: inv.amount,
              description: `Maturing supplier obligation; terms ${inv.payment_terms || 'Net 30'}, due ${inv.due_date} (${inv.days_remaining} days remaining).`,
              metadata: { due_date: inv.due_date, days_remaining: inv.days_remaining, payment_terms: inv.payment_terms }
            }
          ]
        });
      }
    });
  });

  container.querySelector('#btn-export-ap-csv')?.addEventListener('click', () => {
    exportToCsv('finsight_ap_liabilities.csv', [
      { label: 'Vendor Name', key: 'vendor_name' },
      { label: 'Vendor ID', key: 'vendor_id' },
      { label: 'Invoice ID', key: 'invoice_id' },
      { label: 'Due Date', key: 'due_date' },
      { label: 'Days Remaining', key: 'days_remaining' },
      { label: 'Open Amount (INR)', key: 'amount' }
    ], upcomingInvoices);
  });
}
