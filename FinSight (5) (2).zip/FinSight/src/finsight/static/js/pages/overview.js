/**
 * Overview Page View — CFO Executive Command Center
 *
 * Designed around four executive questions:
 * 1. How are we doing? (Four numbers only: Cash, NWC, CCC, Gross Margin)
 * 2. What changed? (3 material movements with direct link to Performance)
 * 3. What needs attention? (2-3 prioritized exposures with direct link to Investigate)
 * 4. What is our cash trajectory? (Today -> 30d -> 60d -> 90d runway trajectory)
 *
 * Absolute minimalism. Zero modals. Zero technical IDs. Progressive disclosure.
 */

import { formatCompactCurrency, escapeHtml } from '../utils/format.js';

function formatMetricTitle(key) {
  const map = {
    gross_margin_percent: 'Gross Margin',
    net_working_capital: 'Net Working Capital',
    cash_position: 'Cash',
    cash_conversion_cycle: 'Operating Cash Cycle (CCC)',
    accounts_receivable: 'Accounts Receivable',
    accounts_payable: 'Accounts Payable',
    inventory: 'Inventory',
    dso: 'DSO',
    dio: 'DIO',
    dpo: 'DPO',
    operating_cash_flow: 'Operating Cash Flow',
    revenue: 'Revenue',
    cogs: 'Cost of Goods Sold',
  };
  return map[key] || key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

export async function renderOverview(container, api, onNavigate, onOpenEvidence) {
  container.innerHTML = `
    <div style="display: flex; justify-content: center; align-items: center; padding: 48px;">
      <div style="color: var(--color-text-muted); font-size: 13px;">Loading executive financial overview...</div>
    </div>
  `;

  try {
    // Concurrently fetch summary, attention, variances, 30/60/90d forecasts, and trust status
    const [summary, attention, whatChanged, forecast30, forecast60, forecast90, trustSummary] = await Promise.all([
      api.getSummary(),
      api.getAttentionSummary(),
      api.getPerformanceWhatChanged(api.currentPeriod, true).catch(() => []),
      api.compareForecastScenarios(30, api.currentPeriod).catch(() => null),
      api.compareForecastScenarios(60, api.currentPeriod).catch(() => null),
      api.compareForecastScenarios(90, api.currentPeriod).catch(() => null),
      api.getTrustSummary(api.currentPeriod).catch(() => null),
    ]);

    container.innerHTML = '';

    // =========================================================================
    // 1. EXECUTIVE HEADER
    // FinSight Global Technologies Inc. · Consolidated · Sep 2026       ✓ Reconciled
    // =========================================================================
    const posHeader = document.createElement('div');
    posHeader.style.cssText = 'display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 22px;';

    const passedTies = trustSummary?.reconciliation_summary?.passed_ties ?? 0;
    const totalTies = trustSummary?.reconciliation_summary?.total_ties ?? 0;
    const isVerified = totalTies > 0 && passedTies === totalTies;

    posHeader.innerHTML = `
      <div style="display: flex; align-items: baseline; gap: 8px;">
        <span style="font-size: 15px; font-weight: 700; color: var(--color-text-primary); letter-spacing: -0.2px;">
          ${escapeHtml(summary.company_name || 'FinSight Global Technologies Inc.')}
        </span>
        <span style="font-size: 12.5px; color: var(--color-text-muted);">
          &bull; Consolidated &bull; ${escapeHtml(summary.period)}
        </span>
      </div>
      <button id="overview-trust-drawer-link" style="background: none; border: none; font-size: 12px; font-weight: 600; color: ${isVerified ? '#16a34a' : '#d97706'}; cursor: pointer; display: flex; align-items: center; gap: 4px; padding: 2px 4px;" title="Click to view full financial ledger reconciliation">
        <span>✓</span>
        <span>${isVerified ? 'Reconciled' : 'Reconciliation Pending'}</span>
      </button>
    `;

    posHeader.querySelector('#overview-trust-drawer-link')?.addEventListener('click', () => {
      if (window.openTrustDrawer) window.openTrustDrawer(summary.period);
    });
    container.appendChild(posHeader);

    // =========================================================================
    // 2. FINANCIAL HEALTH — FOUR NUMBERS ONLY
    // Cash                NWC                 CCC                Gross Margin
    // ₹8.14L              ₹48.49L             89.5 days          40.28%
    // ↓ 34.7%             ↑ 3.5%              ↓ 14.6d            ↓ 1.77 pp
    // =========================================================================
    const kpiSection = document.createElement('section');
    kpiSection.style.cssText = 'display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 24px;';

    // 1. Cash
    const cashVal = summary.cash_position?.value;
    const cashComp = summary.cash_position?.comparison;
    const cashCard = document.createElement('div');
    cashCard.className = 'metric-card';
    cashCard.style.cssText = 'background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 14px 16px; cursor: pointer; box-shadow: var(--shadow-sm); transition: border-color 0.15s ease;';
    cashCard.title = 'Click to view cash subledger in Financials';
    cashCard.innerHTML = `
      <div style="font-size: 12px; font-weight: 600; color: var(--color-text-secondary); margin-bottom: 6px;">Cash</div>
      <div class="num" style="font-size: 24px; font-weight: 800; color: var(--color-text-primary); line-height: 1.15; margin-bottom: 6px;">
        ${cashVal != null ? formatCompactCurrency(cashVal) : '—'}
      </div>
      <div style="font-size: 12px; font-weight: 700; color: ${cashComp && cashComp.percentage_change < 0 ? '#dc2626' : '#16a34a'};">
        ${cashComp ? `${cashComp.percentage_change < 0 ? '↓' : '↑'} ${Math.abs(cashComp.percentage_change).toFixed(1)}%` : '—'}
      </div>
    `;
    cashCard.addEventListener('click', () => onNavigate('financials', { tab: 'cash' }));

    // 2. Net Working Capital
    const nwcVal = summary.net_working_capital?.value;
    const nwcComp = summary.net_working_capital?.comparison;
    const nwcCard = document.createElement('div');
    nwcCard.className = 'metric-card';
    nwcCard.style.cssText = 'background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 14px 16px; cursor: pointer; box-shadow: var(--shadow-sm); transition: border-color 0.15s ease;';
    nwcCard.title = 'Click to view working capital in Financials';
    nwcCard.innerHTML = `
      <div style="font-size: 12px; font-weight: 600; color: var(--color-text-secondary); margin-bottom: 6px;">Net Working Capital</div>
      <div class="num" style="font-size: 24px; font-weight: 800; color: var(--color-text-primary); line-height: 1.15; margin-bottom: 6px;">
        ${nwcVal != null ? formatCompactCurrency(nwcVal) : '—'}
      </div>
      <div style="font-size: 12px; font-weight: 700; color: ${nwcComp && nwcComp.percentage_change < 0 ? '#dc2626' : '#16a34a'};">
        ${nwcComp ? `${nwcComp.percentage_change < 0 ? '↓' : '↑'} ${Math.abs(nwcComp.percentage_change).toFixed(1)}%` : '—'}
      </div>
    `;
    nwcCard.addEventListener('click', () => onNavigate('financials', { tab: 'overview' }));

    // 3. Operating Cash Cycle (CCC)
    const cccVal = summary.ccc?.value != null ? `${Number(summary.ccc.value).toFixed(1)} days` : '—';
    const cccComp = summary.ccc?.comparison;
    const cccCard = document.createElement('div');
    cccCard.className = 'metric-card';
    cccCard.style.cssText = 'background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 14px 16px; cursor: pointer; box-shadow: var(--shadow-sm); transition: border-color 0.15s ease;';
    cccCard.title = 'Click to view cycle drivers in Performance';
    cccCard.innerHTML = `
      <div style="font-size: 12px; font-weight: 600; color: var(--color-text-secondary); margin-bottom: 6px;">Operating Cash Cycle</div>
      <div class="num" style="font-size: 24px; font-weight: 800; color: var(--color-text-primary); line-height: 1.15; margin-bottom: 6px;">
        ${cccVal}
      </div>
      <div style="font-size: 12px; font-weight: 700; color: ${cccComp && cccComp.absolute_change > 0 ? '#dc2626' : '#16a34a'};">
        ${cccComp ? `${cccComp.absolute_change < 0 ? '↓' : '↑'} ${Math.abs(cccComp.absolute_change).toFixed(1)}d` : '—'}
      </div>
    `;
    cccCard.addEventListener('click', () => onNavigate('performance'));

    // 4. Gross Margin
    const gmVal = summary.gross_margin_percent?.value != null ? `${Number(summary.gross_margin_percent.value).toFixed(2)}%` : '—';
    const gmComp = summary.gross_margin_percent?.comparison;
    const gmCard = document.createElement('div');
    gmCard.className = 'metric-card';
    gmCard.style.cssText = 'background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 14px 16px; cursor: pointer; box-shadow: var(--shadow-sm); transition: border-color 0.15s ease;';
    gmCard.title = 'Click to view profitability in Financials';
    gmCard.innerHTML = `
      <div style="font-size: 12px; font-weight: 600; color: var(--color-text-secondary); margin-bottom: 6px;">Gross Margin</div>
      <div class="num" style="font-size: 24px; font-weight: 800; color: var(--color-text-primary); line-height: 1.15; margin-bottom: 6px;">
        ${gmVal}
      </div>
      <div style="font-size: 12px; font-weight: 700; color: ${gmComp && gmComp.absolute_change < 0 ? '#dc2626' : '#16a34a'};">
        ${gmComp ? `${gmComp.absolute_change < 0 ? '↓' : '↑'} ${Math.abs(gmComp.absolute_change).toFixed(2)} pp` : '—'}
      </div>
    `;
    gmCard.addEventListener('click', () => onNavigate('financials', { tab: 'profitability' }));

    kpiSection.appendChild(cashCard);
    kpiSection.appendChild(nwcCard);
    kpiSection.appendChild(cccCard);
    kpiSection.appendChild(gmCard);
    container.appendChild(kpiSection);

    // =========================================================================
    // 3. TWO VERY CLEAN COLUMNS: WHAT CHANGED | NEEDS ATTENTION
    // =========================================================================
    const middleGrid = document.createElement('div');
    middleGrid.style.cssText = 'display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px;';

    // LEFT COLUMN: WHAT CHANGED
    // Only 3 material movements. No table. No modal. Clean link: View performance →
    const whatChangedPanel = document.createElement('div');
    whatChangedPanel.style.cssText = 'background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 18px 20px; box-shadow: var(--shadow-sm); display: flex; flex-direction: column; justify-content: space-between;';

    const movements = whatChanged.slice(0, 3);
    let movementsHtml = '';
    if (movements.length > 0) {
      movementsHtml = movements.map(m => {
        const isNeg = m.impact_direction === 'NEGATIVE' || (m.percentage_change !== null && m.percentage_change < 0);
        const arrow = m.percentage_change > 0 ? '↑' : (m.percentage_change < 0 ? '↓' : '→');
        const deltaStr = m.percentage_change !== null && m.percentage_change !== undefined
          ? `${arrow} ${Math.abs(m.percentage_change).toFixed(1)}%`
          : (m.absolute_change !== null && m.absolute_change !== undefined ? `${m.absolute_change > 0 ? '↑' : '↓'} ${Math.abs(m.absolute_change).toFixed(1)}` : '—');

        const cleanTitle = formatMetricTitle(m.metric_name);
        const reason = m.materiality_reason || m.explanation || 'Material operating movement';

        return `
          <div style="padding: 11px 0; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 3px;">
              <span style="font-size: 13px; font-weight: 600; color: var(--color-text-primary);">${escapeHtml(cleanTitle)}</span>
              <span style="font-size: 12.5px; font-weight: 700; color: ${isNeg ? '#dc2626' : '#16a34a'};">${escapeHtml(deltaStr)}</span>
            </div>
            <div style="font-size: 12px; color: var(--color-text-secondary); line-height: 1.4;">${escapeHtml(reason)}</div>
          </div>
        `;
      }).join('');
    } else {
      movementsHtml = `
        <div style="padding: 24px 0; text-align: center; color: var(--color-text-muted); font-size: 12px;">
          No material period-over-period movements flagged.
        </div>
      `;
    }

    whatChangedPanel.innerHTML = `
      <div>
        <div style="margin-bottom: 10px;">
          <h3 style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin: 0; text-transform: uppercase; letter-spacing: 0.3px;">
            What Changed
          </h3>
        </div>
        <div>
          ${movementsHtml}
        </div>
      </div>
      <div style="margin-top: 14px; text-align: right;">
        <button id="btn-view-performance" style="background: none; border: none; color: var(--color-primary); font-size: 12px; font-weight: 600; cursor: pointer; padding: 0;">
          View performance &rarr;
        </button>
      </div>
    `;

    whatChangedPanel.querySelector('#btn-view-performance')?.addEventListener('click', () => {
      onNavigate('performance');
    });

    // RIGHT COLUMN: NEEDS ATTENTION
    // Only 2–3 items. Clean exposures. Deep-link: Investigate →
    const attentionPanel = document.createElement('div');
    attentionPanel.style.cssText = 'background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 18px 20px; box-shadow: var(--shadow-sm); display: flex; flex-direction: column; justify-content: space-between;';

    const attentionItems = (attention.items || [])
      .filter(item => item.severity === 'CRITICAL' || item.severity === 'HIGH')
      .slice(0, 2);

    let attentionListHtml = '';
    if (attentionItems.length > 0) {
      attentionListHtml = attentionItems.map(item => {
        const impact = item.financial_impact || item.financial_exposure || 0;
        const impactStr = impact > 0 ? formatCompactCurrency(impact) : '';
        const raw = item.summary || item.priority_reason || item.description || '';
        const cleanReason = raw ? (raw.split(/(?<=[.?!])\s+/)[0] || raw) : 'Material attention condition requires review.';

        return `
          <div style="padding: 11px 0; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 3px;">
              <span style="font-size: 13px; font-weight: 700; color: var(--color-text-primary);">${escapeHtml(item.title)}</span>
              ${impactStr ? `<span style="font-size: 12px; font-weight: 700; color: #dc2626; font-family: var(--font-mono);">${escapeHtml(impactStr)} exposure</span>` : ''}
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
              <span style="font-size: 12px; color: var(--color-text-secondary); line-height: 1.35; flex: 1;">${escapeHtml(cleanReason)}</span>
              <button class="btn btn-ghost btn-sm btn-attn-action" data-attn-id="${escapeHtml(item.id || item.attention_id)}" style="color: var(--color-primary); font-size: 11.5px; font-weight: 600; padding: 2px 6px; flex-shrink: 0; cursor: pointer;">
                Investigate &rarr;
              </button>
            </div>
          </div>
        `;
      }).join('');
    } else {
      attentionListHtml = `
        <div style="padding: 24px 0; text-align: center; color: var(--color-text-muted); font-size: 12px;">
          ✓ No critical financial breaches detected in active period.
        </div>
      `;
    }

    attentionPanel.innerHTML = `
      <div>
        <div style="margin-bottom: 10px;">
          <h3 style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin: 0; text-transform: uppercase; letter-spacing: 0.3px;">
            Needs Attention
          </h3>
        </div>
        <div>
          ${attentionListHtml}
        </div>
      </div>
      <div style="margin-top: 14px; text-align: right;">
        <button id="btn-view-actions" style="background: none; border: none; color: var(--color-primary); font-size: 12px; font-weight: 600; cursor: pointer; padding: 0;">
          All Actions (${attention.total_items || attentionItems.length}) &rarr;
        </button>
      </div>
    `;

    attentionPanel.querySelector('#btn-view-actions')?.addEventListener('click', () => {
      onNavigate('actions');
    });

    attentionPanel.querySelectorAll('.btn-attn-action').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-attn-id');
        const item = attention.items.find(i => (i.id === id || i.attention_id === id));
        if (item) {
          const q = item.recommended_question || `Why is there ${item.title.toLowerCase()} in ${summary.period}?`;
          const entityName = item.entities?.[0]?.customer_name || item.entities?.[0]?.entity_name || (typeof item.entities?.[0] === 'string' ? item.entities[0] : null);
          onNavigate('investigate', {
            question: q,
            context: {
              source: 'financial_attention',
              attention_id: item.id || item.attention_id,
              metric: item.metric || (item.metrics && item.metrics[0]) || null,
              entity: entityName,
              period: summary.period,
            }
          });
        } else {
          onNavigate('actions');
        }
      });
    });

    middleGrid.appendChild(whatChangedPanel);
    middleGrid.appendChild(attentionPanel);
    container.appendChild(middleGrid);

    // =========================================================================
    // 4. CASH TRAJECTORY
    // Today ───── 30d ───── 60d ───── 90d
    // ₹8.14L  →  ₹4.48L  →  ₹8.15L  →  ₹5.59L
    // Inflows +₹13.8L · Outflows -₹16.3L
    // View cash analysis →
    // =========================================================================
    const outlookSection = document.createElement('section');
    outlookSection.style.cssText = 'background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 18px 20px; box-shadow: var(--shadow-sm);';

    const base30 = forecast30?.scenarios?.['BASE'] || forecast30?.base_scenario;
    const base60 = forecast60?.scenarios?.['BASE'] || forecast60?.base_scenario;
    const base90 = forecast90?.scenarios?.['BASE'] || forecast90?.base_scenario;

    const closing30 = base30 ? (base30.projected_cash ?? base30.closing_cash ?? cashVal) : (cashVal ?? 0);
    const collections30 = base30 ? (base30.expected_collections ?? base30.total_collections ?? 0) : 0;
    const payables30 = base30 ? (base30.expected_payables ?? base30.total_disbursements ?? 0) : 0;

    const closing60 = base60 ? (base60.projected_cash ?? base60.closing_cash ?? cashVal) : null;
    const closing90 = base90 ? (base90.projected_cash ?? base90.closing_cash ?? cashVal) : null;

    outlookSection.innerHTML = `
      <div style="margin-bottom: 16px;">
        <h3 style="font-size: 13.5px; font-weight: 700; color: var(--color-text-primary); margin: 0; text-transform: uppercase; letter-spacing: 0.3px;">
          Cash Trajectory
        </h3>
      </div>

      <!-- Trajectory Milestones Strip -->
      <div style="background: #fafbfd; border: 1px solid #e2e8f0; border-radius: var(--radius-sm); padding: 14px 20px; margin-bottom: 14px;">
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; text-align: center;">
          <!-- Today -->
          <div>
            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Today</div>
            <div class="num" style="font-size: 18px; font-weight: 800; color: var(--color-text-primary);">
              ${cashVal != null ? formatCompactCurrency(cashVal) : '—'}
            </div>
          </div>
          <!-- 30d -->
          <div>
            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">30d</div>
            <div class="num" style="font-size: 18px; font-weight: 800; color: ${closing30 < 500000 ? '#dc2626' : 'var(--color-text-primary)'};">
              ${formatCompactCurrency(closing30)}
            </div>
          </div>
          <!-- 60d -->
          <div>
            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">60d</div>
            <div class="num" style="font-size: 18px; font-weight: 800; color: var(--color-text-primary);">
              ${closing60 != null ? formatCompactCurrency(closing60) : '—'}
            </div>
          </div>
          <!-- 90d -->
          <div>
            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">90d</div>
            <div class="num" style="font-size: 18px; font-weight: 800; color: var(--color-text-primary);">
              ${closing90 != null ? formatCompactCurrency(closing90) : '—'}
            </div>
          </div>
        </div>
      </div>

      <!-- Inflows/Outflows Summary + Cash Analysis Link -->
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
        <div style="font-size: 12px; color: var(--color-text-secondary);">
          <span>Inflows <strong style="color: #166534;">+${formatCompactCurrency(collections30)}</strong></span>
          <span style="margin: 0 6px; color: #cbd5e1;">&bull;</span>
          <span>Outflows <strong style="color: #dc2626;">-${formatCompactCurrency(payables30)}</strong></span>
        </div>
        <button id="btn-cash-analysis" style="background: none; border: none; color: var(--color-primary); font-size: 12px; font-weight: 600; cursor: pointer; padding: 0;">
          View cash analysis &rarr;
        </button>
      </div>
    `;

    outlookSection.querySelector('#btn-cash-analysis')?.addEventListener('click', () => {
      onNavigate('financials', { tab: 'cash' });
    });

    container.appendChild(outlookSection);

  } catch (err) {
    container.innerHTML = `
      <div style="padding: 20px; color: var(--color-danger-text); background-color: var(--color-danger-bg); border-radius: var(--radius-sm); font-size: 13px;">
        Error loading Overview view: ${escapeHtml(err.message)}
      </div>
    `;
  }
}
