/**
 * Financial Performance & Analysis Page View
 * Executive Performance, Material Movements, Root-Cause Drivers, and Segment Breakdown.
 */

import { exportToCsv } from '../utils/exportCsv.js';
import { formatCurrency, formatCompactCurrency, escapeHtml } from '../utils/format.js';

/**
 * Determines whether a metric change direction is favorable (good) or unfavorable (bad).
 */
function isFavorable(metricName, changeVal) {
  const higherIsBetter = ['revenue', 'gross_profit', 'gross_margin_percent', 'cash_position', 'liquid_cash', 'net_working_capital'];
  const lowerIsBetter = ['cogs', 'overdue_ar', 'dso', 'dio', 'dpo', 'cash_conversion_cycle', 'upcoming_payables_7d'];
  
  const m = (metricName || '').toLowerCase().trim();
  const val = Number(changeVal ?? 0);

  if (higherIsBetter.includes(m)) {
    return val >= 0;
  }
  if (lowerIsBetter.includes(m)) {
    return val <= 0;
  }
  return val >= 0;
}

export async function renderPerformance(
  container,
  api,
  initialTab = 'customers',
  onNavigate,
  onOpenEvidence,
  onOpenInvestigate
) {
  let activeTab = (initialTab === 'overview' || initialTab === 'profitability') ? 'customers' : initialTab;
  let selectedMetric = 'gross_margin_percent';
  let activeDriverData = null;
  let onlyMaterial = false;
  let customerSearchQuery = '';
  let customerStatusFilter = 'ALL';

  container.innerHTML = `
    <div style="display: flex; justify-content: center; align-items: center; padding: 60px;">
      <div style="color: var(--color-text-muted); font-size: 14px; display: flex; align-items: center; gap: 8px;">
        <span style="display: inline-block; width: 14px; height: 14px; border: 2px solid #cbd5e1; border-top-color: #2563eb; border-radius: 50%; animation: spinRing 0.8s linear infinite;"></span>
        <span>Loading financial performance &amp; analysis...</span>
      </div>
    </div>
  `;

  try {
    // Parallel fetch: Performance Summary + Profitability breakdown
    const [perfSummary, pnlData] = await Promise.all([
      api.getPerformanceSummary(),
      api.getProfitability(),
    ]);

    activeDriverData = perfSummary.default_driver;

    // Build lookup dictionary for What Changed items
    const whatChangedMap = (perfSummary.what_changed || []).reduce((acc, item) => {
      acc[item.metric_name] = item;
      return acc;
    }, {});

    async function selectMetricDriver(metricName) {
      selectedMetric = metricName;
      const driverContainer = container.querySelector('#why-it-changed-panel');
      if (driverContainer) {
        driverContainer.innerHTML = `
          <div style="padding: 32px; text-align: center; color: var(--color-text-muted); font-size: 13px; display: flex; align-items: center; justify-content: center; gap: 10px;">
            <span style="display: inline-block; width: 16px; height: 16px; border: 2px solid #cbd5e1; border-top-color: #2563eb; border-radius: 50%; animation: spinRing 0.8s linear infinite;"></span>
            <span>Analyzing driver decomposition for <strong>${escapeHtml(metricName)}</strong>...</span>
          </div>
        `;
      }
      try {
        activeDriverData = await api.getPerformanceDrivers(metricName, perfSummary.period);
      } catch (e) {
        console.warn('Driver fetch fallback:', e);
      }
      renderDriverPanel();
      updateWhatChangedSelection();
    }

    function render() {
      const revItem = whatChangedMap['revenue'];
      const gpItem = whatChangedMap['gross_profit'];
      const gmItem = whatChangedMap['gross_margin_percent'];
      const nwcItem = whatChangedMap['net_working_capital'];
      const cccItem = whatChangedMap['cash_conversion_cycle'];

      const revGrowth = revItem?.percentage_change ?? (pnlData?.revenue?.comparison?.percentage_change ?? 0);
      const gpGrowth = gpItem?.percentage_change ?? (pnlData?.gross_profit?.comparison?.percentage_change ?? 0);
      const gmChange = gmItem?.absolute_change ?? (pnlData?.gross_margin_percent?.comparison?.absolute_change ?? 0);

      const revFavorable = isFavorable('revenue', revGrowth);
      const gpFavorable = isFavorable('gross_profit', gpGrowth);
      const gmFavorable = isFavorable('gross_margin_percent', gmChange);
      const nwcFavorable = isFavorable('net_working_capital', nwcItem?.absolute_change ?? 0);
      const cccFavorable = isFavorable('cash_conversion_cycle', cccItem?.absolute_change ?? 0);

      const allVariances = perfSummary.what_changed || [];
      const materialCount = perfSummary.material_movements_count || allVariances.filter(v => v.is_material).length;

      container.innerHTML = `
        <!-- Analytical Change Header (Replaces duplicated dashboard cards with variance context) -->
        <section class="panel" style="margin-bottom: 20px; padding: 14px 18px; background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); border: 1px solid var(--color-border); border-radius: var(--radius-sm); box-shadow: var(--shadow-sm);">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #eff6ff; border: 1px solid #bfdbfe; display: flex; align-items: center; justify-content: center; color: #2563eb; font-size: 16px;">
                📈
              </div>
              <div>
                <div style="display: flex; align-items: center; gap: 8px;">
                  <h2 style="font-size: 15px; font-weight: 800; color: #0f172a; margin: 0;">Performance &amp; Variance Analysis</h2>
                  <span class="badge ${materialCount > 0 ? 'badge-critical' : 'badge-resolved'}" style="font-size: 10.5px; padding: 2px 7px;">
                    ${materialCount} Material Variance${materialCount !== 1 ? 's' : ''}
                  </span>
                </div>
                <div style="font-size: 12px; color: var(--color-text-muted); margin-top: 2px;">
                  Audited period-over-period variance decomposition &bull; Fiscal Period: <strong class="mono" style="color: #0f172a;">${escapeHtml(perfSummary.period)}</strong> vs <span class="mono">${escapeHtml(perfSummary.comparison_period || 'prior')}</span>
                </div>
              </div>
            </div>

            <!-- Quick Summary Metrics of Change -->
            <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap;">
              <div style="padding: 6px 12px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; text-align: right;">
                <span style="font-size: 10.5px; text-transform: uppercase; color: #64748b; font-weight: 600;">Active Focus</span>
                <div style="font-size: 13px; font-weight: 700; color: #0f172a;">${escapeHtml(activeDriverData?.display_name || selectedMetric)}</div>
              </div>
              <div style="padding: 6px 12px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; text-align: right;">
                <span style="font-size: 10.5px; text-transform: uppercase; color: #64748b; font-weight: 600;">Net Impact</span>
                <div style="font-size: 13px; font-weight: 800; font-family: var(--font-mono); color: ${(activeDriverData?.financial_impact || 0) > 0 ? '#dc2626' : '#16a34a'};">
                  ${formatCurrency(activeDriverData?.financial_impact || 0)}
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- KEY OPERATING VARIANCES: De-clustered Segmented Selector -->
        <section class="panel" style="margin-bottom: 24px; padding: 18px 20px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
            <div>
              <div style="display: flex; align-items: center; gap: 8px;">
                <h3 class="panel-title" style="margin: 0; font-size: 14.5px; font-weight: 700; color: var(--color-text-primary);">
                  Key Operating Variances
                </h3>
                <span class="badge badge-medium" style="font-size: 11px;">
                  ${materialCount} Material Movements
                </span>
              </div>
              <p style="margin: 3px 0 0 0; font-size: 12px; color: var(--color-text-muted);">
                Audited variance vs ${escapeHtml(perfSummary.comparison_period || 'prior period')} &bull; Click any metric card to inspect root causes.
              </p>
            </div>
            
            <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
              <!-- Material Only Toggle -->
              <label style="display: inline-flex; align-items: center; gap: 6px; font-size: 12px; cursor: pointer; color: var(--color-text-secondary); user-select: none;">
                <input type="checkbox" id="perf-only-material-toggle" ${onlyMaterial ? 'checked' : ''} style="cursor: pointer;">
                <span>Show Material Only (${materialCount})</span>
              </label>

              <!-- Metric Jump Selector -->
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="font-size: 11.5px; color: var(--color-text-muted);">Jump to:</span>
                <select id="perf-all-variances-select" class="period-select" style="width: auto; padding: 4px 10px; font-size: 12px;">
                  <option value="">Jump to any metric...</option>
                  ${allVariances.map(item => `
                    <option value="${escapeHtml(item.metric_name)}" ${item.metric_name === selectedMetric ? 'selected' : ''}>
                      ${escapeHtml(item.display_name)} (${escapeHtml(item.formatted_change)})
                    </option>
                  `).join('')}
                </select>
              </div>
            </div>
          </div>

          <!-- Variance Cards Grid -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px;" id="what-changed-cards">
            ${renderCuratedVarianceCards(allVariances, selectedMetric, onlyMaterial)}
          </div>
        </section>

        <!-- WHY IT CHANGED: Active Variance Breakdown Panel -->
        <section class="panel" style="margin-bottom: 24px; border-left: 4px solid #2563eb;" id="why-it-changed-panel">
          <!-- Dynamically populated by renderDriverPanel() -->
        </section>

        <!-- SEGMENTATION DEEP-DIVE TABS: Customers | Products -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid var(--color-border); padding-bottom: 8px; flex-wrap: wrap; gap: 8px;">
          <div class="tabs-nav" style="border-bottom: none; margin-bottom: 0;">
            <button class="tab-btn ${activeTab === 'customers' ? 'active' : ''}" data-tab="customers" style="font-weight: 600;">
              Customer Accounts &amp; Receivables (${pnlData.top_customers_by_revenue?.length || 0})
            </button>
            <button class="tab-btn ${activeTab === 'products' ? 'active' : ''}" data-tab="products" style="font-weight: 600;">
              Product Line Margins &amp; Costs (${pnlData.product_group_margins?.length || 0})
            </button>
          </div>
          <span style="font-size: 12px; color: var(--color-text-muted);">Audited Ledger Attribution &bull; Click row to open deep investigation</span>
        </div>

        <div id="performance-tab-content"></div>
      `;

      // Material only toggle event
      const materialToggle = container.querySelector('#perf-only-material-toggle');
      materialToggle?.addEventListener('change', (e) => {
        onlyMaterial = e.target.checked;
        const cardsContainer = container.querySelector('#what-changed-cards');
        if (cardsContainer) {
          cardsContainer.innerHTML = renderCuratedVarianceCards(allVariances, selectedMetric, onlyMaterial);
          attachCardEvents();
        }
      });

      // Event handlers for What Changed cards
      function attachCardEvents() {
        container.querySelectorAll('.what-changed-card').forEach(card => {
          card.addEventListener('click', () => {
            const m = card.getAttribute('data-metric');
            if (m) selectMetricDriver(m);
          });
        });
      }
      attachCardEvents();

      // Dropdown selector for remaining variances
      const selectEl = container.querySelector('#perf-all-variances-select');
      selectEl?.addEventListener('change', (e) => {
        if (e.target.value) {
          selectMetricDriver(e.target.value);
        }
      });

      // Tab switcher handlers
      container.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          activeTab = btn.getAttribute('data-tab');
          container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          renderActiveTab();
        });
      });

      renderDriverPanel();
      renderActiveTab();
    }

    function updateWhatChangedSelection() {
      container.querySelectorAll('.what-changed-card').forEach(card => {
        const m = card.getAttribute('data-metric');
        if (m === selectedMetric) {
          card.style.borderColor = '#2563eb';
          card.style.backgroundColor = '#eff6ff';
          card.style.boxShadow = '0 2px 6px rgba(37,99,235,0.15)';
        } else {
          card.style.borderColor = 'var(--color-border)';
          card.style.backgroundColor = 'var(--color-surface)';
          card.style.boxShadow = 'none';
        }
      });
      const selectEl = container.querySelector('#perf-all-variances-select');
      if (selectEl) selectEl.value = selectedMetric;
    }

    function renderDriverPanel() {
      const driverContainer = container.querySelector('#why-it-changed-panel');
      if (!driverContainer) return;

      if (!activeDriverData) {
        driverContainer.innerHTML = `
          <div style="padding: 24px; text-align: center; color: var(--color-text-muted); font-size: 13px;">
            Select a key variance movement above to inspect account details and causal factors.
          </div>
        `;
        return;
      }

      const d = activeDriverData;
      const favorable = isFavorable(d.metric_name, d.absolute_change);
      const badgeClass = favorable ? 'badge-resolved' : 'badge-critical';
      const impactColor = favorable ? '#16a34a' : '#dc2626';

      driverContainer.innerHTML = `
        <div class="panel-header" style="border-bottom: 1px solid var(--color-border); padding-bottom: 14px; flex-wrap: wrap; gap: 12px;">
          <div>
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              <span class="badge badge-medium" style="font-size: 11px; text-transform: uppercase;">Root Cause Breakdown</span>
              <h3 class="panel-title" style="font-size: 16px; margin: 0;">${escapeHtml(d.display_name)}</h3>
              <span class="badge ${badgeClass}">${escapeHtml(d.formatted_change)}</span>
            </div>
            <p style="font-size: 13px; color: var(--color-text-secondary); margin-top: 6px; margin-bottom: 0;">
              <strong>Movement:</strong> ${escapeHtml(d.formatted_previous)} &rarr; ${escapeHtml(d.formatted_current)} (${escapeHtml(d.formatted_change)}) &bull; 
              <strong>Financial Impact:</strong> <span style="font-weight: 700; color: ${impactColor};">${formatCurrency(d.financial_impact)}</span>
            </p>
          </div>
          
          <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
            ${d.evidence && d.evidence.length > 0 ? `
              <button class="btn btn-outline btn-sm" id="btn-view-evidence-drawer" style="display: flex; align-items: center; gap: 6px;">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                <span>Evidence (${d.evidence.length})</span>
              </button>
            ` : ''}
            
            <button class="btn btn-outline btn-sm" id="btn-investigate-page" style="display: flex; align-items: center; gap: 6px;">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              <span>AI Analysis ↗</span>
            </button>

            <button class="btn btn-primary btn-sm" id="btn-inspect-in-drawer" style="display: flex; align-items: center; gap: 6px;">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <span>Review Details in Drawer &rarr;</span>
            </button>
          </div>
        </div>

        <div style="padding: 16px 0 6px 0;">
          <!-- Primary Factor Callout -->
          <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-left: 4px solid ${favorable ? '#16a34a' : '#dc2626'}; border-radius: 6px; padding: 12px 16px; margin-bottom: 16px;">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
              <span class="badge ${badgeClass}" style="font-size: 10px;">Primary Driver</span>
              <strong style="color: #0f172a; font-size: 13.5px;">${escapeHtml(d.primary_driver)}</strong>
            </div>
            <p style="margin: 0; font-size: 12.5px; line-height: 1.5; color: #334155;">
              ${escapeHtml(d.summary)}
            </p>
          </div>

          <!-- Contributing Factors Grid -->
          ${d.candidate_drivers && d.candidate_drivers.length > 0 ? `
            <div>
              <h4 style="font-size: 11.5px; font-weight: 700; color: var(--color-text-secondary); margin: 0 0 8px 0; text-transform: uppercase; letter-spacing: 0.5px;">
                Multivariate Contributing Factors (${d.candidate_drivers.length})
              </h4>
              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 10px;">
                ${d.candidate_drivers.map(cd => `
                  <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; display: flex; flex-direction: column; justify-content: space-between;">
                    <div>
                      <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; margin-bottom: 4px;">
                        <strong style="font-size: 13px; color: #0f172a;">${escapeHtml(cd.name)}</strong>
                        ${cd.impact_amount ? `
                          <span style="font-size: 12px; font-weight: 700; color: #dc2626; white-space: nowrap;">${formatCurrency(cd.impact_amount)}</span>
                        ` : ''}
                      </div>
                      <p style="margin: 0; font-size: 12px; color: #475569; line-height: 1.45;">
                        ${escapeHtml(cd.description)}
                      </p>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : ''}
        </div>
      `;

      // Button: Review Details in Drawer
      driverContainer.querySelector('#btn-inspect-in-drawer')?.addEventListener('click', () => {
        if (onOpenInvestigate) {
          onOpenInvestigate({
            type: 'metric',
            metric: d.metric_name,
            name: d.display_name,
            previous: d.formatted_previous,
            current: d.formatted_current,
            change: d.formatted_change,
            impact: d.financial_impact,
            primaryFactor: d.primary_driver,
            summary: d.summary,
            candidateDrivers: d.candidate_drivers,
            evidence: d.evidence
          });
        }
      });

      // Button: Direct Full AI Investigation
      driverContainer.querySelector('#btn-investigate-page')?.addEventListener('click', () => {
        if (onNavigate) {
          onNavigate('investigate', {
            question: `What caused the variance in ${d.display_name} and what actions should finance take to recover it?`,
            context: {
              type: 'metric',
              metric: d.metric_name,
              name: d.display_name,
              change: d.formatted_change,
              impact: d.financial_impact,
              primaryFactor: d.primary_driver,
            }
          });
        }
      });

      // Button: Evidence Drawer
      driverContainer.querySelector('#btn-view-evidence-drawer')?.addEventListener('click', () => {
        if (onOpenEvidence) {
          onOpenEvidence({
            title: `${d.display_name} — Driver Audit Evidence`,
            entity: d.primary_driver,
            evidenceList: d.evidence || [],
            context: {
              metric: d.metric_name,
              change: d.formatted_change,
              impact: formatCurrency(d.financial_impact),
              summary: d.summary,
            }
          });
        }
      });
    }

    function renderActiveTab() {
      const tabContainer = container.querySelector('#performance-tab-content');
      if (!tabContainer) return;

      if (activeTab === 'customers') {
        renderCustomersTab(tabContainer, pnlData, perfSummary, onNavigate, onOpenEvidence, onOpenInvestigate);
      } else if (activeTab === 'products') {
        renderProductsTab(tabContainer, pnlData, perfSummary, onOpenInvestigate);
      }
    }

    render();

  } catch (err) {
    container.innerHTML = `
      <div style="padding: 30px; color: var(--color-danger-text); background-color: var(--color-danger-bg); border-radius: var(--radius-md);">
        Error loading Performance view: ${escapeHtml(err.message)}
      </div>
    `;
  }
}

/**
 * Render clean, curated variance cards with accurate color badging.
 */
function renderCuratedVarianceCards(whatChangedItems, selectedMetric, onlyMaterial = false) {
  let filtered = whatChangedItems;
  if (onlyMaterial) {
    filtered = whatChangedItems.filter(i => i.is_material);
  }

  // Prioritized core executive metrics
  const priorityKeys = [
    'gross_margin_percent',
    'gross_profit',
    'revenue',
    'cogs',
    'accounts_receivable',
    'liquid_cash'
  ];

  let selectedItems = [];
  priorityKeys.forEach(key => {
    const found = filtered.find(item => item.metric_name === key);
    if (found) selectedItems.push(found);
  });

  // If selectedMetric is outside top 6, make sure it is visible
  if (selectedMetric && !selectedItems.some(i => i.metric_name === selectedMetric)) {
    const extra = filtered.find(i => i.metric_name === selectedMetric);
    if (extra) selectedItems.push(extra);
  }

  // Fallback if priorityKeys didn't match or for remaining cards
  if (selectedItems.length === 0) {
    selectedItems = filtered.slice(0, 6);
  }

  if (selectedItems.length === 0) {
    return `
      <div style="grid-column: 1 / -1; padding: 20px; text-align: center; color: var(--color-text-muted); font-size: 13px;">
        No material movements found for this fiscal period. Uncheck "Show Material Only" to view all tracked metrics.
      </div>
    `;
  }

  return selectedItems.map(item => {
    const isSelected = item.metric_name === selectedMetric;
    const favorable = isFavorable(item.metric_name, item.absolute_change);
    const deltaClass = favorable ? 'delta-pos' : 'delta-neg';

    return `
      <div class="what-changed-card" data-metric="${escapeHtml(item.metric_name)}" style="
        padding: 12px 14px;
        background: ${isSelected ? '#eff6ff' : 'var(--color-surface)'};
        border: 1px solid ${isSelected ? '#2563eb' : 'var(--color-border)'};
        border-radius: var(--radius-md);
        cursor: pointer;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 6px;
        transition: all 0.15s ease;
        box-shadow: ${isSelected ? '0 2px 6px rgba(37,99,235,0.15)' : 'none'};
      ">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 6px;">
          <span style="font-size: 12px; font-weight: ${isSelected ? '700' : '600'}; color: ${isSelected ? '#1d4ed8' : 'var(--color-text-primary)'}; line-height: 1.3;">
            ${escapeHtml(item.display_name)}
          </span>
          <span class="badge ${item.is_material ? 'badge-critical' : 'badge-low'}" style="font-size: 9.5px; padding: 1px 5px;">
            ${item.is_material ? 'Material' : 'Tied'}
          </span>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: baseline;">
          <span class="${deltaClass}" style="font-size: 13px; font-weight: 700; font-family: var(--font-mono);">
            ${escapeHtml(item.formatted_change)}
          </span>
          <span style="font-size: 10.5px; color: var(--color-text-muted);">vs prior</span>
        </div>
      </div>
    `;
  }).join('');
}

function renderCustomersTab(container, pnlData, perfSummary, onNavigate, onOpenEvidence, onOpenInvestigate) {
  // Merge P&L customers with richer Performance Driver attribution data
  const custDriversMap = (perfSummary.top_customer_drivers || []).reduce((acc, c) => {
    acc[c.entity_id] = c;
    return acc;
  }, {});

  const allCustomers = (pnlData.top_customers_by_revenue || []).map(c => {
    const driver = custDriversMap[c.entity_id] || {};
    return {
      ...c,
      driverChangeAmount: driver.change_amount ?? null,
      driverMarginChangePp: driver.margin_change_pp ?? null,
      driverExplanation: driver.explanation ?? null,
      driverStatus: driver.payment_status ?? null,
    };
  });

  let searchQuery = '';
  let statusFilter = 'ALL';

  function renderTableContent() {
    let filtered = allCustomers.filter(c => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchesName = (c.entity_name || '').toLowerCase().includes(q);
        const matchesId = (c.entity_id || '').toLowerCase().includes(q);
        if (!matchesName && !matchesId) return false;
      }
      if (statusFilter === 'OVERDUE') {
        const odAmount = c.additional_context?.overdue_amount ?? c.overdue_amount ?? 0;
        return odAmount > 0 || c.driverStatus === 'CRITICAL_OVERDUE' || c.driverStatus === 'DELINQUENT';
      }
      if (statusFilter === 'HEALTHY') {
        const odAmount = c.additional_context?.overdue_amount ?? c.overdue_amount ?? 0;
        return odAmount === 0 && c.driverStatus !== 'CRITICAL_OVERDUE';
      }
      return true;
    });

    const tbody = container.querySelector('#cust-table-tbody');
    if (!tbody) return;

    if (filtered.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="3" style="text-align: center; padding: 30px; color: var(--color-text-muted);">
            No customer accounts match your search or filter criteria.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = filtered.map(c => {
      const odAmount = c.additional_context?.overdue_amount ?? c.overdue_amount ?? 0;
      const isOverdue = odAmount > 0 || c.driverStatus === 'CRITICAL_OVERDUE' || c.driverStatus === 'DELINQUENT';

      return `
        <tr class="clickable-cust-row" data-cust-id="${escapeHtml(c.entity_id)}" style="cursor: pointer; ${isOverdue ? 'background-color: #fffbfa;' : ''}">
          <td>
            <strong style="color: var(--color-text-primary); font-size: 13.5px;">${escapeHtml(c.entity_name)}</strong>
            <div style="font-size: 11px; color: var(--color-text-muted); font-family: var(--font-mono);">
              ${escapeHtml(c.entity_id)} &bull; ${escapeHtml(c.additional_context?.segment || 'Enterprise')}
            </div>
          </td>
          <td class="amount font-semibold" style="font-size: 13.5px;">
            ${formatCurrency(c.amount)}
          </td>
          <td style="text-align: right;">
            <button class="btn ${isOverdue ? 'btn-primary' : 'btn-outline'} btn-sm btn-inspect-cust" data-cust-id="${escapeHtml(c.entity_id)}" style="padding: 4px 14px; font-size: 11.5px; font-weight: 600;">
              Inspect &rarr;
            </button>
          </td>
        </tr>
      `;
    }).join('');

    // Attach row & button clicks
    tbody.querySelectorAll('.btn-inspect-cust').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        triggerCustomerDrawer(btn.getAttribute('data-cust-id'));
      });
    });

    tbody.querySelectorAll('.clickable-cust-row').forEach(row => {
      row.addEventListener('click', () => {
        triggerCustomerDrawer(row.getAttribute('data-cust-id'));
      });
    });
  }

  container.innerHTML = `
    <div class="panel">
      <div class="panel-header" style="margin-bottom: 12px; flex-wrap: wrap; gap: 10px;">
        <div>
          <h3 class="panel-title" style="font-size: 14px;">Customer Accounts &amp; Commercial Health</h3>
          <p style="font-size: 12px; color: var(--color-text-muted); margin: 4px 0 0 0;">
            Click any row or Inspect to view CRM signals, invoices, and margin breakdown.
          </p>
        </div>
        
        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
          <!-- Real-time Search -->
          <input 
            type="text" 
            id="cust-search-input" 
            placeholder="Search account by name or ID..." 
            style="padding: 5px 10px; font-size: 12px; border: 1px solid var(--color-border); border-radius: var(--radius-sm); width: 200px;"
          />

          <!-- Status Filter -->
          <select id="cust-status-filter" class="period-select" style="font-size: 12px; padding: 4px 8px; width: auto;">
            <option value="ALL">All Accounts (${allCustomers.length})</option>
            <option value="OVERDUE">Overdue Accounts Only</option>
            <option value="HEALTHY">Current on Terms</option>
          </select>

          <!-- Export CSV -->
          <button id="btn-export-customers-csv" class="btn btn-outline btn-sm" style="display: flex; align-items: center; gap: 4px; font-size: 11.5px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      <div style="overflow-x: auto;">
        <table class="fin-table" style="width: 100%;">
          <thead>
            <tr>
              <th>Customer Account</th>
              <th class="amount">Monthly Revenue</th>
              <th style="text-align: right;">Action</th>
            </tr>
          </thead>
          <tbody id="cust-table-tbody"></tbody>
        </table>
      </div>
    </div>
  `;

  // Search input handler
  container.querySelector('#cust-search-input')?.addEventListener('input', (e) => {
    searchQuery = e.target.value.trim();
    renderTableContent();
  });

  // Filter handler
  container.querySelector('#cust-status-filter')?.addEventListener('change', (e) => {
    statusFilter = e.target.value;
    renderTableContent();
  });

  // Export CSV
  container.querySelector('#btn-export-customers-csv')?.addEventListener('click', () => {
    exportToCsv('finsight_customer_performance.csv', [
      { label: 'Customer Account', key: 'name' },
      { label: 'Customer ID', key: 'id' },
      { label: 'Segment', key: 'segment' },
      { label: 'Monthly Revenue', key: 'revenue' },
      { label: 'MoM Change', key: 'change' },
      { label: 'Share %', key: 'share' },
      { label: 'Gross Margin %', key: 'margin' },
      { label: 'Margin Change (pp)', key: 'marginChange' },
      { label: 'Overdue Exposure', key: 'overdue' },
      { label: 'Payment Terms', key: 'terms' }
    ], allCustomers.map(c => ({
      name: c.entity_name,
      id: c.entity_id,
      segment: c.additional_context?.segment || 'Enterprise',
      revenue: String(c.amount != null ? c.amount : ''),
      change: c.driverChangeAmount != null ? String(c.driverChangeAmount) : '—',
      share: c.percentage_of_total != null ? `${c.percentage_of_total.toFixed(1)}%` : '—',
      margin: c.additional_context?.gross_margin_percent != null ? `${c.additional_context.gross_margin_percent.toFixed(1)}%` : '—',
      marginChange: c.driverMarginChangePp != null ? `${c.driverMarginChangePp.toFixed(1)} pp` : '—',
      overdue: String(c.additional_context?.overdue_amount ?? c.overdue_amount ?? 0),
      terms: c.additional_context?.payment_terms || 'NET30'
    })));
  });

  function triggerCustomerDrawer(custId) {
    const c = allCustomers.find(item => item.entity_id === custId);
    if (!c) return;
    if (onOpenInvestigate) {
      onOpenInvestigate({
        type: 'customer',
        id: c.entity_id,
        name: c.entity_name,
        segment: c.additional_context?.segment || 'Enterprise',
        revenue: c.amount,
        share: c.percentage_of_total,
        margin: c.additional_context?.gross_margin_percent ?? 0,
        marginDelta: c.driverMarginChangePp ?? 0,
        overdue: c.additional_context?.overdue_amount ?? c.overdue_amount ?? 0,
        terms: c.additional_context?.payment_terms || 'NET30',
        summary: c.driverExplanation || c.additional_context?.summary || null
      });
    }
  }

  renderTableContent();
}

function renderProductsTab(container, pnlData, perfSummary, onOpenInvestigate) {
  // Merge product margins with richer driver intelligence
  const prodDriversMap = (perfSummary.top_product_drivers || []).reduce((acc, p) => {
    acc[(p.entity_name || p.entity_id).toLowerCase()] = p;
    return acc;
  }, {});

  const groups = (pnlData.product_group_margins || []).map(g => {
    const name = g.product_group || g.group_name || 'Group';
    const driver = prodDriversMap[name.toLowerCase()] || {};
    return {
      ...g,
      name,
      marginChangePp: driver.margin_change_pp ?? null,
      driverChangeAmount: driver.change_amount ?? null,
      explanation: driver.explanation ?? null,
    };
  });

  container.innerHTML = `
    <div class="panel">
      <div class="panel-header" style="margin-bottom: 12px; flex-wrap: wrap; gap: 10px;">
        <div>
          <h3 class="panel-title" style="font-size: 14px;">Product Line Margins &amp; Cost Performance</h3>
          <p style="font-size: 12px; color: var(--color-text-muted); margin: 4px 0 0 0;">
            High-level product portfolio. Click any row or Inspect to view COGS breakdown, volume buyers, and margin drivers.
          </p>
        </div>
        <button id="btn-export-products-csv" class="btn btn-outline btn-sm" style="display: flex; align-items: center; gap: 4px; font-size: 11.5px;">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          <span>Export CSV</span>
        </button>
      </div>

      <div style="overflow-x: auto;">
        <table class="fin-table" style="width: 100%;">
          <thead>
            <tr>
              <th>Product Group</th>
              <th class="amount">Monthly Revenue</th>
              <th style="text-align: right;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${groups.map(g => {
              const name = g.name;
              const rev = g.revenue || 0;

              return `
                <tr class="clickable-prod-row" data-product="${escapeHtml(name)}" style="cursor: pointer;">
                  <td>
                    <strong style="color: var(--color-text-primary); font-size: 13.5px;">${escapeHtml(name)}</strong>
                    <div style="font-size: 11px; color: var(--color-text-muted);">Product Portfolio Segment</div>
                  </td>
                  <td class="amount font-semibold" style="font-size: 13.5px;">${formatCurrency(rev)}</td>
                  <td style="text-align: right;">
                    <button class="btn btn-outline btn-sm btn-inspect-product" data-product="${escapeHtml(name)}" style="padding: 4px 14px; font-size: 11.5px; font-weight: 600;">
                      Inspect &rarr;
                    </button>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.querySelector('#btn-export-products-csv')?.addEventListener('click', () => {
    exportToCsv('finsight_product_margins.csv', [
      { label: 'Product Group', key: 'group' },
      { label: 'Revenue', key: 'rev' },
      { label: 'COGS', key: 'cogs' },
      { label: 'Gross Profit', key: 'gp' },
      { label: 'Gross Margin %', key: 'margin' },
      { label: 'Margin Change (pp)', key: 'marginDelta' }
    ], groups.map(g => {
      const name = g.name;
      const rev = g.revenue || 0;
      const cogs = g.cogs || 0;
      const gp = g.gross_profit !== undefined ? g.gross_profit : (rev - cogs);
      const gm = g.gross_margin_percent !== undefined ? g.gross_margin_percent : (rev > 0 ? (gp / rev * 100) : 0);
      return {
        group: name,
        rev: String(rev),
        cogs: String(cogs),
        gp: String(gp),
        margin: `${gm.toFixed(1)}%`,
        marginDelta: g.marginChangePp != null ? `${g.marginChangePp.toFixed(1)} pp` : '—'
      };
    }));
  });

  function triggerProductDrawer(prodName) {
    const g = groups.find(item => item.name === prodName);
    if (!g) return;
    const rev = g.revenue || 0;
    const cogs = g.cogs || 0;
    const gp = g.gross_profit !== undefined ? g.gross_profit : (rev - cogs);
    const gm = g.gross_margin_percent !== undefined ? g.gross_margin_percent : (rev > 0 ? (gp / rev * 100) : 0);
    if (onOpenInvestigate) {
      onOpenInvestigate({
        type: 'product',
        name: prodName,
        revenue: rev,
        cogs: cogs,
        grossProfit: gp,
        margin: gm,
        marginDelta: g.marginChangePp || 0,
        summary: g.explanation || null
      });
    }
  }

  container.querySelectorAll('.btn-inspect-product').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const prodName = btn.getAttribute('data-product');
      triggerProductDrawer(prodName);
    });
  });

  container.querySelectorAll('.clickable-prod-row').forEach(row => {
    row.addEventListener('click', () => {
      const prodName = row.getAttribute('data-product');
      triggerProductDrawer(prodName);
    });
  });
}
