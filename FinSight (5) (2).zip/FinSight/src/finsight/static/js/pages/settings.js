import { auth } from '../services/auth.js';

export async function renderSettings(container, api) {
  let config = null;
  let users = null;
  const currentUser = auth.getUser();
  const isAdmin = auth.isAdmin();

  if (api && isAdmin) {
    try {
      const results = await Promise.all([
        api.getAdminConfig().catch(() => null),
        api.getAdminUsers().catch(() => null)
      ]);
      config = results[0];
      users = results[1];
    } catch (e) {
      console.warn('Could not load live admin config/users:', e);
    }
  }

  const companyCode = config?.company_code || '1000';
  const currency = config?.currency === 'INR' ? 'Indian Rupee (₹ / INR)' : (config?.currency || 'Indian Rupee (₹ / INR)');
  const erpConnector = 'SAP S/4HANA Finance';
  const environment = config?.environment ? (config.environment.charAt(0).toUpperCase() + config.environment.slice(1)) : 'Production';
  const engineVersion = config?.version ? `v${config.version}` : 'v0.2.0';

  // Current active user details
  const profileName = currentUser?.full_name || 'Samarth';
  const profileUsername = currentUser?.username || 'admin';
  const profileEmail = currentUser?.email || 'samarth@finsight.internal';
  const profileRole = currentUser?.role || 'ADMIN';
  const initial = profileName.charAt(0).toUpperCase();

  function getRoleBadge(role) {
    if (role === 'ADMIN') {
      return `<span style="display: inline-flex; align-items: center; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 4px; background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;">
        Finance Admin
      </span>`;
    }
    if (role === 'FINANCE_MANAGER') {
      return `<span style="display: inline-flex; align-items: center; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 4px; background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe;">
        Finance Manager
      </span>`;
    }
    return `<span style="display: inline-flex; align-items: center; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 4px; background: #f8fafc; color: #475569; border: 1px solid #cbd5e1;">
      Finance Analyst
    </span>`;
  }

  function getAvatarGradient(name = '') {
    if (name.startsWith('S')) return 'linear-gradient(135deg, #2563eb, #1d4ed8)';
    if (name.startsWith('P') || name.startsWith('T')) return 'linear-gradient(135deg, #7c3aed, #6d28d9)';
    return 'linear-gradient(135deg, #0d9488, #0f766e)';
  }

  const userList = (isAdmin && users && users.length > 0) ? users : (currentUser ? [currentUser] : []);

  const usersRowsHtml = userList.map(u => {
    const uInitial = (u.full_name || u.username || 'U')[0].toUpperCase();
    return `
      <tr style="border-bottom: 1px solid var(--color-border);">
        <td style="padding: 12px 16px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 30px; height: 30px; border-radius: 50%; background: ${getAvatarGradient(u.full_name || u.username)}; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700;">
              ${uInitial}
            </div>
            <div>
              <div style="font-weight: 600; color: var(--color-text-primary); font-size: 13px;">${u.full_name || u.username}</div>
              <div style="font-size: 11px; color: var(--color-text-muted); font-family: var(--font-mono);">@${u.username}</div>
            </div>
          </div>
        </td>
        <td style="padding: 12px 16px; font-family: var(--font-mono); font-size: 12px; color: var(--color-text-secondary);">
          ${u.email || `${u.username}@finsight.internal`}
        </td>
        <td style="padding: 12px 16px;">
          ${getRoleBadge(u.role)}
        </td>
        <td style="padding: 12px 16px; text-align: right;">
          <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 600; color: #16a34a;">
            <span style="width: 6px; height: 6px; border-radius: 50%; background-color: #16a34a;"></span>
            Active
          </span>
        </td>
      </tr>
    `;
  }).join('');

  container.innerHTML = `
    <div class="settings-workspace" style="display: flex; flex-direction: column; gap: 20px; max-width: 980px; margin: 0 auto; padding-bottom: 40px;">
      
      <!-- Page Header -->
      <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--color-border); padding-bottom: 14px;">
        <div>
          <h2 style="font-size: 20px; font-weight: 700; color: var(--color-text-primary); letter-spacing: -0.3px;">
            Settings
          </h2>
          <p style="font-size: 13px; color: var(--color-text-muted); margin-top: 2px;">
            User profile, core system configurations, and operational parameters.
          </p>
        </div>
        <div>
          <span style="display: inline-flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 600; padding: 4px 10px; border-radius: 999px; background-color: var(--color-surface-subtle); color: var(--color-text-secondary); border: 1px solid var(--color-border);">
            FinSight ${engineVersion} • ${environment}
          </span>
        </div>
      </div>

      <!-- 1. Profile Section (Pehle Profile) -->
      <div class="panel" style="background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-sm);">
        <div style="padding: 14px 20px; border-bottom: 1px solid var(--color-border); background-color: #fafbfd; display: flex; justify-content: space-between; align-items: center;">
          <h3 style="font-size: 14px; font-weight: 700; color: var(--color-text-primary); display: flex; align-items: center; gap: 8px;">
            <span>👤 User Profile</span>
          </h3>
          <span style="display: inline-flex; align-items: center; gap: 5px; font-size: 11px; font-weight: 600; color: #16a34a; background: #f0fdf4; border: 1px solid #bbf7d0; padding: 2px 8px; border-radius: 4px;">
            <span style="width: 6px; height: 6px; border-radius: 50%; background-color: #16a34a;"></span>
            Active Session
          </span>
        </div>

        <div style="padding: 20px;">
          <!-- Profile Main Details Card -->
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; padding: 16px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-md);">
            <div style="display: flex; align-items: center; gap: 16px;">
              <div style="width: 52px; height: 52px; border-radius: 50%; background: ${getAvatarGradient(profileName)}; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 22px; font-weight: 700; box-shadow: 0 2px 8px rgba(0,0,0,0.12);">
                ${initial}
              </div>
              <div>
                <div style="display: flex; align-items: center; gap: 8px;">
                  <h4 style="font-size: 16px; font-weight: 700; color: var(--color-text-primary); margin: 0;">${profileName}</h4>
                  ${getRoleBadge(profileRole)}
                </div>
                <div style="display: flex; align-items: center; gap: 12px; margin-top: 4px; font-size: 12px; color: var(--color-text-secondary);">
                  <span style="font-family: var(--font-mono);">@${profileUsername}</span>
                  <span>•</span>
                  <span>${profileEmail}</span>
                </div>
              </div>
            </div>

            <div style="display: flex; align-items: center; gap: 10px;">
              <button id="btnSettingsSignOut" class="btn btn-secondary btn-sm" style="font-size: 12px; padding: 6px 14px; border: 1px solid var(--color-border); border-radius: 6px; cursor: pointer; background: #ffffff; color: var(--color-text-primary);">
                Sign Out
              </button>
            </div>
          </div>

          <!-- Quick Profile Attributes -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-top: 14px;">
            <div style="padding: 10px 14px; background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm);">
              <div style="font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600;">Governance Role</div>
              <div style="font-size: 13px; font-weight: 600; color: var(--color-text-primary); margin-top: 2px;">
                ${profileRole === 'ADMIN' ? 'Finance Admin (Full Access)' : (profileRole === 'FINANCE_MANAGER' ? 'Finance Manager (Cases & Sign-off)' : 'Finance Analyst (Read-Only)')}
              </div>
            </div>
            <div style="padding: 10px 14px; background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm);">
              <div style="font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600;">Authentication Mode</div>
              <div style="font-size: 13px; font-weight: 600; color: var(--color-text-primary); margin-top: 2px;">Bearer Token / RBAC</div>
            </div>
            <div style="padding: 10px 14px; background: #ffffff; border: 1px solid var(--color-border); border-radius: var(--radius-sm);">
              <div style="font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600;">Assigned Entity</div>
              <div style="font-size: 13px; font-weight: 600; color: var(--color-text-primary); margin-top: 2px;">Company Code: ${companyCode}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 2. System & ERP Settings (Sirf zaroori settings) -->
      <div class="panel" style="background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-sm);">
        <div style="padding: 14px 20px; border-bottom: 1px solid var(--color-border); background-color: #fafbfd; display: flex; justify-content: space-between; align-items: center;">
          <h3 style="font-size: 14px; font-weight: 700; color: var(--color-text-primary); display: flex; align-items: center; gap: 8px;">
            <span>⚙️ System & ERP Configuration</span>
          </h3>
          <span style="font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: var(--radius-sm); background-color: var(--color-blue-subtle); color: var(--color-blue-primary); border: 1px solid var(--color-blue-border);">
            Connected
          </span>
        </div>
        <div style="padding: 20px; display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 14px;">
          <div style="padding: 12px 14px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-md);">
            <div style="font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600;">Operating Entity</div>
            <div style="font-size: 13.5px; font-weight: 600; color: var(--color-text-primary); margin-top: 3px;">FinSight Technologies Inc.</div>
            <div style="font-size: 11px; font-family: var(--font-mono); color: var(--color-text-secondary); margin-top: 2px;">Company Code: ${companyCode}</div>
          </div>
          <div style="padding: 12px 14px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-md);">
            <div style="font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600;">Reporting Currency</div>
            <div style="font-size: 13.5px; font-weight: 600; color: var(--color-text-primary); margin-top: 3px;">${currency}</div>
            <div style="font-size: 11px; color: var(--color-text-secondary); margin-top: 2px;">Standard GL currency</div>
          </div>
          <div style="padding: 12px 14px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-md);">
            <div style="font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600;">ERP Connector</div>
            <div style="font-size: 13.5px; font-weight: 600; color: var(--color-text-primary); margin-top: 3px;">${erpConnector}</div>
            <div style="font-size: 11px; color: #16a34a; font-weight: 600; margin-top: 2px;">Universal Journal (ACDOCA)</div>
          </div>
          <div style="padding: 12px 14px; background: var(--color-surface-subtle); border: 1px solid var(--color-border); border-radius: var(--radius-md);">
            <div style="font-size: 11px; text-transform: uppercase; color: var(--color-text-muted); font-weight: 600;">Environment & Version</div>
            <div style="font-size: 13.5px; font-weight: 600; color: var(--color-text-primary); margin-top: 3px;">${environment}</div>
            <div style="font-size: 11px; color: var(--color-text-secondary); margin-top: 2px;">Engine ${engineVersion}</div>
          </div>
        </div>
      </div>

      <!-- 3. Governance & Alert Thresholds (Concise, no stories) -->
      <div class="panel" style="background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-sm);">
        <div style="padding: 14px 20px; border-bottom: 1px solid var(--color-border); background-color: #fafbfd; display: flex; justify-content: space-between; align-items: center;">
          <h3 style="font-size: 14px; font-weight: 700; color: var(--color-text-primary); display: flex; align-items: center; gap: 8px;">
            <span>🎯 Financial Governance Thresholds</span>
          </h3>
          <span style="font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: var(--radius-sm); background-color: #f1f5f9; color: var(--color-text-secondary); border: 1px solid var(--color-border);">
            Active Rules
          </span>
        </div>
        <div style="padding: 20px; display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 14px;">
          <div style="border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 14px; background: #ffffff;">
            <div style="font-size: 11px; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted);">Floor Materiality</div>
            <div style="font-size: 20px; font-weight: 700; color: var(--color-text-primary); font-family: var(--font-mono); margin: 6px 0 2px 0;">₹50,000</div>
            <div style="font-size: 11.5px; color: var(--color-text-secondary);">Minimum variance impact</div>
          </div>

          <div style="border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 14px; background: #ffffff;">
            <div style="font-size: 11px; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted);">MoM Variance Trigger</div>
            <div style="font-size: 20px; font-weight: 700; color: #2563eb; font-family: var(--font-mono); margin: 6px 0 2px 0;">10.0%</div>
            <div style="font-size: 11.5px; color: var(--color-text-secondary);">Relative period movement</div>
          </div>

          <div style="border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 14px; background: #ffffff;">
            <div style="font-size: 11px; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted);">DSO Sensitivity</div>
            <div style="font-size: 20px; font-weight: 700; color: #b45309; font-family: var(--font-mono); margin: 6px 0 2px 0;">+5.0 Days</div>
            <div style="font-size: 11.5px; color: var(--color-text-secondary);">Working capital deterioration</div>
          </div>

          <div style="border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 14px; background: #ffffff;">
            <div style="font-size: 11px; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted);">Credit Exposure Ceiling</div>
            <div style="font-size: 20px; font-weight: 700; color: #dc2626; font-family: var(--font-mono); margin: 6px 0 2px 0;">25.0%</div>
            <div style="font-size: 11.5px; color: var(--color-text-secondary);">Delinquent AR concentration</div>
          </div>
        </div>
      </div>

      <!-- 4. Authorized Finance Team Directory (Clean table) -->
      ${isAdmin ? `
      <div class="panel" style="background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-sm);">
        <div style="padding: 14px 20px; border-bottom: 1px solid var(--color-border); background-color: #fafbfd; display: flex; justify-content: space-between; align-items: center;">
          <h3 style="font-size: 14px; font-weight: 700; color: var(--color-text-primary); display: flex; align-items: center; gap: 8px;">
            <span>👥 Authorized Team (${userList.length})</span>
          </h3>
          <span style="font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: var(--radius-sm); background-color: var(--color-success-bg); color: var(--color-success-text); border: 1px solid var(--color-success-border);">
            Role-Based Access
          </span>
        </div>
        <div style="overflow-x: auto;">
          <table style="width: 100%; border-collapse: collapse; font-size: 12.5px; text-align: left;">
            <thead>
              <tr style="background-color: var(--color-surface-subtle); border-bottom: 1px solid var(--color-border); color: var(--color-text-muted); font-size: 11px; text-transform: uppercase;">
                <th style="padding: 10px 16px; font-weight: 600;">User</th>
                <th style="padding: 10px 16px; font-weight: 600;">Email</th>
                <th style="padding: 10px 16px; font-weight: 600;">Role</th>
                <th style="padding: 10px 16px; font-weight: 600; text-align: right;">Status</th>
              </tr>
            </thead>
            <tbody>
              ${usersRowsHtml}
            </tbody>
          </table>
        </div>
      </div>
      ` : ''}

    </div>
  `;

  // Attach Sign Out button listener if present
  const signOutBtn = container.querySelector('#btnSettingsSignOut');
  if (signOutBtn) {
    signOutBtn.addEventListener('click', () => {
      api.logout().catch(() => {});
      auth.clearSession();
      window.location.reload();
    });
  }
}
