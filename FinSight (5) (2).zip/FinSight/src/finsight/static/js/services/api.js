/**
 * FinSight API Client Service
 * Encapsulates all backend REST calls to deterministic engine, metrics, intelligence, attention, AI investigator, and cases.
 */

import { auth } from './auth.js';

const API_BASE = window.location.origin;

class FinSightAPI {
  constructor() {
    this.currentPeriod = '2026-09';
    this.periods = [
      '2025-10', '2025-11', '2025-12',
      '2026-01', '2026-02', '2026-03',
      '2026-04', '2026-05', '2026-06',
      '2026-07', '2026-08', '2026-09'
    ];
  }

  setPeriod(period) {
    this.currentPeriod = period;
  }

  async fetchAvailablePeriods() {
    try {
      const status = await this._request('/api/status');
      if (status && Array.isArray(status.available_periods) && status.available_periods.length > 0) {
        this.periods = status.available_periods;
        if (!this.periods.includes(this.currentPeriod)) {
          this.currentPeriod = status.latest_period || this.periods[this.periods.length - 1];
        }
      }
      return this.periods;
    } catch (e) {
      console.warn('Could not fetch available periods dynamically:', e);
      return this.periods;
    }
  }

  async _request(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const token = auth.getToken();
    const defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...defaultHeaders,
          ...(options.headers || {})
        }
      });

      if (!response.ok) {
        if (response.status === 401 && token) {
          auth.clearSession();
        }
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `HTTP Error ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    } catch (err) {
      console.error(`API Error on ${endpoint}:`, err);
      throw err;
    }
  }

  // Summary & Foundational Metrics
  async getSummary(period = this.currentPeriod) {
    return this._request(`/api/financial-summary?period=${encodeURIComponent(period)}`);
  }

  async getCash(period = this.currentPeriod) {
    return this._request(`/api/cash?period=${encodeURIComponent(period)}`);
  }

  async getWorkingCapital(period = this.currentPeriod) {
    return this._request(`/api/working-capital?period=${encodeURIComponent(period)}`);
  }

  async getReceivables(period = this.currentPeriod) {
    return this._request(`/api/receivables?period=${encodeURIComponent(period)}`);
  }

  async getPayables(period = this.currentPeriod) {
    return this._request(`/api/payables?period=${encodeURIComponent(period)}`);
  }

  async getInventory(period = this.currentPeriod) {
    return this._request(`/api/inventory?period=${encodeURIComponent(period)}`);
  }

  async getProfitability(period = this.currentPeriod) {
    return this._request(`/api/profitability?period=${encodeURIComponent(period)}`);
  }

  // Sprint 9: Performance & Driver Intelligence
  async getPerformanceSummary(period = this.currentPeriod) {
    return this._request(`/api/performance/summary?period=${encodeURIComponent(period)}`);
  }

  async getPerformanceWhatChanged(period = this.currentPeriod, onlyMaterial = false) {
    return this._request(`/api/performance/what-changed?period=${encodeURIComponent(period)}&only_material=${onlyMaterial}`);
  }

  async getPerformanceDrivers(metric = 'gross_margin_percent', period = this.currentPeriod) {
    return this._request(`/api/performance/drivers?metric=${encodeURIComponent(metric)}&period=${encodeURIComponent(period)}`);
  }

  async getPerformanceCustomers(period = this.currentPeriod, metric = 'gross_profit') {
    return this._request(`/api/performance/customers?period=${encodeURIComponent(period)}&metric=${encodeURIComponent(metric)}`);
  }

  async getPerformanceProducts(period = this.currentPeriod, metric = 'gross_profit') {
    return this._request(`/api/performance/products?period=${encodeURIComponent(period)}&metric=${encodeURIComponent(metric)}`);
  }

  async getCRMProfile(customerId) {
    return this._request(`/api/crm/customers/${encodeURIComponent(customerId)}`);
  }

  // Layer 1: Financial Intelligence
  async getIntelligenceReport(period = this.currentPeriod) {
    return this._request(`/api/intelligence?period=${encodeURIComponent(period)}`);
  }

  // Layer 2: Financial Attention
  async getAttentionSummary(period = this.currentPeriod, severity = null, type = null) {
    let q = `/api/attention?period=${encodeURIComponent(period)}`;
    if (severity) q += `&severity=${encodeURIComponent(severity)}`;
    if (type) q += `&type=${encodeURIComponent(type)}`;
    return this._request(q);
  }

  // Layer 3: AI Investigation
  async investigate(question, period = this.currentPeriod, context = null) {
    return this._request('/api/investigate', {
      method: 'POST',
      body: JSON.stringify({ question, period, context })
    });
  }

  async askAI(question, period = this.currentPeriod) {
    return this._request('/api/ai/ask', {
      method: 'POST',
      body: JSON.stringify({ question, period })
    });
  }

  // Cases Management
  async getCases(status = null, severity = null, category = null) {
    let q = '/api/cases?';
    const params = [];
    if (status) params.push(`status=${encodeURIComponent(status)}`);
    if (severity) params.push(`severity=${encodeURIComponent(severity)}`);
    if (category) params.push(`category=${encodeURIComponent(category)}`);
    q += params.join('&');
    return this._request(q);
  }

  async getCase(caseId) {
    return this._request(`/api/cases/${encodeURIComponent(caseId)}`);
  }

  async createCase(payload) {
    return this._request('/api/cases', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateCase(caseId, payload) {
    return this._request(`/api/cases/${encodeURIComponent(caseId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload)
    });
  }

  // Governance & Quality
  async getDataQuality() {
    return this._request('/api/data-quality');
  }

  async getSnapshot() {
    return this._request('/api/snapshot');
  }

  async getReconciliation(period = this.currentPeriod) {
    const q = period ? `/api/reconciliation?period=${encodeURIComponent(period)}` : '/api/reconciliation';
    return this._request(q);
  }

  async refreshData() {
    return this._request('/api/refresh', { method: 'POST' });
  }

  // Layer 4: Finance Knowledge Base
  async getKnowledgeDocuments(status = null) {
    const q = status ? `/api/knowledge/documents?status=${encodeURIComponent(status)}` : '/api/knowledge/documents';
    return this._request(q);
  }

  async getKnowledgeDocument(documentId) {
    return this._request(`/api/knowledge/documents/${encodeURIComponent(documentId)}`);
  }

  async searchKnowledge(query, domain = null, documentType = null, effectiveDate = null, topK = 5) {
    let q = `/api/knowledge/search?query=${encodeURIComponent(query)}&top_k=${topK}`;
    if (domain) q += `&domain=${encodeURIComponent(domain)}`;
    if (documentType) q += `&document_type=${encodeURIComponent(documentType)}`;
    if (effectiveDate) q += `&effective_date=${encodeURIComponent(effectiveDate)}`;
    return this._request(q);
  }

  async getKnowledgeSummary() {
    return this._request('/api/knowledge/summary');
  }

  // Phase 6: Control Intelligence
  async getControls(domain = null, status = null) {
    let q = '/api/controls?';
    const params = [];
    if (domain) params.push(`domain=${encodeURIComponent(domain)}`);
    if (status) params.push(`status=${encodeURIComponent(status)}`);
    q += params.join('&');
    return this._request(q);
  }

  async getControl(controlId) {
    return this._request(`/api/controls/${encodeURIComponent(controlId)}`);
  }

  async getControlAssessments(period = this.currentPeriod, status = null, severity = null) {
    let q = `/api/control-assessments?period=${encodeURIComponent(period)}`;
    if (status) q += `&status=${encodeURIComponent(status)}`;
    if (severity) q += `&severity=${encodeURIComponent(severity)}`;
    return this._request(q);
  }

  async getControlSummary(period = this.currentPeriod) {
    return this._request(`/api/control-assessments/summary?period=${encodeURIComponent(period)}`);
  }

  async getControlAssessment(controlId, period = this.currentPeriod) {
    return this._request(`/api/control-assessments/${encodeURIComponent(controlId)}?period=${encodeURIComponent(period)}`);
  }

  async createCaseFromAssessment(controlId, assignedOwner = null, dueDate = null) {
    return this._request(`/api/control-assessments/${encodeURIComponent(controlId)}/create-case`, {
      method: 'POST',
      body: JSON.stringify({ assigned_owner: assignedOwner, due_date: dueDate })
    });
  }

  // Phase 7: Case Remediation Workflow
  async addRemediationAction(caseId, actionPayload) {
    return this._request(`/api/cases/${encodeURIComponent(caseId)}/remediation-action`, {
      method: 'POST',
      body: JSON.stringify(actionPayload)
    });
  }

  async closeCase(caseId, closePayload) {
    return this._request(`/api/cases/${encodeURIComponent(caseId)}/close`, {
      method: 'POST',
      body: JSON.stringify(closePayload)
    });
  }

  async getCaseAuditTrail(caseId) {
    return this._request(`/api/cases/${encodeURIComponent(caseId)}/audit-trail`);
  }

  // Phase 8: Cash Outlook & Scenario Intelligence
  async getCashForecast(horizonDays = 30, scenario = 'BASE', period = this.currentPeriod) {
    return this._request(
      `/api/forecast/cash?horizon_days=${encodeURIComponent(horizonDays)}&scenario=${encodeURIComponent(scenario)}&period=${encodeURIComponent(period)}`
    );
  }

  async compareForecastScenarios(horizonDays = 30, period = this.currentPeriod) {
    return this._request(
      `/api/forecast/scenarios?horizon_days=${encodeURIComponent(horizonDays)}&period=${encodeURIComponent(period)}`
    );
  }

  async getForecastLiquidityRisk(horizonDays = 30, period = this.currentPeriod) {
    return this._request(
      `/api/forecast/liquidity-risk?horizon_days=${encodeURIComponent(horizonDays)}&period=${encodeURIComponent(period)}`
    );
  }

  // Sprint 10: Financial Data Trust & Metric Reconciliation
  async getTrustSummary(period = this.currentPeriod) {
    return this._request(`/api/trust/summary?period=${encodeURIComponent(period)}`);
  }

  async getMetricCatalog() {
    return this._request('/api/trust/catalog');
  }

  async getMetricDefinition(metricName) {
    return this._request(`/api/trust/catalog/${encodeURIComponent(metricName)}`);
  }

  async getTrustMappings() {
    return this._request('/api/trust/mappings');
  }

  async getTrustReconciliation(period = this.currentPeriod, tolerance = null) {
    let url = `/api/trust/reconciliation?period=${encodeURIComponent(period)}`;
    if (tolerance !== null && tolerance !== undefined) {
      url += `&tolerance=${encodeURIComponent(tolerance)}`;
    }
    return this._request(url);
  }

  async getMetricLineage(metricName, period = this.currentPeriod) {
    return this._request(`/api/trust/metrics/${encodeURIComponent(metricName)}/lineage?period=${encodeURIComponent(period)}`);
  }

  async getGovernedMetrics(period = this.currentPeriod) {
    return this._request(`/api/trust/metrics?period=${encodeURIComponent(period)}`);
  }

  // Sprint 11: CFO Ratio Cockpit & Historical Financial Intelligence
  async getRatios(period = this.currentPeriod) {
    return this._request(`/api/ratios?period=${encodeURIComponent(period)}`);
  }

  async getMetricHistory(metricName) {
    return this._request(`/api/metrics/${encodeURIComponent(metricName)}/history`);
  }

  // Sprint 11: Authentication & RBAC APIs
  async login(username, password) {
    return this._request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });
  }

  async logout() {
    return this._request('/api/auth/logout', {
      method: 'POST'
    });
  }

  async getMe() {
    return this._request('/api/auth/me');
  }

  async getAdminUsers() {
    return this._request('/api/admin/users');
  }

  async getAdminConfig() {
    return this._request('/api/admin/config');
  }
}

export const api = new FinSightAPI();
