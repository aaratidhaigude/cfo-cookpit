/**
 * Client-Side Authentication & Session Manager
 */

const TOKEN_KEY = 'finsight_auth_token';
const USER_KEY = 'finsight_auth_user';

class AuthService {
  constructor() {
    this._listeners = [];
  }

  getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }

  getUser() {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  isAuthenticated() {
    const token = this.getToken();
    const user = this.getUser();
    return Boolean(token && user);
  }

  setSession(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    this._notify();
  }

  clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this._notify();
  }

  getRole() {
    return this.getUser()?.role || null;
  }

  isAdmin() {
    return this.getRole() === 'ADMIN';
  }

  isFinanceManager() {
    const r = this.getRole();
    return r === 'ADMIN' || r === 'FINANCE_MANAGER';
  }

  isFinanceAnalyst() {
    return this.getRole() === 'FINANCE_ANALYST';
  }

  subscribe(listener) {
    this._listeners.push(listener);
    return () => {
      this._listeners = this._listeners.filter(l => l !== listener);
    };
  }

  _notify() {
    const isAuth = this.isAuthenticated();
    const user = this.getUser();
    for (const listener of this._listeners) {
      try {
        listener({ isAuthenticated: isAuth, user });
      } catch (e) {
        console.error('Auth listener error:', e);
      }
    }
  }
}

export const auth = new AuthService();
