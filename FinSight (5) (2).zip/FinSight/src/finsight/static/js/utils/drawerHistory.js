/**
 * FinSight Drawer & Overlay History Manager
 * Provides lightweight browser back button (history / popstate) handling for drawers and modal overlays.
 *
 * Expected behavior:
 * Page -> open drawer -> URL/history gets lightweight drawer state (#drawer-id)
 * Browser Back -> drawer closes -> user remains on the same page and same context.
 *
 * Preserves:
 * - Escape-to-close
 * - backdrop close
 * - existing close buttons
 * - page navigation
 * - context parameters
 */

let drawerStack = [];

// Listen to browser popstate globally once
if (typeof window !== 'undefined') {
  window.addEventListener('popstate', (event) => {
    if (drawerStack.length > 0) {
      const top = drawerStack[drawerStack.length - 1];
      // If the active state in history is no longer this drawer, Back was pressed
      if (!event.state || event.state.drawer !== top.id) {
        top.closedByPopstate = true;
        drawerStack.pop();
        try {
          top.close();
        } catch (err) {
          console.warn(`Error closing drawer '${top.id}' on popstate:`, err);
        }
      }
    }
  });
}

/**
 * Register opening of a drawer or overlay.
 * Pushes lightweight state into history and updates URL hash.
 * @param {string} id - Identifier, e.g. 'trust-drawer', 'fin-inspect-drawer'
 * @param {Function} closeFn - Callback to close the drawer or overlay
 */
export function pushDrawerHistory(id, closeFn) {
  // Prevent duplicate stack entries for the same drawer
  if (drawerStack.length > 0 && drawerStack[drawerStack.length - 1].id === id) {
    return;
  }

  const hash = '#' + id;
  try {
    window.history.pushState({ drawer: id }, '', hash);
  } catch (err) {
    console.warn('history.pushState failed:', err);
  }

  drawerStack.push({
    id,
    close: closeFn,
    closedByPopstate: false,
  });
}

/**
 * Notify that a drawer or overlay was closed by user interaction (Escape, backdrop, close button).
 * Pops the history entry if it was not closed via popstate.
 * @param {string} id
 */
export function popDrawerHistory(id) {
  const index = drawerStack.findIndex(d => d.id === id);
  if (index !== -1) {
    const entry = drawerStack[index];
    drawerStack.splice(index, 1);
    if (!entry.closedByPopstate) {
      if (window.history.state?.drawer === id || window.location.hash === '#' + id) {
        try {
          window.history.back();
        } catch (err) {
          console.warn('history.back failed:', err);
        }
      }
    }
  }
}
