/**
 * Universal Formatting Utilities for FinSight
 * Currency: Indian Rupee (₹ / INR)
 */

export function formatCurrency(val, decimals = 0) {
  if (val === null || val === undefined || isNaN(val)) return '—';
  const num = Number(val);
  const sign = num < 0 ? '-' : '';
  return `${sign}₹${Math.abs(num).toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}`;
}

export function formatCompactCurrency(amount) {
  if (amount == null || isNaN(amount)) return '—';
  const abs = Math.abs(amount);
  const sign = amount < 0 ? '-' : '';
  if (abs >= 10000000) {
    return `${sign}₹${(abs / 10000000).toLocaleString('en-IN', { minimumFractionDigits: 1, maximumFractionDigits: 2 })} Cr`;
  }
  if (abs >= 100000) {
    return `${sign}₹${(abs / 100000).toLocaleString('en-IN', { minimumFractionDigits: 1, maximumFractionDigits: 2 })} L`;
  }
  if (abs >= 1000) {
    return `${sign}₹${(abs / 1000).toLocaleString('en-IN', { maximumFractionDigits: 0 })}k`;
  }
  return `${sign}₹${abs.toLocaleString('en-IN')}`;
}

export function formatNumber(val, decimals = 0) {
  if (val === null || val === undefined || isNaN(val)) return '—';
  return Number(val).toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
