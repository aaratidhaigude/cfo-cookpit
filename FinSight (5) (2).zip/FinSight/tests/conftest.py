"""Pytest test fixtures and configuration for FinSight test suite."""

import sys
from pathlib import Path
import pytest
from starlette.testclient import TestClient

# Ensure src is on sys.path
src_path = str(Path(__file__).parent.parent / "src")
if src_path not in sys.path:
    sys.path.insert(0, src_path)

from finsight.adapters.mock_adapter import MockFinancialAdapter
from finsight.api.app import app
from finsight.services.ai_tools_service import AIToolsService
from finsight.services.data_quality_service import DataQualityService
from finsight.services.financial_attention_service import FinancialAttentionService
from finsight.services.financial_engine import FinancialEngine
from finsight.services.financial_intelligence_service import FinancialIntelligenceService
from finsight.services.investigation_service import InvestigationService
from finsight.services.llm_provider import MockLLMProvider
from finsight.services.metric_service import MetricService
from finsight.services.refresh_service import RefreshService


@pytest.fixture(scope="session")
def mock_adapter() -> MockFinancialAdapter:
    """Provides a deterministic mock adapter populated with the 12-month dataset."""
    return MockFinancialAdapter(seed=42)


@pytest.fixture(scope="session")
def financial_engine(mock_adapter: MockFinancialAdapter) -> FinancialEngine:
    """Provides a FinancialEngine instance initialized with the mock dataset."""
    return FinancialEngine(
        company=mock_adapter.get_company(),
        customers=mock_adapter.get_customers(),
        vendors=mock_adapter.get_vendors(),
        products=mock_adapter.get_products(),
        account_mappings=mock_adapter.get_account_mappings(),
        journal_entries=mock_adapter.get_journal_entries(),
        ar_items=mock_adapter.get_ar_items(),
        ap_items=mock_adapter.get_ap_items(),
    )


@pytest.fixture(scope="session")
def metric_service(financial_engine: FinancialEngine) -> MetricService:
    """Provides a MetricService bound to the financial engine."""
    return MetricService(engine=financial_engine, source_name="test_fixture")


@pytest.fixture(scope="session")
def refresh_service() -> RefreshService:
    """Provides an initialized RefreshService."""
    svc = RefreshService()
    svc.execute_refresh()
    return svc


@pytest.fixture(scope="session")
def ai_tools_service(refresh_service: RefreshService) -> AIToolsService:
    """Provides the AI-Ready tool service."""
    return AIToolsService(refresh_service=refresh_service)


@pytest.fixture(scope="session")
def intelligence_service(financial_engine: FinancialEngine, metric_service: MetricService) -> FinancialIntelligenceService:
    """Provides the Financial Intelligence Service."""
    return FinancialIntelligenceService(engine=financial_engine, metric_service=metric_service)


@pytest.fixture(scope="session")
def attention_service(
    financial_engine: FinancialEngine,
    metric_service: MetricService,
    intelligence_service: FinancialIntelligenceService,
) -> FinancialAttentionService:
    """Provides the Financial Attention Service."""
    return FinancialAttentionService(
        engine=financial_engine,
        metric_service=metric_service,
        intelligence_service=intelligence_service,
    )


@pytest.fixture(scope="session")
def mock_llm_provider() -> MockLLMProvider:
    """Provides a deterministic mock LLM provider without external dependencies."""
    return MockLLMProvider()


@pytest.fixture(scope="session")
def investigation_service(
    ai_tools_service: AIToolsService,
    intelligence_service: FinancialIntelligenceService,
    mock_llm_provider: MockLLMProvider,
) -> InvestigationService:
    """Provides the FinSight AI Investigation Service with deterministic mock LLM."""
    return InvestigationService(
        ai_tools_service=ai_tools_service,
        intelligence_service=intelligence_service,
        llm_provider=mock_llm_provider,
    )


@pytest.fixture(scope="session")
def test_client() -> TestClient:
    """FastAPI TestClient with authenticated session for API endpoint integration tests."""
    client = TestClient(app)
    login_res = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"}).json()
    token = login_res.get("token")
    if token:
        client.headers["Authorization"] = f"Bearer {token}"
    return client


@pytest.fixture
def auth_headers(test_client: TestClient) -> dict:
    """Convenience fixture providing default Bearer Authorization headers."""
    return {"Authorization": test_client.headers.get("Authorization", "")}


@pytest.fixture(autouse=True)
def reset_cases_for_test():
    """Ensures each test begins and ends with clean baseline financial cases and reset rate limits."""
    from finsight.api.routes import get_cases_service
    from finsight.auth.repository import get_auth_repository
    get_cases_service().reset()
    try:
        with get_auth_repository()._db_conn() as conn:
            conn.execute("DELETE FROM auth_rate_limits")
            conn.commit()
    except Exception:
        pass
    yield
    get_cases_service().reset()

