"""Tests for AI-Ready Tool Interfaces."""

from finsight.services.ai_tools_service import AIToolsService


def test_ai_tool_get_financial_metric(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_financial_metric("dso", "2026-09")
    assert res["metric_name"] == "dso"
    assert res["status"] == "CALCULATED"
    assert res["value"] is not None


def test_ai_tool_compare_periods(ai_tools_service: AIToolsService):
    res = ai_tools_service.compare_periods("gross_margin", "2026-09", "2026-06")
    assert res["metric_name"] == "gross_margin"
    assert res["status"] == "COMPARISON_SUCCESS"
    assert res["absolute_change"] is not None


def test_ai_tool_get_cash_position(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_cash_position()
    assert res["metric_name"] == "cash_position"
    assert res["value"] > 0


def test_ai_tool_get_receivables(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_receivables(overdue_only=True)
    assert res["total_overdue_amount"] > 0
    assert len(res["items"]) > 0


def test_ai_tool_get_payables(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_payables(overdue_only=False)
    assert res["total_open_amount"] > 0
    assert len(res["items"]) > 0


def test_ai_tool_get_overdue_items(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_overdue_items(item_type="ALL", min_days_overdue=30)
    assert len(res["ar_overdue_items"]) > 0


def test_ai_tool_get_upcoming_payments(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_upcoming_payments(horizon_days=7)
    assert res["total_upcoming_amount"] > 0
    assert len(res["payments"]) > 0


def test_ai_tool_get_customer_exposure(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_customer_exposure(customer_id="CUST-101")
    assert res["customer_name"] == "Apex Retail Group"
    assert res["overdue_ar"] > 0
    assert len(res["open_invoices"]) > 0


def test_ai_tool_get_product_profitability(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_product_profitability(period="2026-09")
    assert len(res["product_group_margins"]) > 0


def test_ai_tool_find_metric_drivers(ai_tools_service: AIToolsService):
    res = ai_tools_service.find_metric_drivers("gross_margin", "2026-09", "2026-06")
    assert "primary_driver" in res
    assert res["margin_change_percentage_points"] < 0  # Compression


def test_ai_tool_get_transaction_evidence(ai_tools_service: AIToolsService):
    res = ai_tools_service.get_transaction_evidence(document_id="DOC-100001")
    assert res["document_id"] == "DOC-100001"
    assert res["line_count"] > 0
    assert res["is_balanced"] is True
