"""Tests for FastAPI endpoints."""

from starlette.testclient import TestClient


def test_api_health(test_client: TestClient):
    response = test_client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["app"] == "FinSight"


def test_api_status(test_client: TestClient):
    response = test_client.get("/api/status")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "operational"
    assert data["company_code"] == "1000"
    assert len(data["available_periods"]) == 12


def test_api_refresh(test_client: TestClient):
    response = test_client.post("/api/refresh")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["calculation_status"] == "READY"
    assert data["records_processed"] > 200
    assert "summary_preview" in data


def test_api_financial_summary(test_client: TestClient):
    response = test_client.get("/api/financial-summary?period=2026-09")
    assert response.status_code == 200
    data = response.json()
    assert data["company_code"] == "1000"
    assert data["period"] == "2026-09"
    assert "cash_position" in data
    assert "net_working_capital" in data
    assert "dso" in data
    assert "gross_margin_percent" in data
    assert len(data["key_findings_preview"]) > 0


def test_api_cash(test_client: TestClient):
    response = test_client.get("/api/cash?period=2026-09")
    assert response.status_code == 200
    data = response.json()
    assert data["cash_position"]["status"] == "CALCULATED"
    assert len(data["bank_accounts_breakdown"]) > 0


def test_api_receivables(test_client: TestClient):
    response = test_client.get("/api/receivables?period=2026-09")
    assert response.status_code == 200
    data = response.json()
    assert data["accounts_receivable"]["value"] > 0
    assert data["overdue_ar"]["value"] > 0
    assert len(data["aging_schedule"]) == 4
    assert len(data["top_overdue_customers"]) > 0


def test_api_payables(test_client: TestClient):
    response = test_client.get("/api/payables?period=2026-09")
    assert response.status_code == 200
    data = response.json()
    assert data["accounts_payable"]["value"] > 0
    assert data["upcoming_payables_7d"]["value"] > 0
    assert len(data["upcoming_schedule"]) == 4


def test_api_inventory(test_client: TestClient):
    response = test_client.get("/api/inventory?period=2026-09")
    assert response.status_code == 200
    data = response.json()
    assert data["inventory_value"]["value"] > 0
    assert data["dio"]["value"] > 0


def test_api_profitability(test_client: TestClient):
    response = test_client.get("/api/profitability?period=2026-09")
    assert response.status_code == 200
    data = response.json()
    assert data["revenue"]["value"] > 0
    assert data["gross_margin_percent"]["value"] > 0
    assert len(data["top_customers_by_revenue"]) > 0


def test_api_metrics_single_and_all(test_client: TestClient):
    # Single metric
    res_single = test_client.get("/api/metrics?metric=dso&period=2026-09")
    assert res_single.status_code == 200
    dso_data = res_single.json()
    assert dso_data["metric_name"] == "dso"

    # All metrics
    res_all = test_client.get("/api/metrics?period=2026-09")
    assert res_all.status_code == 200
    all_data = res_all.json()
    assert "metrics" in all_data
    assert "cash_position" in all_data["metrics"]
    assert "dso" in all_data["metrics"]
    assert "gross_margin_percent" in all_data["metrics"]


def test_api_data_quality(test_client: TestClient):
    response = test_client.get("/api/data-quality")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] in ("HEALTHY", "DEGRADED")
    assert data["total_records"] > 0
    assert "JournalEntry" in data["entity_stats"]
