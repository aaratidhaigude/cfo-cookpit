"""Tests for Sprint 11 Authentication, RBAC, and SQLite Persistence."""

import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.auth.models import UserRole
from finsight.auth.repository import get_auth_repository
from finsight.auth.security import hash_password, verify_password


@pytest.fixture(scope="module")
def client() -> TestClient:
    return TestClient(app)


def test_password_hashing():
    pwd = "secret_password_123"
    hashed = hash_password(pwd)
    assert hashed.startswith("pbkdf2:sha256:100000$")
    assert verify_password(pwd, hashed) is True
    assert verify_password("wrong_password", hashed) is False
    assert verify_password("", hashed) is False


def test_auth_repo_seed_users():
    repo = get_auth_repository()
    admin_user = repo.get_user_by_username("admin")
    assert admin_user is not None
    assert admin_user.role == UserRole.ADMIN

    mgr_user = repo.get_user_by_username("manager")
    assert mgr_user is not None
    assert mgr_user.role == UserRole.FINANCE_MANAGER

    anl_user = repo.get_user_by_username("analyst")
    assert anl_user is not None
    assert anl_user.role == UserRole.FINANCE_ANALYST


def test_login_success(client: TestClient):
    resp = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    assert resp.status_code == 200
    data = resp.json()
    assert "token" in data
    assert data["token_type"] == "Bearer"
    assert data["user"]["username"] == "admin"
    assert data["user"]["role"] == "ADMIN"
    assert "Finance Admin" in data["user"]["display_title"]


def test_login_invalid_password(client: TestClient):
    resp = client.post("/api/auth/login", json={"username": "admin", "password": "wrong_password"})
    assert resp.status_code == 401
    assert "Invalid username or password" in resp.json()["detail"]


def test_login_unknown_user(client: TestClient):
    resp = client.post("/api/auth/login", json={"username": "non_existent_user", "password": "password"})
    assert resp.status_code == 401
    assert "Invalid username or password" in resp.json()["detail"]


def test_protected_route_unauthenticated(client: TestClient):
    resp = client.get("/api/auth/me")
    assert resp.status_code == 401
    assert "Authentication required" in resp.json()["detail"]


def test_protected_route_authenticated(client: TestClient):
    login_resp = client.post("/api/auth/login", json={"username": "manager", "password": "demo123"})
    token = login_resp.json()["token"]

    me_resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me_resp.status_code == 200
    data = me_resp.json()
    assert data["username"] == "manager"
    assert data["role"] == "FINANCE_MANAGER"


def test_logout_invalidates_session(client: TestClient):
    login_resp = client.post("/api/auth/login", json={"username": "analyst", "password": "demo123"})
    token = login_resp.json()["token"]

    # Verify token works
    check1 = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert check1.status_code == 200

    # Logout
    logout_resp = client.post("/api/auth/logout", headers={"Authorization": f"Bearer {token}"})
    assert logout_resp.status_code == 200

    # Token should now be invalid
    check2 = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert check2.status_code == 401


def test_admin_routes_rbac(client: TestClient):
    # Admin login
    admin_token = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"}).json()["token"]
    # Analyst login
    anl_token = client.post("/api/auth/login", json={"username": "analyst", "password": "demo123"}).json()["token"]

    # 1. Admin accesses /api/admin/users -> 200
    res_admin = client.get("/api/admin/users", headers={"Authorization": f"Bearer {admin_token}"})
    assert res_admin.status_code == 200
    assert len(res_admin.json()) >= 3

    # 2. Analyst accesses /api/admin/users -> 403 Forbidden
    res_anl = client.get("/api/admin/users", headers={"Authorization": f"Bearer {anl_token}"})
    assert res_anl.status_code == 403
    assert "Access denied" in res_anl.json()["detail"]

    # 3. Admin accesses /api/admin/config -> 200
    cfg_admin = client.get("/api/admin/config", headers={"Authorization": f"Bearer {admin_token}"})
    assert cfg_admin.status_code == 200
    assert cfg_admin.json()["rbac_active"] is True

    # 4. Analyst accesses /api/admin/config -> 403 Forbidden
    cfg_anl = client.get("/api/admin/config", headers={"Authorization": f"Bearer {anl_token}"})
    assert cfg_anl.status_code == 403


def test_case_close_rbac(client: TestClient):
    anl_token = client.post("/api/auth/login", json={"username": "analyst", "password": "demo123"}).json()["token"]

    # Attempting to close a case as an analyst -> 403
    close_payload = {
        "resolution_summary": "Attempted close by analyst",
        "resolution_evidence": "INV-AR-50065 payment confirmation",
        "reviewer": "Taylor Swift",
        "actor": "Taylor Swift",
    }
    resp = client.post(
        "/api/cases/CASE-2026-001/close",
        json=close_payload,
        headers={"Authorization": f"Bearer {anl_token}"},
    )
    assert resp.status_code == 403
    assert "FINANCE_ANALYST is not authorized to close remediation cases" in resp.json()["detail"]


def test_financial_endpoints_require_authentication(client: TestClient):
    """Verifies all core financial, forecast, AI, and trust endpoints strictly return 401 when unauthenticated."""
    endpoints = [
        ("GET", "/api/financial-summary"),
        ("GET", "/api/snapshot"),
        ("GET", "/api/reconciliation"),
        ("GET", "/api/receivables"),
        ("GET", "/api/payables"),
        ("GET", "/api/ratios"),
        ("GET", "/api/performance"),
        ("GET", "/api/forecast/cash"),
        ("GET", "/api/trust/summary"),
        ("GET", "/api/cases"),
        ("POST", "/api/refresh"),
        ("POST", "/api/ai/ask"),
        ("POST", "/api/investigate"),
    ]
    for method, path in endpoints:
        if method == "GET":
            resp = client.get(path)
        else:
            resp = client.post(path, json={})
        assert resp.status_code == 401, f"{method} {path} should require authentication (got {resp.status_code})"


def test_refresh_rbac_permissions(client: TestClient):
    """POST /api/refresh requires ADMIN or FINANCE_MANAGER role; rejects FINANCE_ANALYST with 403."""
    # 1. Unauthenticated -> 401
    assert client.post("/api/refresh").status_code == 401

    # 2. Analyst -> 403 Forbidden
    anl_token = client.post("/api/auth/login", json={"username": "analyst", "password": "demo123"}).json()["token"]
    resp_anl = client.post("/api/refresh", headers={"Authorization": f"Bearer {anl_token}"})
    assert resp_anl.status_code == 403

    # 3. Finance Manager -> 200 Success
    mgr_token = client.post("/api/auth/login", json={"username": "manager", "password": "demo123"}).json()["token"]
    resp_mgr = client.post("/api/refresh", headers={"Authorization": f"Bearer {mgr_token}"})
    assert resp_mgr.status_code == 200
    assert resp_mgr.json().get("success") is True or resp_mgr.json().get("calculation_status") == "READY"

    # 4. Admin -> 200 Success
    adm_token = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"}).json()["token"]
    resp_adm = client.post("/api/refresh", headers={"Authorization": f"Bearer {adm_token}"})
    assert resp_adm.status_code == 200
    assert resp_adm.json().get("success") is True or resp_adm.json().get("calculation_status") == "READY"


def test_case_audit_actor_spoofing_prevention(client: TestClient):
    """Client-supplied actor or note_author is strictly ignored; authenticated user is enforced in audit trail."""
    anl_token = client.post("/api/auth/login", json={"username": "analyst", "password": "demo123"}).json()["token"]
    headers = {"Authorization": f"Bearer {anl_token}"}

    # 1. Create a case attempting to spoof actor
    create_payload = {
        "title": "Anti-Spoofing Test Case",
        "summary": "Testing actor identity enforcement.",
        "financial_exposure": 10000.0,
        "owner": "Finance Team",
        "actor": "Fake Impersonator",
    }
    create_resp = client.post("/api/cases", json=create_payload, headers=headers)
    assert create_resp.status_code == 200
    case_id = create_resp.json()["id"]

    # 2. Add an action attempting to spoof actor
    action_payload = {
        "action": "Investigate reconciliation",
        "owner": "Alex Morgan",
        "due_date": "2026-10-15",
        "actor": "Fake Hacker",
    }
    action_resp = client.post(f"/api/cases/{case_id}/remediation-action", json=action_payload, headers=headers)
    assert action_resp.status_code == 200

    # 3. Add a note attempting to spoof note_author
    update_payload = {
        "new_note": "Confidential note",
        "note_author": "CEO Impersonator",
    }
    update_resp = client.patch(f"/api/cases/{case_id}", json=update_payload, headers=headers)
    assert update_resp.status_code == 200

    # 4. Verify audit trail: NONE of the events contain spoofed actors
    audit_resp = client.get(f"/api/cases/{case_id}/audit-trail", headers=headers)
    assert audit_resp.status_code == 200
    events = audit_resp.json()

    for event in events:
        actor = event["actor"]
        assert "Fake" not in actor, f"Spoofed actor leaked into audit trail: {actor}"
        assert "CEO Impersonator" not in actor, f"Spoofed note_author leaked into audit trail: {actor}"
        # The actor must be the authenticated user's name or username
        assert actor in ("Taylor Swift", "Alex Morgan", "Morgan Lee", "analyst", "System", "ControlAssessmentService")


def test_login_rate_limiting(client: TestClient):
    """More than 5 failed login attempts within 5 minutes triggers HTTP 429 Too Many Requests."""
    target_user = "rate_limit_victim"
    repo = get_auth_repository()
    repo.clear_failed_logins(target_user)

    for i in range(5):
        resp = client.post("/api/auth/login", json={"username": target_user, "password": "wrong_password"})
        assert resp.status_code == 401

    # 6th attempt should be rate limited with 429
    resp_blocked = client.post("/api/auth/login", json={"username": target_user, "password": "wrong_password"})
    assert resp_blocked.status_code == 429
    assert "Too many failed login attempts" in resp_blocked.json()["detail"]

    # Clear for test isolation
    repo.clear_failed_logins(target_user)

