"""Tests verifying the 9 intentional business scenarios in the generated dataset.

These scenarios must emerge from the deterministic data and not from hard-coded dashboard values.
"""

from datetime import date
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


def test_scenario_1_customer_payment_deterioration(financial_engine: FinancialEngine):
    """SCENARIO 1: Customer Payment Deterioration.

    Apex Retail Group (CUST-101) must have high revenue contribution,
    large outstanding AR, and significant overdue aging exposure (>60 / >90 days).
    """
    ref_date = date(2026, 9, 30)
    ar_summary = financial_engine.get_ar_summary(ref_date)

    # Apex Retail should be in top overdue customers
    apex_overdue = [c for c in ar_summary["top_overdue_customers"] if c["entity_id"] == "CUST-101"]
    assert len(apex_overdue) == 1, "Apex Retail must have overdue items"
    apex_od = apex_overdue[0]

    # Verify significant overdue amount (> $500,000)
    assert apex_od["amount"] > 500000.0

    # Verify overdue invoices spanning multiple aging intervals
    apex_invoices = [
        ar for ar in financial_engine.ar_items
        if ar.customer_id == "CUST-101" and ar.is_open
    ]
    assert len(apex_invoices) >= 3, "Apex must have multiple open invoices"
    overdue_days = [ar.days_overdue(ref_date) for ar in apex_invoices]
    assert any(d > 60 for d in overdue_days), "Apex must have invoices > 60 days overdue"


def test_scenario_2_ar_concentration(financial_engine: FinancialEngine):
    """SCENARIO 2: AR Concentration.

    A small number of customers (top 1-2) must account for a large portion of overdue AR (>60%).
    """
    ref_date = date(2026, 9, 30)
    ar_summary = financial_engine.get_ar_summary(ref_date)

    total_overdue = ar_summary["total_overdue_ar"]
    assert total_overdue > 0

    top_overdue = ar_summary["top_overdue_customers"]
    assert len(top_overdue) >= 1

    # Top customer share of overdue AR
    top_1_share = top_overdue[0]["percentage_of_total"]
    assert top_1_share >= 60.0, f"Expected top customer to hold >=60% of overdue AR, got {top_1_share}%"


def test_scenario_3_upcoming_ap_pressure(financial_engine: FinancialEngine):
    """SCENARIO 3: Upcoming AP Pressure.

    Significant vendor obligations due:
    - due today (2026-09-30)
    - due within 1-3 days
    - due within 7 days
    """
    ref_date = date(2026, 9, 30)
    ap_summary = financial_engine.get_ap_summary(ref_date)

    upcoming_7d = ap_summary["upcoming_payables_7d"]
    assert upcoming_7d > 400000.0, f"Upcoming 7-day payables should exceed $400k, got {upcoming_7d}"

    schedule = {s["timeframe"]: s for s in ap_summary["upcoming_schedule"]}
    assert schedule["Due Today"]["amount"] > 0, "Must have payables due today"
    assert schedule["Due in 1-3 Days"]["amount"] > 0, "Must have payables due in 1-3 days"
    assert schedule["Due in 4-7 Days"]["amount"] > 0, "Must have payables due in 4-7 days"


def test_scenario_4_inventory_buildup(metric_service: MetricService):
    """SCENARIO 4: Inventory Buildup.

    Inventory increases materially faster than sales for at least one period (e.g. Q4 / 2026-09).
    """
    inv_detail = metric_service.calculate_inventory("2026-09")
    assert inv_detail.inventory_growth_rate is not None
    assert inv_detail.sales_growth_rate is not None

    # Inventory growth should be markedly higher than sales growth
    assert inv_detail.inventory_growth_rate > inv_detail.sales_growth_rate, (
        f"Inventory growth ({inv_detail.inventory_growth_rate}%) must exceed sales growth ({inv_detail.sales_growth_rate}%)"
    )
    # Ending DIO should be elevated (> 40 days)
    assert inv_detail.dio.value is not None and inv_detail.dio.value > 40.0


def test_scenario_5_margin_compression(metric_service: MetricService):
    """SCENARIO 5: Margin Compression.

    Between June 2026 (2026-06) and September 2026 (2026-09),
    Revenue grows or holds, but COGS grows faster, causing gross margin % to compress significantly.
    """
    pnl_june = metric_service.calculate_profitability("2026-06")
    pnl_sept = metric_service.calculate_profitability("2026-09")

    gm_june = pnl_june.gross_margin_percent.value
    gm_sept = pnl_sept.gross_margin_percent.value
    assert gm_june is not None and gm_sept is not None

    # Verify gross margin dropped by at least 500 bps (5 percentage points)
    assert gm_sept < gm_june - 5.0, f"Gross margin should decline from {gm_june}% to {gm_sept}%"

    # Verify revenue did not decline (sales were stable or growing)
    assert pnl_sept.revenue.value >= pnl_june.revenue.value


def test_scenario_6_healthy_customer(financial_engine: FinancialEngine):
    """SCENARIO 6: Healthy Customer.

    Nordic Solutions AG (CUST-102) must exhibit:
    - high revenue contribution
    - healthy gross margin (>50%)
    - zero or minimal overdue exposure (pays consistently on terms)
    """
    ref_date = date(2026, 9, 30)
    pnl_breakdown = financial_engine.get_profitability_breakdowns("2026-09")

    nordic_prof = [c for c in pnl_breakdown["top_customers_by_revenue"] if c["entity_id"] == "CUST-102"]
    assert len(nordic_prof) == 1
    nordic = nordic_prof[0]

    # High revenue (> $250k)
    assert nordic["amount"] > 250000.0
    # Healthy margin (> 50%)
    assert nordic["additional_context"]["gross_margin_percent"] > 50.0

    # Low / zero overdue exposure
    ar_summary = financial_engine.get_ar_summary(ref_date)
    nordic_od = [c for c in ar_summary["top_overdue_customers"] if c["entity_id"] == "CUST-102"]
    assert len(nordic_od) == 0, "Healthy customer CUST-102 must have zero overdue exposure"


def test_scenario_7_high_revenue_low_profitability(financial_engine: FinancialEngine):
    """SCENARIO 7: High Revenue / Low Profitability.

    OmniChannel Logistics (CUST-104) and Commodity Server Blade (PRD-004):
    Generates substantial revenue (> $200k/mo), but razor-thin gross margin (< 15%).
    """
    pnl_breakdown = financial_engine.get_profitability_breakdowns("2026-09")
    omni_prof = [c for c in pnl_breakdown["top_customers_by_revenue"] if c["entity_id"] == "CUST-104"]
    assert len(omni_prof) == 1
    omni = omni_prof[0]

    assert omni["amount"] > 200000.0, "OmniChannel must generate high revenue"
    margin_pct = omni["additional_context"]["gross_margin_percent"]
    assert margin_pct < 15.0, f"Gross margin should be low (<15%), got {margin_pct}%"


def test_scenario_8_cash_pressure(metric_service: MetricService):
    """SCENARIO 8: Cash Pressure.

    Combination of:
    - Trapped cash in AR ($800k+ open/overdue)
    - Cash tied up in excess inventory buildup ($1.4M+)
    - Imminent AP obligations due within 7 days ($500k+)
    - Leaving a depleted cash balance unable to comfortably cover 7-day obligations.
    """
    summary = metric_service.get_financial_summary("2026-09")

    cash_val = summary.cash_position.value
    ap_7d = summary.upcoming_payables_7d.value
    assert cash_val is not None and ap_7d is not None

    # 7-day upcoming payables should pose immediate cash pressure relative to cash position
    assert ap_7d > (cash_val * 0.9), f"Upcoming 7-day payables ({ap_7d}) should create acute pressure on cash ({cash_val})"


def test_scenario_9_exposure_concentration(financial_engine: FinancialEngine):
    """SCENARIO 9: Exposure Concentration.

    Meaningful concentration across:
    - Customers: Top 2 customers represent > 50% of revenue
    - Vendors: Titan Semiconductor accounts for largest share of procurement
    """
    pnl = financial_engine.get_profitability_breakdowns("2026-09")
    top_custs = pnl["top_customers_by_revenue"]
    top_2_share = sum(c["percentage_of_total"] for c in top_custs[:2])
    assert top_2_share > 50.0, f"Top 2 customers should account for >50% of sales, got {top_2_share}%"

    # Vendor concentration in AP
    ref_date = date(2026, 9, 30)
    ap_summary = financial_engine.get_ap_summary(ref_date)
    top_vendors = ap_summary["top_vendors_due"]
    assert len(top_vendors) > 0
    assert top_vendors[0]["entity_id"] in ("VEND-201", "VEND-202")
