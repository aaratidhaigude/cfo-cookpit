"""Tests for Canonical Financial Models."""

from datetime import date
import pytest
from pydantic import ValidationError

from finsight.models.canonical import (
    AccountCategory,
    AccountMapping,
    APOpenItem,
    AROpenItem,
    Company,
    Customer,
    FinancialConcept,
    JournalEntry,
    Product,
    Vendor,
)


def test_company_model():
    company = Company(company_code="1000", company_name="FinSight Inc.", currency="USD")
    assert company.company_code == "1000"
    assert company.currency == "USD"


def test_customer_model():
    customer = Customer(
        customer_id="CUST-101",
        customer_name="Apex Retail Group",
        segment="Enterprise",
        region="North America",
        payment_terms="NET30",
    )
    assert customer.customer_id == "CUST-101"
    assert customer.payment_terms == "NET30"


def test_vendor_model():
    vendor = Vendor(
        vendor_id="VEND-201",
        vendor_name="Titan Semiconductor",
        category="Raw Materials",
        payment_terms="NET30",
    )
    assert vendor.vendor_id == "VEND-201"
    assert vendor.category == "Raw Materials"


def test_journal_entry_balancing_properties():
    debit_entry = JournalEntry(
        company_code="1000",
        fiscal_year=2026,
        fiscal_period=9,
        posting_date=date(2026, 9, 15),
        document_id="DOC-101",
        gl_account="101000",
        debit_credit="S",
        amount=5000.0,
        currency="USD",
    )
    credit_entry = JournalEntry(
        company_code="1000",
        fiscal_year=2026,
        fiscal_period=9,
        posting_date=date(2026, 9, 15),
        document_id="DOC-101",
        gl_account="400000",
        debit_credit="H",
        amount=5000.0,
        currency="USD",
    )
    assert debit_entry.is_debit
    assert not debit_entry.is_credit
    assert debit_entry.signed_amount == 5000.0

    assert credit_entry.is_credit
    assert not credit_entry.is_debit
    assert credit_entry.signed_amount == -5000.0

    # Test net document balance
    assert (debit_entry.signed_amount + credit_entry.signed_amount) == 0.0


def test_ar_open_item_validations():
    ar = AROpenItem(
        company_code="1000",
        customer_id="CUST-101",
        invoice_id="INV-AR-001",
        invoice_date=date(2026, 8, 1),
        due_date=date(2026, 8, 31),
        invoice_amount=10000.0,
        open_amount=10000.0,
    )
    assert ar.is_open
    assert not ar.is_cleared
    assert ar.days_overdue(as_of_date=date(2026, 9, 30)) == 30

    # Validation: open_amount cannot exceed invoice_amount
    with pytest.raises(ValidationError):
        AROpenItem(
            company_code="1000",
            customer_id="CUST-101",
            invoice_id="INV-AR-002",
            invoice_date=date(2026, 8, 1),
            due_date=date(2026, 8, 31),
            invoice_amount=5000.0,
            open_amount=6000.0,
        )


def test_ap_open_item_validations():
    ap = APOpenItem(
        company_code="1000",
        vendor_id="VEND-201",
        invoice_id="INV-AP-001",
        invoice_date=date(2026, 9, 15),
        due_date=date(2026, 10, 5),
        invoice_amount=12000.0,
        open_amount=12000.0,
    )
    assert ap.is_open
    assert ap.days_until_due(as_of_date=date(2026, 9, 30)) == 5

    with pytest.raises(ValidationError):
        APOpenItem(
            company_code="1000",
            vendor_id="VEND-201",
            invoice_id="INV-AP-002",
            invoice_date=date(2026, 9, 15),
            due_date=date(2026, 10, 5),
            invoice_amount=10000.0,
            open_amount=15000.0,
        )
