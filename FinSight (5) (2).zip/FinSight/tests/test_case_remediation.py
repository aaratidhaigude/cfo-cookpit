"""Unit and integration tests for Phase 7: Case Remediation Workflow."""

import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.models.cases import (
    AddRemediationActionRequest,
    CaseCategory,
    CaseSeverity,
    CaseStatus,
    CloseCaseRequest,
    CreateCaseRequest,
    RemediationAction,
    UpdateCaseRequest,
)
from finsight.services.cases_service import CasesService


@pytest.fixture
def cases_service():
    return CasesService()


@pytest.fixture
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


@pytest.fixture
def auth_headers(client):
    resp = client.post("/api/auth/login", json={"username": "manager", "password": "demo123"})
    token = resp.json()["token"]
    return {"Authorization": f"Bearer {token}"}


# -----------------------------------------------------------------------------
# 1. Lifecycle State & Seeded Case Tests
# -----------------------------------------------------------------------------

def test_seeded_cases_have_remediation_and_audit_notes(cases_service):
    """Verifies default seeded cases contain structured remediation items and audit logs."""
    case_1 = cases_service.get_case("CASE-2026-001")
    assert case_1 is not None
    assert case_1.status == CaseStatus.OPEN
    assert case_1.financial_exposure == 1044000.00
    assert case_1.entity == "Apex Retail Group"
    assert case_1.control_id == "CONTROL-COLL-001"
    assert len(case_1.remediation_plan) >= 2
    assert len(case_1.audit_notes) >= 2

    # Check audit notes structure
    event = case_1.audit_notes[0]
    assert event.event_type == "CASE_CREATED"
    assert event.actor is not None
    assert event.timestamp is not None


def test_case_status_transitions_logged_in_audit_notes(cases_service):
    """Verifies status changes generate immutable audit log entries."""
    case = cases_service.get_case("CASE-2026-001")
    initial_audit_count = len(case.audit_notes)

    # Transition to IN_PROGRESS
    req = UpdateCaseRequest(
        status=CaseStatus.IN_PROGRESS,
        note_author="Senior Analyst",
        new_note="Reviewing payment agreement with Apex CFO.",
    )
    updated = cases_service.update_case("CASE-2026-001", req)
    assert updated.status == CaseStatus.IN_PROGRESS
    assert len(updated.audit_notes) == initial_audit_count + 2  # STATUS_CHANGED + NOTE_ADDED

    status_event = next(e for e in updated.audit_notes if e.event_type == "STATUS_CHANGED")
    assert "OPEN to IN_PROGRESS" in status_event.details
    assert status_event.actor == "Senior Analyst"


# -----------------------------------------------------------------------------
# 2. Remediation Action Management Tests
# -----------------------------------------------------------------------------

def test_add_remediation_action_service(cases_service):
    """Verifies adding a remediation action updates the plan and audit trail."""
    action = RemediationAction(
        action="Obtain promissory note for remaining balance",
        owner="Commercial Legal Counsel",
        due_date="2026-10-12",
        status="OPEN",
        comment="Requires external legal review",
    )
    updated = cases_service.add_remediation_action(
        case_id="CASE-2026-001",
        action=action,
        actor="Collections Lead",
    )
    assert any(a.action == action.action for a in updated.remediation_plan)
    action_event = next(e for e in updated.audit_notes if e.event_type == "ACTION_ADDED" and "promissory" in e.details.lower())
    assert action_event.actor == "Collections Lead"


def test_api_add_remediation_action(client, auth_headers):
    """POST /api/cases/{case_id}/remediation-action adds action via HTTP."""
    payload = {
        "action": "Escalate to Customer Board Sponsor",
        "owner": "VP Finance",
        "due_date": "2026-10-08",
        "actor": "Credit Committee",
        "comment": "Board-level escalation mandated by credit policy",
    }
    resp = client.post("/api/cases/CASE-2026-001/remediation-action", json=payload, headers=auth_headers)
    assert resp.status_code == 200
    data = resp.json()
    assert any(a["action"] == payload["action"] for a in data["remediation_plan"])


# -----------------------------------------------------------------------------
# 3. Non-Silent Case Closure Enforcement Tests
# -----------------------------------------------------------------------------

def test_non_silent_closure_rejected_without_evidence_and_summary(cases_service):
    """Verifies closing a case without resolution summary or evidence raises ValueError."""
    with pytest.raises(ValueError) as excinfo:
        cases_service.update_case("CASE-2026-001", UpdateCaseRequest(status=CaseStatus.CLOSED))
    assert "resolution_summary" in str(excinfo.value)
    assert "resolution_evidence" in str(excinfo.value)


def test_api_close_case_missing_fields_returns_400(client, auth_headers):
    """POST /api/cases/{case_id}/close without resolution evidence fails with 400."""
    payload = {
        "resolution_summary": "Settled with customer.",
        "resolution_evidence": "",  # Empty evidence
        "reviewer": "CFO",
    }
    resp = client.post("/api/cases/CASE-2026-001/close", json=payload, headers=auth_headers)
    assert resp.status_code == 400
    assert "resolution_evidence" in resp.json()["detail"]


def test_api_close_case_success_with_reviewer_signoff(client, auth_headers):
    """POST /api/cases/{case_id}/close succeeds when complete evidence and reviewer are provided."""
    payload = {
        "resolution_summary": "Apex wired $500,000 installment; remainder restructured under 30-day promissory note.",
        "resolution_evidence": "Wire Transfer Receipt #WT-992014 & Signed Legal Restructuring Agreement",
        "reviewer": "Chief Financial Officer",
        "actor": "Credit Committee Chair",
    }
    resp = client.post("/api/cases/CASE-2026-001/close", json=payload, headers=auth_headers)
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "CLOSED"
    assert data["resolution_summary"] == payload["resolution_summary"]
    assert data["resolution_evidence"] == payload["resolution_evidence"]
    assert data["reviewer"] == "Chief Financial Officer"

    # Verify audit trail contains closure record
    audit_resp = client.get("/api/cases/CASE-2026-001/audit-trail")
    assert audit_resp.status_code == 200
    audit_trail = audit_resp.json()
    closed_event = next(e for e in audit_trail if e["event_type"] == "CLOSED")
    assert "CLOSED" in closed_event["details"]
    assert "Chief Financial Officer" in closed_event["details"]
