"""Tests for Financial Cases API endpoints and workflow governance."""

from starlette.testclient import TestClient


def test_list_cases(test_client: TestClient):
    """Verifies retrieval of seeded enterprise financial cases."""
    resp = test_client.get("/api/cases")
    assert resp.status_code == 200
    cases = resp.json()
    assert len(cases) >= 3

    case_ids = [c["id"] for c in cases]
    assert "CASE-2026-001" in case_ids
    assert "CASE-2026-002" in case_ids
    assert "CASE-2026-003" in case_ids


def test_filter_cases_by_severity(test_client: TestClient):
    """Verifies filtering cases by severity."""
    resp = test_client.get("/api/cases?severity=CRITICAL")
    assert resp.status_code == 200
    cases = resp.json()
    assert len(cases) >= 1
    assert all(c["severity"] == "CRITICAL" for c in cases)
    assert any("Apex Retail Group" in c["title"] for c in cases)


def test_get_case_detail(test_client: TestClient):
    """Verifies single case lookup by ID."""
    resp = test_client.get("/api/cases/CASE-2026-001")
    assert resp.status_code == 200
    case = resp.json()
    assert case["id"] == "CASE-2026-001"
    assert case["financial_impact"] == 1044000.0
    assert case["category"] == "RECEIVABLES"
    assert len(case["notes"]) >= 2
    assert len(case["recommended_actions"]) >= 2

    # Not found case
    not_found = test_client.get("/api/cases/CASE-9999-999")
    assert not_found.status_code == 404


def test_create_and_update_case(test_client: TestClient):
    """Verifies case creation from AI investigation findings and subsequent status transition."""
    # Obtain auth headers
    login_resp = test_client.post("/api/auth/login", json={"username": "manager", "password": "demo123"})
    auth_headers = {"Authorization": f"Bearer {login_resp.json()['token']}"}

    # 1. Create Case
    create_payload = {
        "title": "Inventory Excess in North America Logistics Warehouse",
        "severity": "HIGH",
        "category": "INVENTORY",
        "financial_impact": 420000.0,
        "period": "2026-09",
        "summary": "Inventory grew +51.8% over baseline while sales growth slowed.",
        "assignee": "Supply Chain Director",
        "linked_question": "Why is inventory increasing?",
        "recommended_actions": [
            "Halt speculative procurement for Server Model X.",
            "Run inventory aging analysis across distribution centers."
        ],
        "initial_note": "Case opened following AI Investigation."
    }
    resp = test_client.post("/api/cases", json=create_payload, headers=auth_headers)
    assert resp.status_code == 200
    created = resp.json()
    case_id = created["id"]
    assert "CASE-" in case_id
    assert created["status"] == "OPEN"
    assert created["financial_impact"] == 420000.0
    assert len(created["notes"]) == 1

    # 2. Update Case status and append note
    update_payload = {
        "status": "IN_REVIEW",
        "new_note": "Procurement committee reviewed purchase orders; confirmed hold on PO-8841.",
        "note_author": "Supply Chain Director"
    }
    patch_resp = test_client.patch(f"/api/cases/{case_id}", json=update_payload, headers=auth_headers)
    assert patch_resp.status_code == 200
    updated = patch_resp.json()
    assert updated["status"] == "IN_REVIEW"
    assert len(updated["notes"]) == 2
    assert updated["notes"][-1]["text"] == update_payload["new_note"]

    # 3. Resolve Case
    resolve_payload = {
        "status": "RESOLVED",
        "new_note": "Surplus components transferred to regional repair centers; inventory balance restored to baseline.",
        "note_author": "CFO"
    }
    resolve_resp = test_client.patch(f"/api/cases/{case_id}", json=resolve_payload, headers=auth_headers)
    assert resolve_resp.status_code == 200
    resolved = resolve_resp.json()
    assert resolved["status"] == "RESOLVED"
    assert len(resolved["notes"]) == 3

    # 4. Patch non-existent case returns 404
    bad_patch = test_client.patch("/api/cases/CASE-NONE-000", json={"status": "CLOSED"}, headers=auth_headers)
    assert bad_patch.status_code == 404
