"""Unit and integration tests for Phase 8: Cash Outlook & Scenario Intelligence."""

import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.models.canonical import FinancialConcept
from finsight.models.cash_forecast import (
    CashForecast,
    CashForecastComparison,
    ForecastScenario,
)
from finsight.services.ai_tools_service import AIToolsService
from finsight.services.cash_forecast_service import CashForecastService
from finsight.services.refresh_service import RefreshService


@pytest.fixture
def refresh_service():
    svc = RefreshService()
    svc.execute_refresh()
    return svc


@pytest.fixture
def forecast_service(refresh_service):
    return CashForecastService(
        engine=refresh_service.engine,
        metric_service=refresh_service.metric_service,
    )


@pytest.fixture
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


# -----------------------------------------------------------------------------
# 1. Deterministic Projection Consistency Tests
# -----------------------------------------------------------------------------

def test_forecast_starting_cash_matches_gl_truth(forecast_service, refresh_service):
    """Verifies starting cash is exactly $813,750.00 from authoritative GL."""
    expected_cash = refresh_service.engine.calculate_balance_as_of(
        FinancialConcept.CASH,
        refresh_service.metric_service._get_period_end_date("2026-09"),
    )
    assert expected_cash == 813750.00

    fc = forecast_service.generate_forecast(horizon_days=30, scenario=ForecastScenario.BASE)
    assert fc.starting_cash == 813750.00


def test_forecast_scenarios_30_days(forecast_service):
    """Verifies Base, Conservative, and Improved Collections projections for 30 days."""
    base = forecast_service.generate_forecast(horizon_days=30, scenario=ForecastScenario.BASE)
    conservative = forecast_service.generate_forecast(horizon_days=30, scenario=ForecastScenario.CONSERVATIVE)
    improved = forecast_service.generate_forecast(horizon_days=30, scenario=ForecastScenario.IMPROVED_COLLECTIONS)

    assert base.horizon_days == 30
    assert conservative.horizon_days == 30
    assert improved.horizon_days == 30

    # Improved Collections collections should exceed Conservative collections
    assert improved.expected_collections > base.expected_collections > conservative.expected_collections
    assert improved.projected_cash > base.projected_cash > conservative.projected_cash

    # Payables should be consistent across scenarios for same horizon
    assert base.expected_payables == conservative.expected_payables == improved.expected_payables


def test_forecast_horizons_60_and_90_days(forecast_service):
    """Verifies 60-day and 90-day projection execution."""
    fc_60 = forecast_service.generate_forecast(horizon_days=60, scenario=ForecastScenario.BASE)
    fc_90 = forecast_service.generate_forecast(horizon_days=90, scenario=ForecastScenario.BASE)

    assert fc_60.horizon_days == 60
    assert fc_90.horizon_days == 90
    assert len(fc_60.weekly_projections) == 8
    assert len(fc_90.weekly_projections) == 12


def test_weekly_trajectory_and_week_1_squeeze(forecast_service):
    """Verifies Week-1 liquidity squeeze where $1,377,000 payables mature against $813,750 cash."""
    fc = forecast_service.generate_forecast(horizon_days=30, scenario=ForecastScenario.BASE)
    assert len(fc.weekly_projections) == 4

    week_1 = fc.weekly_projections[0]
    assert week_1.week_number == 1
    assert week_1.disbursements >= 1377000.00

    # LCR indicator check
    lcr_7d = fc.liquidity_indicators["lcr_7d"]
    assert lcr_7d == 0.59  # $813,750 / $1,377,000 = 0.59x
    assert fc.liquidity_indicators["policy_breach_detected"] is True
    assert fc.liquidity_indicators["governing_policy_id"] == "LIQ-CTRL-001"
    assert fc.liquidity_indicators["breach_severity"] == "CRITICAL"


def test_compare_scenarios(forecast_service):
    """Verifies multi-scenario comparison data structure."""
    comparison = forecast_service.compare_scenarios(horizon_days=30)
    assert comparison.starting_cash == 813750.00
    assert comparison.horizon_days == 30
    assert "BASE" in comparison.scenarios
    assert "CONSERVATIVE" in comparison.scenarios
    assert "IMPROVED_COLLECTIONS" in comparison.scenarios
    assert "1,377,000" in comparison.summary_message


# -----------------------------------------------------------------------------
# 2. AI Tool Service Integration Tests
# -----------------------------------------------------------------------------

def test_ai_tool_get_cash_forecast(refresh_service):
    """Verifies get_cash_forecast tool returns structured projection for AI agent."""
    ai_tools = AIToolsService(refresh_service)
    result = ai_tools.get_cash_forecast(horizon_days=30, scenario="BASE")
    assert result["starting_cash"] == 813750.00
    assert result["horizon_days"] == 30
    assert result["scenario"] == "BASE"
    assert "liquidity_indicators" in result
    assert result["liquidity_indicators"]["lcr_7d"] == 0.59
    assert len(result["weekly_projections"]) == 4


# -----------------------------------------------------------------------------
# 3. HTTP API Endpoints Tests
# -----------------------------------------------------------------------------

def test_api_get_cash_forecast(client):
    """GET /api/forecast/cash returns deterministic cash projection."""
    resp = client.get("/api/forecast/cash?horizon_days=30&scenario=BASE")
    assert resp.status_code == 200
    data = resp.json()
    assert data["starting_cash"] == 813750.00
    assert data["horizon_days"] == 30
    assert data["scenario"] == "BASE"


def test_api_compare_forecast_scenarios(client):
    """GET /api/forecast/scenarios returns all 3 scenarios."""
    resp = client.get("/api/forecast/scenarios?horizon_days=30")
    assert resp.status_code == 200
    data = resp.json()
    assert data["starting_cash"] == 813750.00
    assert "BASE" in data["scenarios"]
    assert "CONSERVATIVE" in data["scenarios"]
    assert "IMPROVED_COLLECTIONS" in data["scenarios"]


def test_api_get_forecast_liquidity_risk(client):
    """GET /api/forecast/liquidity-risk returns liquidity indicators."""
    resp = client.get("/api/forecast/liquidity-risk?horizon_days=30")
    assert resp.status_code == 200
    data = resp.json()
    assert data["lcr_7d"] == 0.59
    assert data["policy_breach_detected"] is True
    assert data["governing_policy_id"] == "LIQ-CTRL-001"
