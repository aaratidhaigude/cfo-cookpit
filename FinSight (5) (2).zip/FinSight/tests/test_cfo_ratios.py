"""Sprint 11 CFO Ratio Engine & Historical Trajectory Unit Tests.

Validates deterministic calculation of all CFO ratios:
- Liquidity: Current Ratio, Quick Ratio, Working Capital
- Working Capital: DSO, DIO, DPO, CCC, AR Turnover, AP Turnover
- Profitability: Gross Margin, EBITDA, ROE
- Leverage: Debt to Equity, Interest Coverage
- Growth: Revenue Growth Rate, Budget Variance

Verifies non-negotiable financial rules:
- Rule 1: No hardcoded financial KPIs
- Rule 3: Deterministic backend calculations
- Rule 4: Governed definitions for every ratio
- Rule 6: Missing/invalid denominators never silently become zero
- Rule 10: All financial numbers traceable to underlying inputs
"""

from datetime import date
import pytest

from finsight.models.canonical import (
    AccountCategory,
    AccountMapping,
    Company,
    FinancialConcept,
)
from finsight.models.metrics import MetricStatus, TrendDirection
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


# -----------------------------------------------------------------------------
# LIQUIDITY RATIOS
# -----------------------------------------------------------------------------

def test_current_ratio_calculation(metric_service: MetricService):
    """Verifies Current Ratio = Total Current Assets / Total Current Liabilities."""
    res = metric_service.calculate_current_ratio("2026-09")
    assert res.metric_name == "current_ratio"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert res.value > 1.0  # Normal healthy company current ratio > 1.0
    assert "current_assets" in res.inputs
    assert "current_liabilities" in res.inputs
    assert res.reconciliation_status == "RECONCILED"
    assert res.comparison is not None
    assert res.comparison.trend is not None


def test_current_ratio_zero_denominator():
    """Edge Case: When Current Liabilities <= 0, Current Ratio returns ZERO_DENOMINATOR."""
    company = Company(company_code="1000", company_name="Zero CL Corp", currency="USD")
    engine = FinancialEngine(
        company=company,
        customers=[],
        vendors=[],
        products=[],
        account_mappings=[],
        journal_entries=[],
        ar_items=[],
        ap_items=[],
    )
    svc = MetricService(engine=engine)
    res = svc.calculate_current_ratio("2026-09")
    assert res.status in (MetricStatus.ZERO_DENOMINATOR, MetricStatus.INSUFFICIENT_DATA)
    assert res.value is None
    assert res.formatted_value in ("ZERO_DENOMINATOR", "INSUFFICIENT_DATA")


def test_quick_ratio_calculation(metric_service: MetricService):
    """Verifies Quick Ratio = (Current Assets - Inventory) / Current Liabilities."""
    res = metric_service.calculate_quick_ratio("2026-09")
    assert res.metric_name == "quick_ratio"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert "quick_assets" in res.inputs
    assert "inventory" in res.inputs
    assert "current_liabilities" in res.inputs
    assert res.reconciliation_status == "RECONCILED"
    # Quick Ratio is strictly <= Current Ratio since inventory is subtracted
    cr = metric_service.calculate_current_ratio("2026-09")
    assert res.value <= cr.value


# -----------------------------------------------------------------------------
# WORKING CAPITAL VELOCITY RATIOS
# -----------------------------------------------------------------------------

def test_ar_turnover_calculation(metric_service: MetricService):
    """Verifies AR Turnover = Period Credit Sales / Period-End Accounts Receivable."""
    res = metric_service.calculate_ar_turnover("2026-09")
    assert res.metric_name == "ar_turnover"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert res.value > 0.0
    assert "revenue" in res.inputs
    assert "trade_ar" in res.inputs
    assert res.reconciliation_status == "RECONCILED"


def test_ap_turnover_calculation(metric_service: MetricService):
    """Verifies AP Turnover = Period COGS / Period-End Accounts Payable."""
    res = metric_service.calculate_ap_turnover("2026-09")
    assert res.metric_name == "ap_turnover"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert res.value > 0.0
    assert "cogs" in res.inputs
    assert "trade_ap" in res.inputs
    assert res.reconciliation_status == "RECONCILED"


# -----------------------------------------------------------------------------
# PROFITABILITY RATIOS
# -----------------------------------------------------------------------------

def test_ebitda_calculation(metric_service: MetricService):
    """Verifies EBITDA = Gross Profit - Operating Expenses (SG&A)."""
    res = metric_service.calculate_ebitda("2026-09")
    assert res.metric_name == "ebitda"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert any(c in res.formatted_value for c in ("₹", "$"))
    assert "gross_profit" in res.inputs
    assert "opex" in res.inputs
    assert res.reconciliation_status == "RECONCILED"


def test_roe_calculation(metric_service: MetricService):
    """Verifies ROE = (Net Operating Income / Total Equity) * 100."""
    res = metric_service.calculate_roe("2026-09")
    assert res.metric_name == "roe"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert "%" in res.formatted_value
    assert "operating_income" in res.inputs
    assert "equity" in res.inputs


# -----------------------------------------------------------------------------
# LEVERAGE RATIOS & MISSING INPUT HANDLING
# -----------------------------------------------------------------------------

def test_debt_to_equity_calculation(metric_service: MetricService):
    """Verifies Debt to Equity = Total Liabilities / Total Equity."""
    res = metric_service.calculate_debt_to_equity("2026-09")
    assert res.metric_name == "debt_to_equity"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert res.value > 0.0
    assert "total_debt" in res.inputs
    assert "total_equity" in res.inputs
    assert res.reconciliation_status == "RECONCILED"


def test_interest_coverage_missing_denominator(metric_service: MetricService):
    """Rule 6 & 16: Interest Expense is not in ledger; Interest Coverage must NOT silently become zero.

    Must explicitly return status INSUFFICIENT_DATA and value=None.
    """
    res = metric_service.calculate_interest_coverage("2026-09")
    assert res.metric_name == "interest_coverage"
    assert res.status == MetricStatus.INSUFFICIENT_DATA
    assert res.value is None
    assert res.formatted_value == "INSUFFICIENT_DATA"
    assert res.reconciliation_status == "INSUFFICIENT_DATA"
    assert "interest_expense" in res.inputs
    assert res.inputs["interest_expense"] is None


# -----------------------------------------------------------------------------
# GROWTH & PERFORMANCE RATIOS
# -----------------------------------------------------------------------------

def test_revenue_growth_calculation(metric_service: MetricService):
    """Verifies Revenue Growth Rate = ((Current Revenue - Prior Revenue) / Prior Revenue) * 100."""
    res = metric_service.calculate_revenue_growth("2026-09")
    assert res.metric_name == "revenue_growth"
    assert res.status == MetricStatus.CALCULATED
    assert res.value is not None
    assert "%" in res.formatted_value
    assert "current_revenue" in res.inputs
    assert "previous_revenue" in res.inputs


def test_revenue_growth_first_period(metric_service: MetricService):
    """When evaluating the very first period (2025-10), prior revenue is None -> INSUFFICIENT_DATA."""
    res = metric_service.calculate_revenue_growth("2025-10")
    assert res.status == MetricStatus.INSUFFICIENT_DATA
    assert res.value is None


def test_budget_variance_unconfigured(metric_service: MetricService):
    """Rule 7: Budget Variance target is unconfigured; must NOT fabricate numbers."""
    res = metric_service.calculate_budget_variance("2026-09")
    assert res.metric_name == "budget_variance"
    assert res.status == MetricStatus.INSUFFICIENT_DATA
    assert res.value is None
    assert res.formatted_value == "INSUFFICIENT_DATA"


# -----------------------------------------------------------------------------
# CFO RATIO COCKPIT AGGREGATOR
# -----------------------------------------------------------------------------

def test_get_cfo_ratios_structure(metric_service: MetricService):
    """Verifies complete 5-group CFO ratio cockpit payload."""
    cockpit = metric_service.get_cfo_ratios("2026-09")
    assert cockpit.period == "2026-09"
    assert cockpit.comparison_period == "2026-08"
    assert cockpit.company_code == "1000"
    assert len(cockpit.groups) == 5

    categories = [g.category for g in cockpit.groups]
    assert categories == ["LIQUIDITY", "WORKING_CAPITAL", "PROFITABILITY", "LEVERAGE", "GROWTH"]

    # Verify each group contains expected ratios
    liquidity = next(g for g in cockpit.groups if g.category == "LIQUIDITY")
    liq_names = [r.metric_name for r in liquidity.ratios]
    assert "current_ratio" in liq_names
    assert "quick_ratio" in liq_names
    assert "net_working_capital" in liq_names

    wc = next(g for g in cockpit.groups if g.category == "WORKING_CAPITAL")
    wc_names = [r.metric_name for r in wc.ratios]
    assert "dso" in wc_names
    assert "dio" in wc_names
    assert "dpo" in wc_names
    assert "ccc" in wc_names
    assert "ar_turnover" in wc_names
    assert "ap_turnover" in wc_names

    prof = next(g for g in cockpit.groups if g.category == "PROFITABILITY")
    prof_names = [r.metric_name for r in prof.ratios]
    assert "gross_margin_percent" in prof_names
    assert "ebitda" in prof_names
    assert "roe" in prof_names

    leverage = next(g for g in cockpit.groups if g.category == "LEVERAGE")
    lev_names = [r.metric_name for r in leverage.ratios]
    assert "debt_to_equity" in lev_names
    assert "interest_coverage" in lev_names

    growth = next(g for g in cockpit.groups if g.category == "GROWTH")
    growth_names = [r.metric_name for r in growth.ratios]
    assert "revenue_growth" in growth_names
    assert "budget_variance" in growth_names


# -----------------------------------------------------------------------------
# HISTORICAL FINANCIAL INTELLIGENCE
# -----------------------------------------------------------------------------

def test_metric_history_dso(metric_service: MetricService):
    """Verifies multi-period historical trajectory, deltas, and trend interpretation for DSO."""
    history = metric_service.get_metric_history("dso")
    assert history.metric_name == "dso"
    assert len(history.history) == 12  # All 12 fiscal periods from 2025-10 to 2026-09
    assert history.periods[0] == "2025-10"
    assert history.periods[-1] == "2026-09"

    # Last point has deltas calculated against prior period
    last_pt = history.history[-1]
    assert last_pt.period == "2026-09"
    assert last_pt.value == 60.1
    assert last_pt.absolute_change is not None
    assert last_pt.percentage_change is not None

    # Trend interpretation is populated with business-friendly context
    assert history.interpretation is not None
    assert "DSO" in history.interpretation or "Days Sales" in history.interpretation
    assert history.overall_trend in ("INCREASING", "DECREASING", "STABLE")


def test_metric_history_current_ratio(metric_service: MetricService):
    """Verifies historical trajectory for Current Ratio."""
    history = metric_service.get_metric_history("current_ratio")
    assert history.metric_name == "current_ratio"
    assert len(history.history) == 12
    assert all(pt.value is not None for pt in history.history)
    assert history.overall_change is not None


# -----------------------------------------------------------------------------
# GET_METRIC_BY_NAME ROUTING & ALIASES
# -----------------------------------------------------------------------------

@pytest.mark.parametrize("slug,expected_metric", [
    ("current_ratio", "current_ratio"),
    ("cr", "current_ratio"),
    ("quick_ratio", "quick_ratio"),
    ("qr", "quick_ratio"),
    ("ar_turnover", "ar_turnover"),
    ("art", "ar_turnover"),
    ("ap_turnover", "ap_turnover"),
    ("apt", "ap_turnover"),
    ("ebitda", "ebitda"),
    ("roe", "roe"),
    ("debt_to_equity", "debt_to_equity"),
    ("de", "debt_to_equity"),
    ("interest_coverage", "interest_coverage"),
    ("ic", "interest_coverage"),
    ("revenue_growth", "revenue_growth"),
    ("rg", "revenue_growth"),
    ("budget_variance", "budget_variance"),
    ("bv", "budget_variance"),
])
def test_metric_name_routing(metric_service: MetricService, slug: str, expected_metric: str):
    """Verifies that all new ratios and short aliases resolve correctly in get_metric_by_name."""
    res = metric_service.get_metric_by_name(slug, "2026-09")
    assert res.metric_name == expected_metric
    assert res.period == "2026-09"
