"""API Tests for CFO Ratio Cockpit and Metric History Endpoints.

Validates:
- GET /api/ratios
- GET /api/ratios?period=2026-08
- GET /api/metrics/{metric_name}/history
- GET /api/trust/metrics/{metric_name}/lineage for new CFO ratios
- GET /api/trust/catalog/{metric_name} for new CFO ratios
"""

import pytest
from starlette.testclient import TestClient
from finsight.api.app import app


@pytest.fixture(scope="module")
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


def test_get_cfo_ratios_api(client: TestClient):
    """Verifies GET /api/ratios returns governed 5-group CFO Cockpit."""
    response = client.get("/api/ratios")
    assert response.status_code == 200
    data = response.json()

    assert data["period"] == "2026-09"
    assert data["comparison_period"] == "2026-08"
    assert data["currency"] in ("INR", "USD")
    assert len(data["groups"]) == 5

    group_categories = [g["category"] for g in data["groups"]]
    assert group_categories == ["LIQUIDITY", "WORKING_CAPITAL", "PROFITABILITY", "LEVERAGE", "GROWTH"]

    # Check Liquidity ratios
    liq = next(g for g in data["groups"] if g["category"] == "LIQUIDITY")
    ratios = {r["metric_name"]: r for r in liq["ratios"]}
    assert "current_ratio" in ratios
    assert "quick_ratio" in ratios
    assert "net_working_capital" in ratios
    assert ratios["current_ratio"]["value"] is not None
    assert ratios["current_ratio"]["reconciliation_status"] == "RECONCILED"


def test_get_cfo_ratios_specific_period(client: TestClient):
    """Verifies GET /api/ratios with explicit period parameter."""
    response = client.get("/api/ratios?period=2026-08")
    assert response.status_code == 200
    data = response.json()
    assert data["period"] == "2026-08"
    assert data["comparison_period"] == "2026-07"


def test_get_metric_history_dso(client: TestClient):
    """Verifies GET /api/metrics/dso/history returns 12-month trajectory."""
    response = client.get("/api/metrics/dso/history")
    assert response.status_code == 200
    data = response.json()

    assert data["metric_name"] == "dso"
    assert len(data["history"]) == 12
    assert data["history"][-1]["period"] == "2026-09"
    assert data["history"][-1]["value"] == 60.1
    assert data["interpretation"] is not None


def test_get_metric_history_current_ratio(client: TestClient):
    """Verifies GET /api/metrics/current_ratio/history."""
    response = client.get("/api/metrics/current_ratio/history")
    assert response.status_code == 200
    data = response.json()

    assert data["metric_name"] == "current_ratio"
    assert len(data["history"]) == 12
    assert all(pt["value"] is not None for pt in data["history"])


def test_ratio_metric_lineage_api(client: TestClient):
    """Verifies GET /api/trust/metrics/{metric}/lineage works for new ratios."""
    # Current Ratio
    cr_res = client.get("/api/trust/metrics/current_ratio/lineage")
    assert cr_res.status_code == 200
    cr_data = cr_res.json()
    assert cr_data["metric_name"] == "current_ratio"
    assert len(cr_data["inputs"]) > 0
    assert cr_data["reconciliation_tie"] is not None
    assert cr_data["reconciliation_tie"]["status"] == "RECONCILED"

    # Quick Ratio
    qr_res = client.get("/api/trust/metrics/quick_ratio/lineage")
    assert qr_res.status_code == 200
    qr_data = qr_res.json()
    assert qr_data["metric_name"] == "quick_ratio"
    assert len(qr_data["inputs"]) > 0

    # Debt to Equity
    de_res = client.get("/api/trust/metrics/debt_to_equity/lineage")
    assert de_res.status_code == 200
    de_data = de_res.json()
    assert de_data["metric_name"] == "debt_to_equity"
    assert len(de_data["inputs"]) > 0


def test_ratio_metric_catalog_api(client: TestClient):
    """Verifies GET /api/trust/catalog/{metric} for new ratios."""
    res = client.get("/api/trust/catalog/current_ratio")
    assert res.status_code == 200
    data = res.json()
    assert data["metric_name"] == "current_ratio"
    assert "current assets" in data["description"].lower()
    assert data["denominator_rules"] is not None
