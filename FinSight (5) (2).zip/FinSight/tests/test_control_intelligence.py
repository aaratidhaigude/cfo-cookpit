"""Unit and integration tests for Phase 6: Control Intelligence Engine."""

import pytest
from datetime import date
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.models.canonical import FinancialConcept
from finsight.models.control import (
    AssessmentStatus,
    ControlEvaluationType,
    ControlSeverity,
    ControlStatus,
)
from finsight.services.control_assessment_service import ControlAssessmentService
from finsight.services.refresh_service import RefreshService


@pytest.fixture
def refresh_service():
    svc = RefreshService()
    svc.execute_refresh()
    return svc


@pytest.fixture
def control_service(refresh_service):
    return ControlAssessmentService(
        engine=refresh_service.engine,
        metric_service=refresh_service.metric_service,
    )


@pytest.fixture
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


# -----------------------------------------------------------------------------
# 1. Control Definition & Policy Document Binding Tests
# -----------------------------------------------------------------------------

def test_active_controls_loaded_from_knowledge_retriever(control_service):
    """Verifies all 8 canonical controls are initialized with governing policy metadata."""
    controls = control_service.list_controls()
    assert len(controls) == 8
    ctrl_ids = {c.control_id for c in controls}
    assert "CONTROL-COLL-001" in ctrl_ids
    assert "CONTROL-LIQ-001" in ctrl_ids
    assert "CONTROL-INV-001" in ctrl_ids
    assert "CONTROL-GM-001" in ctrl_ids
    assert "CONTROL-AP-001" in ctrl_ids
    assert "CONTROL-CREDIT-001" in ctrl_ids
    assert "CONTROL-DATA-001" in ctrl_ids
    assert "CONTROL-CASE-001" in ctrl_ids


def test_control_coll_001_bound_to_coll_pol_001(control_service):
    """Verifies Collections Escalation Control is bound dynamically to COLL-POL-001."""
    ctrl = control_service.get_control("CONTROL-COLL-001")
    assert ctrl is not None
    assert ctrl.policy_document_id == "COLL-POL-001"
    assert ctrl.policy_version in ("2.0", "2.1")
    assert ctrl.severity == ControlSeverity.CRITICAL
    assert ctrl.evaluation_type == ControlEvaluationType.AGING
    assert ctrl.status == ControlStatus.ACTIVE
    assert ctrl.threshold_config is not None
    assert ctrl.threshold_config.get("escalation_threshold_usd") == 500000.0


def test_control_liq_001_bound_to_liq_ctrl_001(control_service):
    """Verifies 7-Day Liquidity Coverage Control is bound dynamically to LIQ-CTRL-001."""
    ctrl = control_service.get_control("CONTROL-LIQ-001")
    assert ctrl is not None
    assert ctrl.policy_document_id == "LIQ-CTRL-001"
    assert ctrl.severity == ControlSeverity.CRITICAL
    assert ctrl.evaluation_type == ControlEvaluationType.COVERAGE
    assert ctrl.threshold_config.get("lcr_minimum_safe") == 1.0 or ctrl.threshold_config.get("lcr_target") == 1.25



# -----------------------------------------------------------------------------
# 2. Control Assessment Evaluation Tests
# -----------------------------------------------------------------------------

def test_assess_collections_escalation_apex_breach(control_service):
    """Verifies CONTROL-COLL-001 assesses Apex Retail Group past-due exposure ($1,044,000) as BREACH."""
    assessment = control_service.assess_control("CONTROL-COLL-001")
    assert assessment is not None
    assert assessment.control_id == "CONTROL-COLL-001"
    assert assessment.status == AssessmentStatus.BREACH
    assert assessment.severity == "CRITICAL"
    assert assessment.entity == "Apex Retail Group"
    assert assessment.financial_exposure == 1044000.00
    assert assessment.observed_value == 1044000.00
    assert "INV-AR-50065" in str(assessment.evidence) or "INV-AR-50065" in assessment.financial_evidence_refs
    assert assessment.case_required is True
    assert assessment.exception_detected is True
    assert "hold" in assessment.required_action.lower()


def test_assess_liquidity_coverage_breach(control_service):
    """Verifies CONTROL-LIQ-001 assesses 7-day LCR (0.59x) as BREACH against 0.75x floor."""
    assessment = control_service.assess_control("CONTROL-LIQ-001")
    assert assessment is not None
    assert assessment.control_id == "CONTROL-LIQ-001"
    assert assessment.status == AssessmentStatus.BREACH
    assert assessment.observed_value == 0.59
    assert assessment.threshold_value == 1.0
    assert assessment.financial_exposure == 1377000.00
    assert assessment.policy_document_id == "LIQ-CTRL-001"
    assert assessment.case_required is True
    assert "pause" in assessment.required_action.lower() or "split" in assessment.required_action.lower()


def test_assess_inventory_expansion_review(control_service):
    """Verifies CONTROL-INV-001 flags DIO expansion (89.6 days vs 75.0 target) for REVIEW/BREACH."""
    assessment = control_service.assess_control("CONTROL-INV-001")
    assert assessment is not None
    assert assessment.control_id == "CONTROL-INV-001"
    assert assessment.status in (AssessmentStatus.BREACH, AssessmentStatus.REVIEW)
    assert assessment.observed_value == 89.6
    assert assessment.threshold_value == 75.0
    assert assessment.policy_document_id == "INV-POL-001"


def test_assess_gross_margin_control(control_service):
    """Verifies CONTROL-GM-001 evaluates company gross margin and customer margin dilution."""
    assessment = control_service.assess_control("CONTROL-GM-001")
    assert assessment is not None
    assert assessment.control_id == "CONTROL-GM-001"
    assert assessment.status in (AssessmentStatus.BREACH, AssessmentStatus.REVIEW, AssessmentStatus.PASS)
    assert assessment.policy_document_id == "GM-POL-001"



def test_assess_data_integrity_pass(control_service):
    """Verifies CONTROL-DATA-001 passes when all 24 reconciliation invariants pass."""
    assessment = control_service.assess_control("CONTROL-DATA-001")
    assert assessment is not None
    assert assessment.control_id == "CONTROL-DATA-001"
    assert assessment.status == AssessmentStatus.PASS
    assert assessment.observed_value == 1.0
    assert assessment.financial_exposure == 0.0
    assert assessment.case_required is False


def test_control_summary_portfolio_health(control_service):
    """Verifies executive control summary aggregates reviewed, breached, and exposure."""
    summary = control_service.get_summary()
    assert summary.controls_reviewed == 8
    assert summary.controls_breached >= 2  # Collections & Liquidity
    assert summary.controls_passed >= 1     # Data integrity
    assert summary.total_financial_exposure > 0.0
    assert summary.snapshot_id == "SNAP-202609-001"


# -----------------------------------------------------------------------------
# 3. Control API Endpoints Tests
# -----------------------------------------------------------------------------

def test_api_list_controls(client):
    """GET /api/controls returns all canonical internal controls."""
    resp = client.get("/api/controls")
    assert resp.status_code == 200
    controls = resp.json()
    assert len(controls) == 8
    ctrl_ids = [c["control_id"] for c in controls]
    assert "CONTROL-COLL-001" in ctrl_ids


def test_api_get_control(client):
    """GET /api/controls/{control_id} returns control definition."""
    resp = client.get("/api/controls/CONTROL-COLL-001")
    assert resp.status_code == 200
    ctrl = resp.json()
    assert ctrl["control_id"] == "CONTROL-COLL-001"
    assert ctrl["policy_document_id"] == "COLL-POL-001"


def test_api_control_assessments(client):
    """GET /api/control-assessments returns evaluated assessments."""
    resp = client.get("/api/control-assessments")
    assert resp.status_code == 200
    assessments = resp.json()
    assert len(assessments) == 8
    coll = next(a for a in assessments if a["control_id"] == "CONTROL-COLL-001")
    assert coll["status"] == "BREACH"
    assert coll["entity"] == "Apex Retail Group"


def test_api_control_assessments_summary(client):
    """GET /api/control-assessments/summary returns portfolio summary."""
    resp = client.get("/api/control-assessments/summary")
    assert resp.status_code == 200
    summary = resp.json()
    assert summary["controls_reviewed"] == 8
    assert summary["controls_breached"] >= 2
    assert summary["total_financial_exposure"] > 0.0


def test_api_create_case_from_assessment(client):
    """POST /api/control-assessments/{assessment_id}/create-case spawns a case."""
    login_resp = client.post("/api/auth/login", json={"username": "manager", "password": "demo123"})
    auth_headers = {"Authorization": f"Bearer {login_resp.json()['token']}"}
    resp = client.post(
        "/api/control-assessments/CONTROL-COLL-001/create-case?assigned_owner=Collections+Lead",
        headers=auth_headers,
    )
    assert resp.status_code == 200
    case = resp.json()
    assert "CASE-" in case["id"]
    assert case["control_id"] == "CONTROL-COLL-001"
    assert case["entity"] == "Apex Retail Group"
    assert case["financial_exposure"] == 1044000.00
    assert len(case["remediation_plan"]) >= 1
    assert len(case["audit_notes"]) >= 1
