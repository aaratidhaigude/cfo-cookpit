"""Tests for Data Quality & Validation Layer."""

from datetime import date
from finsight.adapters.mock_adapter import MockFinancialAdapter
from finsight.models.canonical import (
    AccountCategory,
    AccountMapping,
    APOpenItem,
    AROpenItem,
    Company,
    Customer,
    FinancialConcept,
    JournalEntry,
    Product,
    Vendor,
)
from finsight.models.quality import DataQualityStatus, IssueSeverity
from finsight.services.data_quality_service import DataQualityService


def test_data_quality_healthy_dataset(mock_adapter: MockFinancialAdapter):
    dq = DataQualityService()
    report = dq.evaluate(
        company=mock_adapter.get_company(),
        customers=mock_adapter.get_customers(),
        vendors=mock_adapter.get_vendors(),
        products=mock_adapter.get_products(),
        account_mappings=mock_adapter.get_account_mappings(),
        journal_entries=mock_adapter.get_journal_entries(),
        ar_items=mock_adapter.get_ar_items(),
        ap_items=mock_adapter.get_ap_items(),
    )
    assert report.status in (DataQualityStatus.HEALTHY, DataQualityStatus.DEGRADED)
    assert len(report.calculation_blockers) == 0
    assert report.total_records > 300


def test_data_quality_detects_missing_company():
    dq = DataQualityService()
    report = dq.evaluate(
        company=None,
        customers=[],
        vendors=[],
        products=[],
        account_mappings=[],
        journal_entries=[],
        ar_items=[],
        ap_items=[],
    )
    assert report.status == DataQualityStatus.BLOCKED
    assert any(b.issue_type == "MISSING_ENTITY" for b in report.calculation_blockers)


def test_data_quality_detects_unbalanced_journal():
    dq = DataQualityService()
    company = Company(company_code="1000", company_name="Test Corp", currency="USD")
    mappings = [
        AccountMapping(gl_account="101000", financial_concept=FinancialConcept.CASH, category=AccountCategory.ASSET, valid_from=date(2025, 1, 1)),
        AccountMapping(gl_account="400000", financial_concept=FinancialConcept.REVENUE, category=AccountCategory.REVENUE, valid_from=date(2025, 1, 1)),
    ]
    # Unbalanced document: Debit 500, Credit 400
    entries = [
        JournalEntry(
            company_code="1000", fiscal_year=2026, fiscal_period=9,
            posting_date=date(2026, 9, 1), document_id="DOC-999",
            gl_account="101000", debit_credit="S", amount=500.0
        ),
        JournalEntry(
            company_code="1000", fiscal_year=2026, fiscal_period=9,
            posting_date=date(2026, 9, 1), document_id="DOC-999",
            gl_account="400000", debit_credit="H", amount=400.0
        ),
    ]
    report = dq.evaluate(
        company=company,
        customers=[],
        vendors=[],
        products=[],
        account_mappings=mappings,
        journal_entries=entries,
        ar_items=[],
        ap_items=[],
    )
    assert report.status == DataQualityStatus.BLOCKED
    assert any(b.issue_type == "UNBALANCED_JOURNAL_DOCUMENTS" for b in report.calculation_blockers)


def test_data_quality_detects_unresolved_customer():
    dq = DataQualityService()
    company = Company(company_code="1000", company_name="Test Corp", currency="USD")
    ar_item = AROpenItem(
        company_code="1000",
        customer_id="CUST-NONEXISTENT",
        invoice_id="INV-001",
        invoice_date=date(2026, 9, 1),
        due_date=date(2026, 10, 1),
        invoice_amount=1000.0,
        open_amount=1000.0,
    )
    report = dq.evaluate(
        company=company,
        customers=[],
        vendors=[],
        products=[],
        account_mappings=[],
        journal_entries=[],
        ar_items=[ar_item],
        ap_items=[],
    )
    assert any(u.issue_type == "UNRESOLVED_CUSTOMER" for u in report.unresolved_references)
