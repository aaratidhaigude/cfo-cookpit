"""Comprehensive Unit and Integration Tests for Sprint 10: Financial Data Trust & Metric Reconciliation.

Validates the full enterprise pipeline:
SOURCE -> NORMALIZE -> MAP -> DEFINE -> CALCULATE -> RECONCILE -> PUBLISH -> TRACE

Verifies:
1. Governed Account Mappings (coverage %, mapped/unmapped audit, unmapped GL detection)
2. Governed Metric Catalog (registry definitions, formulas, denominator rules, sign conventions)
3. Data Quality Pre-flight Guardrails (zero denominator returns INSUFFICIENT_DATA and NOT_CALCULABLE)
4. Multi-Layer Deterministic Reconciliation Ties (Subledger <-> Mapped GL <-> Metric Input <-> Published)
5. Reconciliation Exception Diagnostics (variance analysis, severity, downstream impact)
6. End-to-End Metric Lineage & Provenance Chains
7. Executive & Controller Data Trust Summary
8. REST API Endpoints (/api/trust/*)
"""

import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.knowledge.metric_catalog import (
    get_governed_metric_catalog,
    get_governed_metric_definition,
)
from finsight.models.canonical import AccountCategory, FinancialConcept
from finsight.models.metrics import MetricUnit
from finsight.models.trust import (
    DataTrustSummaryResponse,
    GovernedAccountMapping,
    GovernedMetricDefinition,
    MappingStatus,
    MetricCalculationState,
    MetricLineageResponse,
    MultiLayerReconciliationTie,
    PeriodType,
    PublicationStatus,
    PublishedGovernedMetric,
    ReconciliationException,
    ReconciliationStatus,
)
from finsight.services.data_trust_service import DataTrustService
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


@pytest.fixture(scope="module")
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


@pytest.fixture(scope="module")
def trust_service(financial_engine, metric_service):
    return DataTrustService(financial_engine, metric_service)


# -----------------------------------------------------------------------------
# 1. Governed Account Mappings (Steps 4 & 5)
# -----------------------------------------------------------------------------

def test_account_mappings_audit(trust_service):
    """Audits the GL chart of accounts against posted journal entries."""
    mappings = trust_service.get_account_mappings()
    assert len(mappings) >= 17

    gl_accounts = [m.gl_account for m in mappings]
    assert "101000" in gl_accounts  # Cash
    assert "110000" in gl_accounts  # Trade AR
    assert "120000" in gl_accounts  # Raw Materials
    assert "121000" in gl_accounts  # Finished Goods
    assert "200000" in gl_accounts  # Trade AP
    assert "400000" in gl_accounts  # Product Sales
    assert "500000" in gl_accounts  # COGS

    # Verify 100% coverage on authoritative baseline
    mapped = [m for m in mappings if m.mapping_status == MappingStatus.MAPPED]
    unmapped = [m for m in mappings if m.mapping_status == MappingStatus.UNMAPPED]
    assert len(unmapped) == 0
    assert len(mapped) == len(mappings)


def test_account_mapping_downstream_metrics(trust_service):
    """Verifies that GL mappings correctly resolve downstream metric consumers."""
    mappings = trust_service.get_account_mappings()
    mapping_map = {m.gl_account: m for m in mappings}

    # Revenue GL 400000 should feed into revenue, gross profit, gross margin %
    rev_mapping = mapping_map["400000"]
    assert "revenue" in rev_mapping.downstream_metrics
    assert "gross_profit" in rev_mapping.downstream_metrics

    # AR GL 110000 should feed into accounts receivable and DSO
    ar_mapping = mapping_map["110000"]
    assert "accounts_receivable" in ar_mapping.downstream_metrics
    assert "dso" in ar_mapping.downstream_metrics


def test_unmapped_account_detection(trust_service):
    """Simulates introducing a rogue unmapped GL account to test detection."""
    from finsight.models.canonical import JournalEntry

    from datetime import date
    rogue_je = JournalEntry(
        company_code="1000",
        fiscal_year=2026,
        fiscal_period=9,
        posting_date=date(2026, 9, 15),
        document_id="DOC-ROGUE-999",
        gl_account="999999",
        debit_credit="S",
        amount=50000.0,
    )
    # Temporarily append to journal entries and clear cache
    trust_service.engine.journal_entries.append(rogue_je)
    trust_service._governed_mappings_cache = None

    try:
        updated_mappings = trust_service.get_account_mappings()
        rogue_mapping = next((m for m in updated_mappings if m.gl_account == "999999"), None)
        assert rogue_mapping is not None
        assert rogue_mapping.mapping_status == MappingStatus.UNMAPPED
        assert rogue_mapping.financial_concept is None

        # Summary should detect unmapped account
        summary = trust_service.get_data_trust_summary("2026-09")
        assert summary.unmapped_accounts_count >= 1
        assert summary.data_quality_status == "DEGRADED"
        assert summary.overall_trust_status == "REVIEW_REQUIRED"
    finally:
        # Restore clean state
        trust_service.engine.journal_entries.remove(rogue_je)
        trust_service._governed_mappings_cache = None


# -----------------------------------------------------------------------------
# 2. Governed Metric Catalog (Steps 6 & 7)
# -----------------------------------------------------------------------------

def test_governed_metric_catalog_completeness():
    """Validates that the governed metric catalog contains all core financial definitions."""
    catalog = get_governed_metric_catalog()
    assert len(catalog) >= 16

    metric_names = [defn.metric_name for defn in catalog]
    expected_metrics = [
        "revenue", "cogs", "gross_profit", "gross_margin_percent",
        "cash_position", "accounts_receivable", "overdue_ar", "accounts_payable",
        "inventory_value", "current_assets", "current_liabilities",
        "net_working_capital", "dso", "dio", "dpo", "cash_conversion_cycle",
    ]
    for m in expected_metrics:
        assert m in metric_names, f"Expected metric '{m}' in governed catalog"


def test_governed_metric_definition_detail():
    """Checks specific fields of governed metric definitions."""
    defn = get_governed_metric_definition("gross_margin_percent")
    assert defn is not None
    assert defn.display_name == "Gross Margin %"
    assert defn.unit == MetricUnit.PERCENTAGE
    assert defn.period_type == PeriodType.FLOW
    assert "Revenue" in defn.denominator_rules
    assert defn.sign_convention == "POSITIVE_FAVORABLE"
    assert defn.version == "v1.0"
    assert defn.is_active is True

    # Check non-existent metric returns None
    assert get_governed_metric_definition("non_existent_metric") is None


# -----------------------------------------------------------------------------
# 3. Data Quality Pre-Flight Guardrails & Publication (Steps 8 & 11)
# -----------------------------------------------------------------------------

def test_published_metric_authoritative_values(trust_service):
    """Ensures published governed metrics match authoritative September 2026 baseline values."""
    # 1. Cash = $813,750
    pub_cash = trust_service.get_published_metric("cash_position", "2026-09")
    assert pub_cash.publication_status == PublicationStatus.PUBLISHED
    assert pub_cash.calculation_state == MetricCalculationState.VALID
    assert pub_cash.value == pytest.approx(813750.0, abs=1.0)
    assert pub_cash.reconciliation_status == ReconciliationStatus.RECONCILED

    # 2. Trade AR = $2,984,000
    pub_ar = trust_service.get_published_metric("accounts_receivable", "2026-09")
    assert pub_ar.publication_status == PublicationStatus.PUBLISHED
    assert pub_ar.value == pytest.approx(2984000.0, abs=10.0)

    # 3. Revenue = $1,490,000
    pub_rev = trust_service.get_published_metric("revenue", "2026-09")
    assert pub_rev.publication_status == PublicationStatus.PUBLISHED
    assert pub_rev.value == pytest.approx(1490000.0, abs=10.0)

    # 4. Gross Margin = 40.28%
    pub_gm = trust_service.get_published_metric("gross_margin_percent", "2026-09")
    assert pub_gm.publication_status == PublicationStatus.PUBLISHED
    assert pub_gm.value == pytest.approx(40.28, abs=0.1)

    # 5. CCC = 89.5 days
    pub_ccc = trust_service.get_published_metric("cash_conversion_cycle", "2026-09")
    assert pub_ccc.publication_status == PublicationStatus.PUBLISHED
    assert pub_ccc.value == pytest.approx(89.5, abs=0.5)


def test_zero_denominator_guardrail(trust_service, monkeypatch):
    """Verifies that non-positive denominators return INSUFFICIENT_DATA and NOT_CALCULABLE, never 0.0."""
    # Mock P&L to return revenue = 0.0
    monkeypatch.setattr(
        trust_service.engine,
        "get_pnl_for_period",
        lambda p: {"revenue": 0.0, "cogs": 50000.0, "gross_profit": -50000.0, "period": p},
    )

    pub_gm = trust_service.get_published_metric("gross_margin_percent", "2026-09")
    assert pub_gm.calculation_state == MetricCalculationState.INSUFFICIENT_DATA
    assert pub_gm.publication_status == PublicationStatus.NOT_CALCULABLE
    assert pub_gm.value is None
    assert pub_gm.formatted_value == "INSUFFICIENT_DATA"

    pub_dso = trust_service.get_published_metric("dso", "2026-09")
    assert pub_dso.calculation_state == MetricCalculationState.INSUFFICIENT_DATA
    assert pub_dso.publication_status == PublicationStatus.NOT_CALCULABLE
    assert pub_dso.value is None


# -----------------------------------------------------------------------------
# 4. Multi-Layer Deterministic Reconciliation Ties (Steps 9 & 10)
# -----------------------------------------------------------------------------

def test_all_core_reconciliation_ties(trust_service):
    """Verifies that all 7 core financial reconciliation ties pass within tolerance."""
    ties = trust_service.audit_all_reconciliation_ties("2026-09")
    assert len(ties) == 7

    tie_map = {t.metric_or_concept: t for t in ties}

    # 1. Cash Tie
    cash_tie = tie_map["cash_position"]
    assert cash_tie.status == ReconciliationStatus.RECONCILED
    assert cash_tie.variance == 0.0
    assert cash_tie.source_value == pytest.approx(813750.0, abs=1.0)
    assert cash_tie.mapped_value == pytest.approx(813750.0, abs=1.0)

    # 2. Trade AR Tie
    ar_tie = tie_map["accounts_receivable"]
    assert ar_tie.status == ReconciliationStatus.RECONCILED
    assert ar_tie.variance == 0.0
    assert ar_tie.source_value == pytest.approx(2984000.0, abs=1.0)
    assert ar_tie.mapped_value == pytest.approx(2984000.0, abs=1.0)

    # 3. Trade AP Tie
    ap_tie = tie_map["accounts_payable"]
    assert ap_tie.status == ReconciliationStatus.RECONCILED
    assert ap_tie.variance == 0.0

    # 4. Inventory Tie
    inv_tie = tie_map["inventory_value"]
    assert inv_tie.status == ReconciliationStatus.RECONCILED
    assert inv_tie.variance == 0.0
    assert inv_tie.source_value == pytest.approx(2656840.0, abs=1.0)

    # 5. Revenue Tie
    rev_tie = tie_map["revenue"]
    assert rev_tie.status == ReconciliationStatus.RECONCILED
    assert rev_tie.variance == 0.0
    assert rev_tie.source_value == pytest.approx(1490000.0, abs=10.0)

    # 6. Gross Margin Tie
    gm_tie = tie_map["gross_margin_percent"]
    assert gm_tie.status == ReconciliationStatus.RECONCILED
    assert gm_tie.variance == 0.0

    # 7. CCC Tie
    ccc_tie = tie_map["cash_conversion_cycle"]
    assert ccc_tie.status == ReconciliationStatus.RECONCILED
    assert ccc_tie.variance <= 0.1


def test_reconciliation_variance_detection(trust_service, monkeypatch):
    """Simulates an artificial discrepancy to verify exception generation."""
    # Force get_cash_position to return $800,000 instead of $813,750
    monkeypatch.setattr(
        trust_service.engine,
        "get_cash_position",
        lambda d: (800000.0, {}),
    )

    cash_tie = trust_service.get_reconciliation_tie("cash_position", "2026-09")
    assert cash_tie is not None
    assert cash_tie.status == ReconciliationStatus.FAILED
    assert cash_tie.variance == pytest.approx(13750.0, abs=1.0)

    # Check that summary produces an exception
    summary = trust_service.get_data_trust_summary("2026-09")
    assert summary.overall_trust_status == "REVIEW_REQUIRED"
    assert summary.active_exceptions_count >= 1

    cash_exc = next((e for e in summary.exceptions if e.metric_or_concept == "cash_position"), None)
    assert cash_exc is not None
    assert cash_exc.severity == "CRITICAL"
    assert "differs" in cash_exc.what_differs


# -----------------------------------------------------------------------------
# 5. End-to-End Metric Lineage & Provenance Chains (Steps 12 & 13)
# -----------------------------------------------------------------------------

def test_metric_lineage_resolution(trust_service):
    """Verifies that an auditable lineage trace can prove where a metric came from."""
    # Test Gross Margin % lineage
    lineage = trust_service.get_metric_lineage("gross_margin_percent", "2026-09")
    assert lineage.metric_name == "gross_margin_percent"
    assert lineage.display_name == "Gross Margin %"
    assert lineage.period == "2026-09"
    assert "Gross Profit / Revenue" in lineage.formula_audit
    assert "Revenue" in (lineage.governed_definition.denominator_rules or "")

    # Inputs trace
    input_concepts = [inp.concept.upper() for inp in lineage.inputs]
    assert "REVENUE" in input_concepts
    assert "COGS" in input_concepts

    rev_inp = next(inp for inp in lineage.inputs if inp.concept.upper() == "REVENUE")
    assert rev_inp.value == pytest.approx(1490000.0, abs=10.0)
    assert "400000" in rev_inp.source_accounts
    assert "410000" in rev_inp.source_accounts

    # Published Metric
    assert lineage.published_value == pytest.approx(40.28, abs=0.1)
    assert lineage.publication_status == PublicationStatus.PUBLISHED

    # Reconciliation Tie
    assert lineage.reconciliation_tie is not None
    assert lineage.reconciliation_tie.status == ReconciliationStatus.RECONCILED


def test_cash_lineage_resolution(trust_service):
    """Verifies lineage trace for Cash Position."""
    lineage = trust_service.get_metric_lineage("cash_position", "2026-09")
    assert lineage.metric_name == "cash_position"
    assert lineage.published_value == pytest.approx(813750.0, abs=1.0)
    assert len(lineage.evidence_trail) >= 1


# -----------------------------------------------------------------------------
# 6. Executive Data Trust Summary (Step 14)
# -----------------------------------------------------------------------------

def test_data_trust_summary(trust_service):
    """Verifies that the executive trust summary fulfills all auditing and reporting fields."""
    summary = trust_service.get_data_trust_summary("2026-09")
    assert summary.period == "2026-09"
    assert "Mock Financial ERP Adapter" in summary.source_system
    assert summary.records_processed > 100
    assert summary.mapping_coverage_pct == 100.0
    assert summary.unmapped_accounts_count == 0
    assert summary.total_reconciliation_checks == 7
    assert summary.reconciled_checks_count == 7
    assert summary.failed_checks_count == 0
    assert summary.active_exceptions_count == 0
    assert summary.overall_trust_status == "RECONCILED"
    assert summary.trust_badge_label == "Financial Data Reconciled"


# -----------------------------------------------------------------------------
# 7. REST API Endpoints (Step 17)
# -----------------------------------------------------------------------------

def test_api_get_trust_summary(client):
    """GET /api/trust/summary returns valid DataTrustSummaryResponse."""
    resp = client.get("/api/trust/summary?period=2026-09")
    assert resp.status_code == 200
    data = resp.json()

    assert data["period"] == "2026-09"
    assert data["overall_trust_status"] == "RECONCILED"
    assert data["mapping_coverage_pct"] == 100.0
    assert data["reconciled_checks_count"] == 7
    assert data["active_exceptions_count"] == 0
    assert "exceptions" in data


def test_api_get_trust_catalog(client):
    """GET /api/trust/catalog returns all governed metric definitions."""
    resp = client.get("/api/trust/catalog")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert len(data) >= 16

    names = [d["metric_name"] for d in data]
    assert "revenue" in names
    assert "cash_conversion_cycle" in names


def test_api_get_trust_catalog_item(client):
    """GET /api/trust/catalog/{metric_name} returns definition or 404."""
    # Valid
    resp = client.get("/api/trust/catalog/revenue")
    assert resp.status_code == 200
    data = resp.json()
    assert data["metric_name"] == "revenue"
    assert data["unit"] in ("currency", "USD")
    assert "GL 400000" in data["formula"]

    # Invalid
    resp_404 = client.get("/api/trust/catalog/unknown_fake_metric")
    assert resp_404.status_code == 404


def test_api_get_trust_mappings(client):
    """GET /api/trust/mappings returns GL account mapping audit."""
    resp = client.get("/api/trust/mappings")
    assert resp.status_code == 200
    data = resp.json()

    assert data["total_accounts"] >= 17
    assert data["mapped_accounts"] == data["total_accounts"]
    assert data["unmapped_accounts"] == 0
    assert data["coverage_percentage"] == 100.0
    assert isinstance(data["mappings"], list)


def test_api_get_trust_reconciliation(client):
    """GET /api/trust/reconciliation returns multi-layer ties."""
    resp = client.get("/api/trust/reconciliation?period=2026-09")
    assert resp.status_code == 200
    ties = resp.json()
    assert isinstance(ties, list)
    assert len(ties) == 7

    for t in ties:
        assert t["status"] == "RECONCILED"
        assert t["variance"] <= 0.1


def test_api_get_metric_lineage(client):
    """GET /api/trust/metrics/{metric_name}/lineage returns provenance trace or 404."""
    # Valid
    resp = client.get("/api/trust/metrics/gross_margin_percent/lineage?period=2026-09")
    assert resp.status_code == 200
    data = resp.json()
    assert data["metric_name"] == "gross_margin_percent"
    assert len(data["inputs"]) >= 2
    assert data["published_value"] == pytest.approx(40.28, abs=0.1)

    # Invalid
    resp_404 = client.get("/api/trust/metrics/fake_metric/lineage")
    assert resp_404.status_code == 404


def test_api_get_published_metrics(client):
    """GET /api/trust/metrics returns all governed published metrics."""
    resp = client.get("/api/trust/metrics?period=2026-09")
    assert resp.status_code == 200
    metrics = resp.json()
    assert isinstance(metrics, list)
    assert len(metrics) >= 16

    names = [m["metric_name"] for m in metrics]
    assert "revenue" in names
    assert "gross_margin_percent" in names
    assert "cash_position" in names

    cash_pub = next(m for m in metrics if m["metric_name"] == "cash_position")
    assert cash_pub["value"] == pytest.approx(813750.0, abs=1.0)
    assert cash_pub["publication_status"] == "PUBLISHED"
