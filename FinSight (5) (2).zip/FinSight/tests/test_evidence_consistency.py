"""Regression and Consistency Tests for FinSight Evidence and Driver Analysis.

Ensures that the single source of truth (the deterministic financial engine)
produces exactly identical, non-contradictory metrics and evidence across:
- Financial Engine
- AIToolsService contracts
- FinancialIntelligenceService driver analysis
- FinancialAttentionService items
- InvestigationService executed steps & findings
- AI LLM provider responses
"""

from datetime import date
import pytest

from finsight.services.ai_tools_service import AIToolsService
from finsight.services.financial_attention_service import FinancialAttentionService
from finsight.services.financial_engine import FinancialEngine
from finsight.services.financial_intelligence_service import FinancialIntelligenceService
from finsight.services.investigation_service import InvestigationService


def test_overdue_ar_single_source_of_truth_consistency(
    financial_engine: FinancialEngine,
    ai_tools_service: AIToolsService,
    intelligence_service: FinancialIntelligenceService,
    attention_service: FinancialAttentionService,
    investigation_service: InvestigationService,
):
    """VERIFICATION: Overdue AR must equal exactly $1,044,000.00 across ALL layers with Apex driving 100%."""
    ref_date = date(2026, 9, 30)
    period = "2026-09"
    expected_total_overdue = 1044000.00

    # 1. Deterministic Engine subledger
    ar_summary = financial_engine.get_ar_summary(ref_date)
    assert ar_summary["total_overdue_ar"] == expected_total_overdue
    top_cust = ar_summary["top_overdue_customers"][0]
    assert top_cust["entity_name"] == "Apex Retail Group"
    assert top_cust["amount"] == expected_total_overdue
    assert top_cust["percentage_of_total"] == 100.0

    # 2. AI Tools Contract: get_overdue_items
    od_tool = ai_tools_service.get_overdue_items(item_type="AR", min_days_overdue=1)
    assert od_tool["total_ar_overdue"] == expected_total_overdue
    assert len(od_tool["ar_overdue_items"]) == 3
    assert all(it["entity_name"] == "Apex Retail Group" for it in od_tool["ar_overdue_items"])
    assert sum(it["open_amount"] for it in od_tool["ar_overdue_items"]) == expected_total_overdue

    # 3. AI Tools Contract: get_customer_exposure
    exp_tool = ai_tools_service.get_customer_exposure(customer_id="CUST-101")
    assert exp_tool["customer_name"] == "Apex Retail Group"
    assert exp_tool["overdue_ar"] == expected_total_overdue
    assert exp_tool["total_open_ar"] == 1479000.00
    assert len(exp_tool["open_invoices"]) == 4
    overdue_invoices = [inv for inv in exp_tool["open_invoices"] if inv["days_overdue"] > 0]
    assert len(overdue_invoices) == 3
    assert sum(inv["open_amount"] for inv in overdue_invoices) == expected_total_overdue

    # 4. Intelligence Service: Driver Analysis for AR
    ar_drivers = intelligence_service.analyze_metric_drivers("accounts_receivable", "2026-09")
    assert "Apex Retail Group" in ar_drivers.primary_driver
    cand = next(c for c in ar_drivers.candidate_drivers if "Apex Retail Group" in c.name)
    assert cand.impact_amount == expected_total_overdue
    assert cand.impact_pct == 100.0

    # 5. Attention Service: Attention Item
    attn_summary = attention_service.get_attention_summary(period)
    ar_attn = next(it for it in attn_summary.items if "AR" in it.type.value or "Apex" in it.title)
    assert ar_attn.financial_impact == expected_total_overdue
    assert any("Apex Retail Group" in d for d in ar_attn.drivers)
    # Check underlying invoice evidence attached
    assert len(ar_attn.evidence) == 3
    assert sum(e.value for e in ar_attn.evidence) == expected_total_overdue

    # 6. Investigation Service: Natural Language Ask
    ask_res = investigation_service.ask("Which customers are driving overdue AR?", period)
    assert "1,044,000" in ask_res.answer or "1044000" in ask_res.answer
    assert "Apex Retail Group" in ask_res.answer
    assert "100" in ask_res.answer
    # CRITICAL: It must NOT claim that Apex drives only $189K
    assert "driving $189,000" not in ask_res.answer
    assert "driving $189K" not in ask_res.answer

    # 7. Investigation Service: Executed Investigation Plan
    exec_res = investigation_service.execute_investigation("Which customers are driving overdue AR?", period)
    assert any(
        f.entity == "Apex Retail Group" and (f.value == expected_total_overdue or f.value in (189000.0, 425000.0, 430000.0))
        for f in exec_res.findings
    )
    assert any(e.entity == "Apex Retail Group" and e.source_type == "AR_OPEN_ITEM" for e in exec_res.evidence)
