"""Tests for Financial Attention Service (Layer 2).

Verifies conversion of financial intelligence findings into prioritized Attention Items,
explainable ranking mechanism, severity calibration, and filtering.
"""

from finsight.models.attention import AttentionSeverity, AttentionType
from finsight.services.financial_attention_service import FinancialAttentionService


def test_attention_summary_generation(attention_service: FinancialAttentionService):
    """Verifies that attention summary surfaces prioritized business concerns."""
    summary = attention_service.get_attention_summary("2026-09")
    assert summary.period == "2026-09"
    assert summary.total_items >= 4, "Should detect multiple key attention items in 2026-09"
    assert summary.total_financial_exposure > 1000000.0, "Total financial exposure should be calculated"

    # Items should be ordered in descending order of priority score
    scores = [it.priority_score for it in summary.items]
    assert scores == sorted(scores, reverse=True), "Items must be ranked strictly by priority score descending"

    # Verify each item has explainable rationale and valid types
    for it in summary.items:
        assert len(it.title) > 0
        assert len(it.summary) > 0
        assert len(it.priority_reason) > 10
        assert it.financial_impact > 0
        assert it.status.value == "OPEN"
        assert len(it.drivers) >= 1


def test_attention_types_and_scenarios(attention_service: FinancialAttentionService):
    """Verifies that intentional business scenarios manifest as specific attention types."""
    summary = attention_service.get_attention_summary("2026-09")
    types_found = {it.type for it in summary.items}

    # Liquidity pressure (Scenario 8)
    assert AttentionType.CASH_PRESSURE in types_found
    cash_item = next(it for it in summary.items if it.type == AttentionType.CASH_PRESSURE)
    assert cash_item.severity == AttentionSeverity.CRITICAL
    assert "coverage ratio" in cash_item.priority_reason.lower()

    # Receivables deterioration (Scenario 1 & 2)
    assert AttentionType.AR_DETERIORATION in types_found
    ar_item = next(it for it in summary.items if it.type == AttentionType.AR_DETERIORATION)
    assert ar_item.severity in (AttentionSeverity.HIGH, AttentionSeverity.CRITICAL)
    assert len(ar_item.evidence) >= 1

    # Customer payment delay (Apex CUST-101)
    assert AttentionType.CUSTOMER_PAYMENT_DETERIORATION in types_found
    cust_item = next(it for it in summary.items if it.type == AttentionType.CUSTOMER_PAYMENT_DETERIORATION)
    assert "Apex" in cust_item.title or "Apex" in cust_item.summary

    # Inventory buildup (Scenario 4)
    assert AttentionType.INVENTORY_BUILDUP in types_found
    inv_item = next(it for it in summary.items if it.type == AttentionType.INVENTORY_BUILDUP)
    assert inv_item.financial_impact > 2000000.0


def test_attention_filtering(attention_service: FinancialAttentionService):
    """Verifies filtering by severity, type, and status."""
    # Filter by severity
    crit_summary = attention_service.get_attention_summary("2026-09", severity_filter="CRITICAL")
    assert all(it.severity == AttentionSeverity.CRITICAL for it in crit_summary.items)
    assert crit_summary.total_items > 0

    # Filter by type
    cash_summary = attention_service.get_attention_summary("2026-09", type_filter="CASH_PRESSURE")
    assert all(it.type == AttentionType.CASH_PRESSURE for it in cash_summary.items)
    assert cash_summary.total_items == 1

    # Filter by status
    open_summary = attention_service.get_attention_summary("2026-09", status_filter="OPEN")
    assert all(it.status.value == "OPEN" for it in open_summary.items)


def test_attention_ranking_explainability(attention_service: FinancialAttentionService):
    """Verifies that priority scores are deterministic and provide non-random explanations."""
    summary = attention_service.get_attention_summary("2026-09")

    top_item = summary.items[0]
    # Top item should be CRITICAL liquidity pressure or receivables deterioration
    assert top_item.severity == AttentionSeverity.CRITICAL
    assert top_item.priority_score >= 85.0
    # Must explain WHY it is high priority
    assert "priority" in top_item.priority_reason.lower()
    assert any(c in top_item.priority_reason for c in ("₹", "$"))
