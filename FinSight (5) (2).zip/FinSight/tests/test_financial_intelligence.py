"""Tests for Financial Intelligence Service (Layer 1).

Verifies period change detection, materiality engine, multi-period trends,
deterministic anomaly detection, metric drivers, and customer/product intelligence.
"""

from finsight.models.intelligence import (
    AnomalySeverity,
    TrendPattern,
)
from finsight.models.metrics import TrendDirection
from finsight.services.financial_intelligence_service import FinancialIntelligenceService


def test_detect_period_changes(intelligence_service: FinancialIntelligenceService):
    """Verifies that all core metrics are evaluated across consecutive periods."""
    changes = intelligence_service.detect_period_changes("2026-09")
    assert len(changes) >= 12, "Should evaluate at least 12 standard tracked metrics"

    change_map = {c.metric_name: c for c in changes}
    assert "revenue" in change_map
    assert "cogs" in change_map
    assert "gross_margin_percent" in change_map
    assert "cash_position" in change_map
    assert "accounts_receivable" in change_map
    assert "overdue_ar" in change_map
    assert "inventory_value" in change_map
    assert "dso" in change_map
    assert "dpo" in change_map
    assert "dio" in change_map
    assert "net_working_capital" in change_map

    # Cash dropped between 2026-08 and 2026-09
    cash_change = change_map["cash_position"]
    assert cash_change.direction == TrendDirection.DECREASING
    assert cash_change.absolute_change < 0
    assert any(c in cash_change.explanation for c in ("₹", "$"))


def test_materiality_engine(intelligence_service: FinancialIntelligenceService):
    """Verifies that materiality filter flags significant issues without flagging every percentage variance."""
    all_changes = intelligence_service.detect_period_changes("2026-09")
    material_changes = intelligence_service.detect_material_changes("2026-09")

    # Material subset should be strictly smaller than or equal to all changes
    assert len(material_changes) <= len(all_changes)
    assert len(material_changes) > 0, "Should detect material changes in 2026-09"

    # Material items must provide a deterministic reason
    for mc in material_changes:
        assert mc.is_material is True
        assert mc.materiality_reason is not None and len(mc.materiality_reason) > 5

    # In 2026-09, cash, AR, overdue AR, inventory, and DSO should be material
    mat_names = {mc.metric_name for mc in material_changes}
    assert "cash_position" in mat_names
    assert "accounts_receivable" in mat_names
    assert "inventory_value" in mat_names


def test_trend_detection(intelligence_service: FinancialIntelligenceService):
    """Verifies multi-period historical trend analysis across 12 periods."""
    trends = intelligence_service.detect_trends()
    assert len(trends) >= 8, "Should compute trends for core metrics"

    trend_map = {t.metric_name: t for t in trends}

    # DSO trend: deteriorating across trailing months
    assert "dso" in trend_map
    dso_trend = trend_map["dso"]
    assert dso_trend.pattern in (TrendPattern.DETERIORATION, TrendPattern.PERSISTENT_INCREASE, TrendPattern.ACCELERATION)
    assert len(dso_trend.periods_analyzed) == 12

    # Inventory trend: increasing
    assert "inventory_value" in trend_map
    inv_trend = trend_map["inventory_value"]
    assert inv_trend.overall_change > 0


def test_anomaly_detection(intelligence_service: FinancialIntelligenceService):
    """Verifies lightweight deterministic anomaly detection against moving baselines."""
    anomalies = intelligence_service.detect_anomalies("2026-09")
    assert len(anomalies) > 0, "Should detect anomalies in 2026-09"

    anomaly_metrics = {a.metric for a in anomalies}
    # Inventory was materially above baseline in 2026-09 (Scenario 4)
    assert "inventory_value" in anomaly_metrics

    inv_anomaly = next(a for a in anomalies if a.metric == "inventory_value")
    assert inv_anomaly.period == "2026-09"
    assert inv_anomaly.actual > inv_anomaly.baseline
    assert inv_anomaly.deviation_pct >= 50.0
    assert inv_anomaly.severity in (AnomalySeverity.HIGH, AnomalySeverity.CRITICAL)
    assert "Inventory" in inv_anomaly.reason
    assert inv_anomaly.method == "historical_rolling_deviation"


def test_cash_driver_analysis(intelligence_service: FinancialIntelligenceService):
    """Verifies deterministic decomposition: Why did cash decrease?"""
    drivers = intelligence_service.analyze_metric_drivers("cash_position", "2026-09")
    assert drivers.metric == "cash_position"
    assert drivers.change_amount < 0, "Cash decreased"
    assert len(drivers.candidate_drivers) >= 2, "Should identify multiple candidate drivers"

    driver_names = [d.name for d in drivers.candidate_drivers]
    # Should identify AR absorption and AP obligations
    assert any("Payable" in name for name in driver_names)
    assert any("Receivables" in name for name in driver_names)

    # Should have supporting entities (e.g. Titan, Apex)
    assert len(drivers.supporting_entities) >= 1
    # Should have verified evidence items
    assert len(drivers.evidence_references) >= 1
    assert "largest observed contributor" in drivers.summary


def test_gross_margin_driver_analysis(intelligence_service: FinancialIntelligenceService):
    """Verifies deterministic decomposition: Why did gross margin decrease?"""
    drivers = intelligence_service.analyze_metric_drivers("gross_margin_percent", "2026-09")
    assert drivers.metric == "gross_margin_percent"
    assert len(drivers.candidate_drivers) >= 1

    driver_names = [d.name for d in drivers.candidate_drivers]
    # Primary driver: COGS growth outpacing revenue
    assert any("COGS" in name for name in driver_names)
    assert "primary contributor" in drivers.summary


def test_customer_intelligence(intelligence_service: FinancialIntelligenceService):
    """Verifies 360-degree customer-level financial intelligence."""
    cust_intel = intelligence_service.analyze_customers("2026-09")
    assert len(cust_intel) >= 5

    c_map = {c.customer_id: c for c in cust_intel}

    # Scenario 1: Apex Retail Group (CUST-101) - High revenue, severe overdue
    apex = c_map["CUST-101"]
    assert apex.customer_name == "Apex Retail Group"
    assert apex.overdue_ar > 500000.0
    assert apex.overdue_pct > 50.0
    assert "HIGH_REVENUE_HIGH_OVERDUE" in apex.tags
    assert apex.payment_behavior_status == "DETERIORATING"
    assert len(apex.evidence) >= 1

    # Scenario 6: Nordic Solutions AG (CUST-102) - Healthy
    nordic = c_map["CUST-102"]
    assert nordic.revenue > 100000.0
    assert nordic.gross_margin_pct >= 40.0
    assert nordic.overdue_ar == 0.0
    assert "HEALTHY" in nordic.tags
    assert nordic.payment_behavior_status == "HEALTHY"

    # Scenario 7: OmniChannel Logistics (CUST-104) - High volume, thin margin
    omni = c_map["CUST-104"]
    assert omni.revenue > 150000.0
    assert omni.gross_margin_pct < 20.0
    assert "HIGH_REVENUE_LOW_MARGIN" in omni.tags


def test_product_intelligence(intelligence_service: FinancialIntelligenceService):
    """Verifies product and product-group level financial intelligence."""
    prod_intel = intelligence_service.analyze_products("2026-09")
    assert len(prod_intel) >= 5

    group_map = {p.product_group: p for p in prod_intel if p.product_id is None}
    assert "Hardware" in group_map
    assert "Software" in group_map
    assert "Services" in group_map

    # Individual product check for PRD-004 (Commodity Micro-Server Unit)
    prod_map = {p.product_id: p for p in prod_intel if p.product_id is not None}
    assert "PRD-004" in prod_map
    commodity = prod_map["PRD-004"]
    assert commodity.gross_margin_pct < 20.0
    assert "HIGH_REVENUE_LOW_MARGIN" in commodity.tags


def test_financial_intelligence_report(intelligence_service: FinancialIntelligenceService):
    """Verifies complete aggregated financial intelligence report generation."""
    report = intelligence_service.generate_report("2026-09")
    assert report.period == "2026-09"
    assert len(report.period_changes) >= 12
    assert len(report.material_changes) >= 1
    assert len(report.trends) >= 8
    assert len(report.anomalies) >= 1
    assert len(report.driver_analyses) == 4
    assert len(report.customer_intelligence) >= 5
    assert len(report.product_intelligence) >= 3
