"""FinSight Sprint 12 — Unified Financial Intelligence Workflow Test Suite.

Verifies the complete end-to-end executive journey:
ATTENTION / METRIC / CUSTOMER / PRODUCT -> INVESTIGATION -> EVIDENCE -> CONTROL / POLICY -> ACTION -> LIFECYCLE

Covers the 15 verification requirements:
1. Attention -> Investigation
2. Metric -> Investigation
3. Customer -> Investigation
4. Product -> Investigation
5. Investigation evidence
6. Investigation policy retrieval
7. Investigation control evaluation
8. Investigation -> Action
9. Context preservation
10. Insufficient-data behavior
11. AI cannot invent financial values
12. AI cannot override deterministic control results
13. Action retains investigation/evidence relationships
14. Existing case lifecycle remains enforced
15. Existing S11 ratio tests remain green
"""

import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.api.routes import (
    get_attention_service,
    get_cases_service,
    get_investigation_service,
    get_refresh_service,
)
from finsight.models.attention import AttentionSeverity, AttentionType
from finsight.models.cases import CaseCategory, CaseSeverity, CaseStatus


@pytest.fixture
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


@pytest.fixture
def auth_headers(client):
    resp = client.post("/api/auth/login", json={"username": "manager", "password": "demo123"})
    token = resp.json()["token"]
    return {"Authorization": f"Bearer {token}"}


# =============================================================================
# 1. Attention -> Investigation
# =============================================================================

def test_attention_to_investigation(client):
    """Test that Attention items cleanly hand off to investigation with context."""
    res = client.get("/api/attention?period=2026-09")
    assert res.status_code == 200
    data = res.json()
    items = data.get("items", [])
    assert len(items) > 0

    # Pick the critical AR deterioration item
    ar_item = next((i for i in items if i["id"] == "AR_DETERIORATION" or i.get("type") == "AR_DETERIORATION"), None)
    assert ar_item is not None
    assert ar_item["metric"] == "dso"
    assert ar_item["recommended_question"] is not None

    # Navigate to investigation using recommended question + context
    inv_payload = {
        "question": ar_item["recommended_question"],
        "period": "2026-09",
        "context": {
            "source": "financial_attention",
            "attention_id": ar_item["id"],
            "metric": ar_item["metric"],
        }
    }
    inv_res = client.post("/api/investigate", json=inv_payload)
    assert inv_res.status_code == 200
    inv_data = inv_res.json()

    assert inv_data["finding"] is not None
    assert inv_data["primary_driver"] is not None
    assert inv_data["financial_impact"] is not None
    assert inv_data["suggested_action"] is not None
    assert inv_data["suggested_action"]["category"] == "RECEIVABLES"


# =============================================================================
# 2. Metric -> Investigation
# =============================================================================

def test_metric_to_investigation(client):
    """Test jumping from governed metric into investigation with context."""
    # Verify metric definition and lineage first
    dso_lineage = client.get("/api/trust/metrics/dso/lineage?period=2026-09")
    assert dso_lineage.status_code == 200

    # Jump to investigate DSO
    inv_res = client.post("/api/investigate", json={
        "question": "Why is DSO increasing?",
        "period": "2026-09",
        "context": {
            "source": "metric_trust",
            "metric": "dso",
            "period": "2026-09",
        }
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    assert "dso" in data["finding"].lower() or "collection" in data["finding"].lower() or "receivable" in data["finding"].lower()
    assert data["assessment_status"] in ("FAILED", "REQUIRES REVIEW", "PASSED")
    assert len(data["financial_evidence"]) > 0
    # Suggested action is created for receivables
    assert data["suggested_action"]["title"] is not None


# =============================================================================
# 3. Customer -> Investigation
# =============================================================================

def test_customer_to_investigation(client):
    """Test jumping from customer row (Apex Retail Group) into investigation."""
    inv_res = client.post("/api/investigate", json={
        "question": "Which customers have high revenue but poor payment behaviour?",
        "period": "2026-09",
        "context": {
            "source": "customer_intelligence",
            "entity": "Apex Retail Group",
            "entity_id": "CUST-101",
        }
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    assert "Apex Retail Group" in data["primary_driver"] or any("Apex" in d for d in data["drivers"])
    assert data["financial_impact"] == 1044000.0
    assert data["control_id"] == "CONTROL-COLL-001"
    assert data["control_status"] in ("BREACH", "BREACHED")
    assert data["assessment_status"] in ("FAILED", "BREACH")

    # Verify contributors list contains Apex Retail Group
    contributors = data.get("contributors", [])
    assert len(contributors) > 0
    assert any("Apex" in c.get("entity_name", "") for c in contributors)


# =============================================================================
# 4. Product -> Investigation
# =============================================================================

def test_product_to_investigation(client):
    """Test jumping from product group row into investigation."""
    inv_res = client.post("/api/investigate", json={
        "question": "Where did gross margin decline?",
        "period": "2026-09",
        "context": {
            "source": "product_intelligence",
            "entity": "Hardware",
        }
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    assert data["finding"] is not None
    assert "margin" in data["finding"].lower() or "cogs" in data["finding"].lower()
    assert data["control_id"] == "CONTROL-GM-001"

    # Verify contributors list contains product group
    contributors = data.get("contributors", [])
    assert len(contributors) > 0
    assert any("Hardware" in c.get("entity_name", "") for c in contributors)


# =============================================================================
# 5. Investigation Evidence
# =============================================================================

def test_investigation_evidence(client):
    """Test that financial evidence is separated from policy evidence and has valid source references."""
    inv_res = client.post("/api/investigate", json={
        "question": "Which customers are driving overdue AR?",
        "period": "2026-09"
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    fin_ev = data.get("financial_evidence", [])
    assert len(fin_ev) > 0
    for ev in fin_ev:
        assert ev["source_type"] != "POLICY_DOCUMENT"
        assert ev["source_id"] is not None
        assert ev["entity"] is not None

    # Check invoice numbers match authoritative subledger records
    source_ids = [e["source_id"] for e in fin_ev]
    assert any(sid.startswith("INV-AR-") for sid in source_ids)


# =============================================================================
# 6. Investigation Policy Retrieval
# =============================================================================

def test_investigation_policy_retrieval(client):
    """Test that policy retrieval returns governed documents without calculating financial values."""
    inv_res = client.post("/api/investigate", json={
        "question": "Why is Apex overdue and what should finance do according to policy?",
        "period": "2026-09"
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    knowledge_sources = data.get("knowledge_sources", [])
    assert len(knowledge_sources) > 0

    doc_ids = [ks["document_id"] for ks in knowledge_sources]
    assert "COLL-POL-001" in doc_ids or "CRED-POL-001" in doc_ids

    # Policy evidence is separated
    pol_ev = data.get("policy_evidence", [])
    assert len(pol_ev) > 0
    for pe in pol_ev:
        assert pe["source_type"] == "POLICY_DOCUMENT"


# =============================================================================
# 7. Investigation Control Evaluation
# =============================================================================

def test_investigation_control_evaluation(client):
    """Test that investigation executes deterministic control evaluation."""
    inv_res = client.post("/api/investigate", json={
        "question": "Are we compliant with our liquidity control policy given our upcoming payments?",
        "period": "2026-09"
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    assert data["control_id"] == "CONTROL-LIQ-001"
    assert data["control_name"] in ("7-Day Liquidity Coverage Control", "7-Day Liquidity Coverage Ratio")
    assert data["control_status"] in ("BREACH", "BREACHED", "WARNING", "HEALTHY")
    assert data["assessment_status"] in ("FAILED", "REQUIRES REVIEW", "PASSED")


# =============================================================================
# 8. Investigation -> Action Hand-off
# =============================================================================

def test_investigation_to_action(client, auth_headers):
    """Test that an investigation result creates a suggested action that can be registered in /api/cases."""
    inv_res = client.post("/api/investigate", json={
        "question": "Which customers are driving overdue AR?",
        "period": "2026-09"
    })
    assert inv_res.status_code == 200
    inv_data = inv_res.json()

    suggested = inv_data.get("suggested_action")
    assert suggested is not None
    assert suggested["title"] is not None
    assert suggested["financial_exposure"] == 1044000.0
    assert suggested["control_id"] == "CONTROL-COLL-001"

    # Register case using suggested action
    case_payload = {
        "title": suggested["title"],
        "summary": suggested["summary"],
        "category": suggested["category"],
        "severity": suggested["severity"],
        "financial_exposure": suggested["financial_exposure"],
        "financial_impact": suggested["financial_impact"],
        "entity": suggested["entity"],
        "control_id": suggested["control_id"],
        "assessment_id": suggested["assessment_id"],
        "financial_evidence_refs": suggested["financial_evidence_refs"],
        "policy_evidence_refs": suggested["policy_evidence_refs"],
        "due_date": suggested["due_date"],
        "owner": suggested["owner"],
        "period": suggested["period"],
    }
    case_res = client.post("/api/cases", json=case_payload, headers=auth_headers)
    assert case_res.status_code == 200
    case_data = case_res.json()

    assert case_data["id"] is not None
    assert case_data["status"] == "OPEN"
    assert case_data["financial_exposure"] == 1044000.0
    assert case_data["control_id"] == "CONTROL-COLL-001"
    assert len(case_data["financial_evidence_refs"]) > 0


# =============================================================================
# 9. Context Preservation
# =============================================================================

def test_context_preservation(client):
    """Test that context passed from attention/metrics/performance correctly guides intent and response."""
    # Pass generic question with specific context
    inv_res = client.post("/api/investigate", json={
        "question": "What is the status of this?",
        "period": "2026-09",
        "context": {
            "source": "financial_attention",
            "attention_id": "CASH_PRESSURE",
            "metric": "cash_position",
        }
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    # Intent correctly deduced from context as CASH_DECREASE_INVESTIGATION
    assert data["intent"] == "CASH_DECREASE_INVESTIGATION"
    assert data["control_id"] == "CONTROL-LIQ-001"
    assert data["financial_impact"] in (433000.0, 563250.0, 1377000.0)


# =============================================================================
# 10. Insufficient Data Behavior
# =============================================================================

def test_insufficient_data_behavior(client):
    """Test that unknown or nonexistent entities return INSUFFICIENT DATA without fabricating numbers."""
    inv_svc = get_investigation_service()
    plan = inv_svc.create_investigation_plan("Analyze customer exposure for CUST-NONEXISTENT")
    # Dispatch customer exposure for nonexistent ID
    res = inv_svc._dispatch_tool_call("get_customer_exposure", {"customer_id": "CUST-NONEXISTENT"})
    assert res["status"] == "CUSTOMER_NOT_FOUND"

    # Execute ask with nonexistent entity
    ask_res = inv_svc.ask("What is the overdue balance for Nonexistent Corp?")
    assert ask_res.answer is not None
    # Cannot invent invoices or values
    assert len(ask_res.financial_evidence) == 0


# =============================================================================
# 11. AI Cannot Invent Financial Values
# =============================================================================

def test_ai_cannot_invent_financial_values(client):
    """Test that all key financial values match deterministic engine calculations exactly."""
    inv_res = client.post("/api/investigate", json={
        "question": "Which customers are driving overdue AR?",
        "period": "2026-09"
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    # Overdue AR exposure must strictly be $1,044,000.00
    assert data["financial_impact"] == 1044000.0
    assert any(x in data["formatted_financial_impact"] for x in ("₹1,044,000", "$1,044,000", "1,044,000"))

    # Cash decrease investigation
    cash_inv = client.post("/api/investigate", json={
        "question": "Why did cash decrease?",
        "period": "2026-09"
    })
    assert cash_inv.status_code == 200
    cash_data = cash_inv.json()
    assert cash_data["financial_impact"] in (433000.0, 563250.0, 1377000.0)


# =============================================================================
# 12. AI Cannot Override Deterministic Control Results
# =============================================================================

def test_ai_cannot_override_deterministic_control_results(client):
    """Test that control evaluation results (BREACHED, WARNING, HEALTHY) cannot be overridden."""
    inv_res = client.post("/api/investigate", json={
        "question": "Why is Apex overdue and what should finance do according to policy?",
        "period": "2026-09"
    })
    assert inv_res.status_code == 200
    data = inv_res.json()

    # Deterministic control is CONTROL-COLL-001 with status BREACH/BREACHED
    assert data["control_id"] == "CONTROL-COLL-001"
    assert data["control_status"] in ("BREACH", "BREACHED")
    assert data["assessment_status"] in ("FAILED", "BREACH")


# =============================================================================
# 13. Action Retains Investigation and Evidence Relationships
# =============================================================================

def test_action_retains_investigation_and_evidence_relationships(client, auth_headers):
    """Test that created case retains control_id, assessment_id, and financial_evidence_refs."""
    # Test via /api/actions alias
    case_payload = {
        "title": "Action: Cash Shortfall Remediation",
        "summary": "Immediate $563,250 7-day liquidity deficit requiring credit draw.",
        "category": "CASH",
        "severity": "CRITICAL",
        "financial_exposure": 563250.0,
        "financial_impact": 563250.0,
        "entity": "Treasury",
        "control_id": "CONTROL-LIQ-001",
        "assessment_id": "ASSESS-202609-LIQ-001",
        "financial_evidence_refs": ["BANK-STMT-202609", "VND-AP-70012"],
        "policy_evidence_refs": ["LIQ-CTRL-001"],
        "due_date": "2026-10-05",
        "owner": "Treasury Director",
        "period": "2026-09",
    }
    post_res = client.post("/api/actions", json=case_payload, headers=auth_headers)
    assert post_res.status_code == 200
    action_data = post_res.json()

    case_id = action_data["id"]
    get_res = client.get(f"/api/cases/{case_id}")
    assert get_res.status_code == 200
    retrieved = get_res.json()

    assert retrieved["control_id"] == "CONTROL-LIQ-001"
    assert retrieved["assessment_id"] == "ASSESS-202609-LIQ-001"
    assert retrieved["financial_evidence_refs"] == ["BANK-STMT-202609", "VND-AP-70012"]
    assert retrieved["policy_evidence_refs"] == ["LIQ-CTRL-001"]


# =============================================================================
# 14. Existing Case Lifecycle Remains Enforced
# =============================================================================

def test_existing_case_lifecycle_remains_enforced(client, auth_headers):
    """Test non-silent closure: cannot close case without resolution summary and evidence."""
    # Create case
    post_res = client.post("/api/cases", json={
        "title": "Apex Collections Follow-up",
        "summary": "Audit follow-up for overdue receivables.",
        "financial_exposure": 1044000.0,
        "entity": "Apex Retail Group",
    }, headers=auth_headers)
    assert post_res.status_code == 200
    case_id = post_res.json()["id"]

    # Attempt to close without resolution summary or evidence -> MUST FAIL
    close_attempt_res = client.patch(f"/api/cases/{case_id}", json={
        "status": "RESOLVED",
    }, headers=auth_headers)
    assert close_attempt_res.status_code == 400
    assert "resolution_summary" in close_attempt_res.json()["detail"].lower()

    # Attempt to close with resolution summary but no evidence -> MUST FAIL
    close_attempt_res2 = client.patch(f"/api/cases/{case_id}", json={
        "status": "RESOLVED",
        "resolution_summary": "Customer paid full overdue balance.",
    }, headers=auth_headers)
    assert close_attempt_res2.status_code == 400
    assert "resolution_evidence" in close_attempt_res2.json()["detail"].lower()

    # Valid close with mandatory summary, evidence, and reviewer -> SUCCEEDS
    valid_close_res = client.patch(f"/api/cases/{case_id}", json={
        "status": "RESOLVED",
        "resolution_summary": "Customer wire received and verified against general ledger.",
        "resolution_evidence": "WIRE-REF-88921",
        "reviewer": "CFO",
    }, headers=auth_headers)
    assert valid_close_res.status_code == 200
    closed_case = valid_close_res.json()
    assert closed_case["status"] == "RESOLVED"
    assert closed_case["resolution_summary"] is not None
    assert closed_case["resolution_evidence"] == "WIRE-REF-88921"
    assert closed_case["reviewer"] == "CFO"


# =============================================================================
# 15. Existing S11 Financial Ratios Remain Green
# =============================================================================

def test_existing_s11_financial_ratios_remain_green(client):
    """Verify that authoritative financial calculations remain verified and unchanged."""
    res = client.get("/api/financials/ratios?period=2026-09")
    assert res.status_code == 200
    ratios_data = res.json()
    all_ratios = []
    if isinstance(ratios_data, dict):
        for g in ratios_data.get("groups", []):
            all_ratios.extend(g.get("ratios", []))
    elif isinstance(ratios_data, list):
        all_ratios = ratios_data

    # Verify key governed ratios
    dso = next(r for r in all_ratios if r["metric_name"] == "dso")
    assert dso["value"] == 60.1

    qr = next(r for r in all_ratios if r["metric_name"] == "quick_ratio")
    assert round(qr["value"], 2) in (1.89, 1.9, 1.90)

    gm = next(r for r in all_ratios if r["metric_name"] == "gross_margin_percent")
    assert round(gm["value"], 2) == 40.28

    nwc_res = client.get("/api/summary?period=2026-09")
    assert nwc_res.status_code == 200
    summary = nwc_res.json()
    assert summary["net_working_capital"]["value"] in (4068840.0, 4848840.0)
