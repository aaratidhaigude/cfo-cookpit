"""Comprehensive test suite for FinSight Financial Reconciliation and Truth Invariants.

Verifies:
1. All 22 deterministic financial integrity and mathematical invariants.
2. Balance Sheet (CA, CL, NWC), P&L (Gross Margin, GP, Completeness), Working Capital Cycle (DSO, DIO, DPO, CCC).
3. Subledger aging, concentration, and cross-layer alignment.
4. Single-source-of-truth invariants (Apex Retail Group $1,044,000 across INV-AR-50065, 50073, 50081).
5. REST API endpoints /api/snapshot and /api/reconciliation.
"""

from decimal import Decimal
import pytest
from starlette.testclient import TestClient

from finsight.models.canonical import FinancialConcept
from finsight.services.cases_service import CasesService
from finsight.services.financial_engine import FinancialEngine
from finsight.services.financial_reconciliation_service import FinancialReconciliationService
from finsight.services.metric_service import MetricService
from finsight.services.refresh_service import RefreshService


class TestFinancialReconciliationService:
    """Tests the deterministic reconciliation service and all 24 mathematical checks."""

    def test_full_reconciliation_audit_passes(self, refresh_service: RefreshService):
        """All 24 checks must execute and evaluate to PASS with zero discrepancies."""
        recon_service = FinancialReconciliationService(
            engine=refresh_service.engine,
            metric_service=refresh_service.metric_service,
            active_snapshot=refresh_service.active_snapshot,
        )
        report = recon_service.execute_audit(period="2026-09")

        assert report.total_checks == 24, f"Expected 24 checks, got {report.total_checks}"
        assert report.passed_checks == 24, f"Expected 24 passes, got {report.passed_checks}"
        assert report.failed_checks == 0, f"Expected 0 failures, got {report.failed_checks}"
        assert report.status == "RECONCILED", f"Expected RECONCILED, got {report.status}"
        assert report.period == "2026-09"
        assert report.snapshot_id == refresh_service.active_snapshot.snapshot_id

        # Verify all check IDs are unique and present
        check_ids = [c.check_id for c in report.checks]
        assert len(check_ids) == len(set(check_ids)), "Reconciliation check IDs must be unique"

    def test_balance_sheet_invariants(self, refresh_service: RefreshService):
        """Validates Balance Sheet equations: CA, CL, NWC, and GL to Subledger ties."""
        recon_service = FinancialReconciliationService(
            engine=refresh_service.engine,
            metric_service=refresh_service.metric_service,
            active_snapshot=refresh_service.active_snapshot,
        )
        report = recon_service.execute_audit(period="2026-09")
        checks_by_id = {c.check_id: c for c in report.checks}

        # NWC Check: CA - CL = NWC
        nwc_check = checks_by_id["RECON-NWC-01"]
        assert nwc_check.status == "PASS"
        assert nwc_check.variance <= 0.01
        assert nwc_check.expected_value == 4848840.0
        assert nwc_check.computed_value == 4848840.0

        # CA Check: Cash + Trade AR + Other Receivables + Inventory = CA
        ca_check = checks_by_id["RECON-CA-01"]
        assert ca_check.status == "PASS"
        assert ca_check.variance <= 0.01
        assert ca_check.expected_value == 7284590.0

        # CL Check: Trade AP + Other Payables = CL
        cl_check = checks_by_id["RECON-CL-01"]
        assert cl_check.status == "PASS"
        assert cl_check.variance <= 0.01
        assert cl_check.expected_value == 2435750.0

        # AR Reconciliation Check: GL AR = Trade AR + Other Receivables
        ar_recon = checks_by_id["RECON-AR-GL-01"]
        assert ar_recon.status == "PASS"
        assert ar_recon.variance <= 0.01
        assert ar_recon.expected_value == 3814000.0
        assert ar_recon.computed_value == 3814000.0

        # AP Reconciliation Check: GL AP = Trade AP + Other Payables
        ap_recon = checks_by_id["RECON-AP-GL-01"]
        assert ap_recon.status == "PASS"
        assert ap_recon.variance <= 0.01
        assert ap_recon.expected_value == 2435750.0
        assert ap_recon.computed_value == 2435750.0

    def test_pnl_invariants(self, refresh_service: RefreshService):
        """Validates P&L equations: Gross Profit, Gross Margin %, and Revenue completeness."""
        recon_service = FinancialReconciliationService(
            engine=refresh_service.engine,
            metric_service=refresh_service.metric_service,
            active_snapshot=refresh_service.active_snapshot,
        )
        report = recon_service.execute_audit(period="2026-09")
        checks_by_id = {c.check_id: c for c in report.checks}

        # Gross Profit: Revenue - COGS = Gross Profit
        gp_check = checks_by_id["RECON-GP-01"]
        assert gp_check.status == "PASS"
        assert gp_check.expected_value == 600140.0
        assert gp_check.computed_value == 600140.0

        # Gross Margin %: (GP / Rev) * 100
        gm_check = checks_by_id["RECON-GM-01"]
        assert gm_check.status == "PASS"
        assert gm_check.expected_value == 40.28
        assert gm_check.computed_value == 40.28

        # Revenue Customer Completeness
        rev_cust = checks_by_id["RECON-CUST-REV-01"]
        assert rev_cust.status == "PASS"
        assert rev_cust.expected_value == 1490000.0

        # Revenue Product Completeness
        rev_prod = checks_by_id["RECON-PROD-REV-01"]
        assert rev_prod.status == "PASS"
        assert rev_prod.expected_value == 1490000.0

    def test_working_capital_cycle_invariants(self, refresh_service: RefreshService):
        """Validates Working Capital metrics: DSO, DIO, DPO, and CCC."""
        recon_service = FinancialReconciliationService(
            engine=refresh_service.engine,
            metric_service=refresh_service.metric_service,
            active_snapshot=refresh_service.active_snapshot,
        )
        report = recon_service.execute_audit(period="2026-09")
        checks_by_id = {c.check_id: c for c in report.checks}

        dso_check = checks_by_id["RECON-DSO-01"]
        dio_check = checks_by_id["RECON-DIO-01"]
        dpo_check = checks_by_id["RECON-DPO-01"]
        ccc_check = checks_by_id["RECON-CCC-01"]

        assert dso_check.status == "PASS"
        assert dso_check.expected_value == 60.1
        assert dio_check.status == "PASS"
        assert dio_check.expected_value == 89.6
        assert dpo_check.status == "PASS"
        assert dpo_check.expected_value == 60.2
        assert ccc_check.status == "PASS"
        assert ccc_check.expected_value == 89.5
        # Verify CCC arithmetic identity: 60.1 + 89.6 - 60.2 = 89.5
        assert round(dso_check.expected_value + dio_check.expected_value - dpo_check.expected_value, 1) == 89.5

    def test_subledger_aging_and_schedule_invariants(self, refresh_service: RefreshService):
        """Validates AR aging buckets tie to overdue AR and AP 7-day schedule ties to upcoming buckets."""
        recon_service = FinancialReconciliationService(
            engine=refresh_service.engine,
            metric_service=refresh_service.metric_service,
            active_snapshot=refresh_service.active_snapshot,
        )
        report = recon_service.execute_audit(period="2026-09")
        checks_by_id = {c.check_id: c for c in report.checks}

        # AR Aging: buckets sum to overdue AR ($1,044,000)
        ar_aging = checks_by_id["RECON-AR-AGING-01"]
        assert ar_aging.status == "PASS"
        assert ar_aging.expected_value == 1044000.0
        assert ar_aging.computed_value == 1044000.0

        # AP 7-Day: upcoming buckets sum to upcoming 7d ($1,377,000)
        ap_up = checks_by_id["RECON-AP-SCHED-01"]
        assert ap_up.status == "PASS"
        assert ap_up.expected_value == 1377000.0
        assert ap_up.computed_value == 1377000.0

    def test_trial_balance_and_subledger_ties(self, refresh_service: RefreshService):
        """Validates double-entry symmetrical tie (Debits == Credits)."""
        recon_service = FinancialReconciliationService(
            engine=refresh_service.engine,
            metric_service=refresh_service.metric_service,
            active_snapshot=refresh_service.active_snapshot,
        )
        report = recon_service.execute_audit(period="2026-09")
        checks_by_id = {c.check_id: c for c in report.checks}

        tb_check = checks_by_id["RECON-TB-01"]
        assert tb_check.status == "PASS"
        assert tb_check.variance == 0.0
        assert tb_check.expected_value == tb_check.computed_value


class TestSingleSourceTruthInvariants:
    """Ensures critical financial figures are identical across every layer and model."""

    def test_apex_retail_group_overdue_ar_single_source(self, refresh_service: RefreshService):
        """Apex Retail Group overdue AR must be exactly $1,044,000.00 across subledger, metrics, and cases."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")

        # 1. Subledger open items for Apex Retail Group (CUST-101)
        apex_items = [
            ar for ar in engine.ar_items
            if ar.customer_id == "CUST-101" and ar.days_overdue(as_of) > 0
        ]
        apex_invoice_ids = {ar.invoice_id for ar in apex_items}
        assert apex_invoice_ids == {"INV-AR-50065", "INV-AR-50073", "INV-AR-50081"}

        apex_subledger_overdue = sum(ar.open_amount for ar in apex_items)
        assert apex_subledger_overdue == 1044000.0, f"Expected 1,044,000, got {apex_subledger_overdue}"

        # 2. Metric service customer concentration & overdue items
        rec_detail = refresh_service.metric_service.calculate_receivables("2026-09")
        assert rec_detail.overdue_ar.value == 1044000.0
        top_apex = next(c for c in rec_detail.top_overdue_customers if c.entity_id == "CUST-101")
        assert top_apex.amount == 1044000.0
        assert top_apex.percentage_of_total == 100.0

        # Overdue invoices list in receivables detail
        overdue_invoices = rec_detail.overdue_invoices
        assert len(overdue_invoices) == 3
        assert sum(inv["amount"] for inv in overdue_invoices) == 1044000.0
        assert {inv["invoice_id"] for inv in overdue_invoices} == {"INV-AR-50065", "INV-AR-50073", "INV-AR-50081"}

        # 3. Cases service Case 001 exposure
        cases_svc = CasesService()
        cases = cases_svc.list_cases()
        case_001 = next(c for c in cases if c.id == "CASE-2026-001")
        assert case_001.financial_impact == 1044000.0
        assert "1,044,000" in case_001.summary

    def test_treasury_7day_payables_squeeze_single_source(self, refresh_service: RefreshService):
        """7-day upcoming payables must be exactly $1,377,000.00 across subledger, metrics, and cases."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")

        # 1. Engine upcoming invoices within 7 days
        upcoming_items = engine.get_upcoming_invoices_7d(as_of)
        assert len(upcoming_items) == 3
        total_upcoming = sum(inv["amount"] for inv in upcoming_items)
        assert total_upcoming == 1377000.0

        # Verify vendor breakdown: Titan ($816k), Precision ($408k), Global Freight ($153k)
        vendor_totals = {inv["vendor_name"]: inv["amount"] for inv in upcoming_items}
        assert vendor_totals.get("Titan Semiconductor Ltd") == 816000.0
        assert vendor_totals.get("Precision Metalworks") == 408000.0
        assert vendor_totals.get("Global Freight & Logistics") == 153000.0

        # 2. Metric service payables upcoming 7d
        pay_detail = refresh_service.metric_service.calculate_payables("2026-09")
        assert len(pay_detail.upcoming_invoices) == 3
        assert sum(inv["amount"] for inv in pay_detail.upcoming_invoices) == 1377000.0

        # 3. Cases service Case 002
        cases_svc = CasesService()
        cases = cases_svc.list_cases()
        case_002 = next(c for c in cases if c.id == "CASE-2026-002")
        assert case_002.financial_impact == 1377000.0
        assert "1,377,000" in case_002.summary
        assert "563,250" in case_002.summary

    def test_liquid_cash_single_source(self, refresh_service: RefreshService):
        """Liquid cash must be exactly $813,750.00 across engine, metrics, and cases."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        cash_val, _ = engine.get_cash_position(as_of)
        assert cash_val == 813750.0

        cash_metric = refresh_service.metric_service.calculate_cash_position("2026-09")
        assert cash_metric.value == 813750.0


class TestReconciliationAPIEndpoints:
    """Tests /api/snapshot and /api/reconciliation endpoints via TestClient."""

    def test_get_snapshot_endpoint(self, test_client: TestClient):
        """GET /api/snapshot returns the authoritative active snapshot."""
        response = test_client.get("/api/snapshot")
        assert response.status_code == 200
        data = response.json()

        assert "snapshot_id" in data
        assert data["period"] == "2026-09"
        assert data["source"] == "mock_financial_adapter"
        assert data["calculation_status"] in ("READY", "COMPLETED")
        assert data["data_quality_status"] == "HEALTHY"
        assert data["is_active"] is True

    def test_get_reconciliation_endpoint(self, test_client: TestClient):
        """GET /api/reconciliation executes audit and returns 24 passing checks."""
        response = test_client.get("/api/reconciliation")
        assert response.status_code == 200
        data = response.json()

        assert data["status"] == "RECONCILED"
        assert data["total_checks"] == 24
        assert data["passed_checks"] == 24
        assert data["failed_checks"] == 0
        assert data["period"] == "2026-09"
        assert len(data["checks"]) == 24

        # Verify summary metrics are present and match deterministic values
        summary = data["summary_metrics"]
        assert summary["cash"] == 813750.0
        assert summary["open_ar"] == 2984000.0
        assert summary["trade_ar"] == 2984000.0
        assert summary["gl_ar"] == 3814000.0
        assert summary["other_receivables"] == 830000.0
        assert summary["overdue_ar"] == 1044000.0
        assert summary["open_ap"] == 1785750.0
        assert summary["trade_ap"] == 1785750.0
        assert summary["gl_ap"] == 2435750.0
        assert summary["other_payables"] == 650000.0
        assert summary["upcoming_payables_7d"] == 1377000.0
        assert summary["revenue"] == 1490000.0
        assert summary["cogs"] == 889860.0
        assert summary["gross_profit"] == 600140.0
        assert summary["gross_margin_percent"] == 40.28
        assert summary["dso"] == 60.1
        assert summary["dio"] == 89.6
        assert summary["dpo"] == 60.2
        assert summary["ccc"] == 89.5

    def test_get_reconciliation_period_filter(self, test_client: TestClient):
        """GET /api/reconciliation?period=2026-09 verifies explicit period filtering."""
        response = test_client.get("/api/reconciliation?period=2026-09")
        assert response.status_code == 200
        data = response.json()
        assert data["period"] == "2026-09"
        assert data["status"] == "RECONCILED"


class TestPhase4A25PointReconciliationAudit:
    """Rigorous audit test suite covering all 25 specific audit points from Step 12.
    
    1. GL AR balance
    2. Trade AR subledger balance
    3. AR reconciliation difference & classification
    4. GL AP balance
    5. AP subledger balance
    6. AP reconciliation difference & classification
    7. Current Assets composition
    8. Current Liabilities composition
    9. Net Working Capital (NWC)
    10. Revenue
    11. COGS
    12. Gross Profit
    13. Gross Margin %
    14. DSO
    15. DIO
    16. DPO
    17. CCC
    18. Overdue AR
    19. Customer overdue concentration (Apex Retail Group)
    20. Upcoming AP (7-day window)
    21. Vendor upcoming concentration (Titan, Precision, Global Freight)
    22. Cross-layer evidence consistency
    23. Attention consistency
    24. Investigation consistency
    25. Case consistency
    """

    def test_01_gl_ar_balance(self, refresh_service: RefreshService):
        """1. GL AR balance: Account 110000 balance must equal $3,814,000.00."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        gl_ar = engine.calculate_balance_as_of(FinancialConcept.AR, as_of)
        assert gl_ar == 3814000.0, f"Expected GL AR $3,814,000.00, got {gl_ar}"

    def test_02_trade_ar_subledger_balance(self, refresh_service: RefreshService):
        """2. Trade AR subledger balance: Open customer invoices must sum to $2,984,000.00."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        subledger_ar = engine.get_ar_subledger_balance(as_of)
        assert subledger_ar == 2984000.0, f"Expected Subledger AR $2,984,000.00, got {subledger_ar}"

    def test_03_ar_reconciliation_difference(self, refresh_service: RefreshService):
        """3. AR reconciliation difference: $830,000 difference classified as Other Receivables."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        recon = engine.get_ar_reconciliation(as_of)
        assert recon["gl_ar"] == 3814000.0
        assert recon["trade_ar_subledger"] == 2984000.0
        assert recon["difference"] == 830000.0
        assert recon["other_receivables"] == 830000.0
        assert recon["is_reconciled"] is True
        assert recon["variance"] == 0.0
        assert "Other Receivables" in recon["classification"]

    def test_04_gl_ap_balance(self, refresh_service: RefreshService):
        """4. GL AP balance: Account 200000 balance must equal $2,435,750.00."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        gl_ap = engine.calculate_balance_as_of(FinancialConcept.AP, as_of)
        assert gl_ap == 2435750.0, f"Expected GL AP $2,435,750.00, got {gl_ap}"

    def test_05_ap_subledger_balance(self, refresh_service: RefreshService):
        """5. AP subledger balance: Open vendor invoices must sum to $1,785,750.00."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        subledger_ap = engine.get_ap_subledger_balance(as_of)
        assert subledger_ap == 1785750.0, f"Expected Subledger AP $1,785,750.00, got {subledger_ap}"

    def test_06_ap_reconciliation_difference(self, refresh_service: RefreshService):
        """6. AP reconciliation difference: $650,000 difference classified as Other Payables."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        recon = engine.get_ap_reconciliation(as_of)
        assert recon["gl_ap"] == 2435750.0
        assert recon["trade_ap_subledger"] == 1785750.0
        assert recon["difference"] == 650000.0
        assert recon["other_payables"] == 650000.0
        assert recon["is_reconciled"] is True
        assert recon["variance"] == 0.0
        assert "Other Payables" in recon["classification"]

    def test_07_current_assets_composition(self, refresh_service: RefreshService):
        """7. Current Assets composition: Cash + Trade AR + Other Receivables + Inventory = $7,284,590.00."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        ca, comp = engine.get_current_assets(as_of)
        assert ca == 7284590.0
        assert comp["cash"] == 813750.0
        assert comp["trade_receivables"] == 2984000.0
        assert comp["other_receivables"] == 830000.0
        assert comp["inventory"] == 2656840.0
        assert comp["other_current_assets"] == 0.0
        assert sum(comp.values()) == ca

    def test_08_current_liabilities_composition(self, refresh_service: RefreshService):
        """8. Current Liabilities composition: Trade AP + Other Payables = $2,435,750.00."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        cl, comp = engine.get_current_liabilities(as_of)
        assert cl == 2435750.0
        assert comp["trade_payables"] == 1785750.0
        assert comp["other_payables"] == 650000.0
        assert comp["short_term_debt"] == 0.0
        assert sum(comp.values()) == cl

    def test_09_nwc_balance(self, refresh_service: RefreshService):
        """9. NWC balance: Current Assets ($7,284,590) - Current Liabilities ($2,435,750) = $4,848,840.00."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        nwc = engine.get_net_working_capital(as_of)
        assert nwc == 4848840.0
        ca, _ = engine.get_current_assets(as_of)
        cl, _ = engine.get_current_liabilities(as_of)
        assert nwc == ca - cl

    def test_10_revenue_balance(self, refresh_service: RefreshService):
        """10. Revenue: Authoritative revenue for 2026-09 is $1,490,000.00."""
        pnl = refresh_service.metric_service.calculate_profitability("2026-09")
        assert pnl.revenue.value == 1490000.0

    def test_11_cogs_balance(self, refresh_service: RefreshService):
        """11. COGS: Authoritative COGS for 2026-09 is $889,860.00."""
        pnl = refresh_service.metric_service.calculate_profitability("2026-09")
        assert pnl.cogs.value == 889860.0

    def test_12_gross_profit_balance(self, refresh_service: RefreshService):
        """12. Gross Profit: Revenue - COGS = $600,140.00."""
        pnl = refresh_service.metric_service.calculate_profitability("2026-09")
        assert pnl.gross_profit.value == 600140.0
        assert pnl.gross_profit.value == pnl.revenue.value - pnl.cogs.value

    def test_13_gross_margin_percent(self, refresh_service: RefreshService):
        """13. Gross Margin %: (Gross Profit / Revenue) * 100 = 40.28%."""
        pnl = refresh_service.metric_service.calculate_profitability("2026-09")
        assert pnl.gross_margin_percent.value == 40.28
        assert round((pnl.gross_profit.value / pnl.revenue.value) * 100, 2) == 40.28

    def test_14_dso_metric(self, refresh_service: RefreshService):
        """14. DSO: (Trade Receivables / Revenue) * 30 days = 60.1 days."""
        rec = refresh_service.metric_service.calculate_receivables("2026-09")
        assert rec.dso.value == 60.1

    def test_15_dio_metric(self, refresh_service: RefreshService):
        """15. DIO: (Inventory / COGS) * 30 days = 89.6 days."""
        inv = refresh_service.metric_service.calculate_inventory("2026-09")
        assert inv.dio.value == 89.6

    def test_16_dpo_metric(self, refresh_service: RefreshService):
        """16. DPO: (Trade Payables / COGS) * 30 days = 60.2 days."""
        pay = refresh_service.metric_service.calculate_payables("2026-09")
        assert pay.dpo.value == 60.2

    def test_17_ccc_metric(self, refresh_service: RefreshService):
        """17. CCC: DSO (60.1) + DIO (89.6) - DPO (60.2) = 89.5 days."""
        ccc = refresh_service.metric_service.calculate_ccc("2026-09")
        assert ccc.value == 89.5
        rec = refresh_service.metric_service.calculate_receivables("2026-09")
        inv = refresh_service.metric_service.calculate_inventory("2026-09")
        pay = refresh_service.metric_service.calculate_payables("2026-09")
        assert round(rec.dso.value + inv.dio.value - pay.dpo.value, 1) == 89.5

    def test_18_overdue_ar_balance(self, refresh_service: RefreshService):
        """18. Overdue AR: Total overdue open receivables as of 2026-09-30 is $1,044,000.00."""
        rec = refresh_service.metric_service.calculate_receivables("2026-09")
        assert rec.overdue_ar.value == 1044000.0

    def test_19_customer_overdue_concentration(self, refresh_service: RefreshService):
        """19. Customer overdue concentration: Apex Retail Group represents 100% ($1,044,000) across 3 invoices."""
        rec = refresh_service.metric_service.calculate_receivables("2026-09")
        assert len(rec.top_overdue_customers) >= 1
        top_apex = rec.top_overdue_customers[0]
        assert top_apex.entity_id == "CUST-101"
        assert top_apex.entity_name == "Apex Retail Group"
        assert top_apex.amount == 1044000.0
        assert top_apex.percentage_of_total == 100.0

        # Exact 3 invoices verification
        apex_invoices = [inv for inv in rec.overdue_invoices if inv["customer_id"] == "CUST-101"]
        assert len(apex_invoices) == 3
        inv_map = {inv["invoice_id"]: inv["amount"] for inv in apex_invoices}
        assert inv_map["INV-AR-50065"] == 189000.0
        assert inv_map["INV-AR-50073"] == 425000.0
        assert inv_map["INV-AR-50081"] == 430000.0

    def test_20_upcoming_ap_7d(self, refresh_service: RefreshService):
        """20. Upcoming AP: 7-day window payables is exactly $1,377,000.00."""
        pay = refresh_service.metric_service.calculate_payables("2026-09")
        assert pay.upcoming_payables_7d.value == 1377000.0
        assert len(pay.upcoming_invoices) == 3

    def test_21_vendor_upcoming_concentration(self, refresh_service: RefreshService):
        """21. Vendor upcoming concentration: Titan ($816K), Precision ($408K), Global Freight ($153K)."""
        pay = refresh_service.metric_service.calculate_payables("2026-09")
        assert len(pay.top_vendors_due) == 3
        vendor_map = {v.entity_name: v.amount for v in pay.top_vendors_due}
        assert vendor_map["Titan Semiconductor Ltd"] == 816000.0
        assert vendor_map["Precision Metalworks"] == 408000.0
        assert vendor_map["Global Freight & Logistics"] == 153000.0

    def test_22_cross_layer_evidence_consistency(self, refresh_service: RefreshService):
        """22. Cross-layer evidence consistency: Subledger items tie exactly to GL control accounts."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        ar_subledger = engine.get_ar_subledger_balance(as_of)
        ap_subledger = engine.get_ap_subledger_balance(as_of)
        gl_ar = engine.calculate_balance_as_of(FinancialConcept.AR, as_of)
        gl_ap = engine.calculate_balance_as_of(FinancialConcept.AP, as_of)

        assert gl_ar == ar_subledger + 830000.0  # $2,984,000 + $830,000 = $3,814,000
        assert gl_ap == ap_subledger + 650000.0  # $1,785,750 + $650,000 = $2,435,750

    def test_23_attention_consistency(self, refresh_service: RefreshService):
        """23. Attention consistency: Attention feed items match subledger exposures."""
        from finsight.services.financial_attention_service import FinancialAttentionService
        from finsight.services.financial_intelligence_service import FinancialIntelligenceService
        intel_svc = FinancialIntelligenceService(refresh_service.engine, refresh_service.metric_service)
        attention_svc = FinancialAttentionService(
            refresh_service.engine,
            refresh_service.metric_service,
            intel_svc,
        )
        attention_feed = attention_svc.get_attention_summary("2026-09")
        attn_items = {a.id: a for a in attention_feed.items}

        assert "ATTN-AR-202609-01" in attn_items
        assert attn_items["ATTN-AR-202609-01"].financial_impact == 1044000.0

        assert "ATTN-CASH-202609-01" in attn_items
        assert attn_items["ATTN-CASH-202609-01"].financial_impact == 1377000.0

    def test_24_investigation_consistency(self, refresh_service: RefreshService):
        """24. Investigation consistency: Underlying investigation analytics return authoritative values."""
        engine = refresh_service.engine
        as_of = refresh_service.metric_service._get_period_end_date("2026-09")
        ar_summary = engine.get_ar_summary(as_of)
        assert ar_summary["overdue_ar"] == 1044000.0
        buckets = {b["bucket_name"]: b["amount"] for b in ar_summary["aging_buckets"]}
        assert buckets["0-30"] == 430000.0
        assert buckets["31-60"] == 425000.0
        assert buckets["61-90"] == 189000.0

        upcoming = engine.get_upcoming_invoices_7d(as_of)
        assert sum(item["amount"] for item in upcoming) == 1377000.0

    def test_25_case_consistency(self, refresh_service: RefreshService):
        """25. Case consistency: Seeded remediation cases match underlying findings as snapshot records."""
        cases_svc = CasesService()
        cases = {c.id: c for c in cases_svc.list_cases()}

        assert "CASE-2026-001" in cases
        assert cases["CASE-2026-001"].financial_impact == 1044000.0
        assert cases["CASE-2026-001"].linked_attention_id == "ATTN-AR-202609-01"

        assert "CASE-2026-002" in cases
        assert cases["CASE-2026-002"].financial_impact == 1377000.0
        assert cases["CASE-2026-002"].linked_attention_id == "ATTN-CASH-202609-01"


class TestReconciliationFailureModes:
    """Verifies that deliberate accounting discrepancies reliably trigger FAIL status and non-zero variance."""

    def test_unbalanced_trial_balance_triggers_failure(self, refresh_service: RefreshService):
        """Injecting an unbalanced debit journal entry must trigger FAIL on RECON-TB-01."""
        from datetime import date
        from finsight.models.canonical import JournalEntry

        bad_entry = JournalEntry(
            company_code="1000",
            fiscal_year=2026,
            fiscal_period=9,
            posting_date=date(2026, 9, 15),
            document_id="DOC-CORRUPT-TB",
            gl_account="101000",
            debit_credit="S",
            amount=50000.0,
            currency="INR",
        )
        corrupted_entries = list(refresh_service.engine.journal_entries) + [bad_entry]
        corrupted_engine = FinancialEngine(
            company=refresh_service.engine.company,
            customers=list(refresh_service.engine.customers.values()),
            vendors=list(refresh_service.engine.vendors.values()),
            products=list(refresh_service.engine.products.values()),
            account_mappings=list(refresh_service.engine.account_mappings.values()),
            journal_entries=corrupted_entries,
            ar_items=list(refresh_service.engine.ar_items),
            ap_items=list(refresh_service.engine.ap_items),
        )
        corrupted_metric_svc = MetricService(corrupted_engine)
        recon_svc = FinancialReconciliationService(corrupted_engine, corrupted_metric_svc)
        report = recon_svc.execute_audit("2026-09")

        assert report.status == "DISCREPANCY"
        assert report.failed_checks >= 1

        tb_check = next(c for c in report.checks if c.check_id == "RECON-TB-01")
        assert tb_check.status == "FAIL"
        assert tb_check.variance == 50000.0

    def test_subledger_overdue_mismatch_triggers_failure(self, refresh_service: RefreshService):
        """Simulating a missing line item in overdue invoice subledger detail triggers FAIL on RECON-TOP-CUST-OD-01."""
        recon_svc = FinancialReconciliationService(refresh_service.engine, refresh_service.metric_service)
        real_get_overdue = refresh_service.engine.get_overdue_invoices

        # Omit the first overdue invoice to simulate line item loss
        refresh_service.engine.get_overdue_invoices = lambda d: real_get_overdue(d)[1:]
        try:
            report = recon_svc.execute_audit("2026-09")
            assert report.status == "DISCREPANCY"
            assert report.failed_checks >= 1

            top_cust_check = next(c for c in report.checks if c.check_id == "RECON-TOP-CUST-OD-01")
            assert top_cust_check.status == "FAIL"
            assert top_cust_check.variance > 0
        finally:
            refresh_service.engine.get_overdue_invoices = real_get_overdue

