"""Comprehensive hardening, financial truth, security, and CRM integration tests."""

from datetime import date
import re
import pytest
from starlette.testclient import TestClient

from finsight.adapters.mock_adapter import MockFinancialAdapter
from finsight.api.app import app
from finsight.config import get_settings
from finsight.crm.crm_mock_adapter import MockCRMAdapter
from finsight.models.canonical import AccountCategory, AccountMapping, FinancialConcept
from finsight.services.financial_engine import FinancialEngine
from finsight.services.financial_reconciliation_service import FinancialReconciliationService
from finsight.services.investigation_service import InvestigationService
from finsight.services.metric_service import MetricService
from finsight.services.refresh_service import RefreshService


def test_fiscal_period_consistency(mock_adapter: MockFinancialAdapter):
    """Verify that posting_date matches fiscal_period and fiscal_year across all generated transactions."""
    for je in mock_adapter.get_journal_entries():
        assert je.posting_date.month == je.fiscal_period, (
            f"JE {je.document_id} posting_date {je.posting_date} month does not match fiscal_period {je.fiscal_period}"
        )
        assert je.posting_date.year == je.fiscal_year, (
            f"JE {je.document_id} posting_date {je.posting_date} year does not match fiscal_year {je.fiscal_year}"
        )


def test_effective_dated_account_mappings(mock_adapter: MockFinancialAdapter):
    """Verify that account mappings are resolved according to effective date boundaries."""
    m1 = AccountMapping(
        gl_account="110100",
        financial_concept=FinancialConcept.CASH,
        category=AccountCategory.ASSET,
        valid_from=date(2025, 1, 1),
        valid_to=date(2025, 12, 31),
    )
    m2 = AccountMapping(
        gl_account="110100",
        financial_concept=FinancialConcept.CASH,
        category=AccountCategory.ASSET,
        valid_from=date(2026, 1, 1),
        valid_to=date(2026, 12, 31),
    )

    engine = FinancialEngine(
        company=mock_adapter.get_company(),
        customers=mock_adapter.get_customers(),
        vendors=mock_adapter.get_vendors(),
        products=mock_adapter.get_products(),
        account_mappings=[m1, m2],
        journal_entries=mock_adapter.get_journal_entries(),
        ar_items=mock_adapter.get_ar_items(),
        ap_items=mock_adapter.get_ap_items(),
    )

    res_2025 = engine.get_mapping("110100", as_of_date=date(2025, 6, 1))
    assert res_2025 is not None
    assert res_2025.valid_from == date(2025, 1, 1)

    res_2026 = engine.get_mapping("110100", as_of_date=date(2026, 6, 1))
    assert res_2026 is not None
    assert res_2026.valid_from == date(2026, 1, 1)

    res_out_of_range = engine.get_mapping("110100", as_of_date=date(2024, 6, 1))
    assert res_out_of_range is None


def test_reconciliation_mathematical_subledger(financial_engine: FinancialEngine, metric_service: MetricService):
    """Verify RECON-SUB-GL-01 calculates real mathematical balances from ledger and subledger."""
    recon_svc = FinancialReconciliationService(engine=financial_engine, metric_service=metric_service)
    report = recon_svc.execute_audit(period="2026-09")

    sub_gl_check = next((c for c in report.checks if c.check_id == "RECON-SUB-GL-01"), None)
    assert sub_gl_check is not None
    assert sub_gl_check.expected_value is not None
    assert sub_gl_check.computed_value is not None
    assert sub_gl_check.variance is not None
    # Variance must exactly equal abs(expected_value - computed_value)
    expected_variance = round(abs(sub_gl_check.expected_value - sub_gl_check.computed_value), 2)
    assert sub_gl_check.variance == expected_variance
    assert sub_gl_check.status in ("PASS", "FAIL")


def test_snapshot_persistence_and_sequential_uuid_id():
    """Verify snapshot ID format follows SNAP-{period}-{seq:03d}-{uuid[:6]} and state persists."""
    svc = RefreshService()
    res = svc.execute_refresh()
    assert res.success is True
    snap = svc.active_snapshot

    pattern = r"^SNAP-\d{6}-\d{3}-[0-9A-Fa-f]{6}$"
    assert re.match(pattern, snap.snapshot_id), f"Snapshot ID '{snap.snapshot_id}' does not match pattern {pattern}"

    # Verify reload from persisted state in database
    new_svc = RefreshService()
    reloaded_snap = new_svc.get_snapshot_for_period("2026-09")
    assert reloaded_snap is not None
    assert reloaded_snap.snapshot_id == snap.snapshot_id
    assert reloaded_snap.period == "2026-09"


def test_crm_adapter_generic_and_scenario():
    """Verify MockCRMAdapter handles both scenario customer and generic unmapped customers."""
    crm = MockCRMAdapter()

    # Scenario customer
    scen_profile = crm.get_customer_crm_profile("CUST-101")
    assert scen_profile is not None
    assert scen_profile.account.customer_id == "CUST-101"
    assert scen_profile.account.crm_account_id == "CRM-ACC-101"
    assert scen_profile.signals.commercial_escalation is True
    assert scen_profile.signals.payment_dispute is True

    # Generic customer (unmapped)
    gen_profile = crm.get_customer_crm_profile("CUST-99999")
    assert gen_profile is not None
    assert gen_profile.account.customer_id == "CUST-99999"
    assert gen_profile.account.crm_account_id == "CRM-ACC-99999"
    assert len(gen_profile.contacts) >= 1
    assert len(gen_profile.activities) >= 1


def test_route_security_and_public_config():
    """Verify /health is public, /api/status requires auth, and /api/public/config exposes only safe config."""
    unauth_client = TestClient(app)

    # 1. /health is public
    health_res = unauth_client.get("/health")
    assert health_res.status_code == 200
    assert health_res.json()["status"] == "healthy"

    # 2. /api/status requires authentication
    status_res = unauth_client.get("/api/status")
    assert status_res.status_code == 401

    # 3. /api/public/config is public and contains only safe properties
    config_res = unauth_client.get("/api/public/config")
    assert config_res.status_code == 200
    cfg = config_res.json()
    assert "environment" in cfg
    assert "enable_demo_credentials" in cfg
    assert "default_currency" in cfg
    assert "currency_symbol" in cfg

    # Ensure sensitive settings are not exposed
    forbidden_keys = {"database_path", "secret_key", "password", "sap_url", "credentials"}
    assert not any(k in cfg for k in forbidden_keys)


def test_investigation_metadata_and_crm_evidence(investigation_service: InvestigationService):
    """Verify investigation returns request_id, latency_ms >= 0, grounding_state, and CRM context."""
    res = investigation_service.execute_investigation(
        question="Why is CUST-101 overdue?",
        period="2026-09",
        context={"entity_id": "CUST-101"},
    )
    assert res.request_id is not None
    assert len(res.request_id) > 0
    assert res.latency_ms >= 0
    assert res.status == "COMPLETED"
    assert res.grounding_state in ("GROUNDED", "PARTIALLY_GROUNDED")
    assert res.crm_evidence is not None
    assert len(res.crm_evidence) > 0
    assert res.crm_evidence[0]["customer_id"] == "CUST-101"
    assert res.crm_evidence[0]["crm_account_id"] == "CRM-ACC-101"


def test_authenticated_crm_api_endpoint(test_client: TestClient):
    """Verify authenticated user can fetch CRM profile via API route."""
    res = test_client.get("/api/crm/customers/CUST-101")
    assert res.status_code == 200
    data = res.json()
    assert data["account"]["customer_id"] == "CUST-101"
    assert data["account"]["crm_account_id"] == "CRM-ACC-101"
    assert "signals" in data
    assert "contacts" in data
