"""Integration tests for Intelligence, Attention, and AI Investigator API endpoints."""

from starlette.testclient import TestClient


def test_api_attention_endpoint(test_client: TestClient):
    """GET /api/attention returns prioritized attention items with explainable ranking."""
    response = test_client.get("/api/attention?period=2026-09")
    assert response.status_code == 200
    data = response.json()

    assert data["period"] == "2026-09"
    assert data["total_items"] >= 4
    assert "counts_by_severity" in data
    assert "total_financial_exposure" in data
    assert len(data["items"]) == data["total_items"]

    # Verify ranking
    first_item = data["items"][0]
    assert first_item["priority_score"] >= data["items"][-1]["priority_score"]
    assert "priority_reason" in first_item
    assert "drivers" in first_item
    assert len(first_item["drivers"]) >= 1


def test_api_attention_filters(test_client: TestClient):
    """GET /api/attention supports filtering by severity, type, and status."""
    # Filter severity
    resp_sev = test_client.get("/api/attention?severity=CRITICAL")
    assert resp_sev.status_code == 200
    data_sev = resp_sev.json()
    assert all(it["severity"] == "CRITICAL" for it in data_sev["items"])

    # Filter type
    resp_type = test_client.get("/api/attention?type=CASH_PRESSURE")
    assert resp_type.status_code == 200
    data_type = resp_type.json()
    assert all(it["type"] == "CASH_PRESSURE" for it in data_type["items"])


def test_api_intelligence_endpoint(test_client: TestClient):
    """GET /api/intelligence returns comprehensive intelligence report."""
    response = test_client.get("/api/intelligence?period=2026-09")
    assert response.status_code == 200
    data = response.json()

    assert data["company_code"] == "1000"
    assert data["period"] == "2026-09"
    assert len(data["period_changes"]) >= 12
    assert len(data["material_changes"]) >= 1
    assert len(data["trends"]) >= 8
    assert len(data["anomalies"]) >= 1
    assert len(data["driver_analyses"]) == 4
    assert len(data["customer_intelligence"]) >= 5
    assert len(data["product_intelligence"]) >= 3


def test_api_investigate_endpoint(test_client: TestClient):
    """POST /api/investigate returns observable plan, executed steps, and grounded explanation."""
    payload = {
        "question": "Why did cash decrease?",
        "period": "2026-09",
    }
    response = test_client.post("/api/investigate", json=payload)
    assert response.status_code == 200
    data = response.json()

    assert data["question"] == "Why did cash decrease?"
    assert data["intent"] == "CASH_DECREASE_INVESTIGATION"
    assert "plan" in data
    assert len(data["steps"]) >= 4
    assert all(s["status"] == "COMPLETED" for s in data["steps"])
    assert len(data["findings"]) >= 1
    assert len(data["evidence"]) >= 1
    assert len(data["drivers"]) >= 1
    assert len(data["suggested_next_steps"]) >= 1
    assert "433" in data["answer"] or "cash" in data["answer"].lower()


def test_api_ai_ask_endpoint(test_client: TestClient):
    """POST /api/ai/ask returns executive-ready structured answer."""
    payload = {
        "question": "Why is DSO increasing?",
        "period": "2026-09",
    }
    response = test_client.post("/api/ai/ask", json=payload)
    assert response.status_code == 200
    data = response.json()

    assert "answer" in data
    assert "key_findings" in data
    assert "drivers" in data
    assert "suggested_next_steps" in data
    assert "plan_summary" in data
    assert "Apex Retail Group" in data["answer"]
