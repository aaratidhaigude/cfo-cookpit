"""Tests for FinSight AI Investigation Service (Layer 3).

Verifies intent interpretation, structured investigation plan creation, deterministic tool orchestration,
audit evidence collection, and grounded financial explanations for natural language questions.
"""

from finsight.models.investigation import AskResponse, InvestigationResult
from finsight.services.investigation_service import InvestigationService


def test_intent_interpretation(investigation_service: InvestigationService):
    """Verifies intent classification across the standard financial question patterns."""
    assert investigation_service.interpret_intent("Why did cash decrease?") == "CASH_DECREASE_INVESTIGATION"
    assert investigation_service.interpret_intent("Why is DSO increasing?") == "DSO_INCREASE_INVESTIGATION"
    assert investigation_service.interpret_intent("Which customers are driving overdue AR?") == "OVERDUE_AR_DRIVERS"
    assert investigation_service.interpret_intent("Which customers have high revenue but poor payment behaviour?") == "HIGH_REV_POOR_PAYMENT"
    assert investigation_service.interpret_intent("Where did gross margin decline?") == "MARGIN_DECLINE_INVESTIGATION"
    assert investigation_service.interpret_intent("Which products are hurting profitability?") == "PRODUCT_PROFITABILITY_ISSUE"
    assert investigation_service.interpret_intent("What payments are due in the next 7 days?") == "UPCOMING_PAYMENTS_INQUIRY"
    assert investigation_service.interpret_intent("Why is inventory increasing?") == "INVENTORY_BUILDUP_INVESTIGATION"
    assert investigation_service.interpret_intent("Where is our biggest financial exposure?") == "BIGGEST_EXPOSURE_INVESTIGATION"
    assert investigation_service.interpret_intent("What changed this month?") == "PERIOD_CHANGE_OVERVIEW"


def test_investigation_plan_structure(investigation_service: InvestigationService):
    """Verifies that structured, observable multi-step plans are constructed with deterministic tools."""
    plan = investigation_service.create_investigation_plan("Why did cash decrease?", "2026-09")
    assert plan.question == "Why did cash decrease?"
    assert plan.intent == "CASH_DECREASE_INVESTIGATION"
    assert len(plan.steps) == 5

    # Check that tools come from AIToolsService contracts
    tool_names = [s.tool_name for s in plan.steps]
    assert "compare_periods" in tool_names
    assert "get_receivables" in tool_names
    assert "get_upcoming_payments" in tool_names
    assert "find_metric_drivers" in tool_names

    # Check step details
    for s in plan.steps:
        assert s.step_number > 0
        assert len(s.action) > 5
        assert len(s.tool_name) > 0
        assert isinstance(s.tool_args, dict)
        assert s.status == "PENDING"


def test_question_why_did_cash_decrease(investigation_service: InvestigationService):
    """REQUIRED INVESTIGATION 1: 'Why did cash decrease?'"""
    res = investigation_service.ask("Why did cash decrease?", "2026-09")
    assert isinstance(res, AskResponse)
    assert res.intent == "CASH_DECREASE_INVESTIGATION"

    # Must contain real verified numbers
    assert "$433,000" in res.answer or "433" in res.answer
    assert "$813,750" in res.answer or "813" in res.answer
    assert len(res.drivers) >= 2
    assert len(res.suggested_next_steps) >= 2
    assert len(res.plan_summary) >= 3


def test_question_why_is_dso_increasing(investigation_service: InvestigationService):
    """REQUIRED INVESTIGATION 2: 'Why is DSO increasing?'"""
    res = investigation_service.ask("Why is DSO increasing?", "2026-09")
    assert res.intent == "DSO_INCREASE_INVESTIGATION"

    # Must cite verified DSO and delinquent customer
    assert "DSO" in res.answer
    assert "Apex Retail Group" in res.answer
    assert len(res.key_findings) >= 1
    assert len(res.suggested_next_steps) >= 2


def test_question_which_customers_driving_overdue_ar(investigation_service: InvestigationService):
    """REQUIRED INVESTIGATION 3: 'Which customers are driving overdue AR?'"""
    res = investigation_service.ask("Which customers are driving overdue AR?", "2026-09")
    assert res.intent == "OVERDUE_AR_DRIVERS"

    # Must cite overdue total and Apex Retail Group
    assert "1,044,000" in res.answer or "1.04M" in res.answer or "1044000" in res.answer
    assert "Apex Retail Group" in res.answer
    assert len(res.suggested_next_steps) >= 2


def test_question_where_did_margin_decline(investigation_service: InvestigationService):
    """REQUIRED INVESTIGATION 4: 'Where did gross margin decline?'"""
    res = investigation_service.ask("Where did gross margin decline?", "2026-09")
    assert res.intent == "MARGIN_DECLINE_INVESTIGATION"

    # Must identify COGS outpacing revenue
    assert "percentage points" in res.answer or "%" in res.answer
    assert "COGS" in res.answer or "Cost of Goods Sold" in res.answer
    assert len(res.suggested_next_steps) >= 2


def test_question_upcoming_payments_7d(investigation_service: InvestigationService):
    """REQUIRED INVESTIGATION 5: 'What payments are due in the next 7 days?'"""
    res = investigation_service.ask("What payments are due in the next 7 days?", "2026-09")
    assert res.intent == "UPCOMING_PAYMENTS_INQUIRY"

    # Must cite $1,377,000 upcoming payables
    assert "1,377,000" in res.answer or "1377000" in res.answer
    assert "Precision Metalworks" in res.answer or "Titan Semiconductor" in res.answer
    assert len(res.suggested_next_steps) >= 2


def test_question_high_revenue_poor_payment(investigation_service: InvestigationService):
    """Verifies analysis of high revenue vs poor payment behavior."""
    res = investigation_service.ask("Which customers have high revenue but poor payment behaviour?", "2026-09")
    assert "Apex Retail Group" in res.answer
    assert "OmniChannel Logistics" in res.answer
    assert "Nordic Solutions AG" in res.answer


def test_question_inventory_buildup(investigation_service: InvestigationService):
    """Verifies inventory buildup investigation."""
    res = investigation_service.ask("Why is inventory increasing?", "2026-09")
    assert "Inventory" in res.answer
    assert "DIO" in res.answer or "outpacing" in res.answer


def test_execute_investigation_full_traceability(investigation_service: InvestigationService):
    """Verifies complete execution record with step outcomes and audit evidence."""
    res = investigation_service.execute_investigation("Why did cash decrease?", "2026-09")
    assert isinstance(res, InvestigationResult)

    # Every step should have executed successfully
    assert all(s.status == "COMPLETED" for s in res.steps)
    assert len(res.tool_calls) == len(res.steps)
    assert len(res.findings) >= 2
    assert len(res.evidence) >= 1

    # Verify audit evidence fields
    for ev in res.evidence:
        assert ev.source_id is not None
        assert ev.source_type is not None
        assert len(ev.description) > 0


def test_question_what_changed_this_month(investigation_service: InvestigationService):
    """Verifies overview investigation: 'What changed this month?'"""
    res = investigation_service.ask("What changed this month?", "2026-09")
    assert res.intent == "PERIOD_CHANGE_OVERVIEW"
    assert len(res.answer) > 20
    assert len(res.suggested_next_steps) >= 1


def test_question_biggest_exposure(investigation_service: InvestigationService):
    """Verifies inquiry: 'Where is our biggest financial exposure?'"""
    res = investigation_service.ask("Where is our biggest financial exposure?", "2026-09")
    assert res.intent == "BIGGEST_EXPOSURE_INVESTIGATION"
    assert "exposure" in res.answer.lower() or "liquidity" in res.answer.lower()


def test_question_products_hurting_profitability(investigation_service: InvestigationService):
    """Verifies inquiry: 'Which products are hurting profitability?'"""
    res = investigation_service.ask("Which products are hurting profitability?", "2026-09")
    assert res.intent == "PRODUCT_PROFITABILITY_ISSUE"
    assert "Commodity Server" in res.answer or "margin" in res.answer.lower()


def test_generic_question_fallback(investigation_service: InvestigationService):
    """Verifies fallback on open-ended general inquiry."""
    res = investigation_service.ask("Can you tell me about our financial position?", "2026-09")
    assert res.intent == "GENERAL_FINANCIAL_INQUIRY"
    assert len(res.answer) > 10
