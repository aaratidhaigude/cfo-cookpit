"""FinSight Phase 5 — Finance Knowledge & Policy Intelligence Test Suite.

Comprehensive audit verifying:
1. Canonical Knowledge Document Model & Default Enterprise Corpus
2. Deterministic Local Knowledge Retriever (BM25, Chunking, Section Boosting, Effective Date Resolution)
3. AI Tools Service Knowledge Search Integration
4. AI Investigation Engine Multi-Step Planning (Pure Financial vs Pure Policy vs Hybrid)
5. Evidence Separation (Financial Evidence vs Policy Evidence)
6. Guardrails & Failure Modes:
   - Missing policy handling (zero hallucination)
   - Expired policy handling (effective date boundary)
   - Insufficient financial data handling
   - Contradiction handling (e.g. shipment hold vs customer overdue)
7. FastAPI REST API Knowledge Endpoints
8. Non-negotiable Financial Truth Preservation (authoritative September 2026 numbers)
"""

from datetime import date
import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.api.routes import get_investigation_service, get_knowledge_retriever, get_refresh_service
from finsight.knowledge.corpus import get_default_knowledge_documents
from finsight.models.canonical import FinancialConcept
from finsight.models.evidence import EvidenceItem, EvidenceSourceType
from finsight.models.knowledge import (
    DocumentChunk,
    DocumentType,
    KnowledgeDocument,
    KnowledgeSearchResult,
    KnowledgeSummary,
)
from finsight.services.ai_tools_service import AIToolsService
from finsight.services.knowledge_retriever import BaseKnowledgeRetriever, LocalKnowledgeRetriever


# =============================================================================
# 1. Knowledge Model & Corpus Tests
# =============================================================================

class TestKnowledgeModelAndCorpus:
    """Verifies canonical knowledge document schema and mock enterprise corpus."""

    def test_document_validation(self):
        doc = KnowledgeDocument(
            document_id="TEST-POL-001",
            title="Test Corporate Policy",
            document_type=DocumentType.POLICY,
            domain="AR",
            version="1.0",
            effective_from="2026-01-01",
            status="ACTIVE",
            owner="VP Finance",
            source="INTERNAL",
            confidentiality="INTERNAL",
            text="## 1. Scope\nThis is a test policy body text.",
        )
        assert doc.document_id == "TEST-POL-001"
        assert doc.document_type == DocumentType.POLICY
        assert doc.is_effective_on("2026-06-15") is True
        assert doc.is_effective_on("2025-12-31") is False

    def test_default_corpus_inventory(self):
        docs = get_default_knowledge_documents()
        assert len(docs) >= 8
        doc_ids = {d.document_id for d in docs}
        assert "COLL-POL-001" in doc_ids
        assert "AR-SOP-001" in doc_ids
        assert "AP-POL-001" in doc_ids
        assert "LIQ-CTRL-001" in doc_ids
        assert "INV-POL-001" in doc_ids
        assert "GM-POL-001" in doc_ids
        assert "CRED-POL-001" in doc_ids
        assert "CASE-SOP-001" in doc_ids

    def test_effective_date_boundaries(self):
        docs = get_default_knowledge_documents()
        coll_v1 = next(d for d in docs if d.document_id == "COLL-POL-001-v1.0")
        coll_v2 = next(d for d in docs if d.document_id == "COLL-POL-001")
        tax_expired = next(d for d in docs if d.document_id == "TAX-SOP-EXPIRED")

        # 2025 period
        assert coll_v1.is_effective_on("2025-06-01") is True
        assert coll_v2.is_effective_on("2025-06-01") is False

        # 2026 active period
        assert coll_v1.is_effective_on("2026-09-30") is False
        assert coll_v2.is_effective_on("2026-09-30") is True

        # Expired document
        assert tax_expired.is_effective_on("2026-09-30") is False
        assert tax_expired.status == "EXPIRED"


# =============================================================================
# 2. Local Knowledge Retriever Tests
# =============================================================================

class TestKnowledgeRetriever:
    """Verifies deterministic BM25 search, chunking, and governance summaries."""

    @pytest.fixture
    def retriever(self):
        return LocalKnowledgeRetriever()

    def test_deterministic_chunking(self, retriever):
        summary = retriever.get_governance_summary()
        assert summary.total_documents >= 8
        assert summary.indexed_chunks >= 20
        assert summary.active_documents >= 8
        assert summary.retrieval_status == "READY"

    def test_search_collections_policy(self, retriever):
        results = retriever.search(
            query="collections escalation policy overdue threshold shipment hold",
            effective_date="2026-09-30",
            top_k=3,
        )
        assert len(results) > 0
        top = results[0]
        assert top.document_id == "COLL-POL-001"
        assert top.version == "2.1"
        assert "500,000" in top.excerpt or "Shipment Hold" in top.section or "Hold" in top.excerpt

    def test_domain_filtering(self, retriever):
        ar_results = retriever.search(query="policy", domain="AR", top_k=5)
        for r in ar_results:
            assert r.domain == "AR"

        treasury_results = retriever.search(query="liquidity", domain="TREASURY", top_k=5)
        for r in treasury_results:
            assert r.domain == "TREASURY"

    def test_version_resolution_selects_active_version(self, retriever):
        # Even with query matching v1.0 and v2.1 text, only active v2.1 should be returned for 2026-09-30
        results = retriever.search(
            query="Level 3 Critical Escalation",
            effective_date="2026-09-30",
            top_k=5,
        )
        doc_versions = {r.document_id: r.version for r in results}
        if "COLL-POL-001" in doc_versions:
            assert doc_versions["COLL-POL-001"] == "2.1"
        assert "COLL-POL-001-v1.0" not in doc_versions

    def test_expired_document_filtered_out(self, retriever):
        results = retriever.search(query="tax provisioning compliance", effective_date="2026-09-30")
        matched_ids = [r.document_id for r in results]
        assert "TAX-SOP-EXPIRED" not in matched_ids

    def test_get_document_by_id(self, retriever):
        doc = retriever.get_document("COLL-POL-001")
        assert doc is not None
        assert doc.title == "Collections Escalation Policy"
        assert doc.status == "ACTIVE"

        missing = retriever.get_document("NON-EXISTENT-ID")
        assert missing is None


# =============================================================================
# 3. AI Tools Service Knowledge Tool Tests
# =============================================================================

class TestAIToolsKnowledgeService:
    """Verifies AIToolsService exposing search_finance_knowledge contract."""

    def test_search_finance_knowledge_contract(self):
        refresh_svc = get_refresh_service()
        ai_tools = AIToolsService(refresh_svc)
        tool_res = ai_tools.search_finance_knowledge(
            query="vendor payment approval thresholds",
            domain="AP",
            effective_date="2026-09-30",
            top_k=3,
        )
        assert tool_res["query"] == "vendor payment approval thresholds"
        assert tool_res["domain"] == "AP"
        assert tool_res["matched_count"] > 0
        assert len(tool_res["results"]) > 0
        top = tool_res["results"][0]
        assert top["document_id"] == "AP-POL-001"
        assert "250,000" in top["excerpt"] or "Level 3" in top["excerpt"] or "Approval" in top["section"]


# =============================================================================
# 4. Investigation Engine Multi-Step Planning & Evidence Separation
# =============================================================================

class TestInvestigationEngineHybrid:
    """Verifies hybrid investigation orchestration, intent classification, and evidence separation."""

    @pytest.fixture
    def inv_service(self):
        refresh_svc = get_refresh_service()
        retriever = LocalKnowledgeRetriever()
        ai_tools = AIToolsService(refresh_svc, knowledge_retriever=retriever)
        from finsight.services.financial_intelligence_service import FinancialIntelligenceService
        intel_svc = FinancialIntelligenceService(refresh_svc.engine, refresh_svc.metric_service)
        from finsight.services.investigation_service import InvestigationService
        return InvestigationService(ai_tools, intel_svc)

    def test_pure_financial_question_plan(self, inv_service):
        plan = inv_service.create_investigation_plan("Why did cash decrease?")
        assert plan.intent == "CASH_DECREASE_INVESTIGATION"
        for step in plan.steps:
            assert step.step_type == "FINANCIAL_TOOL"
            assert step.tool_name != "search_finance_knowledge"

    def test_pure_policy_question_plan(self, inv_service):
        plan = inv_service.create_investigation_plan("What is our collections escalation policy?")
        assert plan.intent == "POLICY_KNOWLEDGE_INQUIRY"
        assert len(plan.steps) >= 1
        assert plan.steps[0].step_type == "KNOWLEDGE_RETRIEVAL"
        assert plan.steps[0].tool_name == "search_finance_knowledge"

    def test_hybrid_apex_escalation_plan(self, inv_service):
        q = "Why is Apex overdue and what should finance do according to policy?"
        plan = inv_service.create_investigation_plan(q)
        assert plan.intent == "APEX_POLICY_ESCALATION"
        step_types = [s.step_type for s in plan.steps]
        assert "FINANCIAL_TOOL" in step_types
        assert "KNOWLEDGE_RETRIEVAL" in step_types

    def test_hybrid_execution_and_evidence_separation(self, inv_service):
        q = "Why is Apex overdue and what should finance do according to policy?"
        res = inv_service.execute_investigation(q)

        assert res.intent == "APEX_POLICY_ESCALATION"
        assert len(res.financial_evidence) > 0
        assert len(res.policy_evidence) > 0
        assert len(res.knowledge_sources) > 0

        # Financial evidence should come from AR open items
        for fe in res.financial_evidence:
            assert fe.source_type != EvidenceSourceType.POLICY_DOCUMENT.value
            assert fe.source_type in (EvidenceSourceType.AR_OPEN_ITEM.value, EvidenceSourceType.CUSTOMER_RECORD.value)

        # Policy evidence should come from policy documents
        for pe in res.policy_evidence:
            assert pe.source_type == EvidenceSourceType.POLICY_DOCUMENT.value
            assert pe.source_id == "COLL-POL-001"

        # Check policy context and assessment are populated
        assert res.policy_context is not None
        assert "COLL-POL-001" in res.policy_context
        assert res.assessment is not None
        assert "exceeds both policy thresholds" in res.assessment

        # Check answer structure has 6-part contract
        assert "### Executive Finding" in res.answer
        assert "### Financial Evidence" in res.answer
        assert "### Policy / Control Context" in res.answer
        assert "### Assessment" in res.answer
        assert "### Suggested Next Steps" in res.answer
        assert "### Evidence Sources" in res.answer

    def test_hybrid_liquidity_investigation(self, inv_service):
        q = "Are we compliant with liquidity risk control policy given our upcoming payments?"
        res = inv_service.execute_investigation(q)
        assert res.intent == "LIQUIDITY_POLICY_HYBRID"
        assert "LIQ-CTRL-001" in res.policy_context
        assert "0.59" in res.answer or "0.59" in res.assessment
        assert "fails the 1.00x" in res.assessment or "emergency" in res.assessment


# =============================================================================
# 5. Guardrails & Failure Modes Tests
# =============================================================================

class TestGuardrailsAndFailureModes:
    """Verifies strict adherence to Phase 5 failure modes & non-hallucination guardrails."""

    @pytest.fixture
    def inv_service(self):
        refresh_svc = get_refresh_service()
        retriever = LocalKnowledgeRetriever()
        ai_tools = AIToolsService(refresh_svc, knowledge_retriever=retriever)
        from finsight.services.financial_intelligence_service import FinancialIntelligenceService
        intel_svc = FinancialIntelligenceService(refresh_svc.engine, refresh_svc.metric_service)
        from finsight.services.investigation_service import InvestigationService
        return InvestigationService(ai_tools, intel_svc)

    def test_failure_mode_1_missing_policy(self, inv_service):
        """When user asks for an unindexed policy, AI must state 'No applicable policy was found' and NOT invent rules."""
        res = inv_service.execute_investigation("What is our corporate travel and entertainment policy?")
        assert res.intent == "POLICY_KNOWLEDGE_INQUIRY"
        assert "No applicable policy was found in the internal knowledge base." in res.answer
        assert "FinSight AI strictly avoids inventing internal policies" in res.answer
        assert "Cannot assess compliance as no governing policy exists" in res.assessment

    def test_failure_mode_2_expired_policy(self, inv_service):
        """When a policy is expired for the requested period, AI must state that it has expired."""
        res = inv_service.execute_investigation("What is our tax provisioning SOP and compliance policy?")
        assert res.intent == "POLICY_KNOWLEDGE_INQUIRY"
        assert "No active policy applicable to the requested period was found" in res.answer
        assert "has expired and is not active for the requested period" in res.answer

    def test_failure_mode_3_insufficient_financial_data(self, inv_service):
        """When financial data is missing for an entity, AI must state 'Insufficient financial evidence'."""
        plan = inv_service.create_investigation_plan("Why is NonExistentCorp overdue and what should policy do?")
        # Force a customer exposure check for a non-existent customer
        tool_results = {
            "customer_exposure": {"status": "CUSTOMER_NOT_FOUND", "customer_id": "CUST-999"},
        }
        resp = inv_service.llm.generate_explanation(
            question="Why is NonExistentCorp overdue?",
            intent="APEX_POLICY_ESCALATION",
            findings=[],
            drivers=[],
            evidence=[],
            tool_results=tool_results,
        )
        assert "Insufficient financial evidence to assess policy compliance" in resp["answer"]
        assert "Insufficient financial data to evaluate against policy thresholds." in resp["assessment"]

    def test_failure_mode_4_contradiction_shipment_hold(self, inv_service):
        """When user asks 'Can we release shipments to Apex?', AI must answer 'Shipments cannot be released'."""
        res = inv_service.execute_investigation("Can we release shipments to Apex Retail Group?")
        assert res.intent == "APEX_POLICY_ESCALATION"
        assert "Shipments cannot be released under current policy." in res.answer
        assert any(x in res.answer or x in res.policy_context for x in ("₹500,000", "$500,000", "500,000"))
        assert "45 days" in res.answer or "45 days" in res.policy_context
        assert any(x in res.answer for x in ("₹1,044,000", "$1,044,000", "1,044,000"))
        assert "68 days" in res.answer


# =============================================================================
# 6. REST API Endpoints Tests
# =============================================================================

class TestKnowledgeAPIEndpoints:
    """Verifies all FastAPI routes for knowledge retrieval and hybrid investigation."""

    @pytest.fixture
    def client(self):
        c = TestClient(app)
        resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
        if resp.status_code == 200:
            c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
        return c

    def test_api_list_documents(self, client):
        resp = client.get("/api/knowledge/documents")
        assert resp.status_code == 200
        docs = resp.json()
        assert len(docs) >= 8

        # Test status filter
        active_resp = client.get("/api/knowledge/documents?status=ACTIVE")
        assert active_resp.status_code == 200
        active_docs = active_resp.json()
        assert all(d["status"] == "ACTIVE" for d in active_docs)

    def test_api_get_document_success_and_404(self, client):
        resp = client.get("/api/knowledge/documents/COLL-POL-001")
        assert resp.status_code == 200
        doc = resp.json()
        assert doc["document_id"] == "COLL-POL-001"
        assert doc["title"] == "Collections Escalation Policy"

        resp_404 = client.get("/api/knowledge/documents/UNKNOWN-DOC-999")
        assert resp_404.status_code == 404

    def test_api_search_knowledge(self, client):
        resp = client.get("/api/knowledge/search?query=collections+escalation&domain=AR&top_k=3")
        assert resp.status_code == 200
        results = resp.json()
        assert len(results) > 0
        assert results[0]["document_id"] == "COLL-POL-001"

    def test_api_knowledge_summary(self, client):
        resp = client.get("/api/knowledge/summary")
        assert resp.status_code == 200
        summary = resp.json()
        assert summary["total_documents"] >= 8
        assert summary["active_documents"] >= 8
        assert summary["retrieval_status"] == "READY"

    def test_api_investigate_hybrid_endpoint(self, client):
        payload = {
            "question": "Why is Apex overdue and what should finance do according to policy?",
            "period": "2026-09",
        }
        resp = client.post("/api/investigate", json=payload)
        assert resp.status_code == 200
        res = resp.json()
        assert res["intent"] == "APEX_POLICY_ESCALATION"
        assert len(res["financial_evidence"]) > 0
        assert len(res["policy_evidence"]) > 0
        assert len(res["knowledge_sources"]) > 0
        assert "COLL-POL-001" in res["policy_context"]
        assert "### Executive Finding" in res["answer"]

    def test_api_ask_hybrid_endpoint(self, client):
        payload = {
            "question": "Can we release shipments to Apex Retail Group?",
            "period": "2026-09",
        }
        resp = client.post("/api/ai/ask", json=payload)
        assert resp.status_code == 200
        res = resp.json()
        assert "Shipments cannot be released under current policy." in res["answer"]
        assert len(res["policy_evidence"]) > 0


# =============================================================================
# 7. Regression & Authoritative Financial Truth Audit
# =============================================================================

class TestFinancialTruthPreservation:
    """Verifies zero drift on authoritative September 2026 figures."""

    def test_authoritative_september_2026_values(self):
        refresh_svc = get_refresh_service()
        engine = refresh_svc.engine
        m_svc = refresh_svc.metric_service
        ref_date = date(2026, 9, 30)

        # 1. Cash: $813,750
        cash = m_svc.get_metric_by_name("cash_position", "2026-09")
        assert cash.value == 813750.0

        # 2. Trade AR: $2,984,000
        trade_ar = m_svc.get_metric_by_name("accounts_receivable", "2026-09")
        assert trade_ar.value == 2984000.0

        # 3. Other Receivables: $830,000
        other_ar = m_svc.get_metric_by_name("other_receivables", "2026-09")
        assert other_ar.value == 830000.0

        # 4. Inventory: $2,656,840
        inv = m_svc.get_metric_by_name("inventory_value", "2026-09")
        assert inv.value == 2656840.0

        # 5. Current Assets: $7,284,590
        ca = m_svc.get_metric_by_name("current_assets", "2026-09")
        assert ca.value == 7284590.0

        # 6. Trade AP: $1,785,750
        trade_ap = m_svc.get_metric_by_name("accounts_payable", "2026-09")
        assert trade_ap.value == 1785750.0

        # 7. Other Payables: $650,000
        other_ap = m_svc.get_metric_by_name("other_payables", "2026-09")
        assert other_ap.value == 650000.0

        # 8. Current Liabilities: $2,435,750
        cl = m_svc.get_metric_by_name("current_liabilities", "2026-09")
        assert cl.value == 2435750.0

        # 9. NWC: $4,848,840
        nwc = m_svc.get_metric_by_name("net_working_capital", "2026-09")
        assert nwc.value == 4848840.0

        # 10. Revenue: $1,490,000
        rev = m_svc.get_metric_by_name("revenue", "2026-09")
        assert rev.value == 1490000.0

        # 11. COGS: $889,860
        cogs = m_svc.get_metric_by_name("cogs", "2026-09")
        assert cogs.value == 889860.0

        # 12. Gross Profit: $600,140
        gp = m_svc.get_metric_by_name("gross_profit", "2026-09")
        assert gp.value == 600140.0

        # 13. Gross Margin: 40.28%
        gm = m_svc.get_metric_by_name("gross_margin_percent", "2026-09")
        assert round(gm.value, 2) == 40.28

        # 14. DSO: 60.1 days
        dso = m_svc.get_metric_by_name("dso", "2026-09")
        assert round(dso.value, 1) == 60.1

        # 15. DIO: 89.6 days
        dio = m_svc.get_metric_by_name("dio", "2026-09")
        assert round(dio.value, 1) == 89.6

        # 16. DPO: 60.2 days
        dpo = m_svc.get_metric_by_name("dpo", "2026-09")
        assert round(dpo.value, 1) == 60.2

        # 17. CCC: 89.5 days
        ccc = m_svc.get_metric_by_name("cash_conversion_cycle", "2026-09")
        assert round(ccc.value, 1) == 89.5

        # 18. Overdue AR: $1,044,000 (100% Apex Retail Group across 3 invoices)
        ar_summary = engine.get_ar_summary(ref_date)
        assert ar_summary["total_overdue_ar"] == 1044000.0
        top_od = ar_summary["top_overdue_customers"]
        assert len(top_od) >= 1
        assert top_od[0]["entity_name"] == "Apex Retail Group"
        assert top_od[0]["amount"] == 1044000.0
