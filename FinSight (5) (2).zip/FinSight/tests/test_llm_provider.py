"""Tests for LLM Provider abstraction and financial grounding safety."""

import os
from unittest.mock import patch

from finsight.models.evidence import EvidenceItem
from finsight.services.llm_provider import (
    FINANCIAL_SAFETY_SYSTEM_PROMPT,
    MockLLMProvider,
    RealLLMProvider,
    get_llm_provider,
)


def test_mock_llm_provider_offline():
    """Verifies that MockLLMProvider operates fully offline without API keys."""
    provider = MockLLMProvider()
    resp = provider.generate("Summarize financial numbers")
    assert isinstance(resp, str)
    assert len(resp) > 0


def test_mock_llm_explanation_grounding():
    """Verifies that generated explanations strictly reflect findings and evidence."""
    provider = MockLLMProvider()
    findings = [
        {"claim": "Cash decreased by $433,000 from $1,246,750 to $813,750"},
        {"claim": "Upcoming payables of $1,377,000 mature in 7 days"},
    ]
    evidence = [
        EvidenceItem(
            source_type="AP_OPEN_ITEM",
            source_id="INV-AP-101",
            entity="Titan Semiconductor",
            metric="upcoming_payables",
            value=816000.0,
            description="Obligation due in 5 days",
        )
    ]
    tool_results = {
        "cash_comparison": {
            "current_value": 813750.0,
            "previous_value": 1246750.0,
            "absolute_change": -433000.0,
            "percentage_change": -34.7,
        }
    }

    result = provider.generate_explanation(
        question="Why did cash decrease?",
        intent="CASH_DECREASE_INVESTIGATION",
        findings=findings,
        drivers=["Imminent Accounts Payable Obligations"],
        evidence=evidence,
        tool_results=tool_results,
    )

    assert "answer" in result
    assert "key_findings" in result
    assert "drivers" in result
    assert "suggested_next_steps" in result

    # Answer must include exact figures from tool results
    assert any(x in result["answer"] for x in ("₹433,000", "$433,000", "433"))
    assert any(x in result["answer"] for x in ("₹813,750", "$813,750", "813"))
    assert "Titan Semiconductor" in result["answer"]


def test_financial_safety_system_prompt():
    """Verifies that the financial safety instructions forbid calculation and hallucination."""
    prompt = FINANCIAL_SAFETY_SYSTEM_PROMPT
    assert "NEVER calculate or compute financial numbers yourself" in prompt
    assert "NEVER invent, assume, or hallucinate" in prompt
    assert "traceable to the provided tool outputs" in prompt
    assert "insufficient" in prompt


def test_llm_provider_factory():
    """Verifies provider selection logic with defaults and fallbacks."""
    # Default to mock
    provider = get_llm_provider("mock")
    assert isinstance(provider, MockLLMProvider)

    # When no key is set for gemini, falls back to MockLLMProvider
    with patch.dict(os.environ, {"GEMINI_API_KEY": ""}, clear=False):
        provider = get_llm_provider("gemini")
        assert isinstance(provider, MockLLMProvider)


def test_real_llm_provider_fallback_on_network_error():
    """Verifies that RealLLMProvider falls back gracefully to MockLLMProvider when network or API fails."""
    real_provider = RealLLMProvider(provider_type="gemini")
    # Generating with invalid key or network disconnection falls back to deterministic mock
    resp = real_provider.generate("test prompt")
    assert isinstance(resp, str)
    assert len(resp) > 0
