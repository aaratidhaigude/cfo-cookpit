"""Comprehensive validation tests for FinSight Master Phase 1 (S20 to S26).

Covers:
S20 — Financial Correctness & Trust (Period & Horizon validation, 400 on invalid input, zero drift)
S21 — .env + Configuration + Secrets (safe masking, SAP variables)
S22 — Backend + API Endpoint Audit (governed HTTP statuses, no fabricated numbers)
S23 — Financial Data Foundation (ACDOCA-aligned records, DeterministicScenario enum)
S24 — Ratios + Calculation Governance (DuPont 3-tier tie with governed Operating ROE)
S25 — CFO Intelligence (Customer-level AR aging schedule & concentration)
S26 — Performance + Historical Intelligence (Material movements, driver attribution)
"""

import pytest
from fastapi.testclient import TestClient

from finsight.api.app import app
from finsight.config import settings
from finsight.adapters.mock_adapter import DeterministicScenario, MockFinancialAdapter
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


client = TestClient(app)
_login_res = client.post("/api/auth/login", json={"username": "admin", "password": "demo123"}).json()
if "token" in _login_res:
    client.headers["Authorization"] = f"Bearer {_login_res['token']}"


# -----------------------------------------------------------------------------
# S20: Financial Correctness, Validation & Trust
# -----------------------------------------------------------------------------

def test_s20_invalid_periods_return_400():
    """Verify invalid fiscal period inputs strictly return HTTP 400 Bad Request."""
    invalid_periods = ["2026-00", "2026-13", "bad", "", "2026-9", "invalid-period"]
    endpoints = [
        "/api/snapshot",
        "/api/financials",
        "/api/reconciliation",
        "/api/financials/ratios",
        "/api/financials/dupont",
    ]

    for ep in endpoints:
        for p in invalid_periods:
            res = client.get(f"{ep}?period={p}")
            assert res.status_code == 400, f"Expected 400 for {ep}?period={p}, got {res.status_code}"


def test_s20_unsupported_forecast_horizons_return_400():
    """Verify unsupported forecast horizons return HTTP 400."""
    for h in [17, 999, 0, -5, 45]:
        res = client.get(f"/api/forecast/cash?horizon_days={h}")
        assert res.status_code == 400, f"Expected 400 for horizon {h}, got {res.status_code}"


def test_s20_supported_forecast_horizons_return_200():
    """Verify standard governed horizons (30, 60, 90) return HTTP 200."""
    for h in [30, 60, 90]:
        res = client.get(f"/api/forecast/cash?horizon_days={h}")
        assert res.status_code == 200, f"Expected 200 for horizon {h}, got {res.status_code}"
        data = res.json()
        assert data["horizon_days"] == h
        assert data["starting_cash"] == 813750.0


# -----------------------------------------------------------------------------
# S21: Configuration, .env & Secrets
# -----------------------------------------------------------------------------

def test_s21_configuration_masks_secrets():
    """Verify configuration safe_dict masks sensitive credentials."""
    safe = settings.safe_dict()

    assert "sap_password" in safe
    assert safe["sap_password"] in ("***", "********") or safe["sap_password"] is None
    if settings.gemini_api_key:
        assert safe["gemini_api_key"] in ("***", "********")
    if settings.openai_api_key:
        assert safe["openai_api_key"] in ("***", "********")

    # Verify public settings are exposed properly
    assert "default_currency" in safe
    assert "currency_symbol" in safe
    assert "sap_mock_mode" in safe
    assert "is_sap_live_configured" in safe


def test_s21_admin_config_endpoint_masks_secrets():
    """Verify admin config API route enforces authentication and exposes settings without secrets."""
    # Unauthenticated request must return 401 Unauthorized
    unauth_client = TestClient(app)
    res_unauth = unauth_client.get("/api/admin/config")
    assert res_unauth.status_code == 401

    # Authenticate as admin
    login_resp = unauth_client.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    assert login_resp.status_code == 200
    token = login_resp.json()["token"]

    # Authenticated admin request returns 200 and masks secrets
    res = unauth_client.get("/api/admin/config", headers={"Authorization": f"Bearer {token}"})
    assert res.status_code == 200
    cfg = res.json()
    assert "sap_password" not in cfg or cfg.get("sap_password") in ("***", "********")
    assert "currency" in cfg
    assert "sap_mock_mode" in cfg


# -----------------------------------------------------------------------------
# S22: Backend & API Endpoint Surface Audit
# -----------------------------------------------------------------------------

def test_s22_core_api_surface_health():
    """Verify all authoritative endpoints return 200 and well-formed schemas."""
    endpoints = [
        "/api/health",
        "/api/snapshot",
        "/api/financials",
        "/api/reconciliation",
        "/api/ratios",
        "/api/financials/dupont",
        "/api/performance",
        "/api/data-trust/summary",
    ]
    for ep in endpoints:
        res = client.get(ep)
        assert res.status_code == 200, f"Expected 200 for {ep}, got {res.status_code}"


# -----------------------------------------------------------------------------
# S23: Financial Data Foundation
# -----------------------------------------------------------------------------

def test_s23_deterministic_scenarios_enum():
    """Verify deterministic scenario foundation defines required enterprise stress scenarios."""
    scenarios = [s.value for s in DeterministicScenario]
    assert "NORMAL" in scenarios
    assert "AR_DETERIORATION" in scenarios
    assert "INVENTORY_BUILDUP" in scenarios
    assert "MARGIN_DECLINE" in scenarios
    assert "LIQUIDITY_PRESSURE" in scenarios


def test_s23_canonical_adapter_referential_integrity():
    """Verify adapter data integrity across GL, AR, AP, and master data."""
    adapter = MockFinancialAdapter()
    engine = FinancialEngine.from_adapter(adapter)

    wc = engine.get_working_capital_components(adapter._reference_date)
    assert wc["total_current_assets"] == 7284590.0
    pnl = engine.get_pnl_for_period("2026-09")
    assert pnl["revenue"] == 1490000.0
    assert pnl["cogs"] == 889860.0
    assert pnl["gross_profit"] == 600140.0


# -----------------------------------------------------------------------------
# S24: Ratios & Calculation Governance (DuPont Analysis)
# -----------------------------------------------------------------------------

def test_s24_dupont_analysis_mathematical_tie():
    """Verify DuPont 3-tier decomposition ties mathematically with governed Operating ROE."""
    res = client.get("/api/financials/dupont?period=2026-09")
    assert res.status_code == 200
    dupont = res.json()

    # Authoritative inputs for 2026-09
    assert dupont["period"] == "2026-09"
    assert dupont["revenue"] == 1490000.0
    assert dupont["total_assets"] == 10284590.0
    assert dupont["total_equity"] == 3900000.0
    assert dupont["operating_income"] == 162140.0

    # DuPont components
    assert round(dupont["operating_margin_pct"], 2) == 10.88
    assert round(dupont["asset_turnover"], 4) == 0.1449
    assert round(dupont["equity_multiplier"], 4) == 2.6371

    # Exact mathematical product
    # 10.8819% * 0.144877 * 2.637074 = 4.1574% -> 4.16%
    assert dupont["dupont_operating_roe"] == 4.16
    assert dupont["governed_operating_roe"] == 4.16
    assert dupont["variance"] <= 0.01
    assert dupont["is_tied"] is True
    assert "mathematically ties" in dupont["explanation"]


# -----------------------------------------------------------------------------
# S25: CFO Intelligence: Customer-Level AR Aging
# -----------------------------------------------------------------------------

def test_s25_customer_level_ar_aging_breakdown():
    """Verify AR summary includes customer-level aging schedule across all 5 standard buckets."""
    adapter = MockFinancialAdapter()
    engine = FinancialEngine.from_adapter(adapter)
    summary = engine.get_ar_summary(adapter._reference_date)

    assert "customer_aging" in summary
    assert len(summary["customer_aging"]) > 0

    # Verify each customer entry has full aging bucket decomposition
    total_customer_open = 0.0
    total_customer_overdue = 0.0

    for c in summary["customer_aging"]:
        assert "customer_id" in c
        assert "customer_name" in c
        assert "current_amount" in c
        assert "overdue_1_30" in c
        assert "overdue_31_60" in c
        assert "overdue_61_90" in c
        assert "overdue_90_plus" in c
        assert "total_open" in c
        assert "total_overdue" in c

        # Arithmetic check within customer
        calc_open = (
            c["current_amount"]
            + c["overdue_1_30"]
            + c["overdue_31_60"]
            + c["overdue_61_90"]
            + c["overdue_90_plus"]
        )
        assert abs(calc_open - c["total_open"]) <= 0.01

        calc_od = (
            c["overdue_1_30"]
            + c["overdue_31_60"]
            + c["overdue_61_90"]
            + c["overdue_90_plus"]
        )
        assert abs(calc_od - c["total_overdue"]) <= 0.01

        total_customer_open += c["total_open"]
        total_customer_overdue += c["total_overdue"]

    # Verify total ties with subledger AR
    assert round(total_customer_open, 2) == 2984000.0
    assert round(total_customer_overdue, 2) == 1044000.0


def test_s25_apex_retail_group_aging_schedule():
    """Verify Apex Retail Group has $1,044,000 overdue concentrated in 1-30, 31-60, 61-90."""
    adapter = MockFinancialAdapter()
    engine = FinancialEngine.from_adapter(adapter)
    summary = engine.get_ar_summary(adapter._reference_date)

    apex = next((c for c in summary["customer_aging"] if "Apex" in c["customer_name"]), None)
    assert apex is not None
    assert apex["total_overdue"] == 1044000.0
    assert apex["current_amount"] == 435000.0
    assert apex["total_open"] == 1479000.0
    assert round(apex["overdue_percentage"], 1) == 70.6


# -----------------------------------------------------------------------------
# S26: Performance & Historical Intelligence
# -----------------------------------------------------------------------------

def test_s26_performance_intelligence_summary():
    """Verify performance intelligence provides material movements and drivers."""
    res = client.get("/api/performance?period=2026-09")
    assert res.status_code == 200
    perf = res.json()

    assert perf["period"] == "2026-09"
    assert perf["revenue"] == 1490000.0
    assert perf["gross_profit"] == 600140.0
    assert perf["net_working_capital"] == 4848840.0
    assert perf["ccc"] == 89.5
    assert len(perf["what_changed"]) > 0
    assert perf["material_movements_count"] > 0
