"""Comprehensive Automated Verification Test Suite for FinSight Master Phase 2 (S27 - S33).

Tests:
1. S27: Executive 6-KPI row contract on /api/financial-summary (Cash, NWC, Current Ratio, DSO, CCC, Gross Margin).
2. S28: Grounded AI evidence state (SUPPORTED, PARTIALLY_SUPPORTED, INSUFFICIENT_DATA, OUT_OF_SCOPE).
3. S29: SQLite persistence for cases and actions across service instances.
4. S29: Strict lifecycle transitions (OPEN -> IN_REVIEW -> ACTION_REQUIRED -> RESOLVED -> CLOSED) and closed case immutability.
5. S30: Authentication & RBAC security enforcement (401 unauthenticated, 403 unauthorized for ANALYST closing cases).
6. S31: Failure modes: unknown period 404, invalid period 400, invalid horizon 400, zero-division ratio safety.
"""

import tempfile
import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.models.cases import (
    CaseCategory,
    CaseSeverity,
    CaseStatus,
    CloseCaseRequest,
    CreateCaseRequest,
    RemediationAction,
    UpdateCaseRequest,
)
from finsight.services.cases_service import CasesService
from finsight.services.financial_engine import FinancialEngine
from finsight.services.refresh_service import RefreshService
from finsight.models.metrics import MetricStatus


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def manager_token(client):
    resp = client.post("/api/auth/login", json={"username": "manager", "password": "demo123"})
    assert resp.status_code == 200
    return resp.json()["token"]


@pytest.fixture
def analyst_token(client):
    resp = client.post("/api/auth/login", json={"username": "analyst", "password": "demo123"})
    assert resp.status_code == 200
    return resp.json()["token"]


# -----------------------------------------------------------------------------
# S27: Executive 6-KPI Contract Verification
# -----------------------------------------------------------------------------

def test_executive_six_kpi_payload_contract(client, manager_token):
    """Verifies /api/financial-summary delivers all 6 executive KPIs dynamically."""
    resp = client.get("/api/financial-summary?period=2026-09", headers={"Authorization": f"Bearer {manager_token}"})
    assert resp.status_code == 200
    data = resp.json()

    # 1. Cash Position
    assert "cash_position" in data
    assert data["cash_position"]["value"] is not None

    # 2. Net Working Capital
    assert "net_working_capital" in data
    assert data["net_working_capital"]["value"] is not None

    # 3. Current Ratio
    assert "current_ratio" in data
    assert data["current_ratio"]["value"] is not None
    assert data["current_ratio"]["value"] > 0

    # 4. DSO
    assert "dso" in data
    assert data["dso"]["value"] is not None

    # 5. CCC
    assert "ccc" in data
    assert data["ccc"]["value"] is not None

    # 6. Gross Margin %
    assert "gross_margin_percent" in data
    assert data["gross_margin_percent"]["value"] is not None


# -----------------------------------------------------------------------------
# S28: AI Grounding & Evidence States
# -----------------------------------------------------------------------------

def test_investigation_evidence_states(client, manager_token):
    """Verifies AI investigation returns grounded evidence states."""
    headers = {"Authorization": f"Bearer {manager_token}"}
    # Out of scope query
    resp = client.post("/api/ai/ask", json={"question": "What is the weather in Mumbai?"}, headers=headers)
    assert resp.status_code == 200
    data = resp.json()
    assert data["evidence_state"] == "OUT_OF_SCOPE"

    # Unsupported future revenue forecast
    resp2 = client.post("/api/ai/ask", json={"question": "What will our sales be next quarter?"}, headers=headers)
    assert resp2.status_code == 200
    data2 = resp2.json()
    assert data2["evidence_state"] == "INSUFFICIENT_DATA"

    # Supported query grounded in actual financial ledger
    resp3 = client.post("/api/ai/ask", json={"question": "Why did cash decrease in September 2026?"}, headers=headers)
    assert resp3.status_code == 200
    data3 = resp3.json()
    assert data3["evidence_state"] in ("SUPPORTED", "PARTIALLY_SUPPORTED")
    assert len(data3["evidence"]) > 0


# -----------------------------------------------------------------------------
# S29: SQLite Persistence Across Restarts
# -----------------------------------------------------------------------------

def test_sqlite_persistence_across_service_instances(tmp_path):
    """Verifies cases written to SQLite persist across separate CasesService instances."""
    db_file = str(tmp_path / "test_persistence.db")

    # Instance 1: Create a case and add an action
    service1 = CasesService(db_path=db_file)
    new_case = service1.create_case(CreateCaseRequest(
        title="Vendor Rebate Recovery Dispute",
        severity=CaseSeverity.HIGH,
        category=CaseCategory.PAYABLES,
        financial_exposure=450000.0,
        entity="Apex Supply Partners",
        period="2026-09",
        summary="Disputed volume rebate credit memo pending audit confirmation.",
    ))
    case_id = new_case.id

    service1.add_remediation_action(
        case_id=case_id,
        action=RemediationAction(
            action="Confirm credit memo with Apex controller",
            owner="AP Lead",
            due_date="2026-10-15",
            status="OPEN",
        ),
        actor="Finance Manager",
    )

    # Instance 2: Brand new instance pointing to same SQLite database
    service2 = CasesService(db_path=db_file)
    retrieved = service2.get_case(case_id)
    assert retrieved is not None
    assert retrieved.title == "Vendor Rebate Recovery Dispute"
    assert retrieved.financial_exposure == 450000.0
    assert retrieved.entity == "Apex Supply Partners"
    assert len(retrieved.remediation_plan) >= 1
    assert any(a.action == "Confirm credit memo with Apex controller" for a in retrieved.remediation_plan)


# -----------------------------------------------------------------------------
# S29: Strict Lifecycle Transitions & Closed Case Immutability
# -----------------------------------------------------------------------------

def test_strict_lifecycle_transitions(tmp_path):
    """Verifies allowed transitions: OPEN -> IN_REVIEW -> ACTION_REQUIRED -> RESOLVED -> CLOSED."""
    db_file = str(tmp_path / "test_lifecycle.db")
    svc = CasesService(db_path=db_file)
    case = svc.create_case(CreateCaseRequest(
        title="Lifecycle Test Case",
        summary="Testing state machine",
    ))
    cid = case.id
    assert case.status == CaseStatus.OPEN

    # 1. OPEN -> IN_REVIEW
    c1 = svc.update_case(cid, UpdateCaseRequest(status=CaseStatus.IN_REVIEW))
    assert c1.status == CaseStatus.IN_REVIEW

    # 2. IN_REVIEW -> ACTION_REQUIRED
    c2 = svc.update_case(cid, UpdateCaseRequest(status=CaseStatus.ACTION_REQUIRED))
    assert c2.status == CaseStatus.ACTION_REQUIRED

    # 3. ACTION_REQUIRED -> RESOLVED (requires resolution evidence & summary)
    c3 = svc.update_case(cid, UpdateCaseRequest(
        status=CaseStatus.RESOLVED,
        resolution_summary="Reconciliation verified by auditor",
        resolution_evidence="Auditor signoff letter #2026-09",
    ))
    assert c3.status == CaseStatus.RESOLVED

    # 4. RESOLVED -> CLOSED
    c4 = svc.update_case(cid, UpdateCaseRequest(
        status=CaseStatus.CLOSED,
        resolution_summary="Reconciliation verified by auditor",
        resolution_evidence="Auditor signoff letter #2026-09",
        reviewer="CFO",
    ))
    assert c4.status == CaseStatus.CLOSED

    # 5. Closed case cannot be modified
    with pytest.raises(ValueError, match="Cannot modify a closed case"):
        svc.update_case(cid, UpdateCaseRequest(status=CaseStatus.OPEN))

    with pytest.raises(ValueError, match="Cannot modify a closed case"):
        svc.add_remediation_action(cid, RemediationAction(
            action="Illegal action after close",
            owner="Analyst",
            due_date="2026-10-20",
        ))


# -----------------------------------------------------------------------------
# S30: Authentication & RBAC Enforcement
# -----------------------------------------------------------------------------

def test_rbac_mutation_and_closure_guards(client, manager_token, analyst_token):
    """Verifies 401 unauthenticated and 403 role-based access control."""
    # 1. Unauthenticated mutation -> 401
    resp_unauth = client.post("/api/cases", json={
        "title": "Unauthenticated Case",
        "summary": "Should be rejected",
    })
    assert resp_unauth.status_code == 401

    # 2. Authenticated creation by Analyst -> 200
    resp_create = client.post(
        "/api/cases",
        json={"title": "Analyst Created Case", "summary": "Valid creation"},
        headers={"Authorization": f"Bearer {analyst_token}"},
    )
    assert resp_create.status_code == 200
    case_id = resp_create.json()["id"]

    # 3. Analyst attempting to close case -> 403 Forbidden
    resp_close_analyst = client.post(
        f"/api/cases/{case_id}/close",
        json={
            "resolution_summary": "Attempting analyst close",
            "resolution_evidence": "Evidence 123",
            "reviewer": "Self",
        },
        headers={"Authorization": f"Bearer {analyst_token}"},
    )
    assert resp_close_analyst.status_code == 403
    assert "FINANCE_ANALYST is not authorized" in resp_close_analyst.json()["detail"]

    # 4. Manager closing case -> 200 Success
    resp_close_mgr = client.post(
        f"/api/cases/{case_id}/close",
        json={
            "resolution_summary": "Manager verified and resolved",
            "resolution_evidence": "Signoff #9941",
            "reviewer": "Finance Manager",
        },
        headers={"Authorization": f"Bearer {manager_token}"},
    )
    assert resp_close_mgr.status_code == 200
    assert resp_close_mgr.json()["status"] == "CLOSED"


# -----------------------------------------------------------------------------
# S31: Failure Modes & Input Validation
# -----------------------------------------------------------------------------

def test_failure_modes_and_input_validation(client, manager_token):
    """Verifies graceful handling of unknown periods, invalid formats, and bad horizons."""
    headers = {"Authorization": f"Bearer {manager_token}"}
    # 1. Invalid period format -> 400 Bad Request
    resp1 = client.get("/api/financial-summary?period=invalid-period", headers=headers)
    assert resp1.status_code == 400

    # 2. Unknown period (valid format, but not in ledger) -> 404 Not Found
    resp2 = client.get("/api/financial-summary?period=2015-01", headers=headers)
    assert resp2.status_code == 404

    # 3. Invalid cash forecast horizon -> 400 Bad Request
    resp3 = client.get("/api/forecast/cash?horizon_days=45", headers=headers)
    assert resp3.status_code == 400

    # 4. Non-silent closure validation: missing evidence returns 400
    resp4 = client.post("/api/cases/CASE-2026-001/close", json={
        "resolution_summary": "Summary without evidence",
        "resolution_evidence": "",
    }, headers=headers)
    assert resp4.status_code == 400


def test_ratio_zero_denominator_safe_indicators():
    """Verifies that ratio calculators handle zero denominators safely without crashing."""
    svc = RefreshService().metric_service

    # Normal calculations return valid dynamic metrics
    cr = svc.calculate_current_ratio(period="2026-09")
    assert cr.value is not None
    assert cr.value > 0

    recv = svc.calculate_receivables(period="2026-09")
    assert recv.dso.value is not None

    inv = svc.calculate_inventory(period="2026-09")
    assert inv.dio.value is not None

    pay = svc.calculate_payables(period="2026-09")
    assert pay.dpo.value is not None

    ccc = svc.calculate_ccc(period="2026-09")
    assert ccc.value is not None

    # Ratio calculation with zero denominator handles gracefully with ZERO_DENOMINATOR status
    from unittest.mock import patch
    with patch.object(svc.engine, "get_working_capital_components", return_value={"total_current_assets": 1000.0, "total_current_liabilities": 0.0}):
        cr_zero = svc.calculate_current_ratio(period="2026-09")
        assert cr_zero.value is None
        assert cr_zero.status == MetricStatus.ZERO_DENOMINATOR
        assert cr_zero.formatted_value == "ZERO_DENOMINATOR"
