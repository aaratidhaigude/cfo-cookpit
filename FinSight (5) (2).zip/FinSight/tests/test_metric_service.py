"""Tests for Metric Service calculations, period comparisons, and edge cases."""

from datetime import date
from finsight.models.canonical import (
    AccountCategory,
    AccountMapping,
    Company,
    FinancialConcept,
    JournalEntry,
)
from finsight.models.metrics import MetricStatus, TrendDirection
from finsight.services.financial_engine import FinancialEngine
from finsight.services.metric_service import MetricService


def test_cash_metric(metric_service: MetricService):
    cash = metric_service.calculate_cash_position("2026-09")
    assert cash.status == MetricStatus.CALCULATED
    assert cash.value is not None
    assert cash.value > 0
    assert any(c in cash.formatted_value for c in ("₹", "$"))
    assert len(cash.dimensions["bank_accounts"]) > 0


def test_working_capital_metrics(metric_service: MetricService):
    wc = metric_service.calculate_working_capital("2026-09")
    assert wc.current_assets.value is not None and wc.current_assets.value > 0
    assert wc.current_liabilities.value is not None and wc.current_liabilities.value > 0
    assert wc.net_working_capital.value is not None
    # Verify mathematical identity: NWC = CA - CL
    expected_nwc = round(wc.current_assets.value - wc.current_liabilities.value, 2)
    assert abs(wc.net_working_capital.value - expected_nwc) < 0.05


def test_receivables_metrics_and_dso(metric_service: MetricService):
    rec = metric_service.calculate_receivables("2026-09")
    assert rec.accounts_receivable.value is not None and rec.accounts_receivable.value > 0
    assert rec.overdue_ar.value is not None and rec.overdue_ar.value > 0
    assert rec.overdue_ar_percent.value is not None and rec.overdue_ar_percent.value > 0
    assert rec.dso.value is not None and rec.dso.value > 20.0
    assert len(rec.aging_schedule) == 4


def test_payables_metrics_and_dpo(metric_service: MetricService):
    pay = metric_service.calculate_payables("2026-09")
    assert pay.accounts_payable.value is not None and pay.accounts_payable.value > 0
    assert pay.upcoming_payables_7d.value is not None and pay.upcoming_payables_7d.value > 0
    assert pay.dpo.value is not None and pay.dpo.value > 15.0
    assert len(pay.upcoming_schedule) == 4


def test_inventory_metrics_and_dio(metric_service: MetricService):
    inv = metric_service.calculate_inventory("2026-09")
    assert inv.inventory_value.value is not None and inv.inventory_value.value > 0
    assert inv.dio.value is not None and inv.dio.value > 30.0
    assert inv.inventory_to_sales_ratio.value is not None


def test_profitability_metrics(metric_service: MetricService):
    prof = metric_service.calculate_profitability("2026-09")
    assert prof.revenue.value is not None and prof.revenue.value > 1000000.0
    assert prof.cogs.value is not None and prof.cogs.value > 500000.0
    assert prof.gross_profit.value is not None
    assert prof.gross_margin_percent.value is not None
    # GP = Revenue - COGS
    expected_gp = round(prof.revenue.value - prof.cogs.value, 2)
    assert abs(prof.gross_profit.value - expected_gp) < 0.05


def test_period_comparison(metric_service: MetricService):
    prof = metric_service.calculate_profitability("2026-09")
    comp = prof.revenue.comparison
    assert comp is not None
    assert comp.previous_period == "2026-08"
    assert comp.previous_value is not None
    assert comp.absolute_change is not None
    assert comp.percentage_change is not None


def test_edge_case_zero_revenue_denominator():
    """Edge Case: When revenue is 0, DSO and Gross Margin % must NOT divide by zero or silently return 0.

    They must explicitly return status ZERO_DENOMINATOR and value=None.
    """
    company = Company(company_code="1000", company_name="Zero Rev Corp", currency="USD")
    mappings = [
        AccountMapping(gl_account="101000", financial_concept=FinancialConcept.CASH, category=AccountCategory.ASSET, valid_from=date(2025, 1, 1)),
        AccountMapping(gl_account="400000", financial_concept=FinancialConcept.REVENUE, category=AccountCategory.REVENUE, valid_from=date(2025, 1, 1)),
        AccountMapping(gl_account="500000", financial_concept=FinancialConcept.COGS, category=AccountCategory.EXPENSE, valid_from=date(2025, 1, 1)),
    ]
    # No revenue entries posted in 2026-09
    engine = FinancialEngine(
        company=company,
        customers=[],
        vendors=[],
        products=[],
        account_mappings=mappings,
        journal_entries=[],
        ar_items=[],
        ap_items=[],
    )
    svc = MetricService(engine=engine)

    prof = svc.calculate_profitability("2026-09")
    assert prof.gross_margin_percent.status == MetricStatus.ZERO_DENOMINATOR
    assert prof.gross_margin_percent.value is None

    rec = svc.calculate_receivables("2026-09")
    assert rec.dso.status == MetricStatus.ZERO_DENOMINATOR
    assert rec.dso.value is None


def test_edge_case_zero_cogs_denominator():
    """Edge Case: When COGS is 0, DPO and DIO must explicitly return ZERO_DENOMINATOR."""
    company = Company(company_code="1000", company_name="Zero COGS Corp", currency="USD")
    engine = FinancialEngine(
        company=company,
        customers=[],
        vendors=[],
        products=[],
        account_mappings=[],
        journal_entries=[],
        ar_items=[],
        ap_items=[],
    )
    svc = MetricService(engine=engine)

    pay = svc.calculate_payables("2026-09")
    assert pay.dpo.status == MetricStatus.ZERO_DENOMINATOR
    assert pay.dpo.value is None

    inv = svc.calculate_inventory("2026-09")
    assert inv.dio.status == MetricStatus.ZERO_DENOMINATOR
    assert inv.dio.value is None


def test_get_metric_by_name(metric_service: MetricService):
    dso = metric_service.get_metric_by_name("dso", "2026-09")
    assert dso.metric_name == "dso"
    assert dso.value is not None

    gm = metric_service.get_metric_by_name("gross_margin", "2026-09")
    assert gm.metric_name == "gross_margin_percent"
    assert gm.value is not None

    unknown = metric_service.get_metric_by_name("non_existent_metric", "2026-09")
    assert unknown.status == MetricStatus.NOT_APPLICABLE
    assert unknown.value is None


def test_calculate_cash_conversion_cycle(metric_service: MetricService):
    """Verifies CCC = DSO + DIO - DPO = 60.1 + 89.6 - 60.2 = 89.5 days."""
    ccc = metric_service.calculate_ccc("2026-09")
    assert ccc.metric_name == "ccc"
    assert ccc.value == 89.5
    assert ccc.formatted_value == "89.5 days"
    assert ccc.status == MetricStatus.CALCULATED
    assert ccc.comparison is not None
    assert ccc.comparison.trend is not None

    # Via get_metric_by_name
    ccc_slug = metric_service.get_metric_by_name("ccc", "2026-09")
    assert ccc_slug.value == 89.5

    # Via get_financial_summary
    summary = metric_service.get_financial_summary("2026-09")
    assert summary.ccc is not None
    assert summary.ccc.value == 89.5
