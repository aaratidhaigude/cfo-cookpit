"""Tests for the Mock Financial Adapter."""

from finsight.adapters.mock_adapter import MockFinancialAdapter


def test_mock_adapter_entity_presence(mock_adapter: MockFinancialAdapter):
    company = mock_adapter.get_company()
    assert company is not None
    assert company.company_code == "1000"

    customers = mock_adapter.get_customers()
    assert len(customers) >= 8

    vendors = mock_adapter.get_vendors()
    assert len(vendors) >= 6

    products = mock_adapter.get_products()
    assert len(products) >= 5

    mappings = mock_adapter.get_account_mappings()
    assert len(mappings) >= 15

    journal_entries = mock_adapter.get_journal_entries()
    assert len(journal_entries) > 200

    ar_items = mock_adapter.get_ar_items()
    assert len(ar_items) >= 90

    ap_items = mock_adapter.get_ap_items()
    assert len(ap_items) >= 60


def test_mock_adapter_filtering_by_period(mock_adapter: MockFinancialAdapter):
    entries_sep = mock_adapter.get_journal_entries(period="2026-09")
    assert len(entries_sep) > 0
    assert all(e.fiscal_year == 2026 and e.fiscal_period == 9 for e in entries_sep)


def test_mock_adapter_raw_dataset(mock_adapter: MockFinancialAdapter):
    raw = mock_adapter.get_raw_dataset()
    assert "company" in raw
    assert "customers" in raw
    assert "vendors" in raw
    assert "products" in raw
    assert "journal_entries" in raw
    assert "ar_items" in raw
    assert "ap_items" in raw
    assert raw["meta"]["seed"] == 42
