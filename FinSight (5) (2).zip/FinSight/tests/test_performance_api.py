"""Integration tests for Sprint 9: Performance & Driver Intelligence REST API Endpoints."""

import pytest
from starlette.testclient import TestClient

from finsight.api.app import app


@pytest.fixture(scope="module")
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


# -----------------------------------------------------------------------------
# 1. Performance Summary Endpoints
# -----------------------------------------------------------------------------

def test_api_get_performance_summary(client):
    """GET /api/performance returns executive cockpit payload."""
    resp = client.get("/api/performance?period=2026-09")
    assert resp.status_code == 200
    data = resp.json()

    assert data["period"] == "2026-09"
    assert data["comparison_period"] == "2026-08"
    assert data["revenue"] == pytest.approx(1490000.0, abs=10.0)
    assert data["gross_margin_pct"] == pytest.approx(40.28, abs=0.1)
    assert data["gross_profit"] == pytest.approx(600140.0, abs=10.0)
    assert data["ccc"] == pytest.approx(89.5, abs=0.5)
    assert "what_changed" in data
    assert "default_driver" in data
    assert "top_customer_drivers" in data
    assert "top_product_drivers" in data


def test_api_get_performance_summary_alias(client):
    """GET /api/performance/summary is an alias for /api/performance."""
    resp = client.get("/api/performance/summary?period=2026-09")
    assert resp.status_code == 200
    data = resp.json()
    assert data["period"] == "2026-09"
    assert data["revenue"] == pytest.approx(1490000.0, abs=10.0)


# -----------------------------------------------------------------------------
# 2. What Changed Endpoints
# -----------------------------------------------------------------------------

def test_api_get_what_changed_all(client):
    """GET /api/performance/what-changed with only_material=false returns all tracked metrics."""
    resp = client.get("/api/performance/what-changed?period=2026-09&only_material=false")
    assert resp.status_code == 200
    items = resp.json()
    assert isinstance(items, list)
    assert len(items) >= 12

    metric_names = [it["metric_name"] for it in items]
    assert "gross_margin_percent" in metric_names
    assert "revenue" in metric_names
    assert "dso" in metric_names
    assert "accounts_receivable" in metric_names


def test_api_get_what_changed_material_only(client):
    """GET /api/performance/what-changed with default only_material=true filters to material items."""
    resp = client.get("/api/performance/what-changed?period=2026-09&only_material=true")
    assert resp.status_code == 200
    items = resp.json()
    assert isinstance(items, list)
    assert all(it["is_material"] is True for it in items)

    # Gross margin drop (-1.90 pp) must be flagged material
    gm = next((it for it in items if it["metric_name"] == "gross_margin_percent"), None)
    assert gm is not None
    assert gm["is_material"] is True


# -----------------------------------------------------------------------------
# 3. Metric Drivers Decomposition Endpoints
# -----------------------------------------------------------------------------

def test_api_get_metric_drivers_gross_margin(client):
    """GET /api/performance/drivers?metric=gross_margin_percent returns causal decomposition."""
    resp = client.get("/api/performance/drivers?metric=gross_margin_percent&period=2026-09")
    assert resp.status_code == 200
    data = resp.json()

    assert data["metric_name"] == "gross_margin_percent"
    assert data["current_value"] == pytest.approx(40.28, abs=0.1)
    assert "primary_driver" in data
    assert len(data["primary_driver"]) > 0
    assert len(data["candidate_drivers"]) > 0
    assert len(data["customer_contributors"]) > 0
    assert len(data["product_contributors"]) > 0
    assert len(data["evidence"]) > 0

    # Apex Retail should be in customer contributors
    assert any("Apex" in c["entity_name"] for c in data["customer_contributors"])


def test_api_get_metric_drivers_revenue(client):
    """GET /api/performance/drivers?metric=revenue."""
    resp = client.get("/api/performance/drivers?metric=revenue&period=2026-09")
    assert resp.status_code == 200
    data = resp.json()
    assert data["metric_name"] == "revenue"
    assert data["current_value"] == pytest.approx(1490000.0, abs=10.0)


def test_api_get_metric_drivers_working_capital(client):
    """GET /api/performance/drivers?metric=net_working_capital."""
    resp = client.get("/api/performance/drivers?metric=net_working_capital&period=2026-09")
    assert resp.status_code == 200
    data = resp.json()
    assert data["metric_name"] == "net_working_capital"
    assert len(data["candidate_drivers"]) >= 2


def test_api_get_metric_drivers_dso(client):
    """GET /api/performance/drivers?metric=dso."""
    resp = client.get("/api/performance/drivers?metric=dso&period=2026-09")
    assert resp.status_code == 200
    data = resp.json()
    assert data["metric_name"] == "dso"
    assert data["current_value"] == pytest.approx(60.1, abs=0.5)


def test_api_get_metric_drivers_cash(client):
    """GET /api/performance/drivers?metric=cash_position."""
    resp = client.get("/api/performance/drivers?metric=cash_position&period=2026-09")
    assert resp.status_code == 200
    data = resp.json()
    assert data["metric_name"] == "cash_position"
    assert data["current_value"] == pytest.approx(813750.0, abs=1.0)


# -----------------------------------------------------------------------------
# 4. Customer Drivers Attribution Endpoints
# -----------------------------------------------------------------------------

def test_api_get_customer_drivers(client):
    """GET /api/performance/customers returns customer contribution breakdown."""
    resp = client.get("/api/performance/customers?period=2026-09&metric=gross_profit")
    assert resp.status_code == 200
    customers = resp.json()
    assert isinstance(customers, list)
    assert len(customers) >= 3

    apex = next((c for c in customers if "Apex" in c["entity_name"]), None)
    assert apex is not None
    assert apex["change_amount"] < 0
    assert apex["gross_margin_pct"] == pytest.approx(24.0, abs=1.0)


def test_api_get_customer_drivers_overdue(client):
    """GET /api/performance/customers?metric=overdue_ar."""
    resp = client.get("/api/performance/customers?period=2026-09&metric=overdue_ar")
    assert resp.status_code == 200
    customers = resp.json()
    apex = next((c for c in customers if "Apex" in c["entity_name"]), None)
    assert apex is not None
    assert apex["current_value"] == pytest.approx(1044000.0, abs=1.0)


# -----------------------------------------------------------------------------
# 5. Product Drivers Attribution Endpoints
# -----------------------------------------------------------------------------

def test_api_get_product_drivers(client):
    """GET /api/performance/products returns product group margins and contributions."""
    resp = client.get("/api/performance/products?period=2026-09&metric=gross_profit")
    assert resp.status_code == 200
    products = resp.json()
    assert isinstance(products, list)
    assert len(products) >= 2

    hw = next((p for p in products if "Hardware" in p["entity_name"]), None)
    sw = next((p for p in products if "Software" in p["entity_name"]), None)
    assert hw is not None
    assert sw is not None
    assert hw["change_amount"] < 0
    assert sw["change_amount"] > 0
