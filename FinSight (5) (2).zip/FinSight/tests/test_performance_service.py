"""Unit and integration tests for Sprint 9: Performance & Driver Intelligence Service."""

import pytest

from finsight.models.metrics import MetricUnit, TrendDirection
from finsight.models.performance import (
    EntityContribution,
    MaterialityConfig,
    MetricDriverResponse,
    PerformanceSummaryResponse,
    WhatChangedItem,
)
from finsight.services.financial_intelligence_service import FinancialIntelligenceService
from finsight.services.performance_service import PerformanceService
from finsight.services.refresh_service import RefreshService


@pytest.fixture(scope="module")
def refresh_service():
    svc = RefreshService()
    svc.execute_refresh()
    return svc


@pytest.fixture(scope="module")
def intel_service(refresh_service):
    return FinancialIntelligenceService(
        engine=refresh_service.engine,
        metric_service=refresh_service.metric_service,
    )


@pytest.fixture(scope="module")
def performance_service(refresh_service, intel_service):
    return PerformanceService(
        engine=refresh_service.engine,
        metric_service=refresh_service.metric_service,
        intelligence_service=intel_service,
    )


# -----------------------------------------------------------------------------
# 1. Period-over-Period "What Changed" Engine Tests
# -----------------------------------------------------------------------------

def test_what_changed_default_period(performance_service):
    """Verifies that What Changed returns all tracked metrics for 2026-09 vs 2026-08."""
    changes = performance_service.get_what_changed(period="2026-09", only_material=False)
    assert len(changes) >= 12

    metric_names = [item.metric_name for item in changes]
    expected_metrics = [
        "revenue",
        "gross_margin_percent",
        "gross_profit",
        "cogs",
        "accounts_receivable",
        "overdue_ar",
        "accounts_payable",
        "inventory_value",
        "dso",
        "dio",
        "dpo",
        "cash_conversion_cycle",
        "cash_position",
        "net_working_capital",
    ]
    for expected in expected_metrics:
        assert expected in metric_names, f"Expected {expected} in What Changed results"


def test_what_changed_materiality_filter(performance_service):
    """Verifies that only_material=True filters to items meeting materiality thresholds."""
    all_changes = performance_service.get_what_changed(period="2026-09", only_material=False)
    material_changes = performance_service.get_what_changed(period="2026-09", only_material=True)

    assert len(material_changes) < len(all_changes)
    assert all(item.is_material for item in material_changes)

    # Gross margin dropped from 42.18% to 40.28% (-1.90 pp), exceeding the 1.0 pp threshold
    gm_change = next((c for c in material_changes if c.metric_name == "gross_margin_percent"), None)
    assert gm_change is not None
    assert gm_change.is_material is True
    assert "pp" in gm_change.materiality_reason


def test_what_changed_custom_materiality_config(performance_service):
    """Verifies that custom materiality thresholds adjust materiality classifications."""
    # Stricter config: 5.0 pp margin threshold, $500k currency threshold
    strict_config = MaterialityConfig(
        currency_abs_threshold=500000.0,
        currency_pct_threshold=50.0,
        margin_pp_threshold=5.0,
        days_abs_threshold=20.0,
    )
    strict_materials = performance_service.get_what_changed(
        period="2026-09", only_material=True, config=strict_config
    )

    # Lenient config: 0.1 pp margin threshold, $10k currency threshold
    lenient_config = MaterialityConfig(
        currency_abs_threshold=10000.0,
        currency_pct_threshold=1.0,
        margin_pp_threshold=0.1,
        days_abs_threshold=1.0,
    )
    lenient_materials = performance_service.get_what_changed(
        period="2026-09", only_material=True, config=lenient_config
    )

    assert len(strict_materials) < len(lenient_materials)


def test_what_changed_first_period(performance_service):
    """Verifies behavior when analyzing the earliest period with no prior comparison data in ledger."""
    changes = performance_service.get_what_changed(period="2025-10", only_material=False)
    assert len(changes) > 0
    for item in changes:
        assert item.previous_value == 0.0
        assert item.previous_period == "2025-09"


def test_what_changed_mathematical_consistency(performance_service):
    """Verifies mathematical consistency of change amounts and percentages."""
    changes = performance_service.get_what_changed(period="2026-09", only_material=False)
    for item in changes:
        expected_abs = round(item.current_value - item.previous_value, 2)
        assert abs(item.absolute_change - expected_abs) < 0.05
        if item.previous_value != 0:
            expected_pct = round((item.absolute_change / abs(item.previous_value)) * 100, 2)
            assert item.percentage_change is not None
            assert abs(item.percentage_change - expected_pct) < 0.1


# -----------------------------------------------------------------------------
# 2. Metric Driver Decomposition Tests
# -----------------------------------------------------------------------------

def test_driver_gross_margin_decomposition(performance_service):
    """Verifies causal driver decomposition of Gross Margin drop."""
    driver_res = performance_service.get_metric_drivers("gross_margin_percent", period="2026-09")
    assert isinstance(driver_res, MetricDriverResponse)
    assert driver_res.metric_name == "gross_margin_percent"
    assert driver_res.current_value == pytest.approx(40.28, rel=1e-2)
    assert driver_res.previous_value == pytest.approx(42.18, rel=1e-2)
    assert driver_res.absolute_change < 0  # compressed margin

    # Primary driver must be explainable
    assert len(driver_res.primary_driver) > 0
    assert len(driver_res.candidate_drivers) >= 2

    # Evidence items must be traceable
    assert len(driver_res.evidence) >= 2
    assert any("HARDWARE" in ev.source_id or "SOFTWARE" in ev.source_id for ev in driver_res.evidence)

    # Customer attribution: Apex Retail Group should be identified as diluting margin
    apex = next((c for c in driver_res.customer_contributors if "Apex" in c.entity_name), None)
    assert apex is not None
    assert apex.gross_margin_pct < apex.previous_gross_margin_pct

    # Product attribution: Hardware margin compression
    hw = next((p for p in driver_res.product_contributors if "Hardware" in p.entity_name), None)
    assert hw is not None
    assert hw.gross_margin_pct < hw.previous_gross_margin_pct


def test_driver_gross_profit_decomposition(performance_service):
    """Verifies that Gross Profit drop reconciles mathematically with customer and product contributions."""
    gp_res = performance_service.get_metric_drivers("gross_profit", period="2026-09")
    assert gp_res.current_value == pytest.approx(600140.0, abs=10.0)
    assert gp_res.previous_value == pytest.approx(622400.0, abs=10.0)
    total_gp_delta = gp_res.absolute_change  # -22,260.0

    # Verify Customer GP contributions sum to the total portfolio GP change
    customer_gp_sum = sum(c.change_amount for c in gp_res.customer_contributors)
    assert customer_gp_sum == pytest.approx(total_gp_delta, abs=1.0)

    # Verify Product GP contributions sum to the total portfolio GP change
    product_gp_sum = sum(p.change_amount for p in gp_res.product_contributors)
    assert product_gp_sum == pytest.approx(total_gp_delta, abs=1.0)


def test_driver_revenue_decomposition(performance_service):
    """Verifies Revenue driver decomposition."""
    rev_res = performance_service.get_metric_drivers("revenue", period="2026-09")
    assert rev_res.current_value == pytest.approx(1490000.0, abs=10.0)
    assert len(rev_res.customer_contributors) > 0
    assert len(rev_res.product_contributors) > 0
    assert any("Apex" in c.entity_name for c in rev_res.customer_contributors)


def test_driver_cogs_decomposition(performance_service):
    """Verifies COGS driver decomposition."""
    cogs_res = performance_service.get_metric_drivers("cogs", period="2026-09")
    assert cogs_res.current_value == pytest.approx(889860.0, abs=10.0)
    assert len(cogs_res.product_contributors) > 0
    hw = next((p for p in cogs_res.product_contributors if "Hardware" in p.entity_name), None)
    assert hw is not None
    assert hw.change_amount > 0  # Hardware COGS rose significantly


def test_driver_working_capital_decomposition(performance_service):
    """Verifies Net Working Capital driver decomposition."""
    nwc_res = performance_service.get_metric_drivers("net_working_capital", period="2026-09")
    assert nwc_res.metric_name == "net_working_capital"
    assert len(nwc_res.candidate_drivers) >= 2  # Asset buildup & Liability influx
    driver_names = [cd.name for cd in nwc_res.candidate_drivers]
    assert any("Assets" in name for name in driver_names)
    assert any("Liabilities" in name for name in driver_names)


def test_driver_cash_decomposition(performance_service):
    """Verifies Cash position driver decomposition."""
    cash_res = performance_service.get_metric_drivers("cash_position", period="2026-09")
    assert cash_res.current_value == pytest.approx(813750.0, abs=1.0)
    assert len(cash_res.evidence) >= 1
    assert any("INV-AR" in ev.source_id or "INV-AP" in ev.source_id for ev in cash_res.evidence)


def test_driver_dso_decomposition(performance_service):
    """Verifies DSO driver decomposition."""
    dso_res = performance_service.get_metric_drivers("dso", period="2026-09")
    assert dso_res.current_value == pytest.approx(60.1, abs=0.5)
    assert len(dso_res.customer_contributors) > 0
    assert any(c.current_value > 0 for c in dso_res.customer_contributors)


def test_driver_dio_decomposition(performance_service):
    """Verifies DIO driver decomposition."""
    dio_res = performance_service.get_metric_drivers("dio", period="2026-09")
    assert dio_res.current_value == pytest.approx(89.6, abs=0.5)
    assert len(dio_res.candidate_drivers) >= 2


def test_driver_dpo_decomposition(performance_service):
    """Verifies DPO driver decomposition."""
    dpo_res = performance_service.get_metric_drivers("dpo", period="2026-09")
    assert dpo_res.current_value == pytest.approx(60.2, abs=0.5)


def test_driver_ccc_decomposition(performance_service):
    """Verifies CCC driver decomposition."""
    ccc_res = performance_service.get_metric_drivers("cash_conversion_cycle", period="2026-09")
    assert ccc_res.current_value == pytest.approx(89.5, abs=0.5)
    factors = [cd.name for cd in ccc_res.candidate_drivers]
    assert any("DSO" in f for f in factors)
    assert any("DIO" in f for f in factors)
    assert any("DPO" in f for f in factors)


def test_driver_generic_or_unknown_metric(performance_service):
    """Verifies safe graceful handling for unrecognized or non-standard metric name."""
    res = performance_service.get_metric_drivers("unknown_custom_metric", period="2026-09")
    assert isinstance(res, MetricDriverResponse)
    assert res.metric_name == "unknown_custom_metric"
    assert res.current_value == 0.0


# -----------------------------------------------------------------------------
# 3. Customer and Product Drivers Segment Attribution Tests
# -----------------------------------------------------------------------------

def test_get_customer_drivers_gross_profit(performance_service):
    """Verifies customer profitability and margin dilution attribution."""
    customers = performance_service.get_customer_drivers(period="2026-09", metric="gross_profit")
    assert len(customers) >= 3

    # Apex Retail Group drove the largest gross profit contraction
    apex = next((c for c in customers if "Apex" in c.entity_name), None)
    assert apex is not None
    assert apex.change_amount < 0
    assert apex.gross_margin_pct < apex.previous_gross_margin_pct
    assert apex.contribution_share_pct is not None


def test_get_customer_drivers_overdue_ar(performance_service):
    """Verifies customer overdue AR concentration attribution."""
    customers = performance_service.get_customer_drivers(period="2026-09", metric="overdue_ar")
    assert len(customers) >= 1

    # Overdue AR of $1,044,000 matches authoritative GL / subledger truth
    apex = next((c for c in customers if "Apex" in c.entity_name), None)
    assert apex is not None
    assert apex.current_value == pytest.approx(1044000.0, abs=1.0)


def test_get_product_drivers_gross_profit(performance_service):
    """Verifies product group margin and profit attribution."""
    products = performance_service.get_product_drivers(period="2026-09", metric="gross_profit")
    assert len(products) >= 2

    # Hardware compressed margin and drove the profit decline
    hw = next((p for p in products if "Hardware" in p.entity_name), None)
    assert hw is not None
    assert hw.change_amount < 0
    assert hw.gross_margin_pct < hw.previous_gross_margin_pct

    # Software maintained healthy margin
    sw = next((p for p in products if "Software" in p.entity_name), None)
    assert sw is not None
    assert sw.change_amount > 0


def test_get_product_drivers_revenue(performance_service):
    """Verifies product group revenue attribution."""
    products = performance_service.get_product_drivers(period="2026-09", metric="revenue")
    assert len(products) >= 2
    total_rev = sum(p.current_value for p in products)
    assert total_rev == pytest.approx(1490000.0, abs=10.0)


# -----------------------------------------------------------------------------
# 4. Performance Summary Cockpit Tests
# -----------------------------------------------------------------------------

def test_get_performance_summary(performance_service):
    """Verifies the complete executive performance summary package."""
    summary = performance_service.get_performance_summary(period="2026-09")
    assert isinstance(summary, PerformanceSummaryResponse)
    assert summary.period == "2026-09"
    assert summary.comparison_period == "2026-08"

    # Executive Core Financials
    assert summary.revenue == pytest.approx(1490000.0, abs=10.0)
    assert summary.gross_margin_pct == pytest.approx(40.28, abs=0.1)
    assert summary.gross_profit == pytest.approx(600140.0, abs=10.0)
    assert summary.cogs == pytest.approx(889860.0, abs=10.0)
    assert summary.ccc == pytest.approx(89.5, abs=0.5)

    # Material movements
    assert len(summary.what_changed) > 0
    assert any(c.metric_name == "gross_margin_percent" for c in summary.what_changed)

    # Top drivers
    assert summary.default_driver is not None
    assert summary.default_driver.metric_name == "gross_margin_percent"

    # Highlights
    assert len(summary.top_customer_drivers) > 0
    assert len(summary.top_product_drivers) > 0
