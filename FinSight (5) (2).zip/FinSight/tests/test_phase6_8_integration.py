"""End-to-End Integration tests for FinSight Phases 6-8:
Control Intelligence + Case Remediation + Cash Outlook.
"""

from datetime import date
import pytest
from starlette.testclient import TestClient

from finsight.api.app import app
from finsight.models.canonical import FinancialConcept
from finsight.models.cases import CaseStatus, RemediationAction
from finsight.services.ai_tools_service import AIToolsService
from finsight.services.cases_service import CasesService
from finsight.services.cash_forecast_service import CashForecastService
from finsight.services.control_assessment_service import ControlAssessmentService
from finsight.services.investigation_service import InvestigationService
from finsight.services.knowledge_retriever import LocalKnowledgeRetriever
from finsight.services.refresh_service import RefreshService


@pytest.fixture
def refresh_service():
    svc = RefreshService()
    svc.execute_refresh()
    return svc


@pytest.fixture
def knowledge_retriever():
    return LocalKnowledgeRetriever()


@pytest.fixture
def client():
    c = TestClient(app)
    resp = c.post("/api/auth/login", json={"username": "admin", "password": "demo123"})
    if resp.status_code == 200:
        c.headers["Authorization"] = f"Bearer {resp.json()['token']}"
    return c


# -----------------------------------------------------------------------------
# End-to-End Flow 1: Apex Overdue AR -> Attention -> Investigation -> Policy -> Control -> Case -> Remediation
# -----------------------------------------------------------------------------

def test_e2e_flow_apex_overdue_control_to_case_remediation(refresh_service, knowledge_retriever):
    """Traces complete workflow from financial fact to closed remediation case."""
    # 1. Deterministic Financial Fact
    ref_date = date(2026, 9, 30)
    ar_summary = refresh_service.engine.get_ar_summary(ref_date)
    assert ar_summary["total_overdue_ar"] == 1044000.00
    apex_item = next(c for c in ar_summary["top_overdue_customers"] if c["entity_name"] == "Apex Retail Group")
    assert apex_item["amount"] == 1044000.00

    # 2. Knowledge Policy Retrieval
    policy = knowledge_retriever.get_document("COLL-POL-001")
    assert policy is not None
    assert policy.metadata["escalation_threshold_usd"] == 500000.0

    # 3. Control Assessment
    ctrl_svc = ControlAssessmentService(refresh_service.engine, refresh_service.metric_service, knowledge_retriever)
    assessment = ctrl_svc.assess_control("CONTROL-COLL-001")
    assert assessment.status.value == "BREACH"
    assert assessment.financial_exposure == 1044000.00
    assert assessment.case_required is True

    # 4. Spawn Remediation Case from Assessment
    cases_svc = CasesService()
    case = cases_svc.create_case_from_assessment(
        assessment=assessment,
        assigned_owner="Senior Collections Manager",
        due_date="2026-10-10",
    )
    assert case.status == CaseStatus.OPEN
    assert case.control_id == "CONTROL-COLL-001"
    assert case.financial_exposure == 1044000.00
    assert len(case.remediation_plan) >= 1
    assert len(case.audit_notes) >= 3

    # 5. Add Remediation Action
    new_action = RemediationAction(
        action="Freeze shipments to Apex Distribution Centers via ERP",
        owner="Logistics Lead",
        due_date="2026-10-02",
        status="COMPLETED",
        evidence="Hold flag set in ERP sales order interface",
    )
    case_updated = cases_svc.add_remediation_action(case.id, new_action, actor="Operations Controller")
    assert any(a.action == new_action.action for a in case_updated.remediation_plan)

    # 6. Execute Non-Silent Case Closure
    with pytest.raises(ValueError):
        # Attempt silent closure
        from finsight.models.cases import UpdateCaseRequest
        cases_svc.update_case(case.id, UpdateCaseRequest(status=CaseStatus.CLOSED))

    # Formal closure with evidence
    from finsight.models.cases import CloseCaseRequest
    closed_case = cases_svc.close_case(
        case.id,
        CloseCaseRequest(
            resolution_summary="Apex signed $1.044M debt restructuring agreement and paid $500K immediate deposit.",
            resolution_evidence="Bank receipt #BK-88402 & Restructuring Contract DocRef #LGL-2026-094",
            reviewer="VP Commercial Finance",
        ),
        actor="Collections Lead",
    )
    assert closed_case.status == CaseStatus.CLOSED
    assert closed_case.resolution_summary is not None
    assert closed_case.resolution_evidence is not None

    # Verify audit trail
    assert any(e.event_type == "CLOSED" for e in closed_case.audit_notes)


# -----------------------------------------------------------------------------
# End-to-End Flow 2: Cash Pressure -> Cash Outlook -> Liquidity Policy -> Control Assessment
# -----------------------------------------------------------------------------

def test_e2e_flow_cash_outlook_to_liquidity_control(refresh_service, knowledge_retriever):
    """Traces workflow from maturing payables squeeze into liquidity forecast and control evaluation."""
    # 1. Financial Engine AP Obligations
    sched = refresh_service.engine.get_upcoming_payables_schedule(horizon_days=7)
    assert sched["total_upcoming_amount"] == 1377000.00
    ref_date = refresh_service.metric_service._get_period_end_date("2026-09")
    cash_bal = refresh_service.engine.calculate_balance_as_of(
        FinancialConcept.CASH,
        ref_date,
    )
    assert cash_bal == 813750.00

    # 2. Cash Forecast Service Evaluation
    fc_svc = CashForecastService(refresh_service.engine, refresh_service.metric_service)
    forecast = fc_svc.generate_forecast(horizon_days=30, scenario="BASE")
    assert forecast.starting_cash == 813750.00
    assert forecast.liquidity_indicators["lcr_7d"] == 0.59
    assert forecast.liquidity_indicators["policy_breach_detected"] is True

    # 3. Control Assessment Service
    ctrl_svc = ControlAssessmentService(refresh_service.engine, refresh_service.metric_service, knowledge_retriever)
    liq_assessment = ctrl_svc.assess_control("CONTROL-LIQ-001")
    assert liq_assessment.status.value == "BREACH"
    assert liq_assessment.policy_document_id == "LIQ-CTRL-001"
    assert liq_assessment.observed_value == 0.59
    assert liq_assessment.threshold_value == 1.0


# -----------------------------------------------------------------------------
# End-to-End Flow 3: AI Investigation Tool Dispatch for Cash Outlook
# -----------------------------------------------------------------------------

def test_e2e_ai_investigation_cash_outlook_tool(client):
    """Verifies that an AI investigation query regarding cash outlook dispatches get_cash_forecast."""
    payload = {
        "question": "What is our cash outlook and 30-day liquidity forecast under the base scenario?",
        "period": "2026-09",
    }
    resp = client.post("/api/investigate", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "answer" in data
    assert len(data["answer"]) > 50
    assert "evidence" in data

    # Verify tool calls executed in investigation plan
    tools_called = [step["tool_name"] for step in data["steps"]]
    assert "get_cash_forecast" in tools_called
