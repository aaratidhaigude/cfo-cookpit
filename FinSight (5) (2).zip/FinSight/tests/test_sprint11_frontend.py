"""
Tests for Sprint 11 Executive UX, Static Module Serving, and Frontend Integrity.
"""

import pytest
from starlette.testclient import TestClient
from finsight.api.app import app


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def test_index_html_has_login_and_app_containers(client):
    response = client.get("/")
    assert response.status_code == 200
    html = response.text
    assert 'id="login-container"' in html
    assert 'id="app-container"' in html
    assert 'src="/js/app.js"' in html


def test_static_javascript_modules_served(client):
    modules = [
        "/js/app.js",
        "/js/services/auth.js",
        "/js/services/api.js",
        "/js/pages/login.js",
        "/js/pages/overview.js",
        "/js/pages/financials.js",
        "/js/pages/performance.js",
        "/js/pages/investigate.js",
        "/js/pages/actions.js",
        "/js/components/sidebar.js",
        "/js/components/header.js",
        "/js/components/userProfileMenu.js",
        "/js/utils/drawerHistory.js",
    ]
    for mod in modules:
        res = client.get(mod)
        assert res.status_code == 200, f"Module {mod} failed to load with status {res.status_code}"
        assert len(res.text) > 50, f"Module {mod} is suspiciously short"


def test_static_css_contains_sprint11_styles(client):
    res = client.get("/css/main.css")
    assert res.status_code == 200
    css = res.text
    assert ".login-wrapper" in css
    assert ".user-profile-menu-container" in css
    assert ".metric-trust-pill" in css
    assert ".lineage-modal-overlay" in css


def test_sidebar_module_has_five_primary_destinations(client):
    res = client.get("/js/components/sidebar.js")
    assert res.status_code == 200
    content = res.text
    assert "nav-overview" in content
    assert "nav-financials" in content
    assert "nav-performance" in content
    assert "nav-investigate" in content
    assert "nav-actions" in content
    # Ensure removed items from Sprint 10 are not in primary nav
    assert 'id="nav-money"' not in content
    assert 'id="nav-dataStatus"' not in content


def test_investigate_module_has_seven_structured_blocks(client):
    res = client.get("/js/pages/investigate.js")
    assert res.status_code == 200
    content = res.text
    assert "FINDING" in content
    assert "PRIMARY DRIVER" in content
    assert "FINANCIAL IMPACT" in content
    assert "SUPPORTING DATA" in content
    assert "POLICY / CONTROL CONTEXT" in content
    assert "RECOMMENDED FOLLOW-UP" in content
    assert "CREATE ACTION" in content


def test_actions_module_has_three_lifecycle_tabs(client):
    res = client.get("/js/pages/actions.js")
    assert res.status_code == 200
    content = res.text
    assert 'data-tab="OPEN"' in content
    assert 'data-tab="IN_REVIEW"' in content
    assert 'data-tab="RESOLVED"' in content
    assert "Open Actions" in content
    assert "In Review" in content
    assert "Resolved" in content


def test_drawer_history_module_and_integration(client):
    """Verifies that drawerHistory.js is properly structured and integrated into drawers."""
    history_res = client.get("/js/utils/drawerHistory.js")
    assert history_res.status_code == 200
    assert "pushDrawerHistory" in history_res.text
    assert "popDrawerHistory" in history_res.text
    assert "popstate" in history_res.text

    # Verify drawers integrate drawer history
    for drawer_path in [
        "/js/components/trustDrawer.js",
        "/js/components/financialInspectDrawer.js",
        "/js/components/investigateDrawer.js",
        "/js/components/evidenceDrawer.js",
        "/js/pages/financials.js",
    ]:
        res = client.get(drawer_path)
        assert res.status_code == 200
        assert "pushDrawerHistory" in res.text, f"{drawer_path} missing pushDrawerHistory"
        assert "popDrawerHistory" in res.text, f"{drawer_path} missing popDrawerHistory"


def test_sidebar_period_dropdown_optgroups(client):
    """Verifies that the sidebar contains fiscal year grouping logic for periods."""
    res = client.get("/js/components/sidebar.js")
    assert res.status_code == 200
    content = res.text
    assert "renderPeriodOptions" in content
    assert "optgroup" in content
    assert "MONTH_NAMES" in content

