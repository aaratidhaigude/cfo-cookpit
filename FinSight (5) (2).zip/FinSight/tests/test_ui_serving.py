"""Tests for static UI asset serving and frontend-backend endpoint integration."""

from starlette.testclient import TestClient


def test_serve_index_html(test_client: TestClient):
    """Verifies that the root path serves the FinSight executive web interface."""
    resp = test_client.get("/")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    assert "FinSight" in resp.text
    assert "Financial Intelligence" in resp.text
    assert "Control" in resp.text
    assert "id=\"app-sidebar\"" in resp.text
    assert "id=\"evidence-drawer\"" in resp.text




def test_serve_css_and_js_assets(test_client: TestClient):
    """Verifies that modern ES modules and CSS assets are served correctly."""
    css_resp = test_client.get("/css/main.css")
    assert css_resp.status_code == 200
    assert "text/css" in css_resp.headers["content-type"]
    assert "--color-navy-dark" in css_resp.text

    app_js_resp = test_client.get("/js/app.js")
    assert app_js_resp.status_code == 200
    assert "FinSightApp" in app_js_resp.text

    api_js_resp = test_client.get("/js/services/api.js")
    assert api_js_resp.status_code == 200
    assert "FinSightAPI" in api_js_resp.text


def test_api_routes_not_shadowed_by_static_mount(test_client: TestClient):
    """Verifies that /api routes take precedence and return JSON without interference from static files."""
    summary_resp = test_client.get("/api/summary")
    assert summary_resp.status_code == 200
    assert "application/json" in summary_resp.headers["content-type"]
    data = summary_resp.json()
    assert "cash_position" in data
    assert "dso" in data
    assert "ccc" in data

    cases_resp = test_client.get("/api/cases")
    assert cases_resp.status_code == 200
    assert isinstance(cases_resp.json(), list)
